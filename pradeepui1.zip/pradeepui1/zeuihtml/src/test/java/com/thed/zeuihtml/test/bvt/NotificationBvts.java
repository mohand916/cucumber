package com.thed.zeuihtml.test.bvt;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.thed.zeuihtml.BaseTest;
import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;
import com.thed.zeuihtml.ze.impl.zehtmlpages.HomePage;

public class NotificationBvts extends BaseTest {
	
	public NotificationBvts() {
		logger = Logger.getLogger(this.getClass());
	}

	@Test (enabled= testEnabled, priority=217)
	public void bvt145_addNewPhaseSystemAndViewNotificationAndApplyChanges() {
		logger.info("Executing bvt145...");
		altID = 145;
		
		//zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		String releaseName = "Release 1.0";
		String appName = "Test Repository";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		WebDriver temp = Driver.driver;
		WebDriver d = CommonUtil.getNewWebDriver();
		d.navigate().to(Config.getValue("ZE_URL"));
		Driver.driver = d;
		logger.info("Changed Control to Lead Window..");
		zeNavigator.doLogin(Config.getValue("ZE_LEAD_USERNAME"), Config.getValue("ZE_LEAD_PASSWORD"));
		
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		String phaseName = Config.getTCRPropValue("PHASE_4");
		String phaseDescription = phaseName + " description";
		Assert.assertTrue(zeNavigator.createPhase(releaseName, phaseName, phaseDescription),
				"Phase not created successfully.");
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.createNode(phaseName, Config.getTCRPropValue("NODE_7"), "description"),
				"Node not created successfully.");
		
		CommonUtil.normalWait(2000);
		d = Driver.driver;
		Driver.driver = temp;
		d.quit();
		logger.info("Changed Control to Manager Window..");
		Assert.assertTrue(zeNavigator.applyNotification("2"), "Notification Not Applied");
		HomePage.getInstance().waitForProgressBarToComplete();
		Assert.assertTrue(zeNavigator.verifyPhase(phaseName, phaseDescription),"Not able to verify Phase");
		logger.info("Verified Created Phase");
		phases.add(phaseName);
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		zeNavigator.verifyNode(phaseName, Config.getTCRPropValue("NODE_7"), "description");
		logger.info("Verified Created Node");
		
		isSuccess = true;
		logger.info("bvt145 is executed successfully.");
		
	}
	
	@Test (enabled= testEnabled, priority=218)
	public void bvt146_addNewTestcaseAndViewNotificationAndApplyChanges() {
		logger.info("Executing bvt146...");
		altID = 146;
		
		//zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		String releaseName = "Release 1.0";
		String appName = "Test Repository";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_4"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		
		WebDriver temp = Driver.driver;
		WebDriver d = CommonUtil.getNewWebDriver();
		d.navigate().to(Config.getValue("ZE_URL"));
		Driver.driver = d;
		logger.info("Changed Control to Lead Window..");
		zeNavigator.doLogin(Config.getValue("ZE_LEAD_USERNAME"), Config.getValue("ZE_LEAD_PASSWORD"));
		
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String testcaseId = zeNavigator.addDefaultTestcase(Config.getTCRPropValue("PHASE_4"));
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");
		
		CommonUtil.normalWait(2000);
		d = Driver.driver;
		Driver.driver = temp;
		d.quit();
		logger.info("Changed Control to Manager Window..");
		Assert.assertTrue(zeNavigator.applyNotification("1"), "Notification Not Applied");
		HomePage.getInstance().waitForProgressBarToComplete();
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.clickOnTestcase(testcaseId), "Not able to verify created testcase");
		zeNavigator.navigateBackToTestcaseList();
		logger.info("Verified Created Testcase");
		
		isSuccess = true;
		logger.info("bvt146 is executed successfully.");
	}
	
	@Test (enabled= testEnabled, priority=219)
	public void bvt189_createTopLevelReqNodeInGlobalTreeAndViewNotificationAndApplyChanges() {
		logger.info("Executing bvt189...");
		altID = 189;
		
		//zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		List<String> phases = new ArrayList<String>();
		phases.add("Project Requirements");
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		
		CommonUtil.normalWait(1000);
		WebDriver temp = Driver.driver;
		WebDriver d = CommonUtil.getNewWebDriver();
		d.navigate().to(Config.getValue("ZE_URL"));
		Driver.driver = d;
		logger.info("Changed Control to Lead Window..");
		zeNavigator.doLogin(Config.getValue("ZE_LEAD_USERNAME"), Config.getValue("ZE_LEAD_PASSWORD"));
		
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		
		Assert.assertTrue(zeNavigator.createNodeinReqGlobal("Project Requirements", Config.getReqPropValue("PHASE_4"), "description"));
		
		CommonUtil.normalWait(2000);
		d = Driver.driver;
		Driver.driver = temp;
		d.quit();
		logger.info("Changed Control to Manager Window..");
		Assert.assertTrue(zeNavigator.applyNotification("1"), "Notification Not Applied");
		HomePage.getInstance().waitForProgressBarToComplete();
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.verifyNodeinReqGlobal("Project Requirements", Config.getReqPropValue("PHASE_4"), "description"), "Not able to verify created node in global");
		logger.info("Verified Created Req Node in Global");
		
		isSuccess = true;
		logger.info("bvt189 is executed successfully.");
	}
	
	@Test (enabled= testEnabled, priority=220)
	public void bvt190_allocateSingleReqFromGlobalToReleaseLevelAndViewNotificationAndApplyChanges() {
		logger.info("Executing bvt190...");
		altID = 190;
		
		//zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		List<String> phases = new ArrayList<String>();
		phases.add(releaseName);
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		
		CommonUtil.normalWait(1000);
		WebDriver temp = Driver.driver;
		WebDriver d = CommonUtil.getNewWebDriver();
		d.navigate().to(Config.getValue("ZE_URL"));
		Driver.driver = d;
		logger.info("Changed Control to Lead Window..");
		zeNavigator.doLogin(Config.getValue("ZE_LEAD_USERNAME"), Config.getValue("ZE_LEAD_PASSWORD"));
		
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		List<String> phases1 = new ArrayList<String>();
		phases1.add("Project Requirements");
		phases1.add(Config.getReqPropValue("PHASE_4"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases1), "Not navigated to nodes.");
		
		String reqId = zeNavigator.addDefaultRequirement(Config.getReqPropValue("PHASE_4"));
		zeNavigator.allocateRequirement("Untitled requirement");
		
		CommonUtil.normalWait(2000);
		d = Driver.driver;
		Driver.driver = temp;
		d.quit();
		logger.info("Changed Control to Manager Window..");
		Assert.assertTrue(zeNavigator.applyNotification("1"), "Notification Not Applied");
		HomePage.getInstance().waitForProgressBarToComplete();
		phases.add(Config.getReqPropValue("PHASE_4"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		zeNavigator.verifyRequirement("Untitled requirement", null);
		zeNavigator.navigateBackToReqList();
		
		logger.info("Verified Allocated Requirement");
		
		isSuccess = true;
		logger.info("bvt190 is executed successfully.");
	}
	
//	@Test (enabled=true, priority=221)
	public void bvt191_mapRequirementToTestcaseAndViewNotificationAndApplyChanges() {
		logger.info("Executing bvt191...");
		altID = 191;
		
		//zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		List<String> phases = new ArrayList<String>();
		phases.add(releaseName);
		phases.add(Config.getReqPropValue("PHASE_4"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		
		CommonUtil.normalWait(1000);
		WebDriver temp = Driver.driver;
		WebDriver d = CommonUtil.getNewWebDriver();
		d.navigate().to(Config.getValue("ZE_URL"));
		Driver.driver = d;
		logger.info("Changed Control to Lead Window..");
		zeNavigator.doLogin(Config.getValue("ZE_LEAD_USERNAME"), Config.getValue("ZE_LEAD_PASSWORD"));
		
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		List<String> testcaseTreeNodes = new ArrayList<String>();
		testcaseTreeNodes.add(0, "Release 1.0");
		testcaseTreeNodes.add(1, Config.getTCRPropValue("PHASE_1"));
		testcaseTreeNodes.add(2, Config.getTCRPropValue("NODE_1"));
		testcaseTreeNodes.add(3, Config.getTCRPropValue("SUB_NODE_1"));
		
		Assert.assertTrue(zeNavigator.mapTestcaseToRequirement("Untitled requirement", testcaseTreeNodes, "Add attachment to testcase"), "Req not mapped to any Testcase");
		zeNavigator.navigateBackToReqList();
		
		CommonUtil.normalWait(2000);
		d = Driver.driver;
		Driver.driver = temp;
		d.quit();
		logger.info("Changed Control to Manager Window..");
		Assert.assertTrue(zeNavigator.applyNotification("1"), "Notification Not Applied");
		HomePage.getInstance().waitForProgressBarToComplete();
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		zeNavigator.verifyMapTestcaseToRequirement("Untitled requirement", "1");
		zeNavigator.navigateBackToReqList();
		
		logger.info("Verified Map");
		
		isSuccess = true;
		logger.info("bvt191 is executed successfully.");
	}
	
	@Test (enabled= testEnabled, priority=222)
	public void bvt185_addPhaseToCycleAndViewNotificationInTCEApp() {
		logger.info("Executing bvt185...");
		altID = 185;
		
		//zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		String releaseName = "Release 1.0";
		String appName = "Test Execution";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		List<String> phases = new ArrayList<String>();
		phases.add(releaseName);
		Assert.assertTrue(zeNavigator.navigateToNodesInTestExecution(phases), "Not navigated to nodes.");
		
		CommonUtil.normalWait(1000);
		WebDriver temp = Driver.driver;
		WebDriver d = CommonUtil.getNewWebDriver();
		d.navigate().to(Config.getValue("ZE_URL"));
		Driver.driver.manage().window().maximize();
		Driver.driver = d;
		logger.info("Changed Control to Lead Window..");
		zeNavigator.doLogin(Config.getValue("ZE_LEAD_USERNAME"), Config.getValue("ZE_LEAD_PASSWORD"));
		
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp("Test Planning");
		
		String startDate = CommonUtil.returnTodaysDate();
		String endDate = CommonUtil.returnFutureDateStartingTodaysDate(0, 5, 0);
		
		Assert.assertTrue(zeNavigator.createCycle(Config.getEASPropValue("CYCLE6_NAME"), null
				, null,startDate,endDate),  "Not created cycle successfully.");
		
		zeNavigator.addPhaseToCycle(Config.getEASPropValue("CYCLE6_NAME"), Config.getTCRPropValue("PHASE_1")
				, "anyone", true);
		
		CommonUtil.normalWait(2000);
		d = Driver.driver;
		Driver.driver = temp;
		d.quit();
		logger.info("Changed Control to Manager Window..");
		Assert.assertTrue(zeNavigator.applyNotification("2"), "Notification Not Applied");
		HomePage.getInstance().waitForProgressBarToComplete();
		phases.add(Config.getEASPropValue("CYCLE6_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesInTestExecution(phases), "Not navigated to nodes.");
		
		logger.info("Verified Created Cycle");
		
		isSuccess = true;
		logger.info("bvt185 is executed successfully.");
	}
	
	@Test (enabled= testEnabled, priority=223)
	public void bvt186_quickSearchAndAddTcToFFPAndViewNotificationInEASApp() {
		logger.info("Executing bvt186...");
		altID = 186;
		
		//zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		String releaseName = "Release 1.0";
		String appName = "Test Planning";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		CommonUtil.normalWait(1000);
		WebDriver temp = Driver.driver;
		WebDriver d = CommonUtil.getNewWebDriver();
		d.navigate().to(Config.getValue("ZE_URL"));
		Driver.driver = d;
		logger.info("Changed Control to Lead Window..");
		zeNavigator.doLogin(Config.getValue("ZE_LEAD_USERNAME"), Config.getValue("ZE_LEAD_PASSWORD"));
		
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		CommonUtil.normalWait(1000);
		Assert.assertTrue(zeNavigator.addFreeformPhaseToCycle(Config.getEASPropValue("CYCLE6_NAME")
				, Config.getEASPropValue("FREEFORM3_PHASE_NAME"), false)
				, "Failed to add Freeform phase to cycle Successfully");
		HomePage.getInstance().waitForProgressBarToComplete();
		//zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE6_NAME"), Config.getEASPropValue("FREEFORM3_PHASE_NAME"), false);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(Config.getEASPropValue("FREEFORM3_PHASE_NAME"));
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		List<String> expectedTestcases = new ArrayList<String>();
		expectedTestcases.add(Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"));
		
		zeNavigator.addTestcaseToFreeformNode("Quick", Config.getTCRPropValue("TESTCASE_WITHOUT_STEP_PRIORITY"), expectedTestcases, true, false, false);
		
		zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"), "Unassigned", true);
		
		CommonUtil.normalWait(2000);
		d = Driver.driver;
		Driver.driver = temp;
		d.quit();
		logger.info("Changed Control to Manager Window..");
		Assert.assertTrue(zeNavigator.applyNotification("1"), "Notification Not Applied");
		HomePage.getInstance().waitForProgressBarToComplete();
		Assert.assertTrue(zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE6_NAME"), Config.getEASPropValue("FREEFORM3_PHASE_NAME"), true), "FFP not found!");
		
		logger.info("Verified Created FFP");
		
		isSuccess = true;
		logger.info("bvt186 is executed successfully.");
	}
	
	@Test (enabled= testEnabled, priority=224)
	public void bvt187_ExecuteTestcaseAssignedToAnyoneAndViewNotificationInTCEAppAndApplyChanges() {
		logger.info("Executing bvt187...");
		altID = 187;
		
		//zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		String releaseName = "Release 1.0";
		String appName = "Test Execution";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		List<String> phases = new ArrayList<String>();
		phases.add(releaseName);
		phases.add(Config.getEASPropValue("CYCLE6_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesInTestExecution(phases), "Not navigated to nodes.");
		
		CommonUtil.normalWait(1000);
		WebDriver temp = Driver.driver;
		WebDriver d = CommonUtil.getNewWebDriver();
		d.navigate().to(Config.getValue("ZE_URL"));
		Driver.driver = d;
		Driver.driver.manage().window().maximize();
		logger.info("Changed Control to Lead Window..");
		zeNavigator.doLogin(Config.getValue("ZE_LEAD_USERNAME"), Config.getValue("ZE_LEAD_PASSWORD"));
		
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		CommonUtil.normalWait(1000);
		Assert.assertTrue(zeNavigator.navigateToNodesInTestExecution(phases), "Not navigated to nodes.");
		CommonUtil.normalWait(1000);
		Assert.assertTrue(zeNavigator.executeTestcaseInSelectedNodeAndVerify(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), "Pass"), "Failed to execute Test");
		
		CommonUtil.normalWait(2000);
		d = Driver.driver;
		Driver.driver = temp;
		d.quit();
		logger.info("Changed Control to Manager Window..");
		Assert.assertTrue(zeNavigator.applyNotification("1"), "Notification Not Applied");
		HomePage.getInstance().waitForProgressBarToComplete();
		//Assert.assertTrue(zeNavigator.navigateToNodesInTestExecution(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.verifyTestcaseExecutionStatus(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), "Pass"));
		
		logger.info("Verified Testcase Status");
		
		isSuccess = true;
		logger.info("bvt187 is executed successfully.");
	}
	
	@Test (enabled= testEnabled, priority=225)
	public void bvt188_ExecuteTeststepAssignedToAnyoneAndViewNotificationInTCEAppAndApplyChanges() {
		logger.info("Executing bvt188...");
		altID = 188;
		
		//zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		String releaseName = "Release 1.0";
		String appName = "Test Execution";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		List<String> phases = new ArrayList<String>();
		phases.add(releaseName);
		phases.add(Config.getEASPropValue("CYCLE6_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesInTestExecution(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.SelectTestcase(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP")), "Testcase not selected");
		zeNavigator.navigateBackToTestcaseList();
		
		CommonUtil.normalWait(1000);
		WebDriver temp = Driver.driver;
		WebDriver d = CommonUtil.getNewWebDriver();
		d.navigate().to(Config.getValue("ZE_URL"));
		Driver.driver = d;
		Driver.driver.manage().window().maximize();
		logger.info("Changed Control to Lead Window..");
		zeNavigator.doLogin(Config.getValue("ZE_LEAD_USERNAME"), Config.getValue("ZE_LEAD_PASSWORD"));
		
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		CommonUtil.normalWait(1000);
		Assert.assertTrue(zeNavigator.navigateToNodesInTestExecution(phases), "Not navigated to nodes.");
		CommonUtil.normalWait(1000);
		zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), "1", "Pass", true, false, null);

		CommonUtil.normalWait(2000);
		d = Driver.driver;
		Driver.driver = temp;
		d.quit();
		logger.info("Changed Control to Manager Window..");
		Assert.assertTrue(zeNavigator.applyNotification("1"), "Notification Not Applied");
		HomePage.getInstance().waitForProgressBarToComplete();
		Assert.assertTrue(zeNavigator.verifyTeststepExecutionStatus(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), "1", "Pass", true, false, null));
		
		logger.info("Verified Teststep Status");
		
		isSuccess = true;
		logger.info("bvt188 is executed successfully.");
	}
	
	@BeforeMethod
	public void beforeMethod() {
		isSuccess = false;
	}

	@AfterMethod
	public void afterMethod() {
		baseAfterMethod();
		if(!isSuccess){
			zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		}
	}
	
	@BeforeClass
	public void beforeClass() {
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
	}
	
	@AfterClass
	public void afterClass() {
		zeNavigator.logout();
	}

}
