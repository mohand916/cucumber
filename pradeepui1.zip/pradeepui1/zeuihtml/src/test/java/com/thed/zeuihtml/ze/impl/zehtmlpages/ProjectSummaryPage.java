package com.thed.zeuihtml.ze.impl.zehtmlpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;

public class ProjectSummaryPage {
	
	Logger logger;
	
	public ProjectSummaryPage(){
		logger = Logger.getLogger(this.getClass());
	}
	public static ProjectSummaryPage getInstance(){
		return PageFactory.initElements(Driver.driver, ProjectSummaryPage.class);
	}

	/******************************************************
	 * 	WEBELEMENTS
	 *****************************************************/
	
	@FindBy(xpath="//li//span[normalize-space(text())='Hi']/following-sibling::strong")
	private WebElement loggedInUserTitle;
	
	//@FindBy(xpath="//zui-project-left-nav//h4/div/span[@class='title']")
	@FindBy(xpath="//*[@id='projectDropDown']/span")
	private WebElement currentSelectedProject;
	
	@FindBy(xpath="//div[@class='zee-module1-wrapper summarybox-release']//span[text()='Releases']/preceding-sibling::span")
	private WebElement totalReleases;
	
	@FindBy(xpath="//div[@class='zee-module1-wrapper summarybox-inprogress']//span[text()='In-progress']/preceding-sibling::span")
	private WebElement totalInprogressReleases;
	
	@FindBy(xpath="//div[@class='zee-module1-wrapper summarybox-testcases']//span[text()='Test Cases']/preceding-sibling::span")
	private WebElement totalTestcaseInSelectedProject;
	
	@FindBy(xpath="//div[@class='zee-module1-wrapper summarybox-executions']//span[text()='Executions']/preceding-sibling::span")
	private WebElement totalExecutionInSelectedProject;
	
	@FindBy(xpath="//div[@class='zee-module1-wrapper summarybox-members']//span[text()='Members']/preceding-sibling::span")
	private WebElement totalMembersInSelectedProject;
	
	@FindBy(xpath="//div[@class='zui-ng-select project-release-select']//span[@id='select2--container']")
	private WebElement goToreleaseSelectDropdown;
	
	
	
	
	
	//Header
	@FindBy(xpath="//span[@id='dropdownMenu4']/i")
	private WebElement adminDropdown;
	
	@FindBy(xpath="//a[text()='Administration']")
	private WebElement administrationInDropdown;
	
	/******************************************************
	 * 	Methods
	 *****************************************************/
	
	
	
	public String getLoggedInUserTitle(){
		return loggedInUserTitle.getText();
	}
	
	public String getCurrentSelectedProject(){
		return currentSelectedProject.getText();
	}
	
	public int getTotalReleaseCountInSelectedProject(){
		return Integer.parseInt(totalReleases.getText());
	}
	
	public int getTotalInprogressReleaseCountInSelectedProject(){
		return Integer.parseInt(totalReleases.getText());
	}
	
	public int getTotalTestcaseCountInSelectedProject(){
		return Integer.parseInt(totalTestcaseInSelectedProject.getText());
	}
	
	public int getTotalExecutionCountInSelectedProject(){
		return Integer.parseInt(totalExecutionInSelectedProject.getText());
	}
	
	public int getTotalMembersInSelectedProject(){
		return Integer.parseInt(totalMembersInSelectedProject.getText());
	}
	
	
	public boolean selectRelease(String releaseName){
		try{
			logger.info("Selecting release : "+releaseName);
			CommonUtil.normalWait(2000);
			goToreleaseSelectDropdown.click();
//			CommonUtil.normalWait(2000);
			CommonUtil.visibilityOfElementLocated("//span[contains(@class,'select2-results')]");
			CommonUtil.returnWebElement("//span[contains(@class,'select2-results')]//li[text()='"+releaseName+"']").click();
//			CommonUtil.normalWait(5000);
			logger.info("Release selected successfully.");
			Assert.assertTrue(ReleaseSummaryPage.getInstance().verifyReleaseSummaryPage(releaseName), "Release Header not found.");
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean selectReleaseFromGrid(String ReleaseName){
		logger.info("Release selection from grid started .......");
		//a[text()='Release 1.0']
		WebElement wb = Driver.driver.findElement(By.xpath("//div[@title='"+ReleaseName+"']/a[text()='"+ReleaseName+"']"));
		if(wb!=null){
			//CommonUtil.moveToElement(wb);
			CommonUtil.normalWait(1000);
			wb.click();
			logger.info("Clicked on Release name in grid, Release Name: " + ReleaseName);
			CommonUtil.normalWait(2000);
			HomePage.getInstance().waitForProgressBarToComplete();
			logger.info("Release selection completed successfully .......");
			return true;
		}else{
			return false;
		}
	}
	
	
	//Header
	public boolean launchAdministration(){
		logger.info("launching Administration Page");
		if(adminDropdown!=null){
			//CommonUtil.moveToElement(adminDropdown);
			adminDropdown.click();
			CommonUtil.normalWait(1000);
			administrationInDropdown.click();
			logger.info("Clicked Administration in Dropdown");
			CommonUtil.implicitWait(30);
			return true;
		}else{
			logger.info("Admin dropdown not found");
		}
		return false;
	}
	

	
	
	
	/******************************************************
	 * 	Verification Methods
	 *****************************************************/
	
	
	public void verifyTotalReleaseCountInSelectedProject(int expectedReleaseCount){
		int actualReleaseCount = getTotalReleaseCountInSelectedProject();
		String failingMsg = "Expected total Release in selected Project not matching, Expected total Release Count: " + expectedReleaseCount
				+ "Actual total Release count: " + actualReleaseCount;
		
		Assert.assertTrue(actualReleaseCount==expectedReleaseCount, failingMsg);
	}
	
	public void verifyTotalInprogressReleaseCountInSelectedProject(int expectedInprogressReleaseCount){
		int actualInprogressReleaseCount = getTotalInprogressReleaseCountInSelectedProject();
		String failingMsg = "Expected total Inprogress Release in selected Project not matching, Expected total Inprogress Release Count: " + expectedInprogressReleaseCount
				+ "Actual total Inprogress Release count: " + actualInprogressReleaseCount;
		
		Assert.assertTrue(actualInprogressReleaseCount==expectedInprogressReleaseCount, failingMsg);
	}
	
	public void verifyLoggedInUserTitle(String expectedUserTitle){
		String failingMsg = "Expected user title not matching, Expected User: " + expectedUserTitle 
				+ "Actual User Title found: " + getLoggedInUserTitle();
		
		Assert.assertTrue(getLoggedInUserTitle().equalsIgnoreCase(expectedUserTitle), failingMsg);
	}
	
	public void verifyCurrentSelectedProject(String expectedProject){
		String failingMsg = "Expected project to be selected not matching, Expected Project: "
				+ expectedProject +"Actual Selected Project Found: " + getCurrentSelectedProject();
		
		Assert.assertTrue(getCurrentSelectedProject().equals(expectedProject), failingMsg);
	}
	
	public void verifyTotalTestcaseCountInSelectedProject(int expectedTotalTestcaseCount){
		int actualTotalTestcaseCount = getTotalTestcaseCountInSelectedProject();
		String failingMsg = "Expected total Testcase count in selected Project not matching, Expected total Testcase Count: " + expectedTotalTestcaseCount
				+ "Actual total Testcase count: " + actualTotalTestcaseCount;
		
		Assert.assertTrue(actualTotalTestcaseCount==expectedTotalTestcaseCount, failingMsg);
	}
	
	public void verifyTotalExecutionCountInSelectedProject(int expectedTotalExecutionCount){
		int actualTotalExecutionCount = getTotalExecutionCountInSelectedProject();
		String failingMsg = "Expected total Execution count in selected Project not matching, Expected total Execution Count: " + expectedTotalExecutionCount
				+ "Actual total Execution count: " + actualTotalExecutionCount;
		
		Assert.assertTrue(actualTotalExecutionCount==expectedTotalExecutionCount, failingMsg);
	}
	
	public void verifyTotalMembersInSelectedProject(int expectedTotalMembersCount){
		int actualTotalMembersCount = getTotalMembersInSelectedProject();
		String failingMsg = "Expected total Resource count in selected Project not matching, Expected total Resource Count: " + expectedTotalMembersCount
				+ "Actual total Ressource count: " + actualTotalMembersCount;
		
		Assert.assertTrue(actualTotalMembersCount==expectedTotalMembersCount, failingMsg);
	}
	
	
	public void verifyProjectSummaryPage(String expectedDefaultSelectedProjectName, String expectedUserTitle, Integer totalReleaseCount
			, Integer totalInprogressRelease, Integer totalTestcases, Integer totalExecutions, Integer totalmembers){
		
		HomePage.getInstance().appDockUndock();
		if(expectedDefaultSelectedProjectName!=null){
			verifyCurrentSelectedProject(expectedDefaultSelectedProjectName);
		}
		if(expectedUserTitle!=null){
			verifyLoggedInUserTitle(expectedUserTitle);
		}
		if(totalReleaseCount!=null){
			verifyTotalReleaseCountInSelectedProject(totalReleaseCount);
		}
		if(totalInprogressRelease!=null){
			verifyTotalInprogressReleaseCountInSelectedProject(totalInprogressRelease);
		}
		if(totalTestcases!=null){
			verifyTotalTestcaseCountInSelectedProject(totalTestcases);
		}
		if(totalExecutions!=null){
			verifyTotalExecutionCountInSelectedProject(totalExecutions);
		}
		if(totalmembers!=null){
			verifyTotalMembersInSelectedProject(totalmembers);
		}
		
	}
	
	
}