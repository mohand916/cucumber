package com.thed.zeuihtml.ze.impl.zehtmlpages;


import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.yaml.snakeyaml.constructor.SafeConstructor.ConstructYamlOmap;

import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;

public class SystemConfigurationPage {
	
	Logger logger;
	
	public SystemConfigurationPage(){
		logger = Logger.getLogger(this.getClass());
	}
	
	public static SystemConfigurationPage getInstance(){
		return PageFactory.initElements(Driver.driver, SystemConfigurationPage.class);
	}
	
	/******************************************************
	 * 	WEBELEMENTS
	 *****************************************************/
	
	@FindBy(xpath="//h3/b[text()='System Configuration']")
	private WebElement headerSystemConfiguration;
	
	@FindBy(xpath="//b[text()='Company Name:']")
	private WebElement labelCompanyName;
	
	@FindBy(xpath="//b[text()='System Name:']")
	private WebElement labelSystemName;
	
	@FindBy(xpath="//label[b[text()='Company Name:']]/following-sibling::div//span[contains(@class,'zephyr-inline-field-name')]")
	private WebElement currentCompanyName;
	
	@FindBy(xpath="//b[text()='System Name:']/parent::label/following-sibling::div//span[contains(@class,'zephyr-inline-field-name')]")
	private WebElement currentSystemName;
	
	@FindBy(xpath="//b[text()='Company Name:']/parent::label/following-sibling::div//span[@class='zephyr-overlay-icon fa fa-pencil zui-fa-pencil']")
	private WebElement iconToEditCompanyName;
	
	@FindBy(xpath="//b[text()='System Name:']/parent::label/following-sibling::div//span[@class='zephyr-overlay-icon fa fa-pencil zui-fa-pencil']")
	private WebElement iconToEditSystemName;
	
	@FindBy(xpath="//div[@class='subform company-info-subform']//input[@type='text']")
	private WebElement textBoxEditCompanyInfoWorksAfterIconClick;
	
	@FindBy(xpath="//input[@id='name_ip']")
	private WebElement textBoxhostName;
	
	@FindBy(xpath="//input[@id='port']")
	private WebElement textBoxPort;
	
	//input[@id='smtpcb']
	@FindBy(xpath="//b[text()='Use SMTP Authentication']/parent::label")
	private WebElement checkboxSmtp;
	
	@FindBy(xpath="//input[@id='username']")
	private WebElement textBoxMailServerUsername;
	
	@FindBy(xpath="//input[@id='password_mailserver']")
	private WebElement textBoxMailServerPassword;
	
	@FindBy(xpath="//input[@id='sslcb']")
	private WebElement checkboxSsl;
	
	@FindBy(xpath="//button[text()='Save']")
	private WebElement buttonSave;
	
	@FindBy(xpath="//button[text()='Cancel']")
	private WebElement buttonCancel;
	
	@FindBy(xpath="//div[@class='save-options']/button[@type='submit']")
	private WebElement buttonUpdate;
	
	@FindBy(xpath="//b[text()='Desktop URL:']/parent::label/following-sibling::div/span")
	private WebElement labelDesktopURLProtocol;
	
	@FindBy(xpath="//b[text()='Dashboard URL:']/parent::label/following-sibling::div/span")
	private WebElement labelDashboardURLProtocol;
	
	@FindBy(xpath="//b[text()='Desktop URL:']/parent::label/following-sibling::div//span[contains(@class,'zephyr-inline-field-name')]")
	private WebElement currentDesktopURL;
	
	@FindBy(xpath="//b[text()='Dashboard URL:']/parent::label/following-sibling::div//span[contains(@class,'zephyr-inline-field-name')]")
	private WebElement currentDashboardURL;
	
	@FindBy(xpath="//b[text()='Desktop URL:']/parent::label/following-sibling::div//span[@class='zephyr-inline-field-name']/following-sibling::span")
	private WebElement iconToEditDesktopURL;
	
	@FindBy(xpath="//b[text()='Dashboard URL:']/parent::label/following-sibling::div//span[@class='zephyr-inline-field-name']/following-sibling::span")
	private WebElement iconToEditDashboardURL;
	
	
	
	/******************************************************
	 * 	Methods
	 *****************************************************/

	public void verifySystemConfigPage(String companyName, String systemName, String desktopURL, String dashboardURL,
			String mailServerHostName, String mailServerPort, String mailServerUsername){
		
		logger.info("Verification of SystemConfiguration page started....");
		HomePage.getInstance().waitForProgressBarToComplete();
		Assert.assertTrue(headerSystemConfiguration!=null, "Header by name System Configuration");
		if(companyName!=null){
			CommonUtil.visibilityOfElementLocated(currentCompanyName);
			logger.info("Going to verify company name as: " + companyName);
			String currectCompany = currentCompanyName.getText();
			Assert.assertTrue(currectCompany.equalsIgnoreCase(companyName), "Company Name not matching, Expected: " + companyName
					+ " Actual: " +currectCompany);
		}
		if(systemName!=null){
			logger.info("Going to verify system name as: " + systemName);
			String currectSystem = currentSystemName.getText();
			Assert.assertTrue(currectSystem.equalsIgnoreCase(systemName), "Company Name not matching, Expected: " + systemName
					+ "Actual: " +currectSystem);
		}
		
		if(mailServerHostName!=null){
			String actualHostName = textBoxhostName.getAttribute("value");
			logger.info("Going to verify Mail Server Host Name as: " + mailServerHostName);
			
			Assert.assertTrue(actualHostName.equals(mailServerHostName), "Mail Server Host Name not matching, Expected: " 
			+ mailServerHostName + " Actual: " + actualHostName);
		}
		
		if(mailServerPort!=null){
			String actualPort = textBoxPort.getAttribute("value");
			logger.info("Going to verify Mail Server Port as: " + mailServerPort);
			
			Assert.assertTrue(actualPort.equals(mailServerPort), "Mail Server Host Name not matching, Expected: " 
			+ mailServerPort + " Actual: " + actualPort);
		}
		if(mailServerUsername!=null){
			String actualMailServerUsername = textBoxMailServerUsername.getAttribute("value");
			logger.info("Going to verify Mail Server Username as: " + mailServerUsername);
			
			Assert.assertTrue(actualMailServerUsername.equals(mailServerUsername), "Mail Server Host Name not matching, Expected: " 
					+ mailServerUsername + " Actual: " + actualMailServerUsername);
		}
		
		if(desktopURL!=null){
			logger.info("Going to verify Desktop URL as: " + desktopURL);
			String currentDeskTopURL = labelDesktopURLProtocol.getText() + currentDesktopURL.getText();
			Assert.assertTrue(currentDeskTopURL.equalsIgnoreCase(desktopURL), "Desktop URL not matching, Expected: " + desktopURL
					+ " Actual: " +currentDeskTopURL);
		}
		if(dashboardURL!=null){
			logger.info("Going to verify Dashboard URL as: " + dashboardURL);
			String curDashboardURL = labelDashboardURLProtocol.getText() + currentDashboardURL.getText();
			Assert.assertTrue(curDashboardURL.equalsIgnoreCase(dashboardURL), "Desktop URL not matching, Expected: " + dashboardURL
					+ " Actual: " +curDashboardURL);
		}
		
		/*JavascriptExecutor js = (JavascriptExecutor) Driver.driver;
		System.out.println(js.executeScript("document.getElementById('name_ip').value"));*/
		//System.out.println(textBoxhostName.getAttribute("value"));
		
	}
	
	public boolean changeSystemConfigurations(String companyName, String systemName, String hostName, String port, 
			String mailServerUsername, String mailServerPassword){
		try {
			CommonUtil.normalWait(2000);
			if(companyName!=null){
				Assert.assertTrue(changeComanyName(companyName), "Not changed the Company details.");
			}
			if(systemName!=null){
				changeSystemName(systemName);
			}
			if(hostName!=null||port!=null){
				changeHostNameAndPort(hostName, port);
			}
			if(mailServerUsername!=null||mailServerPassword!=null){
				changeMailServerUsernameAndPassword(mailServerUsername, mailServerPassword);
			}
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}
	
	private boolean changeComanyName(String companyName){
		try {
			CommonUtil.normalWait(500);
			CommonUtil.scrollToWebElementAndView(currentCompanyName);
			CommonUtil.normalWait(500);
			currentCompanyName.click();
			CommonUtil.normalWait(1000);
			CommonUtil.scrollToWebElementAndView(textBoxEditCompanyInfoWorksAfterIconClick);
			textBoxEditCompanyInfoWorksAfterIconClick.clear();
			textBoxEditCompanyInfoWorksAfterIconClick.sendKeys(companyName);
			CommonUtil.normalWait(1000);
			buttonUpdate.click();
			CommonUtil.normalWait(1000);
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}
	
	private boolean changeSystemName(String systemName){
		currentSystemName.click();
		CommonUtil.normalWait(1000);
		textBoxEditCompanyInfoWorksAfterIconClick.clear();
		textBoxEditCompanyInfoWorksAfterIconClick.sendKeys(systemName);
		CommonUtil.normalWait(1000);
		buttonUpdate.click();
		//CommonUtil.pressEnter();
		CommonUtil.normalWait(1000);
		return true;
	}
	
	private boolean changeHostNameAndPort(String hostName, String port){
		if(hostName!=null){
			textBoxhostName.clear();
			CommonUtil.normalWait(1000);
			textBoxhostName.sendKeys(hostName);
			CommonUtil.normalWait(1000);
		}
		if(port!=null){
			textBoxPort.clear();
			CommonUtil.normalWait(1000);
			textBoxPort.sendKeys(port);
			CommonUtil.normalWait(1000);
		}
		buttonSave.click();
		HomePage.getInstance().closeToastPopup();
		HomePage.getInstance().waitForProgressBarToComplete();
		
		return true;
	}
	
	private boolean changeMailServerUsernameAndPassword(String username, String password){
		if(username!=null){
			CommonUtil.normalWait(1000);
			
			checkboxSmtp.click();
			CommonUtil.normalWait(1000);
			if(textBoxMailServerUsername.getAttribute("value")!=null){
				textBoxMailServerUsername.clear();
			}
			
			textBoxMailServerUsername.sendKeys(username);
			CommonUtil.normalWait(1000);
		}
		if(password!=null){
			//textBoxMailServerPassword.clear();
			if(textBoxMailServerPassword.getAttribute("value")!=null){
				textBoxMailServerPassword.clear();
			}
			textBoxMailServerPassword.sendKeys(password);
			CommonUtil.normalWait(1000);
		}
		buttonSave.click();
		HomePage.getInstance().closeToastPopup();
		HomePage.getInstance().waitForProgressBarToComplete();
		
		return true;
	}
	
	
}
