package com.thed.zeuihtml.jira;

public interface JiraNavigator {

	boolean doJiraLogin(String username, String password);

	public boolean verifyNewMappedProject(String zephyrProjectName, String jiraProjectName);
	
	public boolean verifyIssueLink(String testcaseName);
	
	public boolean editIssue (String issueKey, String summary, String priority);
	
	public boolean jiraLoginCloud(String username, String password);
}
