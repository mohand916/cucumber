package com.thed.zeuihtml.ze.impl.zehtmlpages;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;

public class ManageUsers {

	Logger logger;
	
	public ManageUsers(){
		logger = Logger.getLogger(this.getClass());
	}
	
	public static ManageUsers getInstance(){
		return PageFactory.initElements(Driver.driver, ManageUsers.class);
	}
	
	/******************************************************
	 * 	WEBELEMENTS
	 *****************************************************/
	
	@FindBy(xpath="//b[text()='User Setup']")
	private WebElement headerUserSetup;
	
	@FindBy(xpath="//button[@title='Add Resource']")
	private WebElement buttonAddResource;
	
	@FindBy(xpath="//input[@id='resource-firstname']")
	private WebElement textBoxResourceFirstName;
	
	@FindBy(xpath="//input[@id='resource-lastname']")
	private WebElement textBoxResourceLastName;
	
//	@FindBy(xpath="//input[@id='resource-credentialsExpired']")
	@FindBy(xpath="//label/b[text()='Expire Credentials']")
	private WebElement checkBoxExpireCredentials;
	
	@FindBy(xpath="//select[@id='resource-type']")
	private WebElement selectResourceType;
	
	@FindBy(xpath="//select[@id='resource-roles']")
	private WebElement selectResourceRole;
	
	@FindBy(xpath="//input[@id='resource-email']")
	private WebElement textBoxResourceEmail;
	
	@FindBy(xpath="//input[@id='resource-title']")
	private WebElement textBoxResourceTitle;
	
	@FindBy(xpath="//input[@id='resource-location']")
	private WebElement textBoxResourceLocation;
	
	@FindBy(xpath="//button[text()='Save']")
	private WebElement buttonSave;
	
	@FindBy(xpath="//span[@class='forward-image']")
	private WebElement addSelectedProjects;
	
	@FindBy(xpath="//*[@id='resource-modal']//button[@class='close']")
	private WebElement crossclose;
	
	@FindBy(xpath="//button[@id='user-confirmation-continue']")
	private WebElement buttoncontinue;
	
	@FindBy(xpath="//div[@class='clearfix form-footer']/button[text()='Cancel']")
	private WebElement buttonCancel;
	
	//div[@class='toast-title']
	
	/******************************************************
	 * 	Methods
	 *****************************************************/
	
	public boolean addNewUser(String userFistAndLastName, String userRole, String email, String location){
		String resourceName[] = userFistAndLastName.split(" ");
		CommonUtil.normalWait(1000);
			
		if(CommonUtil.visibilityOfElementLocated(buttonAddResource)){
			CommonUtil.normalWait(2000);
			buttonAddResource.click();
			CommonUtil.normalWait(2000);
			/*if(CommonUtil.visibilityOfElementLocated(checkBoxExpireCredentials)) {
				CommonUtil.normalWait(1000);
				checkBoxExpireCredentials.click();
			}
			else {
				logger.info("Expire Credentials Checkbox not found");
				return false;
			}
			CommonUtil.normalWait(2000);*/
			if(CommonUtil.visibilityOfElementLocated(textBoxResourceFirstName)){
				textBoxResourceFirstName.clear();
				textBoxResourceFirstName.sendKeys(resourceName[0]);
				CommonUtil.normalWait(1000);
				if(CommonUtil.visibilityOfElementLocated(textBoxResourceLastName)){
					textBoxResourceLastName.clear();
					textBoxResourceLastName.sendKeys(resourceName[1]);
					CommonUtil.normalWait(1000);
					if(CommonUtil.visibilityOfElementLocated(selectResourceRole)){
						CommonUtil.selectListWithVisibleText(selectResourceRole, userRole);
						CommonUtil.normalWait(1000);
						if(CommonUtil.visibilityOfElementLocated(textBoxResourceEmail)){
							textBoxResourceEmail.clear();
							textBoxResourceEmail.sendKeys(email);
							CommonUtil.normalWait(1000);
							if(CommonUtil.visibilityOfElementLocated(textBoxResourceLocation)){
								textBoxResourceLocation.clear();
								textBoxResourceLocation.sendKeys(location);
								CommonUtil.normalWait(1000);
								if(CommonUtil.visibilityOfElementLocated(buttonSave)){
									CommonUtil.normalWait(1000);
									buttonSave.click();
									logger.info("Clicked on Save button successfully to Add Resource");
									HomePage.getInstance().closeToastPopup();
									HomePage.getInstance().waitForProgressBarToComplete();
									
								}else{
									logger.info("Save User Button not found");
									return false;
								}
							}else{
								logger.info("Textbox User Location not found");
								return false;
							}
						}else{
							logger.info("Textbox User Email not found");
							return false;
						}
					}else{
						logger.info("Select User Role Dropdown not found");
						return false;
					}	
				}else{
					logger.info("Textbox User Last Name not found");
					return false;
				}
			}else{
				logger.info("Textbox User First Name not found");
				return false;
			}
		}else{
			logger.info("Button Add User not found, Manage User App not launched or Add User button missing");
			return false;
		}
		
		return true;
	}
	
	public void verifyUser(String userFistAndLastName, String userRole, String email, String location){
		//CommonUtil.browserRefresh();
		HomePage.getInstance().waitForProgressBarToComplete();
		CommonUtil.visibilityOfElementLocated(headerUserSetup);
		logger.info("Going to verify User Name as: " + userFistAndLastName);
		Assert.assertTrue(CommonUtil.isElementPresent("//div[@class='grid-content']//div[text()='"+userFistAndLastName+"']")
				, "Resource Name not found Expected: " +userFistAndLastName);
		logger.info("Verified Successfully User Name as: " + userFistAndLastName);
		
		logger.info("Going to verify User Role of Resource '"+userFistAndLastName+"' as: " + userRole);
		Assert.assertTrue(CommonUtil.isElementPresent
				("//div[@class='grid-content']//div[text()='"+userFistAndLastName+"']/parent::div/parent::div/following-sibling::div//div[text()='"+userRole+"']")
				, "Resource Role not matching for User: "+userFistAndLastName+" Expected: " +userRole);
		logger.info("Verified Successfully User Role of Resource '"+userFistAndLastName+"' as: " + userRole);
		
		logger.info("Going to verify email of User '"+userFistAndLastName+"' as: " + email);
		Assert.assertTrue(CommonUtil.isElementPresent
				("//div[@class='grid-content']//div[text()='"+userFistAndLastName+"']/parent::div/parent::div/following-sibling::div//div[text()='"+email+"']")
				, "Resource Email not matching for User: "+userFistAndLastName+" Expected: " +email);
		logger.info("Verified Successfully email of User '"+userFistAndLastName+"' as: " + email);
		
		
		logger.info("Going to verify location of User '"+userFistAndLastName+"' as: " + location);
		Assert.assertTrue(CommonUtil.isElementPresent
				("//div[@class='grid-content']//div[@title='"+userFistAndLastName+"']/parent::div/parent::div/following-sibling::div//div[text()='"+location+"']")
				, "Resource Location not matching for User: "+userFistAndLastName+" Expected: " +location);
		logger.info("Verified location of User '"+userFistAndLastName+"' as: " + location);
		
		CommonUtil.normalWait(2000);
		//CommonUtil.moveToElement(crossclose);
		//crossclose.click();
		CommonUtil.normalWait(1000);
		//canclepopUp();
		
		
	}
	
	/*private boolean canclepopUp()
	{
		logger.info("cliacked on cross button");
		if(CommonUtil.visibilityOfElementLocated(buttoncontinue))
		{
			logger.info("continue button found");
			CommonUtil.normalWait(1000);
			buttoncontinue.click();
		}
	return true;
	}*/
	
	
	public boolean assignProjectsToUser(String userFistAndLastName, List<String> projectNames){
		
		CommonUtil.browserRefresh();
		HomePage.getInstance().waitForProgressBarToComplete();
		
		if(CommonUtil.visibilityOfElementLocated(headerUserSetup)){
			logger.info("Going to select User Name as: " + userFistAndLastName);
			
			if(CommonUtil.visibilityOfElementLocated("//div[@class='grid-content']//div[text()='"+userFistAndLastName+"']")){
				CommonUtil.returnWebElement("//div[@class='grid-content']//div[text()='"+userFistAndLastName+"']").click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(2000);
				for(String projectName : projectNames){
					CommonUtil.normalWait(1000);
					CommonUtil.returnWebElement("//div[@class='unselected-list']//label[text()='"+ projectName +"']").click();
					CommonUtil.normalWait(1000);
				}
				addSelectedProjects.click();
				CommonUtil.normalWait(500);
				buttonSave.click();
				HomePage.getInstance().closeToastPopup();
				HomePage.getInstance().waitForProgressBarToComplete();
				
			}else{
				logger.info("User not found in grid by name : " + userFistAndLastName);
				return false;
			}
			
		}else{
			logger.info("Manage User App not launched");
			return false;
		}
		
		return true;
	}
	
	public void verifyProjectsAssignedToUser(String userFistAndLastName, List<String> projectNames){
		
		logger.info("Checking Manage User App launched or not");
		Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerUserSetup), "Manage User App not launched");
		logger.info("Going to select User Name as: " + userFistAndLastName);
		
		Assert.assertTrue(CommonUtil.isElementPresent("//div[@class='grid-content']//div[text()='"+userFistAndLastName+"']")
				, "User not found in grid by name : " + userFistAndLastName);
		CommonUtil.returnWebElement("//div[@class='grid-content']//div[text()='"+userFistAndLastName+"']").click();
		
		for(String projectName : projectNames){
			if(CommonUtil.visibilityOfElementLocated("//div[@class='selected-list']//label[text()='"+ projectName +"']")){
				logger.info("Verified Project assinged to User as : " + projectName);
			}else{
				logger.info("Assigned Project not found by Project name as : " + projectName);
				Assert.assertTrue(false, "Assigned project not found for Resource by project name as : " + projectName);
			}
		}
		
		CommonUtil.normalWait(1000);
		buttonCancel.click();
		CommonUtil.normalWait(1000);
		buttoncontinue.click();
		
	}
}
