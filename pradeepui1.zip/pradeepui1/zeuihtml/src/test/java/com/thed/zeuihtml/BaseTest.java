package com.thed.zeuihtml;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.specification.RequestSpecification;
import com.thed.zeuihtml.jira.JiraNavigator;
import com.thed.zeuihtml.jira.JiraNavigatorFactory;
import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.CustomHTMLLayout;
import com.thed.zeuihtml.utils.Driver;
import com.thed.zeuihtml.utils.RestUtils;
import com.thed.zeuihtml.utils.TestStatusUpdateUtil;
import com.thed.zeuihtml.ze.ZeNavigator;
import com.thed.zeuihtml.ze.impl.ZeNavigatorImpl;



public class BaseTest {
	
	protected static ZeNavigator zeNavigator = null ;
	
	protected static JiraNavigator jiraNavigator = null ;
	
	protected static boolean isInit = false ;
	
	/***stores the <b>alt Id</b> of currently running bvt*/
	protected static int altID;
	/***stores boolean value as true or false according to status of current bvt*/
	protected boolean isSuccess = false ;
	
	protected Logger logger = null ;
	
	protected static final boolean testEnabled = true;
	
	protected static RequestSpecification basicAuth = null;
	
	protected static JSONArray scheduleArray = null;
	
//	protected static ZAPIAPIServiceImpl zapiService = null;
	
	protected static String testcaseId;
	
	protected static String bvtFilePath = null;
	
	public BaseTest(){
		init();
	}
	
	public void init(){
		if(isInit){
			return;
		}
		new Config();
		zeNavigator = new ZeNavigatorImpl();
		jiraNavigator = new JiraNavigatorFactory().getInstance();
//		zapiService = new ZAPIAPIServiceImpl();
		isInit=true;
	}
	
	
	/**
	 * updates the current bvt status in excel bvt sheet
	 * default value as <b>f<b>
	 */
	public void updateStatus(){
		String status = "f";
		if(isSuccess){
			status="p";
		}
		TestStatusUpdateUtil.writeStatus(Config.getFilePath("ZE_6.1_BVT_Fayre.xls"), altID, status);
	}
	
	public  void captureScreenshotInLog() {
		CommonUtil.captureScreenshot(Config.getScreenPath());
		String imgPath = CommonUtil.captureScreenshot(Config.getScreenPath());
		logger.info(CustomHTMLLayout.IMAGE_PREFIX + "src=\"../" + imgPath + "\"/>");
	}
	
	@BeforeSuite
	public void beforeSuite(){
//		extentReport = new ExtentReports("reports" + File.separator + "ExtentReportsTestNG.html", true);
		bvtFilePath = Config.getFilePath("ZE_6.1_BVT_Fayre.xls");
		TestStatusUpdateUtil.setBuildNumber(bvtFilePath, Config.getValue("BUILD_NO"));
		
		
		CommonUtil.launchBrowser(Config.getValue("ZE_URL"));
		
		RestUtils.setContentType(ContentType.JSON);
		RestUtils.setBaseURI(Config.getValue("ZE_URL").replace("/html5", ""));
		basicAuth = RestUtils.basicAuthRequest(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		
		CommonUtil.cleanDirectory(Config.getValue("EXPORT_FILE_PATH")+"/delete");
	}

	@AfterSuite
	public void afterSuite() {
		CommonUtil.closeTheDriver();
	}
	
	/**
	 * updates the status of current bvt in bvt excel sheet<br>
	 */
	public void baseAfterMethod() {
		if(!isSuccess){
			captureScreenshotInLog();
			CommonUtil.closeTheDriver();
			Driver.driver = CommonUtil.getNewWebDriver();
			CommonUtil.launchBrowser(Config.getValue("ZE_URL"));
		}
		if(altID > 0){  
			updateStatus();
		}
	}

	

}
