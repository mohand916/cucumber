package com.thed.zeuihtml.ze.impl.zehtmlpages;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hamcrest.Factory;
import org.json.JSONArray;
import org.json.JSONObject;
import org.omg.CORBA.COMM_FAILURE;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.gargoylesoftware.htmlunit.javascript.host.media.webkitMediaStream;
import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.Constants;
import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;

public class TestPlanningPage {

	Logger logger;

	public TestPlanningPage() {
		logger = Logger.getLogger(this.getClass());
	}

	public static TestPlanningPage getInstance() {
		return PageFactory.initElements(Driver.driver, TestPlanningPage.class);
	}

	/******************************************************
	 * WEBELEMENTS
	 *****************************************************/

	@FindBy(xpath = "//*[@class='testcase-eas-wrapper']//section[@class='module-subheader']//h3")
	private WebElement testPlanningHeaderText;

	@FindBy(xpath = "//head/title[contains(text(),'Test Planning')]")
	private WebElement testPlanPageHeader;

	// @FindBy(xpath = "//*[@class='testcase-eas-wrapper']//h3[@class='fixed-top
	// execution-txt']")
	@FindBy(xpath = "//*[@id='ze-main-app']//h3[@class='fixed-top']")
	private WebElement testPlanningExecutionSectionHeaderText;

	@FindBy(xpath = "//*[@class='testcase-eas-wrapper']//section[@class='module-subheader']//button")
	private WebElement testPlanningSectionReleaseNameText;

	// Create cycle details
	@FindBy(xpath = "//*[@class='testcase-eas-wrapper']//button[@title='Add new cycle']")
	private WebElement createNewCycleBtn;

	@FindBy(id = "easAddCycleModal")
	private WebElement createNewCycleModalPopup;

	@FindBy(xpath = "//*[@id='easAddCycleModal']//h4[@class='modal-title']")
	private WebElement createNewCycleModalPopupHeaderText;

	@FindBy(xpath = "//*[@id='easAddCycleModal']//input[@formcontrolname='name']")
	private WebElement createNewCycleNameTextBox;

	@FindBy(xpath = "//*[@id='easAddCycleModal']//input[@formcontrolname='build']")
	private WebElement createNewCycleBuildTextBox;

	@FindBy(xpath = "//*[@id='easAddCycleModal']//input[@formcontrolname='environment']")
	private WebElement createNewCycleEnvironmentTextBox;

	@FindBy(xpath = "//*[@id='easAddCycleModal']//b[contains(text(),'Start Date')]/parent::label/following-sibling::div//input[@type='text']")
	private WebElement createNewCycleStartDateTextBox;

	@FindBy(xpath = "//*[@id='easAddCycleModal']//b[contains(text(),'End Date')]/parent::label/following-sibling::div//input[@type='text']")
	private WebElement createNewCycleEndDateTextBox;

	@FindBy(xpath = "//*[@id='easAddCycleModal']//zui-modal-footer/button[text()='Save']")
	private WebElement createNewCycleSubmitBtn;

	@FindBy(xpath = "//*[@id='easAddCycleModal']//zui-modal-footer/button[text()='Cancel']")
	private WebElement createNewCycleCancelBtn;

	@FindBy(xpath = "//*[@id='zephyr-tree-eas-cycle']//a[@data-node='cycle']")
	private List<WebElement> listOfCycleElements;

	// Edit Cycle Elements
	@FindBy(id = "easEditNodeModal")
	private WebElement editCycleModalPopup;

	@FindBy(xpath = "//*[@id='easEditNodeModal']//h4[@class='modal-title']")
	private WebElement editCycleModalPopupHeaderText;

	@FindBy(xpath = "//*[@id='easEditNodeModal']//input[@formcontrolname='name']")
	private WebElement editCycleNameTextBox;

	@FindBy(xpath = "//*[@id='easEditNodeModal']//input[@formcontrolname='build']")
	private WebElement editCycleBuildTextBox;

	@FindBy(xpath = "//*[@id='easEditNodeModal']//input[@formcontrolname='environment']")
	private WebElement editCycleEnvironmentTextBox;

	@FindBy(xpath = "//div[@id='easEditNodeModal']//input[@formcontrolname='status']")
	private WebElement checkboxHideCycle;

	@FindBy(xpath = "//*[@id='easEditNodeModal']//b[contains(text(),'Start Date')]/parent::label/following-sibling::div//input[@type='text']")
	private WebElement editCycleStartDateTextBox;

	@FindBy(xpath = "//div[@id='easEditNodeModal']//b[contains(text(),'Start Date')]/parent::label/following-sibling::div/calendar/div")
	private WebElement calendarIconCycleStartDate;

	@FindBy(xpath = "//div[@id='easEditNodeModal']//b[contains(text(),'End Date')]/parent::label/following-sibling::div/calendar/div")
	private WebElement calendarIconCycleEndDate;

	@FindBy(xpath = "//*[@id='easEditNodeModal']//b[contains(text(),'End Date')]/parent::label/following-sibling::div//input[@type='text']")
	private WebElement editCycleEndDateTextBox;

	@FindBy(xpath = "//*[@id='easEditNodeModal']//zui-modal-footer/button[text()='Save']")
	private WebElement editCycleSubmitBtn;

	@FindBy(xpath = "//*[@id='easEditNodeModal']//zui-modal-footer/button[text()='Cancel']")
	private WebElement editCycleCancelBtn;

	// Delete Cycle Elements
	@FindBy(id = "easDeleteNodeModal")
	private WebElement deleteCycleModalPopup;

	@FindBy(xpath = "//*[@id='easDeleteNodeModal']//h4[@class='modal-title']")
	private WebElement deleteCycleModalPopupHeaderText;

	@FindBy(xpath = ".//*[@id='easDeleteNodeModal']//*[@class='modal-body']//p")
	private WebElement deleteCycleModalPopupBodyText;

	@FindBy(xpath = "//*[@id='easDeleteNodeModal']//zui-modal-footer/button[text()='Delete']")
	private WebElement deleteCycleSubmitBtn;

	@FindBy(xpath = "//*[@id='easDeleteNodeModal']//zui-modal-footer/button[text()='Cancel']")
	private WebElement deleteCycleCancelBtn;

	@FindBy(xpath = "//a[text()='Add Phase']")
	private WebElement linkAddPhase;

	@FindBy(xpath = "//a[text()='Add Folder']")
	private WebElement linkAddNodeInFreeform;

	@FindBy(xpath = "//a[text()='Rename']")
	private WebElement linkEditNodeInFreeform;

	@FindBy(xpath = "//a[text()='Delete']")
	private WebElement linkDeleteNodeInFreeform;

	@FindBy(xpath = "//div[@id='easDeleteNodeModal']//button[text()='Yes']")
	private WebElement buttonYesToConfirmDelete;

	@FindBy(xpath = "//a[text()='Assign']")
	private WebElement linkAssing;

	@FindBy(xpath = "//a[text()='Delete']")
	private WebElement linkDelete;

	@FindBy(xpath = "//div[@id='easDeleteNodeModal']//h4[text()='Delete phase']")
	private WebElement headerDeleteNode;

	@FindBy(xpath = "//div[@id='easDeleteNodeModal']//button[text()='Delete']")
	private WebElement buttonDeleteNodeInCycle;

	@FindBy(xpath = "//a[text()='Clone']")
	private WebElement linkClone;

	@FindBy(xpath = "//a[text()='Export']")
	private WebElement linkExport;

	@FindBy(xpath = "//h4[text()='Add New Phase']")
	private WebElement popupAddNewPhase;

	@FindBy(xpath = "//h4[text()='Add Folder']")
	private WebElement headerAddNodeInFreeform;

	@FindBy(xpath = "//select[@id='defect-system-select2']")
	private WebElement selectExistingPhase;

	@FindBy(xpath = "//button[text()='Save']")
	private WebElement buttonSave;

	@FindBy(xpath = "//div[@id='bulk-assignment-initial-modal']//button[text()='Save']")
	private WebElement buttonSaveInitialBulkAssingment;

	@FindBy(xpath = "//div[@id='bulk-assignment-initial-modal']//h4[text()='Bulk Assignment']")
	private WebElement headerBulkAssignmentInInitial;

	@FindBy(xpath = "//div[@id='bulk-assignment-initial-modal']//button[text()='Cancel']")
	private WebElement buttonCancelBulkAssignmentPopup;

	@FindBy(xpath = "//span[text()='Automatically assign All testcases to the creator of the testcase']")
	private WebElement radioButtonAutoAssignToCreator;

	@FindBy(xpath = "//span[text()='Automatically assign All testcases to anyone']")
	private WebElement radioButtonAutoAssignToAnyone;

	@FindBy(xpath = "//h3[text()='Assign Test Cases to Execute']")
	private WebElement headerAssingTestcasesToExecute;

	@FindBy(xpath = "//h3[text()='Assign Test Cases to Execute']/i")
	private WebElement iconToNavigateBackToCycle;

	@FindBy(xpath = "//h4[text()='Clone Cycle']")
	private WebElement headerCloneCycle;

	@FindBy(xpath = "//*[@id='checkHiddenCycle']")
	private WebElement hidecycleChebox;

	@FindBy(xpath = "//div[@id='easCloneNodeModal']//input[@formcontrolname='name']")
	private WebElement textboxCycleNameInCloneCyclePopup;

	@FindBy(xpath = "//span[text()='Also copy testcase assignments over']/preceding-sibling::div/input")
	private WebElement checkboxCopyTestcaseAssingmentsOver;

	@FindBy(xpath = "//h4[text()='Clone Cycle']/parent::div/parent::div/parent::div//button[text()='Save']")
	private WebElement buttonSaveInCloneCycleWindow;

	@FindBy(xpath = "//span[@title='Bulk assign testcases in the selected folder (including its sub folder)']")
	private WebElement iconBulkAssign;

	// @FindBy(xpath="//label[@for='eas_mode_1_radio']/parent::div/following-sibling::div//select")
	// private WebElement
	// selectAssigneeDropdownInBulkWindowForOptionNotExecutedTest;

	@FindBy(xpath = "//label[@for='eas_mode_1_radio']/parent::div/following-sibling::div//span[@class ='select2-selection__placeholder']")
	private WebElement selectAssigneeDropdownInBulkWindowForOptionNotExecutedTest;

	@FindBy(xpath = "//label[@for='eas_mode_1_radio']")
	private WebElement radioButtonAssignAllNotExecutedTest;

	@FindBy(xpath = "//input[@id='apply_to_subfolders_1']")
	private WebElement checkboxApplySubfolderInBulkWindowForOptionNotExecutedTest;

	@FindBy(xpath = "//label[@for='eas_mode_2_radio']/parent::div/following-sibling::div//span[@class ='select2-selection__placeholder']")
	private WebElement selectAssigneeDropdownInBulkWindowForOptionUnassignedTest;

	@FindBy(xpath = "//label[@for='eas_mode_2_radio']")
	private WebElement radioButtonAssignAllUnassignedTest;

	@FindBy(xpath = "//input[@id='apply_to_subfolders_2']")
	private WebElement checkboxApplySubfolderInBulkWindowForOptionUnassignedTest;

	@FindBy(xpath = "//label[@for='eas_mode_3_radio']/parent::div/following-sibling::div/div[1]//span[@class ='select2-selection__placeholder']")
	private WebElement selectFromAssigneeDropdownInBulkWindowForOptionAssignButNotExecutedTest;

	@FindBy(xpath = "//label[@for='eas_mode_3_radio']")
	private WebElement radioButtonAssignAllAssignedButNotExecutedTest;

	@FindBy(xpath = "//label[@for='eas_mode_3_radio']/parent::div/following-sibling::div/div[2]//span[@class ='select2-selection__placeholder']")
	private WebElement selectToAssigneeDropdownInBulkWindowForOptionAssignButNotExecutedTest;

	@FindBy(xpath = "//input[@id='apply_to_subfolders_3']")
	private WebElement checkboxApplySubfolderInBulkWindowForOptionAssignButNotExecutedTest;

	@FindBy(xpath = "//div[@id='bulk-assignment-modal']//button[text()='Save']")
	private WebElement buttonSaveInBulkAssignmentPopup;

	@FindBy(xpath = "//div[@id='bulk-assignment-modal']//button[text()='Cancel']")
	private WebElement buttonCancelInBulkAssignmentPopup;

	@FindBy(xpath = "//div[@id='bulk-assignment-modal']//h4[text()='Bulk Assignment']")
	private WebElement headerBulkAssignment;

	@FindBy(xpath = "//div[@id='easAddPhaseModal']//span[text()='Create New']")
	private WebElement radioButtonCreateNewFreeformPhase;

	@FindBy(xpath = "//div[@id='easAddPhaseModal']//span[text()='Create New']/parent::label/following-sibling::input")
	private WebElement textBoxFreeformPhaseNameInAddPhase;

	@FindBy(xpath = "//input[@id='node-name']")
	private WebElement textBoxFreeformChildNodeName;

	@FindBy(xpath = "//input[@id='node-description']")
	private WebElement textBoxFreeformChildNodeDescription;

	@FindBy(xpath = "//div[@id='easAddNodeModal']//button[text()='Save']")
	private WebElement buttonSaveFreeformChildNode;

	@FindBy(xpath = "//div[@id='easEditNodeModal']//button[text()='Save']")
	private WebElement buttonSaveEditedFreeformNode;

	@FindBy(xpath = "//button[@id='zui-modal-trigger-eas-freform-add-testcase']")
	private WebElement buttonToLaunchAddTestcasesWindowForFreeform;

	@FindBy(xpath = "//div[@id='zui-eas-freform-add-testcase-modal']//h4[text()='Add Testcase(s)']")
	private WebElement headerAddTestcases;

	@FindBy(xpath = "//span[text()='Advanced']")
	private WebElement radioButtonAdvanced;

	@FindBy(xpath = "//span[text()='Quick']")
	private WebElement radioButtonQuick;

	@FindBy(xpath = "//input[@id='zui-search-textarea']")
	private WebElement textAreaForQuickSearch;

	@FindBy(xpath = "//input[@id='zql-search-input-eas-search']")
	private WebElement textAreaForAdvanceSearch;

	// @FindBy(xpath="//input[@id='zui-search-save-all']")
	@FindBy(xpath = "//*[@id='zui-eas-freform-add-testcase-modal']//label[text()='Select All']")
	private WebElement checkboxSaveAllTestcasesFetchedBySearch;

	@FindBy(xpath = "//div[@id='zui-eas-freform-add-testcase-modal']//button[text()='Go']")
	private WebElement buttonGo;

	@FindBy(xpath = "//div[@id='zui-eas-freform-add-testcase-modal']//button[text()='Save']")
	private WebElement buttonSaveToAddFetchedTestcaseToFreeform;

	// @FindBy(xpath="//input[@id='zui-heirarchy']")
	@FindBy(xpath = "//*[@id='zui-eas-freform-add-testcase-modal']//label/b[contains(text(),'Hierarchy')]")
	private WebElement checkboxBringHeirarchy;

	@FindBy(xpath = "//div[@id='testcase-modal-confirmation']//h4[text()='Add Testcase(s) Status:']")
	private WebElement headerAddTestcasesStatus;

	// @FindBy(xpath="//div[@id='testcase-modal-confirmation']//button[normalize-space(text())='Ok']")
	@FindBy(xpath = "//*[@id='testcase-modal-confirmation']//zui-modal-footer/button[normalize-space(text())='Ok']")
	private WebElement buttonOkInConfirmationOfTestcaseAdded;

	@FindBy(xpath = "//input[@id='testcase_select_all']")
	private WebElement checkboxSelectAllTestcaseInGrid;

	@FindBy(xpath = "//input[@id='phase_testcase_select_all']")
	private WebElement checkboxSelectAllTestcaseInGridInOtherCycle;

	@FindBy(xpath = "//input[@id='zui-heirarchy']/parent::div/parent::div//following-sibling::button[text()='Cancel']")
	private WebElement buttonCancelInAddTestcaseWindow;

	@FindBy(xpath = "//span[@title='Sync brings in the changes that were made after the phase was scheduled or last synchronized']")
	private WebElement buttonSync;

	@FindBy(xpath = "//h4[text()='Proceed with Synchronization']")
	private WebElement headerProceedWithSynchronization;

	@FindBy(xpath = "//label[@for='delete-nodes-testcases']")
	private WebElement checkboxAndLabelSyncDeletedNodeTestcases;

	@FindBy(xpath = "//div[@id='sync-modal']//button[text()='Continue']")
	private WebElement buttonContinueSync;

	@FindBy(xpath = "//h4[text()='Warning!']")
	private WebElement headerWarningForSync;

	@FindBy(xpath = "//button[@value='SYNC']")
	private WebElement buttonContinueSyncInWarningPopup;

	@FindBy(xpath = "//div[@id='sync-messages-modal']//h4[text()='Changes Made']")
	private WebElement headerChangesMadeForSync;

	@FindBy(xpath = "//div[@id='sync-messages-modal']//button[text()='Ok']")
	private WebElement buttonOkInSyncChangesMade;

	@FindBy(xpath = "//span[@title='Delete selected testcases']")
	private WebElement buttonDeleteSelectedTestcase;

	@FindBy(xpath = "//div[@id='confirmation-modal']//h4[text()='Confirmation Delete']")
	private WebElement headerConfirmationDelete;

	@FindBy(xpath = "//div[@id='confirmation-modal']//button[@value='DELETE']")
	private WebElement buttonDeleteInConfirmationPopup;

	@FindBy(xpath = "//div[@id='zui-eas-freform-add-testcase-modal']//div[normalize-space(text())='Other Cycles']")
	private WebElement optionOtherCycle;

	@FindBy(xpath = "//div[@id='zui-eas-freform-add-testcase-modal']//b[text()='Select Cycle']/parent::label/following-sibling::select")
	private WebElement selectCycleInAddTestcaseFromAnotherCycle;

	@FindBy(xpath = "//div[@id='zui-eas-freform-add-testcase-modal']//b[text()='Select Phase']/parent::label/following-sibling::select")
	private WebElement selectPhaseInAddTestcaseFromAnotherCycle;

	@FindBy(xpath = "//div[@id='zui-eas-freform-add-testcase-modal']//b[text()='Filter By Status']/parent::label/following-sibling::div//select")
	private WebElement selectStatusInAddTestcaseFromAnotherCycle;

	@FindBy(xpath = "//div[@id='zui-eas-freform-add-testcase-modal']//b[text()='Filter By Status']/parent::label/following-sibling::div//input")
	private WebElement selectStatusInAddTestcaseFromAnotherCycleclick;

	@FindBy(xpath = "//div[@id='zui-eas-freform-add-testcase-modal']//button[normalize-space(text())='Go']")
	private WebElement buttonGoInAddTestcaseFromAnotherCycle;

	@FindBy(xpath = "//span[text()='Data (Excel only)']")
	private WebElement radioButtonDataExcel;

	@FindBy(xpath = "//span[text()='Detailed']")
	private WebElement radioButtonDetailed;

	@FindBy(xpath = "//span[text()='HTML']")
	private WebElement radioButtonHtml;

	@FindBy(xpath = "//span[text()='PDF']")
	private WebElement radioButtonPdf;

	@FindBy(xpath = "//span[text()='Word']")
	private WebElement radioButtonWord;

	@FindBy(xpath = "//span[text()='Summary']")
	private WebElement radioButtonSummary;

	@FindBy(xpath = "//div[@id='zui-export-modal-tcr_5']//button[text()='Save']")
	private WebElement buttonSaveExport;

	@FindBy(xpath = "//div[@id='zui-export-modal-tcr_5-download']//h4[text()='Download File']")
	private WebElement headerDownloadFileInPopup;

	@FindBy(xpath = "//div[@id='zui-export-modal-tcr_5-download']//button[text()='Download']")
	private WebElement buttonDownload;

	@FindBy(xpath = "//div[@id='bulk-operation-warning-modal']//h4[text()='Bulk Assignment']")
	private WebElement headerBulkAssignmentInWarningPopup;

	@FindBy(xpath = "//div[@id='bulk-operation-warning-modal']//button[text()='OK']")
	private WebElement buttonOkInBulkOperationWarningPopup;

	// Pagination

	@FindBy(xpath = "//select[@id='pagination-page-size-eas_add_search']")
	private WebElement selectPaginationPageSize;

	@FindBy(xpath = "//div[@id='zui-freeform-testcase-add-grid-wrapper']//span[text()='Next']/parent::a")
	private WebElement linkNextPage;

	@FindBy(xpath = "//div[@id='zui-freeform-testcase-add-grid-wrapper']//span[text()='Prev']/parent::a")
	private WebElement linkPrevPage;

	// Browse Add add testcase to freeform

	@FindBy(xpath = "//div[@data-target-name='browse']")
	private WebElement selectBrowse;

	@FindBy(xpath = "//a[@data-name='Freeform Node']")
	private WebElement selectNode;

	@FindBy(xpath = "//a[text()='Release 1.0']/preceding::i[@class='jstree-icon jstree-ocl']")
	private WebElement BrowseReleaseSelect;

	@FindBy(xpath = "//a[@data-name='Phase 1']/preceding::i[@class='jstree-icon jstree-ocl'][1]")
	private WebElement browsePhaseSelect;

	@FindBy(xpath = "//a[@data-name='Node 1']/preceding::i[@class='jstree-icon jstree-ocl'][1]")
	private WebElement browseNodeSelect;
	@FindBy(xpath = "//a[@data-name='Sub-Node 1']")
	private WebElement subNodeSelect;

	@FindBy(xpath = "//input[@id='testcase_select_all']")
	private WebElement selectAll;

	@FindBy(xpath = "//*[@id='zui-eas-freform-add-testcase-modal']//zui-modal-footer/button[text()='Save']")
	private WebElement browseAndSave;

	@FindBy(xpath = "//div[@id='easEditNodeModal']//button[@class='close']")
	private WebElement buttonCloseEditCycle;

	/******************************************************
	 * Methods
	 * 
	 * @return
	 *****************************************************/

	public boolean createCycle(String cycleName, String buildName, String environment, String startDate,
			String endDate) {
		try {
			logger.info("Creating a cycle in Test Planning page.");
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			// createNewCycleBtn.click();
			// CommonUtil.ClickOnElementUsingJS(createNewCycleBtn);
			CommonUtil.scrollToWebElementAndView(createNewCycleBtn);
			createNewCycleBtn.click();
			logger.info("Clicked on Create a new cycle button and waiting for cycle popup.");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(createNewCycleModalPopup),
					"Create new cycle Nodal popup not opened.");
			logger.info("Create new cycle Modal popup not opened.");

			Assert.assertTrue(createNewCycleModalPopupHeaderText.getText().equals("Add New Cycle"),
					"Create new cycle Modal popup header text not verified.");
			logger.info("Create new cycle Modal popup header text verified.");

			// Adding Cycle Name of Cycle
			createNewCycleNameTextBox.sendKeys(cycleName);
			CommonUtil.normalWait(100);
			logger.info("Create new cycle Name Given successfully.");

			// Adding Build Name of Cycle
			if (buildName != null) {
				createNewCycleBuildTextBox.sendKeys(buildName);
				CommonUtil.normalWait(100);
				logger.info("Create new Build Name Given successfully.");
			}
			// Adding Environment of Cycle
			if (environment != null) {
				createNewCycleEnvironmentTextBox.sendKeys(environment);
				CommonUtil.normalWait(100);
				logger.info("Create new Cycle Environment Given successfully.");
			}

			// Adding Start date of Cycle
			createNewCycleStartDateTextBox.sendKeys(startDate);
			CommonUtil.normalWait(100);
			logger.info("Create new cycle Start date Given successfully.");

			// Adding End date of Cycle
			createNewCycleEndDateTextBox.sendKeys(endDate);
			CommonUtil.normalWait(100);
			logger.info("Create new cycle End date Given successfully.");

			createNewCycleSubmitBtn.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(5000);
			logger.info("Clicked on Create new cycle Submit button successfully.");

			/*
			 * CommonUtil.browserRefresh(); CommonUtil.normalWait(1000);
			 * HomePage.getInstance().waitForProgressBarToComplete();
			 */
			Assert.assertTrue(verifyCycles(cycleName), "Not Verified New cycle.");
			logger.info("New cycle verified successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;

	}

	public boolean editCycle(String cycleName, String newCycleName, String buildName, String environment,
			String cycleStartDate, String cycleEndDate, List<String> phaseNameWithStartDates,
			List<String> phaseNameWithEndDates, boolean hideCycle, boolean viewhideCycle) {
		try {
			logger.info("Editing a cycle in Test Planning page.");
			CommonUtil.normalWait(1000);
			String cycleNameToVerify = null;
			WebElement we = CommonUtil.returnWebElement("//a[@data-name='" + cycleName + "']");
			CommonUtil.moveToElement(we);
			CommonUtil.returnWebElement("//a[@data-name='" + cycleName + "']//div[contains(@class,'contextMenuIcon')]")
					.click();
			// createNewCycleBtn.click();
			CommonUtil.normalWait(1000);
			CommonUtil.ClickOnElementUsingJS(CommonUtil.returnWebElement("//a[text()='Edit']"));
			logger.info("Clicked on Edit cycle button and waiting for cycle popup.");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(editCycleModalPopup),
					"Edit new cycle Modal popup not opened.");
			logger.info("edit cycle Modal popup found successfully.");

			Assert.assertTrue(editCycleModalPopupHeaderText.getText().equals("Edit Cycle"),
					"edit cycle Modal popup header text not verified.");
			logger.info("edit cycle Modal popup header text verified.");

			if (newCycleName != null) {
				// Adding Cycle Name of Cycle
				editCycleNameTextBox.clear();
				CommonUtil.normalWait(500);
				editCycleNameTextBox.sendKeys(newCycleName);
				CommonUtil.normalWait(100);
				logger.info("edit cycle Name Given successfully.");
				cycleNameToVerify = newCycleName;
			} else {
				cycleNameToVerify = cycleName;
			}

			// Adding Build Name of Cycle
			if (buildName != null) {
				editCycleBuildTextBox.clear();
				CommonUtil.normalWait(500);
				editCycleBuildTextBox.sendKeys(buildName);
				CommonUtil.normalWait(100);
				logger.info("edit Build Name Given successfully.");
			}
			// Adding Build Name of Cycle
			if (environment != null) {
				editCycleEnvironmentTextBox.clear();
				CommonUtil.normalWait(500);
				editCycleEnvironmentTextBox.sendKeys(environment);
				CommonUtil.normalWait(100);
				logger.info("edit Cycle Environment Given successfully.");
			}

			// Adding Start date of Cycle
			if (cycleStartDate != null) {

				calendarIconCycleStartDate.click();
				CommonUtil.normalWait(2000);
				String splitDate[] = cycleStartDate.split("/");
				String mm = splitDate[0];
				int dd = Integer.parseInt(splitDate[1]);
				String yyyy = splitDate[2];
				CommonUtil.returnWebElement(
						"//div[@id='easEditNodeModal']//label[contains(text(),'Start Date')]/following-sibling::div/calendar/div//td[contains(@id,'-"
								+ dd + "')]")
						.click();
				CommonUtil.normalWait(2000);
				logger.info("edit cycle Start date Given successfully.");
			}

			// Adding End date of Cycle
			if (cycleEndDate != null) {

				calendarIconCycleEndDate.click();
				CommonUtil.normalWait(2000);
				String splitDate[] = cycleEndDate.split("/");
				String mm = splitDate[0];
				int dd = Integer.parseInt(splitDate[1]);
				String yyyy = splitDate[2];

				CommonUtil.returnWebElement(
						"//div[@id='easEditNodeModal']//label[contains(text(),'End Date')]/following-sibling::div/calendar/div//td[contains(@id,'-"
								+ dd + "')]")
						.click();

				CommonUtil.normalWait(4000);
				logger.info("edit cycle End date Given successfully.");
			}

			if (phaseNameWithEndDates != null) {
				CommonUtil.normalWait(2000);
				for (String eachPhaseWithEndDate : phaseNameWithEndDates) {
					String phaseDetails[] = eachPhaseWithEndDate.split(">");
					String phaseName = phaseDetails[0];
					String phaseEndDate = phaseDetails[1];

					Assert.assertTrue(CommonUtil.returnWebElement("//td/span[@title='" + phaseName + "']") != null,
							"Phase Name: " + phaseName + " not found in Edit Cycle Popup");

					logger.info("Phase Name: " + phaseName + " found successfully in Edit Cycle Popup");
					// td/span[@title='"+phaseName+"']/parent::td/following-sibling::td[2]//input
					WebElement phEndDate = CommonUtil.returnWebElement(
							"//td/span[@title='" + phaseName + "']/parent::td/following-sibling::td[2]/calendar/div");
					CommonUtil.normalWait(500);
					phEndDate.click();
					CommonUtil.normalWait(2000);
					String splitDate[] = phaseEndDate.split("/");
					String mm = splitDate[0];
					// int dd = Integer.parseInt(splitDate[1]);
					String dd = splitDate[1];
					String yyyy = splitDate[2];

					Assert.assertTrue(
							CommonUtil.visibilityOfElementLocated("//td/span[@title='" + phaseName
									+ "']/parent::td/following-sibling::td[2]//td/button/span[text()='" + dd + "']"),
							"Unable to click on Date: " + dd);
					// CommonUtil.returnWebElement("//td/span[@title='"+phaseName+"']/parent::td/following-sibling::td[2]//td[contains(@id,'-"+dd+"')]").click();
					CommonUtil
							.returnWebElement("//td/span[@title='" + phaseName
									+ "']/parent::td/following-sibling::td[2]//td/button/span[text()='" + dd + "']")
							.click();

					CommonUtil.normalWait(5000);

				}
			}

			if (phaseNameWithStartDates != null) {
				CommonUtil.normalWait(2000);
				for (String eachPhaseWithStartDate : phaseNameWithStartDates) {
					String phaseDetails[] = eachPhaseWithStartDate.split(">");
					String phaseName = phaseDetails[0];
					String phaseStartDate = phaseDetails[1];

					Assert.assertTrue(CommonUtil.returnWebElement("//td/span[@title='" + phaseName + "']") != null,
							"Phase Name: " + phaseName + " not found in Edit Cycle Popup");

					logger.info("Phase Name: " + phaseName + " found successfully in Edit Cycle Popup");

					WebElement phStartDate = CommonUtil.returnWebElement(
							"//td/span[@title='" + phaseName + "']/parent::td/following-sibling::td[1]/calendar/div");
					CommonUtil.normalWait(500);
					phStartDate.click();
					CommonUtil.normalWait(2000);
					String splitDate[] = phaseStartDate.split("/");
					String mm = splitDate[0];
					// int dd = Integer.parseInt(splitDate[1]);
					String dd = splitDate[1];
					String yyyy = splitDate[2];
					// CommonUtil.returnWebElement("//td/span[@title='"+phaseName+"']/parent::td/following-sibling::td[1]//td[contains(@id,'-"+dd+"')]").click();
					CommonUtil
							.returnWebElement("//td/span[@title='" + phaseName
									+ "']/parent::td/following-sibling::td[1]//td/button/span[text()='" + dd + "']")
							.click();
					CommonUtil.normalWait(5000);

				}
			}

			if (hideCycle) {
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
				checkboxHideCycle.click();
				CommonUtil.normalWait(1000);

			}

			editCycleSubmitBtn.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(100);
			logger.info("Clicked on edit cycle Submit button successfully.");
			// CommonUtil.browserRefresh();
			if (viewhideCycle) {
				Assert.assertTrue(verifyCycles(cycleNameToVerify), "Not Verified Edited cycle.");
			} else {
				Assert.assertFalse(verifyCycles(cycleNameToVerify), "Not Verified Edited cycle.");
			}
			logger.info("Edited cycle verified successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			if (CommonUtil.visibilityOfElementLocated(buttonCloseEditCycle, 5)) {
				List<WebElement> cal = CommonUtil.returnWebElements("//div[@class='inline-calendar-body']");
				for (WebElement c : cal) {
					if (CommonUtil.isElementClickable(c, 3)) {
						c.click();
						CommonUtil.normalWait(1000);
					}
				}
				buttonCloseEditCycle.click();
				CommonUtil.normalWait(4000);
			}
		}
		return true;

	}

	public boolean deleteCycle(String deleteCycleName) {
		try {
			logger.info("Delete a cycle in Test Planning page.");
			CommonUtil.normalWait(1000);

			if (CommonUtil.visibilityOfElementLocated("//a[@data-name='" + deleteCycleName + "']", 5)) {
				CommonUtil.browserRefresh();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(2000);
			}

			WebElement we = CommonUtil.returnWebElement("//a[@data-name='" + deleteCycleName + "']");
			CommonUtil.moveToElement(we);
			CommonUtil
					.returnWebElement(
							"//a[@data-name='" + deleteCycleName + "']//div[contains(@class,'contextMenuIcon')]")
					.click();
			// createNewCycleBtn.click();
			CommonUtil.ClickOnElementUsingJS(CommonUtil.returnWebElement("//a[text()='Delete']"));
			logger.info("Clicked on Delete cycle button and waiting for cycle popup.");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(deleteCycleModalPopup),
					"Delete new cycle Nodal popup not opened.");
			logger.info("Delete cycle Modal popup not opened.");

			Assert.assertTrue(deleteCycleModalPopupHeaderText.getText().equals("Delete cycle"),
					"Delete cycle Modal popup header text not verified.");
			logger.info("Delete cycle Modal popup header text verified.");

			Assert.assertTrue(
					deleteCycleModalPopupBodyText.getText()
							.equals("Are you sure you want to delete " + deleteCycleName + " ?"),
					"Delete cycle Modal popup body text not verified.");
			logger.info("Delete cycle Modal popup body text verified.");

			deleteCycleSubmitBtn.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(3000);
			logger.info("Clicked on Delete cycle Submit button successfully.");

			Assert.assertFalse(verifyCycles(deleteCycleName), "Not Verified deleted cycle.");
			logger.info("Deleted cycle verified successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;

	}

	public boolean verifyCycles(String cycleName) {
		boolean flag = false;
		try {
			Assert.assertTrue(
					CommonUtil.textToBePresentInElement(testPlanningExecutionSectionHeaderText, "Execution Cycles"),
					"Test Planning Execution section header Header not found.");
			logger.info("Test Planning Execution section header text validated successfully after cycle created.");

			for (Iterator iterator = listOfCycleElements.iterator(); iterator.hasNext();) {
				WebElement webElement = (WebElement) iterator.next();
				logger.info(webElement.getText());
				if (webElement.getText().trim().equals(cycleName)) {
					flag = true;
					logger.info(cycleName + " verified successfully.");
					break;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			return flag;
		}
		return flag;
	}

	public boolean verifyTestPlanningPage(String releaseName) {
		try {
			Assert.assertEquals(CommonUtil.getTitle(), "Test Planning - Zephyr Enterprise 6.2");
			// Assert.assertTrue(CommonUtil.textToBePresentInElement(testPlanningHeaderText,
			// "Test Planning"),
			// "Test Planning Header not found.");
			logger.info("Test Planning header text validated successfully.");

			/*
			 * Assert.assertTrue(
			 * CommonUtil.textToBePresentInElement(testPlanningExecutionSectionHeaderText,
			 * "Execution Cycles"),
			 * "Test Planning Execution section header Header not found."); logger.
			 * info("Test Planning Execution section header text validated successfully.");
			 */

			// Assert.assertTrue(CommonUtil.visibilityOfElementLocated(createNewCycleBtn),
			// "Create New Cycle button not present in Test Planning page.");
			// logger.info("Create New Cycle button verified in Test Planning
			// page.");

			// Assert.assertTrue(testPlanningSectionReleaseNameText.getAttribute("title").equals(releaseName),
			// releaseName + " not verified in Test Planning page.");
			// logger.info(releaseName + " verified successfully on Test Planning Page.");

			logger.info("Test Planning page verified successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean addPhaseToCycle(String cycleName, String phaseName, String bulkAssingTo,
			boolean navigatebackToCycle) {

		try {
			logger.info("Going to Add Phase: " + phaseName + " to Cycle " + cycleName);
			CommonUtil.normalWait(500);

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//a[@data-name='" + cycleName + "']"),
					"Cycle not found by name: " + cycleName);
			WebElement we = CommonUtil.returnWebElement("//a[@data-name='" + cycleName + "']");
			CommonUtil.moveToElement(we);
			CommonUtil.normalWait(500);
			WebElement cycleContextMenu = CommonUtil.returnWebElement("//a[@data-name='" + cycleName + "']//div[contains(@class,'contextMenuIcon')]");
			CommonUtil.ClickOnElementUsingJS(cycleContextMenu);
			CommonUtil.normalWait(500);
			CommonUtil.ClickOnElementUsingJS(linkAddPhase);

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(popupAddNewPhase),
					"Popup Header Add Phase not found.");
			logger.info("Popup Header Add Phase not found successfully.");

			CommonUtil.selectListWithVisibleText(selectExistingPhase, phaseName);
			logger.info("Selected Phase " + phaseName + " successfully in dropdown");
			CommonUtil.normalWait(500);
			// buttonSave.click();
			CommonUtil.ClickOnElementUsingJS(buttonSave);
			CommonUtil.normalWait(2000);
			HomePage.getInstance().waitForProgressBarToComplete();
			logger.info("Clicked on save button successfully.");
			if (!CommonUtil.visibilityOfElementLocated(headerBulkAssignmentInInitial, 5)) {
				CommonUtil.browserRefresh();
				HomePage.getInstance().waitForProgressBarToComplete();
				logger.info("Browser refreshed successfully and now trying to find the popup.");
			}
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerBulkAssignmentInInitial, 5),
					"Bulk Assingment window not found.");

			if (bulkAssingTo.equalsIgnoreCase("creator")) {
				radioButtonAutoAssignToCreator.click();
				logger.info("Clicked on radio button 'creator' successfully.");
				CommonUtil.normalWait(500);
			}
			if (bulkAssingTo.equalsIgnoreCase("anyone")) {
				radioButtonAutoAssignToAnyone.click();
				logger.info("Clicked on radio button 'Anyone' successfully.");
				CommonUtil.normalWait(500);
			}

			buttonSaveInitialBulkAssingment.click();
			logger.info("Clicked on Save button in assingment window successfully.");
			HomePage.getInstance().closeToastPopup();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			if (bulkAssingTo.equalsIgnoreCase("creator") || bulkAssingTo.equalsIgnoreCase("anyone")) {
				if (CommonUtil.visibilityOfElementLocated(headerBulkAssignmentInWarningPopup, 2)) {
					buttonOkInBulkOperationWarningPopup.click();
					CommonUtil.normalWait(2000);
				}
			}

			if (navigatebackToCycle) {
				navigateBackToCycles();
			}

		} catch (Exception e) {
			logger.info("Failed to Add and assign phase");
			e.printStackTrace();
			return false;
		}

		return true;
	}

	public boolean navigateToAssignTestcaseToExecuteWindow(String cycleName, String phaseName,
			boolean initialBulkAssignmentPopupExpected) {
		try {
			logger.info("Going to launch Assign testcase window for cycle: " + cycleName + " and Phase: " + phaseName);
			CommonUtil.normalWait(1000);

			if (!CommonUtil.visibilityOfElementLocated("//a[@data-name='" + cycleName + "']", 5)) {
				CommonUtil.browserRefresh();
				HomePage.getInstance().waitForProgressBarToComplete();
			}

			if (!CommonUtil.visibilityOfElementLocated(
					"//a[@data-name='" + cycleName + "']/following-sibling::ul//a[@data-name='" + phaseName + "']",
					5)) {
				CommonUtil.browserRefresh();
				HomePage.getInstance().waitForProgressBarToComplete();
			}

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//a[@data-name='" + cycleName + "']", 5),
					"Cycle not found by name: " + cycleName);
			Assert.assertTrue(
					CommonUtil.visibilityOfElementLocated("//a[@data-name='" + cycleName
							+ "']/following-sibling::ul//a[@data-name='" + phaseName + "']", 5),
					"Phase not found by name: " + phaseName + "under cycle: " + cycleName);
			HomePage.getInstance().waitForProgressBarToComplete();
			WebElement we = CommonUtil.returnWebElement(
					"//a[@data-name='" + cycleName + "']/following-sibling::ul//a[@data-name='" + phaseName + "']");

			if (we == null) {
				logger.info("Phase: " + phaseName + " was not visible under cycle " + cycleName
						+ " hence going to try browser refresh");
				CommonUtil.browserRefresh();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(2000);
				we = CommonUtil.returnWebElement(
						"//a[@data-name='" + cycleName + "']/following-sibling::ul//a[@data-name='" + phaseName + "']");
				if (we == null) {
					logger.info("Phase: " + phaseName + " is not visible under cycle " + cycleName
							+ " even after browser refresh");
				} else {
					logger.info("Phase: " + phaseName + " was not visible under cycle " + cycleName
							+ ", but after browser refresh able to view successfully");
					Assert.assertTrue(false, "Phase: " + phaseName + " was not visible under cycle " + cycleName
							+ ", but after browser refresh able to view successfully");
				}
			}
			CommonUtil.normalWait(1000);
			CommonUtil.scrollToWebElementAndView(we);
			CommonUtil.normalWait(1000);
			// CommonUtil.visibilityOfElementLocated("//a[@data-name='"+cycleName+"']/following-sibling::ul//a[@data-name='"+phaseName+"']//div[contains(@class,'contextMenuIcon')]");
			// CommonUtil.normalWait(1000);
			// WebElement we1 = CommonUtil.returnWebElement(
			// "//a[@data-name='"+cycleName+"']/following-sibling::ul//a[@data-name='"+phaseName+"']//div[contains(@class,'contextMenuIcon')]");
			WebElement we1 = CommonUtil.returnWebElement(
					"//a[@data-name='" + cycleName + "']/following-sibling::ul//a[@data-name='" + phaseName + "']");
			CommonUtil.actionClass().contextClick(we1).build().perform();
			;
			// CommonUtil.ClickOnElementUsingJS(we1);
			CommonUtil.normalWait(1000);
			CommonUtil.ClickOnElementUsingJS(linkAssing);
			HomePage.getInstance().waitForProgressBarToComplete();

			if (initialBulkAssignmentPopupExpected) {
				CommonUtil.normalWait(2000);
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerBulkAssignmentInInitial),
						"Initial bulk Assingment window not found for Phase with all unassinged testcases on navigating to Assingment window");
				buttonCancelBulkAssignmentPopup.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(2000);
			}

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerAssingTestcasesToExecute, 15000),
					"Header 'Assign Test Cases To Execute' window not found");

		} catch (Exception e) {
			logger.info("Failed to navigate to Assing Test Cases To Execute Window");
			e.printStackTrace();
			return false;
		}

		return true;
	}

	public void verifyPhaseNotVisiblieInHiddenCyclePage(String hiddenCycleName, String phaseName) {
		logger.info("Going to check presence of hidden cycle: " + hiddenCycleName + " but Phase: " + phaseName
				+ " should not be visible in UI");
		CommonUtil.normalWait(1000);

		Assert.assertFalse(CommonUtil.visibilityOfElementLocated("//a[@data-name='" + hiddenCycleName + "']", 5),
				"Cycle not found by name: " + hiddenCycleName);

		Assert.assertFalse(
				CommonUtil.isElementPresent("//a[@data-name='" + hiddenCycleName
						+ "']/following-sibling::ul//a[@data-name='" + phaseName + "']"),
				"Phase should not be visible by name: " + phaseName + "under cycle: " + hiddenCycleName);
		logger.info("Verified that phase: " + phaseName + " is not visible for hidden cycle: " + hiddenCycleName);
	}

	public void verifyPhaseNotVisiblieInCyclePage(String hiddenCycleName, String phaseName) {
		logger.info("Going to check presence of hidden cycle: " + hiddenCycleName + " but Phase: " + phaseName
				+ " should not be visible in UI");
		CommonUtil.normalWait(1000);

		Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//a[@data-name='" + hiddenCycleName + "']", 5),
				"Cycle not found by name: " + hiddenCycleName);

		Assert.assertFalse(
				CommonUtil.isElementPresent("//a[@data-name='" + hiddenCycleName
						+ "']/following-sibling::ul//a[@data-name='" + phaseName + "']"),
				"Phase should not be visible by name: " + phaseName + "under cycle: " + hiddenCycleName);
		logger.info("Verified that phase: " + phaseName + " is not visible for hidden cycle: " + hiddenCycleName);
	}

	public boolean navigateToNodeInAssingTestcaseToExecuteWindow(List<String> nodeList) {
		List<String> nodeDone = new ArrayList<String>();
		String workingNodeName = null;

		for (String nodeName : nodeList) {

			if (!CommonUtil.visibilityOfElementLocated("//a[@data-name='" + nodeName + "']/parent::li", 5)) {
				CommonUtil.browserRefresh();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(2000);
				for (String reExpand : nodeDone) {
					String areaExpanded = CommonUtil.returnWebElement("//a[@data-name='" + reExpand + "']/parent::li")
							.getAttribute("aria-expanded");

					if (areaExpanded != null) {
						if (areaExpanded.equals("true")) {
							CommonUtil.normalWait(1000);
							WebElement we = CommonUtil.returnWebElement("//a[@data-name='" + nodeName + "']");
							CommonUtil.ClickOnElementUsingJS(we);
							HomePage.getInstance().waitForProgressBarToComplete();
							logger.info(reExpand = " Node is already Expanded.");
						} else {
							CommonUtil.normalWait(1000);
							WebElement we = CommonUtil.returnWebElement("//a[@data-name='" + reExpand + "']");
							CommonUtil.doubleClick(we);
							HomePage.getInstance().waitForProgressBarToComplete();
							logger.info("Waiting for the child Node.");
							CommonUtil.visibilityOfElementLocated(
									"//a[@data-name='" + reExpand + "']//following-sibling::ul", 5);
							logger.info("Expanded the Node " + reExpand + " successfully");
						}
					} else {
						CommonUtil.normalWait(1000);
						CommonUtil.browserRefresh();
						HomePage.getInstance().waitForProgressBarToComplete();
						CommonUtil.normalWait(2000);
						CommonUtil.returnWebElement("//a[@data-name='" + reExpand + "']").click();
						HomePage.getInstance().waitForProgressBarToComplete();
					}
				}

			}

			workingNodeName = nodeName;
			HomePage.getInstance().waitForProgressBarToComplete();

			String areaExpanded = CommonUtil.returnWebElement("//a[@data-name='" + nodeName + "']/parent::li")
					.getAttribute("aria-expanded");

			if (areaExpanded != null) {
				if (areaExpanded.equals("true")) {
					CommonUtil.normalWait(1000);
					WebElement we = CommonUtil.returnWebElement("//a[@data-name='" + nodeName + "']");
					CommonUtil.ClickOnElementUsingJS(we);
					HomePage.getInstance().waitForProgressBarToComplete();
					logger.info(nodeName = " Node is already Expanded.");
				} else {
					CommonUtil.normalWait(1000);
					WebElement we = CommonUtil.returnWebElement("//a[@data-name='" + nodeName + "']");
					CommonUtil.doubleClick(we);
					HomePage.getInstance().waitForProgressBarToComplete();
					logger.info("Waiting for the child Node.");
					CommonUtil.visibilityOfElementLocated("//a[@data-name='" + nodeName + "']//following-sibling::ul",
							5);
					logger.info("Expanded the Node " + nodeName + " successfully");
				}
			} else {
				CommonUtil.normalWait(1000);

				CommonUtil.returnWebElement("//a[@data-name='" + nodeName + "']").click();
				HomePage.getInstance().waitForProgressBarToComplete();
			}

			nodeDone.add(workingNodeName);
		}

		return true;
	}

	public void verifyAssigneeOfTestcase(String testcaseName, String assignee, boolean navigateBackToCycles) {

		HomePage.getInstance().waitForProgressBarToComplete();
		CommonUtil.normalWait(1000);
		logger.info("Going to verify testcase in grid by name:  " + testcaseName);
		Assert.assertTrue(CommonUtil.visibilityOfElementLocated(
				"//div[@class='grid-content']//div[text()='" + testcaseName + "']"), "Testcase not found");
		logger.info("Verified testcase in grid by name:  " + testcaseName);
		String actualAssingee = CommonUtil.returnWebElement("//div[@class='grid-content']//div[text()='" + testcaseName
				+ "']/parent::div/parent::div/following-sibling::div[1]//span").getText();
		System.out.println(actualAssingee + " As Actual assinge");

		Assert.assertTrue(actualAssingee.equals(assignee),
				"Assignee not found as " + assignee + " for testcase " + testcaseName);

		if (navigateBackToCycles) {
			navigateBackToCycles();
		}
	}

	public void verifyAbsenceOfTestcaseInCycleAssignmentWindow(String testcaseName, boolean navigateBackToCycles) {

		CommonUtil.normalWait(1000);
		logger.info("Going to verify testcase in grid by name:  " + testcaseName);
		Assert.assertFalse(
				CommonUtil.visibilityOfElementLocated(
						"//div[@class='grid-content']//div[text()='" + testcaseName + "']", 5),
				"Removed testcase is still visible by name: " + testcaseName);
		logger.info("Verified testcase in grid by name:  " + testcaseName);

		if (navigateBackToCycles) {
			navigateBackToCycles();
		}
	}

	public boolean cloneCycle(String cycleName, String clonedCycleNewName, boolean copyTestcaseAssignments) {

		try {
			logger.info("Going to clone cycle: " + cycleName);
			CommonUtil.normalWait(1000);

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//a[@data-name='" + cycleName + "']"),
					"Cycle not found by name: " + cycleName);

			WebElement we = CommonUtil.returnWebElement("//a[@data-name='" + cycleName + "']");
			CommonUtil.moveToElement(we);
			CommonUtil.returnWebElement("//a[@data-name='" + cycleName + "']//div[contains(@class,'contextMenuIcon')]")
					.click();
			CommonUtil.normalWait(1000);
			CommonUtil.ClickOnElementUsingJS(linkClone);
			HomePage.getInstance().waitForProgressBarToComplete();

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerCloneCycle, 10),
					"Header 'Clone Cycle' not found");

			if (clonedCycleNewName != null) {
				CommonUtil.normalWait(500);
				textboxCycleNameInCloneCyclePopup.clear();
				CommonUtil.normalWait(1000);
				textboxCycleNameInCloneCyclePopup.sendKeys(clonedCycleNewName);
				CommonUtil.normalWait(1000);
			}

			if (copyTestcaseAssignments) {
				checkboxCopyTestcaseAssingmentsOver.click();
				CommonUtil.normalWait(2000);
			}

			buttonSaveInCloneCycleWindow.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(5000);

		} catch (Exception e) {
			logger.info("Failed to clone cycle");
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean assignTestIndividually(String testcaseName, String assignee, boolean navigateBackToCycles) {

		CommonUtil.normalWait(1000);
		logger.info("Going to verify testcase in grid by name:  " + testcaseName);
		Assert.assertTrue(CommonUtil.visibilityOfElementLocated(
				"//div[@class='grid-content']//div[text()='" + testcaseName + "']"), "Testcase not found");
		logger.info("Verified testcase in grid by name:  " + testcaseName);
		logger.info("Going to change assignee of testcase:  " + testcaseName + " to assignee: " + assignee);
		CommonUtil.moveToElement("//div[@class='grid-content']//div[text()='" + testcaseName
				+ "']/parent::div/parent::div/following-sibling::div[1]//span");
		CommonUtil.normalWait(1000);
		CommonUtil.returnWebElement("//div[@class='grid-content']//div[text()='" + testcaseName
				+ "']/parent::div/parent::div/following-sibling::div[1]//span").click();
		HomePage.getInstance().waitForProgressBarToComplete();
		CommonUtil.normalWait(1000);

		CommonUtil.returnWebElement("//span[@class='select2-results']/ul/li[text()='" + assignee + "']").click();
		HomePage.getInstance().closeToastPopup();
		HomePage.getInstance().waitForProgressBarToComplete();
		CommonUtil.normalWait(5000);

		String actualAssingee = CommonUtil.returnWebElement("//div[@class='grid-content']//div[text()='" + testcaseName
				+ "']/parent::div/parent::div/following-sibling::div[1]//span").getText();

		Assert.assertTrue(actualAssingee.equals(assignee),
				"Assignee not changed to " + assignee + " for testcase " + testcaseName);

		if (navigateBackToCycles) {
			navigateBackToCycles();
		}

		return true;
	}

	public boolean bulkAssignNotExecutedTest(String assignee, boolean applySubFolders, boolean navigateBackToCycles) {

		try {
			CommonUtil.normalWait(1000);
			logger.info("Going to click on bulk Assignment icon");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(iconBulkAssign, 10), "Icon bulk Assing not found");
			CommonUtil.ClickOnElementUsingJS(iconBulkAssign);
			HomePage.getInstance().waitForProgressBarToComplete();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerBulkAssignment),
					"Header bulk Assignment not found");
			// CommonUtil.normalWait(1000);
			radioButtonAssignAllNotExecutedTest.click();
			CommonUtil.normalWait(1000);
			selectAssigneeDropdownInBulkWindowForOptionNotExecutedTest.click();
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement("//span[@class='select2-results']//li[text()='" + assignee + "']").click();
			// CommonUtil.selectListWithVisibleText(selectAssigneeDropdownInBulkWindowForOptionNotExecutedTest,
			// assignee);
			// CommonUtil.selectListWithValue(selectAssigneeDropdownInBulkWindowForOptionNotExecutedTest,
			// assignee);
			CommonUtil.normalWait(2000);

			if (applySubFolders) {
				checkboxApplySubfolderInBulkWindowForOptionNotExecutedTest.click();
				CommonUtil.normalWait(1000);
			}

			buttonSaveInBulkAssignmentPopup.click();
			HomePage.getInstance().closeToastPopup();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(4000);

			if (CommonUtil.visibilityOfElementLocated(headerBulkAssignmentInWarningPopup, 2)) {
				buttonOkInBulkOperationWarningPopup.click();
				CommonUtil.normalWait(1000);
			}

			CommonUtil.normalWait(3000);

			if (navigateBackToCycles) {
				navigateBackToCycles();
			}

		} catch (Exception e) {
			logger.info("Failed to Bulk Assing Not Executed Test to :" + assignee);
			e.printStackTrace();
		}

		return true;
	}

	public boolean bulkAssignUnassignedTest(String assignee, boolean applySubFolders, boolean navigateBackToCycles) {

		try {
			CommonUtil.normalWait(1000);
			logger.info("Going to click on bulk Assignment icon");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(iconBulkAssign, 10), "Icon bulk Assing not found");
			iconBulkAssign.click();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerBulkAssignment),
					"Header bulk Assignment not found");
			CommonUtil.normalWait(1000);
			radioButtonAssignAllUnassignedTest.click();
			CommonUtil.normalWait(500);
			selectAssigneeDropdownInBulkWindowForOptionUnassignedTest.click();
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement("//span[@class='select2-results']//li[text()='" + assignee + "']").click();
			// CommonUtil.selectListWithVisibleText(selectAssigneeDropdownInBulkWindowForOptionUnassignedTest,
			// assignee);
			CommonUtil.normalWait(2000);

			if (applySubFolders) {
				checkboxApplySubfolderInBulkWindowForOptionUnassignedTest.click();
				CommonUtil.normalWait(1000);
			}

			buttonSaveInBulkAssignmentPopup.click();
			HomePage.getInstance().closeToastPopup();
			HomePage.getInstance().waitForProgressBarToComplete();
			if (CommonUtil.visibilityOfElementLocated(headerBulkAssignmentInWarningPopup, 2)) {
				buttonOkInBulkOperationWarningPopup.click();
				CommonUtil.normalWait(1000);
			}
			CommonUtil.normalWait(4000);

			if (navigateBackToCycles) {
				navigateBackToCycles();
			}

		} catch (Exception e) {
			logger.info("Failed to Bulk Assing Unassigned Test to :" + assignee);
			e.printStackTrace();
		}

		return true;
	}

	public boolean bulkAssignAllAssignedButNotExecutedTest(String fromAssignee, String toAssignee,
			boolean applySubFolders, boolean navigateBackToCycles) {

		try {
			CommonUtil.normalWait(1000);
			logger.info("Going to click on bulk Assignment icon");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(iconBulkAssign, 10), "Icon bulk Assing not found");
			iconBulkAssign.click();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerBulkAssignment),
					"Header bulk Assignment not found");
			CommonUtil.normalWait(1000);
			radioButtonAssignAllAssignedButNotExecutedTest.click();
			CommonUtil.normalWait(500);
			CommonUtil.selectListWithVisibleText(
					selectFromAssigneeDropdownInBulkWindowForOptionAssignButNotExecutedTest, fromAssignee);
			CommonUtil.normalWait(1000);
			CommonUtil.selectListWithVisibleText(selectToAssigneeDropdownInBulkWindowForOptionAssignButNotExecutedTest,
					toAssignee);
			CommonUtil.normalWait(2000);

			if (applySubFolders) {
				checkboxApplySubfolderInBulkWindowForOptionAssignButNotExecutedTest.click();
				CommonUtil.normalWait(1000);
			}

			buttonSaveInBulkAssignmentPopup.click();
			HomePage.getInstance().closeToastPopup();
			HomePage.getInstance().waitForProgressBarToComplete();
			if (CommonUtil.visibilityOfElementLocated(headerBulkAssignmentInWarningPopup, 2)) {
				buttonOkInBulkOperationWarningPopup.click();
				CommonUtil.normalWait(1000);
			}
			CommonUtil.normalWait(5000);

			if (navigateBackToCycles) {
				navigateBackToCycles();
			}

		} catch (Exception e) {
			logger.info("Failed to Bulk Assing All assigned but not executed test from :" + fromAssignee + " to: "
					+ toAssignee);
			e.printStackTrace();
		}

		return true;
	}

	public boolean addFreeformPhaseToCycle(String cycleName, String freeformPhaseName, boolean navigateBackToCycles) {

		try {
			logger.info("Going to Add Freeform Phase by name: " + freeformPhaseName + " to Cycle " + cycleName);
			CommonUtil.normalWait(1000);

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//a[@data-name='" + cycleName + "']", 4),
					"Cycle not found by name: " + cycleName);
			CommonUtil.normalWait(500);
			WebElement we = CommonUtil.returnWebElement("//a[@data-name='" + cycleName + "']");
			CommonUtil.moveToElement(we);
			CommonUtil.normalWait(500);
			WebElement cycleWe = CommonUtil
					.returnWebElement("//a[@data-name='" + cycleName + "']//div[contains(@class,'contextMenuIcon')]");
			CommonUtil.ClickOnElementUsingJS(cycleWe);
			CommonUtil.normalWait(1000);
			CommonUtil.ClickOnElementUsingJS(linkAddPhase);

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(popupAddNewPhase),
					"Popup Header Add Phase not found.");
			logger.info("Popup Header Add Phase found successfully.");

			CommonUtil.normalWait(1000);
			radioButtonCreateNewFreeformPhase.click();
			CommonUtil.normalWait(1000);
			textBoxFreeformPhaseNameInAddPhase.sendKeys(freeformPhaseName);
			CommonUtil.normalWait(1000);
			buttonSave.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			logger.info("Clicked on save button successfully.");
			CommonUtil.normalWait(5000);

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//a[@data-name='" + freeformPhaseName + "']"),
					"Freeform phase: " + freeformPhaseName + " not found after adding to cycle");

			if (navigateBackToCycles) {
				navigateBackToCycles();
			}

		} catch (Exception e) {
			logger.info("Failed to add Freeform phase to cycle: " + cycleName + ", Tried with Freeform Phase name: "
					+ freeformPhaseName);
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean addFreeformChildNode(String freeformNodeNameToAddChildNodes, List<String> freeformChildNodeNames,
			boolean navigateBackToCycles) {

		for (String ffChildNodeDetails : freeformChildNodeNames) {

			String ffDetails[] = ffChildNodeDetails.split(">");
			String ffChildNodeName = ffDetails[0];

			String ffChildNodeDescription = null;

			if (ffDetails.length == 2) {
				ffChildNodeDescription = ffDetails[1];
			}

			logger.info("Going to Add Chld node: " + ffChildNodeName + " in Freeform Phase: "
					+ freeformNodeNameToAddChildNodes);
			CommonUtil.normalWait(1000);
			CommonUtil.normalWait(1000);
			Assert.assertTrue(
					CommonUtil.visibilityOfElementLocated("//a[@data-name='" + freeformNodeNameToAddChildNodes + "']"),
					"Freeform Phase not found by name: " + freeformNodeNameToAddChildNodes);
			WebElement we = CommonUtil.returnWebElement("//a[@data-name='" + freeformNodeNameToAddChildNodes + "']");
			CommonUtil.moveToElement(we);
			CommonUtil.returnWebElement("//a[@data-name='" + freeformNodeNameToAddChildNodes
					+ "']//div[contains(@class,'contextMenuIcon')]").click();
			CommonUtil.normalWait(1000);
			CommonUtil.ClickOnElementUsingJS(linkAddNodeInFreeform);

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerAddNodeInFreeform),
					"Popup Header Add Node not found to add nodes in freeform");
			logger.info("Popup Header Add Node found successfully to add node in freeform");
			CommonUtil.normalWait(1000);
			textBoxFreeformChildNodeName.sendKeys(ffChildNodeName);
			CommonUtil.normalWait(1000);

			if (ffChildNodeDescription != null) {
				textBoxFreeformChildNodeDescription.sendKeys(ffChildNodeDescription);
				CommonUtil.normalWait(1000);
			}
			buttonSaveFreeformChildNode.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(5000);
		}
		if (navigateBackToCycles) {
			navigateBackToCycles();
		}

		return true;
	}

	public boolean editFreeformChildNode(String freeformNodeNameToEdit, String newNodeName, String newNodeDescription,
			boolean navigateBackToCycles) {

		try {
			logger.info("Going to Edit Freeform node: " + freeformNodeNameToEdit + " to: " + newNodeName);
			CommonUtil.normalWait(1000);

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//a[@data-name='" + freeformNodeNameToEdit + "']"),
					"Freeform Node not found by name: " + freeformNodeNameToEdit);
			WebElement we = CommonUtil.returnWebElement("//a[@data-name='" + freeformNodeNameToEdit + "']");
			CommonUtil.scrollToWebElementAndView(we);
			CommonUtil
					.returnWebElement(
							"//a[@data-name='" + freeformNodeNameToEdit + "']//div[contains(@class,'contextMenuIcon')]")
					.click();
			CommonUtil.normalWait(1000);
			CommonUtil.ClickOnElementUsingJS(linkEditNodeInFreeform);

			CommonUtil.normalWait(1000);
			textBoxFreeformChildNodeName.clear();
			CommonUtil.normalWait(1000);
			textBoxFreeformChildNodeName.sendKeys(newNodeName);
			CommonUtil.normalWait(1000);

			if (newNodeDescription != null) {
				textBoxFreeformChildNodeDescription.clear();
				CommonUtil.normalWait(1000);
				textBoxFreeformChildNodeDescription.sendKeys(newNodeDescription);
				CommonUtil.normalWait(1000);
			}
			buttonSaveEditedFreeformNode.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(5000);
			if (navigateBackToCycles) {
				navigateBackToCycles();
			}

		} catch (Exception e) {
			logger.info("Failed to Edit Freeform node cleanly");
			e.printStackTrace();
		}

		return true;
	}

	public boolean deleteFreeformChildNodeAndVerify(String freeformNodeNameToDelete, boolean navigateBackToCycles) {

		try {
			logger.info("Going to Delete Freeform node: " + freeformNodeNameToDelete);
			CommonUtil.normalWait(1000);

			Assert.assertTrue(
					CommonUtil.visibilityOfElementLocated("//a[@data-name='" + freeformNodeNameToDelete + "']"),
					"Freeform Node not found by name: " + freeformNodeNameToDelete);
			WebElement we = CommonUtil.returnWebElement("//a[@data-name='" + freeformNodeNameToDelete + "']");
			CommonUtil.scrollToWebElementAndView(we);
			CommonUtil.returnWebElement(
					"//a[@data-name='" + freeformNodeNameToDelete + "']//div[contains(@class,'contextMenuIcon')]")
					.click();
			CommonUtil.normalWait(1000);
			CommonUtil.ClickOnElementUsingJS(linkDeleteNodeInFreeform);
			CommonUtil.visibilityOfElementLocated(buttonYesToConfirmDelete);
			CommonUtil.normalWait(1000);
			buttonYesToConfirmDelete.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(5000);

			Assert.assertFalse(CommonUtil.isElementPresent("//a[@data-name='" + freeformNodeNameToDelete + "']"),
					"Failed to delete Freeform Node: " + freeformNodeNameToDelete);

			if (navigateBackToCycles) {
				navigateBackToCycles();
			}

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

		return true;
	}

	public boolean addTestcaseToFreeformNodeBrowse(String freeFormName, String phaseName, String nodeName,
			String subNodeName, boolean bringHierarchy) {

		logger.info("Going to launch Add Testcases window");

		Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//a[@data-name='" + freeFormName + "']"),
				"Freeform phase not found");
		WebElement we0 = CommonUtil.returnWebElement("//a[@data-name='" + freeFormName + "']");
		CommonUtil.moveToElement(we0);
		CommonUtil.returnWebElement("//a[@data-name='" + freeFormName + "']").click();
		// selectNode.click();
		CommonUtil.normalWait(1000);
		Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonToLaunchAddTestcasesWindowForFreeform),
				"Button to launch Add Testcase Window not found");
		buttonToLaunchAddTestcasesWindowForFreeform.click();
		CommonUtil.normalWait(1000);

		Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerAddTestcases), "Header Add Testcases not found");
		logger.info("Add Testcases window launched successfully");
		selectBrowse.click();
		CommonUtil.normalWait(1000);
		BrowseReleaseSelect.click();
		CommonUtil.normalWait(1000);

		if (phaseName != null) {
			Assert.assertTrue(
					CommonUtil.visibilityOfElementLocated(
							"//a[text()='" + phaseName + "']/preceding::i[@class='jstree-icon jstree-ocl'][1]"),
					"Phase Node not found by name: " + phaseName);
			WebElement we = CommonUtil.returnWebElement(
					"//a[text()='" + phaseName + "']/preceding::i[@class='jstree-icon jstree-ocl'][1]");
			CommonUtil.moveToElement(we);
			CommonUtil.returnWebElement(
					"//a[text()='" + phaseName + "']/preceding::i[@class='jstree-icon jstree-ocl'][1]").click();
		}

		CommonUtil.normalWait(1000);

		if (nodeName != null) {
			Assert.assertTrue(
					CommonUtil.visibilityOfElementLocated(
							"//a[text()='" + nodeName + "']/preceding::i[@class='jstree-icon jstree-ocl'][1]"),
					" Node not found by name: " + nodeName);
			WebElement we1 = CommonUtil.returnWebElement(
					"//a[text()='" + nodeName + "']/preceding::i[@class='jstree-icon jstree-ocl'][1]");
			CommonUtil.moveToElement(we1);
			CommonUtil
					.returnWebElement("//a[text()='" + nodeName + "']/preceding::i[@class='jstree-icon jstree-ocl'][1]")
					.click();
		}

		// subNodeSelect.click();
		CommonUtil.normalWait(1000);
		Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//a[text()='" + subNodeName + "']"),
				" SubnodeNode not found by name: " + subNodeName);
		// WebElement we2 =
		// CommonUtil.returnWebElement("//a[@data-name='"+subNodeName+"']");
		// CommonUtil.moveToElement(we2);
		CommonUtil.returnWebElement("//a[text()='" + subNodeName + "']").click();

		CommonUtil.normalWait(1000);
		CommonUtil.scrollToWebElementAndView(selectAll);
		CommonUtil.ClickOnElementUsingJS(selectAll);
		CommonUtil.normalWait(1000);
		// checkboxBringHeirarchy.click();
		if (bringHierarchy) {
			CommonUtil.scrollToWebElementAndView(checkboxBringHeirarchy);
			checkboxBringHeirarchy.click();
			CommonUtil.normalWait(1000);
		}

		CommonUtil.normalWait(1000);
		browseAndSave.click();
		Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonOkInConfirmationOfTestcaseAdded),
				"Button ok on tosterd message is not found");
		CommonUtil.normalWait(1000);
		buttonOkInConfirmationOfTestcaseAdded.click();

		HomePage.getInstance().waitForProgressBarToComplete();
		CommonUtil.normalWait(2000);
		Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonCancelInAddTestcaseWindow),
				"Button to close browse window is not fount");
		HomePage.getInstance().waitForProgressBarToComplete();
		CommonUtil.normalWait(1000);
		buttonCancelInAddTestcaseWindow.click();

		HomePage.getInstance().waitForProgressBarToComplete();
		CommonUtil.normalWait(1000);

		return true;
	}

	public boolean addTestcaseToFreeformNode(String searchType, String searchQuery, List<String> expectedTestcases,
			boolean addAllFetchedTestcases, boolean selectAllCheckboxInGrid, boolean bringHierarchy) {

		try {
			logger.info("Going to launch Add Testcases window");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonToLaunchAddTestcasesWindowForFreeform),
					"Button to launch Add Testcase Window not found");
			buttonToLaunchAddTestcasesWindowForFreeform.click();
			CommonUtil.normalWait(1000);

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerAddTestcases),
					"Header Add Testcases not found");
			logger.info("Add Testcases window launched successfully");

			if (searchType.equalsIgnoreCase("Quick")) {
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonQuick),
						"Radio button Quick not found");
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textAreaForQuickSearch),
						"Text Area for Quick search not found");
				CommonUtil.normalWait(1000);
				textAreaForQuickSearch.sendKeys(searchQuery);
				CommonUtil.normalWait(1000);
				buttonGo.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);

			} else {
				if (searchType.equalsIgnoreCase("Advanced")) {
					logger.info("Going to select Advanced Search Option");
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonAdvanced),
							"Radio button Advanced not found");
					radioButtonAdvanced.click();
					CommonUtil.normalWait(1000);
					logger.info("Clicked on Advanced Search Option successfully");

					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textAreaForAdvanceSearch),
							"Text Area for Advance search not found");
					CommonUtil.normalWait(1000);
					textAreaForAdvanceSearch.sendKeys(searchQuery);
					CommonUtil.normalWait(1000);
					buttonGo.click();
					CommonUtil.normalWait(1000);
					HomePage.getInstance().waitForProgressBarToComplete();

				} else {
					Assert.assertTrue(false,
							"Please provide proper search Type in Test, Expected values are: Quick, Advanced");
				}
			}
			int testcasesCheckedToAdd = 0;
			for (String fetchedTestcase : expectedTestcases) {

				if (addAllFetchedTestcases) {

					logger.info("Going to verify searched testcase by name: " + fetchedTestcase);
					Assert.assertTrue(
							CommonUtil.visibilityOfElementLocated(
									"//*[@id='grid-table-eas_add_search']//div[text()='" + fetchedTestcase + "']"),
							"Testcase not found after search by name: " + fetchedTestcase);
					logger.info("Verified searched testcase by name: " + fetchedTestcase);
				} else {
					logger.info("Going to verify searched testcase by name: " + fetchedTestcase);
					Assert.assertTrue(
							CommonUtil.visibilityOfElementLocated(
									"//*[@id='grid-table-eas_add_search']//div[text()='" + fetchedTestcase + "']"),
							"Testcase not found after search by name: " + fetchedTestcase);
					logger.info("Verified searched testcase by name: " + fetchedTestcase);
					logger.info("Going to select checkbox for testcase by name: " + fetchedTestcase);
					CommonUtil.returnWebElement("(//div[@id='grid-table-eas_add_search']//div[text()='"
							+ fetchedTestcase
							+ "']/parent::div/parent::div/preceding-sibling::div//input[@name='testcase_select'])[1]")
							.click();
					CommonUtil.normalWait(1000);
					testcasesCheckedToAdd++;
				}

			}

			if (addAllFetchedTestcases) {
				checkboxSaveAllTestcasesFetchedBySearch.click();
				testcasesCheckedToAdd = Integer.parseInt(CommonUtil
						.returnWebElement(
								"//div[@id='zui-freeform-testcase-add-grid-wrapper']//div[@class='page-track']/b[3]")
						.getText());
				CommonUtil.normalWait(1000);
			} else {
				if (selectAllCheckboxInGrid) {
					checkboxSelectAllTestcaseInGrid.click();
					testcasesCheckedToAdd = Integer.parseInt(CommonUtil.returnWebElement(
							"//div[@id='zui-freeform-testcase-add-grid-wrapper']//div[@class='page-track']/b[2]")
							.getText());
					CommonUtil.normalWait(1000);
				}
			}

			if (bringHierarchy) {
				checkboxBringHeirarchy.click();
				CommonUtil.normalWait(1000);
			}

			buttonSaveToAddFetchedTestcaseToFreeform.click();
			HomePage.getInstance().waitForProgressBarToComplete();

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerAddTestcasesStatus),
					"Status popup not found after adding testcase in freeform node");

			Assert.assertTrue(
					CommonUtil.visibilityOfElementLocated("//div[@id='testcaseAdded']/span[text()='"
							+ testcasesCheckedToAdd + " testcase/schedule(s) were added to this phase.']"),
					"Added testcases count is not matching in Status popup, expected count: " + testcasesCheckedToAdd);

			CommonUtil.normalWait(1000);

			buttonOkInConfirmationOfTestcaseAdded.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			buttonCancelInAddTestcaseWindow.click();

			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);

		} catch (Exception e) {
			logger.info("Failed to add Testcase in freeform node cleanly");
			e.printStackTrace();
			return false;
		}

		return true;
	}

	public boolean addTestcaseToFreeformNodeFromAnotherCycle(String fromCycle, String fromPhase, String withStatus,
			List<String> expectedTestcases, boolean selectAllCheckboxInGrid, boolean bringHierarchy) {

		try {
			logger.info("Going to launch Add Testcases window");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonToLaunchAddTestcasesWindowForFreeform),
					"Button to launch Add Testcase Window not found");
			buttonToLaunchAddTestcasesWindowForFreeform.click();
			CommonUtil.normalWait(1000);

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerAddTestcases),
					"Header Add Testcases not found");
			logger.info("Add Testcases window launched successfully");

			CommonUtil.normalWait(1000);
			optionOtherCycle.click();

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(selectCycleInAddTestcaseFromAnotherCycle),
					"Select Cycle Dropdown not found");
			CommonUtil.normalWait(1000);

			CommonUtil.selectListWithVisibleText(selectCycleInAddTestcaseFromAnotherCycle, fromCycle);
			CommonUtil.normalWait(1000);

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(selectPhaseInAddTestcaseFromAnotherCycle),
					"Select Phase Dropdown not found");
			CommonUtil.normalWait(1000);

			CommonUtil.selectListWithVisibleText(selectPhaseInAddTestcaseFromAnotherCycle, fromPhase);
			CommonUtil.normalWait(1000);

			Assert.assertTrue(CommonUtil.isElementPresent(selectStatusInAddTestcaseFromAnotherCycle),
					"Select Status Dropdown not found");
			CommonUtil.normalWait(1000);
			selectStatusInAddTestcaseFromAnotherCycleclick.click();
			CommonUtil.returnWebElement("//span[@class='select2-results']//li[text()='" + withStatus + "']").click();

			// CommonUtil.selectListWithVisibleText(selectStatusInAddTestcaseFromAnotherCycle,
			// withStatus);
			CommonUtil.normalWait(1000);

			buttonGoInAddTestcaseFromAnotherCycle.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);

			int testcasesCheckedToAdd = 0;
			if (selectAllCheckboxInGrid) {
				checkboxSelectAllTestcaseInGridInOtherCycle.click();
				testcasesCheckedToAdd = Integer.parseInt(CommonUtil
						.returnWebElement(
								"//div[@id='zui-freeform-testcase-add-grid-wrapper']//div[@class='page-track']/b[2]")
						.getText());
				CommonUtil.normalWait(1000);
			} else {
				for (String fetchedTestcase : expectedTestcases) {
					logger.info("Going to verify searched testcase by name: " + fetchedTestcase);
					Assert.assertTrue(
							CommonUtil.visibilityOfElementLocated(
									"//*[@id='grid-table-other_cycle']//div[text()='" + fetchedTestcase + "']"),
							"Testcase not found after search by name: " + fetchedTestcase);
					logger.info("Verified searched testcase by name: " + fetchedTestcase);
					logger.info("Going to select checkbox for testcase by name: " + fetchedTestcase);
					CommonUtil.returnWebElement("//div[@id='grid-table-other_cycle']//div[text()='" + fetchedTestcase
							+ "']/parent::div/parent::div/preceding-sibling::div//input[@name='testcase_select']")
							.click();
					CommonUtil.normalWait(1000);
					testcasesCheckedToAdd++;
				}
			}

			if (bringHierarchy) {
				checkboxBringHeirarchy.click();
				CommonUtil.normalWait(1000);
			}

			buttonSaveToAddFetchedTestcaseToFreeform.click();
			HomePage.getInstance().waitForProgressBarToComplete();

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerAddTestcasesStatus),
					"Status popup not found after adding testcase in freeform node");

			Assert.assertTrue(
					CommonUtil.visibilityOfElementLocated("//div[@id='testcaseAdded']/span[text()='"
							+ testcasesCheckedToAdd + " testcase/schedule(s) were added to this phase.']"),
					"Added testcases count is not matching in Status popup, expected count: " + testcasesCheckedToAdd);

			CommonUtil.normalWait(1000);

			buttonOkInConfirmationOfTestcaseAdded.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			buttonCancelInAddTestcaseWindow.click();

			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean syncSelectedNode(List<String> nodesNameWithTestCountAdded,
			List<String> nodesNameWithTestCountDeleted, boolean removeDeleted, boolean navigateBackToCycles) {

		try {
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonSync), "Sync Button not found.");
			CommonUtil.normalWait(1000);
			buttonSync.click();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerProceedWithSynchronization),
					"Header 'Proceed with Synchronization' not found.");
			CommonUtil.normalWait(1000);

			if (removeDeleted) {
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(checkboxAndLabelSyncDeletedNodeTestcases),
						"Checkbox Sync Delete Node Testcases not found");
				checkboxAndLabelSyncDeletedNodeTestcases.click();
				CommonUtil.normalWait(1000);

			}
            CommonUtil.moveToElement(buttonContinueSync);
            CommonUtil.normalWait(1000);
			buttonContinueSync.click();
			if (CommonUtil.visibilityOfElementLocated(headerWarningForSync, 2)) {
				CommonUtil.normalWait(2000);
				buttonContinueSyncInWarningPopup.click();
				HomePage.getInstance().waitForProgressBarToComplete();
			}
			CommonUtil.normalWait(4000);
			if(CommonUtil.visibilityOfElementLocated(headerChangesMadeForSync)){
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerChangesMadeForSync),
					"Header Changes Made not found after sync.");
			}else{
				logger.info("Change Header Not found ");
			}
			
			if (nodesNameWithTestCountAdded != null) {
				int totalTestcaseIncludingAllNodes = 0;

				for (String nodeNameWithTestCount : nodesNameWithTestCountAdded) {
					String nodeNameWithCount[] = nodeNameWithTestCount.split(Constants.CHAR_TO_SPLIT_STRING);
					String nodeName = nodeNameWithCount[0];
					String testCount = nodeNameWithCount[1];

					Assert.assertTrue(
							CommonUtil.visibilityOfElementLocated("//div[@id='sync-messages-modal']//p[text()='"
									+ testCount + " testcase(s) added to \"" + nodeName + "\".']"),
							"Added Testcase count not matching, Expected String: " + testCount
									+ " testcase(s) added to \"" + nodeName + "\".");
					totalTestcaseIncludingAllNodes = totalTestcaseIncludingAllNodes + Integer.parseInt(testCount);

				}

				Assert.assertTrue(
						CommonUtil.visibilityOfElementLocated("//div[@id='sync-messages-modal']//p[text()='"
								+ totalTestcaseIncludingAllNodes + " testcase(s) added to this phase.']"),
						"Total Testcase added count not matched, Expected String: " + totalTestcaseIncludingAllNodes
								+ " testcase(s) added to this phase.']");

			}

			if (removeDeleted) {
				if (nodesNameWithTestCountDeleted != null) {
					int totalTestcaseDeletedInAllNodes = 0;

					for (String nodeNameWithTestCount : nodesNameWithTestCountDeleted) {
						String nodeNameWithCount[] = nodeNameWithTestCount.split(Constants.CHAR_TO_SPLIT_STRING);
						String nodeName = nodeNameWithCount[0];
						String testCount = nodeNameWithCount[1];

						Assert.assertTrue(
								CommonUtil.visibilityOfElementLocated("//div[@id='sync-messages-modal']//p[text()='"
										+ testCount + " testcase(s) deleted from \"" + nodeName + "\".']"),
								"Added Testcase count not matching, Expected String: " + testCount
										+ " testcase(s) deleted from \"" + nodeName + "\".");
						totalTestcaseDeletedInAllNodes = totalTestcaseDeletedInAllNodes + Integer.parseInt(testCount);
					}

					Assert.assertTrue(
							CommonUtil.visibilityOfElementLocated("//div[@id='sync-messages-modal']//p[text()='"
									+ totalTestcaseDeletedInAllNodes + " testcase(s) deleted from this phase.']"),
							"Total Testcase added count not matched, Expected String: " + totalTestcaseDeletedInAllNodes
									+ " testcase(s) deleted from this phase.']");

				}
			} else {

			}

			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(2000);

			buttonOkInSyncChangesMade.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();

			if (navigateBackToCycles) {
				navigateBackToCycles();
			}

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

		return true;
	}

	public boolean deleteTestcaseFromSelectedNodeInAssingTestcaseToExecuteWindow(
			List<String> testcaseNamesInSelectedNode, boolean navigateBackToCycles) {
		try {
			int totalTestcaseSelectedToDelete = 0;
			for (String testcaseName : testcaseNamesInSelectedNode) {
				Assert.assertTrue(
						CommonUtil.visibilityOfElementLocated(
								"//div[@id='grid-table-phase']//div[text()='" + testcaseName + "']"),
						"Testcase Not found to delete");

				WebElement checkboxOfTestcase = CommonUtil
						.returnWebElement("//div[@id='grid-table-phase']//div[text()='" + testcaseName
								+ "']/parent::div/parent::div/preceding-sibling::div//div[@class='zui-checkbox2']");

				if (checkboxOfTestcase != null) {
					CommonUtil.normalWait(1000);
					checkboxOfTestcase.click();
					CommonUtil.normalWait(1000);

					totalTestcaseSelectedToDelete++;
				} else {
					logger.info("Checkbox not found to select testcase");
					Assert.assertTrue(false, "Checkbox not found to select testcase");
				}
			}

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonDeleteSelectedTestcase),
					"Delete button not found to delete selected testcases");

			buttonDeleteSelectedTestcase.click();

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerConfirmationDelete),
					"Header Confirmation Delete popup not found");

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(
					"//div[@id='confirmation-modal']//p[normalize-space(text())='Are you sure you want to delete "
							+ totalTestcaseSelectedToDelete + " testcase ?']"),
					"Testcase count displayed incorrect in confirmation popup, Expected: "
							+ totalTestcaseSelectedToDelete);

			CommonUtil.normalWait(1000);

			buttonDeleteInConfirmationPopup.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);

			if (navigateBackToCycles) {
				navigateBackToCycles();
			}

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			navigateBackToCycles();
		}

		return true;
	}

	public boolean deleteCyclePhase(String cycleName, String phaseName) {

		try {
			logger.info("Going to launch Assign testcase window for cycle: " + cycleName + " and Phase: " + phaseName);
			CommonUtil.normalWait(1000);

			if (!CommonUtil.visibilityOfElementLocated("//a[@data-name='" + cycleName + "']", 5)) {
				CommonUtil.browserRefresh();
				HomePage.getInstance().waitForProgressBarToComplete();
			}
			if (!CommonUtil.visibilityOfElementLocated(
					"//a[@data-name='" + cycleName + "']/following-sibling::ul//a[@data-name='" + phaseName + "']",
					5)) {
				CommonUtil.browserRefresh();
				HomePage.getInstance().waitForProgressBarToComplete();
			}

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//a[@data-name='" + cycleName + "']"),
					"Cycle not found by name: " + cycleName);
			Assert.assertTrue(
					CommonUtil.visibilityOfElementLocated("//a[@data-name='" + cycleName
							+ "']/following-sibling::ul//a[@data-name='" + phaseName + "']"),
					"Phase not found by name: " + phaseName + "under cycle: " + cycleName);
			HomePage.getInstance().waitForProgressBarToComplete();
			WebElement we = CommonUtil.returnWebElement(
					"//a[@data-name='" + cycleName + "']/following-sibling::ul//a[@data-name='" + phaseName + "']");

			CommonUtil.moveToElement(we);
			CommonUtil.returnWebElement("//a[@data-name='" + cycleName + "']/following-sibling::ul//a[@data-name='"
					+ phaseName + "']//div[contains(@class,'contextMenuIcon')]").click();
			CommonUtil.normalWait(1000);
			CommonUtil.ClickOnElementUsingJS(linkDelete);
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerDeleteNode),
					"Header delete not found in Confirmation popup");
			buttonDeleteNodeInCycle.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

		return true;
	}

	public void verifyAbsenseOfCycle(String cycleName) {

	}

	public boolean verifyTestcaseCountOfSelectedNode(String nodeName, int testCaseCount, boolean navigateBackToCycles) {

		try {

			HomePage.getInstance().waitForProgressBarToComplete();

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//a[@data-name='" + nodeName + "']"),
					"Node: " + nodeName + " not found");
			WebElement nodeElement = CommonUtil.returnWebElement("//a[@data-name='" + nodeName + "']");
			String nodeCount = nodeElement.getAttribute("data-count").split("/")[0];

			System.out.println(nodeCount + " for node ");

			int number = Integer.parseInt(nodeCount);
			Assert.assertTrue(number == testCaseCount, "Node count not matched");

			if (navigateBackToCycles) {
				navigateBackToCycles();
			}

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

		return true;
	}

	public boolean navigateBackToCycles() {
		try {
			CommonUtil.normalWait(1000);
			iconToNavigateBackToCycle.click();
			logger.info("Navigated back to cycle");
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean exportCycle(String cycleName, String reportType, String outputAs) {
		try {
			logger.info("Going to launch Export Window");
			CommonUtil.normalWait(1000);

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//a[@data-name='" + cycleName + "']"),
					"Cycle not found by name: " + cycleName);

			WebElement we = CommonUtil.returnWebElement("//a[@data-name='" + cycleName + "']");
			CommonUtil.moveToElement(we);
			CommonUtil.returnWebElement("//a[@data-name='" + cycleName + "']//div[contains(@class,'contextMenuIcon')]")
					.click();
			CommonUtil.normalWait(1000);
			CommonUtil.ClickOnElementUsingJS(linkExport);
			HomePage.getInstance().waitForProgressBarToComplete();

			logger.info("Clicked on Export in Context menu");
			CommonUtil.normalWait(5000);

			if (reportType.equalsIgnoreCase("Excel")) {
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDataExcel),
						"Excel export not found in Export window");
				radioButtonDataExcel.click();

			} else {
				if (reportType.equalsIgnoreCase("Summary")) {
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonSummary),
							"Summary export not found in Export window");
					radioButtonSummary.click();

				} else {
					if (reportType.equalsIgnoreCase("Detailed")) {
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDetailed),
								"Detailed export not found in Export window");
						radioButtonDetailed.click();
					}
				}
				CommonUtil.normalWait(1000);
				if (outputAs.equalsIgnoreCase("HTML")) {
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonHtml),
							"HTML type not found in Export window");
					radioButtonHtml.click();
				} else {
					if (outputAs.equalsIgnoreCase("PDF")) {
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonPdf),
								"PDF type not found in Export window");
						radioButtonPdf.click();
					} else {
						if (outputAs.equalsIgnoreCase("Word")) {
							Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonWord),
									"Word type not found in Export window");
							radioButtonWord.click();
						}
					}
				}

			}
			CommonUtil.normalWait(1000);
			buttonSaveExport.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerDownloadFileInPopup),
					"Header Download File not found");
			buttonDownload.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(10000);

		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Failed to export node successfully");
			return false;
		}
		return true;
	}

	public boolean exportNodeFromTestPlanningAssignmentWindow(String nodeName, String reportType, String outputAs,
			boolean navigateBackToCycle) {
		try {
			logger.info("Going to launch Export Window");
			CommonUtil.normalWait(1000);

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//a[@data-name='" + nodeName + "']"),
					"Node not found by name: " + nodeName);

			WebElement we = CommonUtil.returnWebElement("//a[@data-name='" + nodeName + "']");
			CommonUtil.scrollToWebElementAndView(we);
			CommonUtil.returnWebElement("//a[@data-name='" + nodeName + "']//div[contains(@class,'contextMenuIcon')]")
					.click();
			CommonUtil.normalWait(1000);
			CommonUtil.ClickOnElementUsingJS(linkExport);
			HomePage.getInstance().waitForProgressBarToComplete();

			logger.info("Clicked on Export in Context menu");
			CommonUtil.normalWait(5000);

			if (reportType.equalsIgnoreCase("Excel")) {
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDataExcel),
						"Excel export not found in Export window");
				radioButtonDataExcel.click();

			} else {
				if (reportType.equalsIgnoreCase("Summary")) {
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonSummary),
							"Summary export not found in Export window");
					radioButtonSummary.click();

				} else {
					if (reportType.equalsIgnoreCase("Detailed")) {
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDetailed),
								"Detailed export not found in Export window");
						radioButtonDetailed.click();
					}
				}
				CommonUtil.normalWait(1000);
				if (outputAs.equalsIgnoreCase("HTML")) {
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonHtml),
							"HTML type not found in Export window");
					radioButtonHtml.click();
				} else {
					if (outputAs.equalsIgnoreCase("PDF")) {
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonPdf),
								"PDF type not found in Export window");
						radioButtonPdf.click();
					} else {
						if (outputAs.equalsIgnoreCase("Word")) {
							Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonWord),
									"Word type not found in Export window");
							radioButtonWord.click();
						}
					}
				}

			}
			CommonUtil.normalWait(1000);
			buttonSaveExport.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerDownloadFileInPopup),
					"Header Download File not found");
			buttonDownload.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(10000);

		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Failed to export node successfully");
			return false;
		} finally {
			if (navigateBackToCycle) {
				navigateBackToCycles();
			}
		}
		return true;
	}

	public boolean performSearchInEASAddTestcaseToFreeformWindow(String searchType, String searchQuery,
			String setPageSize, int expectedNoOfPages, Map<Integer, List<String>> pageAndexpectedTestcases) {

		try {
			logger.info("Going to launch Add Testcases window");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonToLaunchAddTestcasesWindowForFreeform),
					"Button to launch Add Testcase Window not found");
			buttonToLaunchAddTestcasesWindowForFreeform.click();
			CommonUtil.normalWait(1000);

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerAddTestcases),
					"Header Add Testcases not found");
			logger.info("Add Testcases window launched successfully");

			if (searchType.equalsIgnoreCase("Quick")) {
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonQuick),
						"Radio button Quick not found");
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textAreaForQuickSearch),
						"Text Area for Quick search not found");
				CommonUtil.normalWait(1000);
				textAreaForQuickSearch.sendKeys(searchQuery);
				CommonUtil.normalWait(1000);
				buttonGo.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
				sort(true);
				sort(true);

			} else {
				if (searchType.equalsIgnoreCase("Advanced")) {
					logger.info("Going to select Advanced Search Option");
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonAdvanced),
							"Radio button Advanced not found");
					radioButtonAdvanced.click();
					CommonUtil.normalWait(1000);
					logger.info("Clicked on Advanced Search Option successfully");

					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textAreaForAdvanceSearch),
							"Text Area for Advance search not found");
					CommonUtil.normalWait(1000);
					textAreaForAdvanceSearch.sendKeys(searchQuery);
					CommonUtil.normalWait(1000);
					buttonGo.click();
					CommonUtil.normalWait(1000);
					HomePage.getInstance().waitForProgressBarToComplete();

				} else {
					Assert.assertTrue(false,
							"Please provide proper search Type in Test, Expected values are: Quick, Advanced");
				}
			}

			setPageSizeInEASAddTestcaseToFreeformScreen(setPageSize);

			for (int i = 1; i <= expectedNoOfPages; i++) {

				if (pageAndexpectedTestcases.containsKey(i)) {
					List<String> testcasesNames = pageAndexpectedTestcases.get(i);
					if (i > 1) {
						Assert.assertTrue(navigateToNextOrPrevPageInTestPlanningFreeformGrid("Next"));
					}
					Assert.assertTrue(verifyTestcasesInGridOfSelectedPageInAddTestcaseToFreeformScreen(testcasesNames));
				}

			}

			CommonUtil.normalWait(1000);
			buttonCancelInAddTestcaseWindow.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			navigateBackToCycles();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);

		} catch (Exception e) {
			logger.info(
					"Failed to verify testcases across different pagination pages in Add Testcase To Freeform Screen");
			e.printStackTrace();
			return false;
		}

		return true;
	}

	public boolean setPageSizeInEASAddTestcaseToFreeformScreen(String size) {
		try {

			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			CommonUtil.selectListWithVisibleText(selectPaginationPageSize, size);
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);

		} catch (Exception e) {
			logger.info("Failed to change page size to: " + size);
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean navigateToNextOrPrevPageInTestPlanningFreeformGrid(String nextOrPrev) {
		try {
			if (nextOrPrev.equalsIgnoreCase("Next")) {
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkNextPage), "Link Next page not found");
				linkNextPage.click();
			} else {
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkPrevPage), "Link Prev page not found");
				linkPrevPage.click();
			}
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
		} catch (Exception e) {
			logger.info("Failed to navigate ot " + nextOrPrev + " Page.");
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean verifyTestcasesInGridOfSelectedPageInAddTestcaseToFreeformScreen(List<String> testcasesNames) {
		try {

			for (String testcaseName : testcasesNames) {
				Assert.assertTrue(
						CommonUtil.visibilityOfElementLocated(
								"//div[@id='grid-table-eas_add_search']//div[text()='" + testcaseName + "']"),
						"Testcase not found by name: " + testcaseName);
			}
			logger.info("Verified testcases in assign window");
		} catch (Exception e) {
			logger.info("Failed to verify testcases successfully");
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean verifyCycleAndPhaseDetailsInTestPlanning(String cycleName, String cycleStartDateExpected,
			String cycleEndDateExpected, String phaseName, String phaseStartDateExpected, String phaseEndDateExpected) {
		try {

			logger.info("Verifying Cycle details in Test Planning page.");
			CommonUtil.normalWait(1000);
			logger.info("Verifying Cycle name as: " + cycleName);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//a[@data-name='" + cycleName + "']"),
					"Cycle not found by name: " + cycleName);

			if (phaseName != null) {
				Assert.assertTrue(
						CommonUtil.visibilityOfElementLocated("//a[@data-name='" + cycleName
								+ "']/following-sibling::ul//a[@data-name='" + phaseName + "']"),
						"Phase not found by name: " + phaseName + " under cycle: " + cycleName);
			}

			WebElement we = CommonUtil.returnWebElement("//a[@data-name='" + cycleName + "']");
			CommonUtil.scrollToWebElementAndView(we);
			CommonUtil.returnWebElement("//a[@data-name='" + cycleName + "']//div[contains(@class,'contextMenuIcon')]")
					.click();
			CommonUtil.normalWait(1000);
			CommonUtil.ClickOnElementUsingJS(CommonUtil.returnWebElement("//a[text()='Edit']"));
			logger.info("Clicked on Edit cycle button and waiting for cycle popup.");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(editCycleModalPopup),
					"Edit new cycle Modal popup not opened.");
			logger.info("Edit cycle Modal popup found successfully.");

			logger.info("Going to verify Cycle Start date");

			calendarIconCycleStartDate.click();
			CommonUtil.normalWait(2000);

			String cycleActualStartDate = CommonUtil.getText(
					"//div[@id='easEditNodeModal']//b[text()='Start Date']/parent::label/following-sibling::div//td/button[contains(@class,'active')]/span");
			calendarIconCycleStartDate.click();

			calendarIconCycleEndDate.click();
			CommonUtil.normalWait(2000);
			String cycleActualEndDate = CommonUtil.getText(
					"//div[@id='easEditNodeModal']//b[text()='End Date']/parent::label/following-sibling::div//td/button[contains(@class,'active')]/span");
			calendarIconCycleEndDate.click();
			CommonUtil.normalWait(1000);

			WebElement phStartDate = CommonUtil.returnWebElement(
					"//td/span[@title='" + phaseName + "']/parent::td/following-sibling::td[1]/calendar/div");
			CommonUtil.normalWait(1000);
			phStartDate.click();
			String phaseActualStartDate = CommonUtil.getText("//td/span[@title='" + phaseName
					+ "']/parent::td/following-sibling::td[1]//td/button[contains(@class,'active')]/span");
			phStartDate.click();
			CommonUtil.normalWait(1000);

			WebElement phEndDate = CommonUtil.returnWebElement(
					"//td/span[@title='" + phaseName + "']/parent::td/following-sibling::td[2]/calendar/div");
			CommonUtil.normalWait(1000);
			phEndDate.click();

			String phaseActualEndDate = CommonUtil.getText("//td/span[@title='" + phaseName
					+ "']/parent::td/following-sibling::td[2]//td/button[contains(@class,'active')]/span");
			phEndDate.click();
			CommonUtil.normalWait(1000);

			Assert.assertEquals(cycleActualStartDate, cycleStartDateExpected);
			Assert.assertEquals(cycleActualEndDate, cycleEndDateExpected);
			Assert.assertEquals(phaseActualStartDate, phaseStartDateExpected);
			Assert.assertEquals(phaseActualEndDate, phaseEndDateExpected);

			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			CommonUtil.normalWait(2000);
			buttonCloseEditCycle.click();
			CommonUtil.browserRefresh();
			HomePage.getInstance().waitForProgressBarToComplete();
		}
		return true;
	}

	public boolean unhideCycle()

	{
		hidecycleChebox.click();
		return true;

	}
	
	public boolean sort(boolean TestcaseID) {
		if (TestcaseID = true) {
		String sorttestcase =	"//div[@title='Test Case ID']/following-sibling::i";
		WebElement we = CommonUtil.returnWebElement(sorttestcase);
		CommonUtil.moveToElement(we);
		we.click();
		}
		
		return true;
	}
}
