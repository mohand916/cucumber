package com.thed.zeuihtml.jira.impl.jira70;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;

public class JiraLoginCloud {
Logger logger;
	
	public JiraLoginCloud(){
		logger = Logger.getLogger(this.getClass());
	}
	public static JiraLoginCloud getInstance(){
		return PageFactory.initElements(Driver.driver, JiraLoginCloud.class);
}
	
	/******************************************************
	 * 	WEBELEMENTS
	 *****************************************************/
	@FindBy(xpath="//*[@id='username']")
	private WebElement jiraUsername; 
	
	@FindBy(xpath=".//*[@id='login-submit']")
	private WebElement jiracontinoue;
	
	@FindBy(xpath=".//*[@id='password']")
	private WebElement jirapassword;
	
	





	
public boolean jiraLoginCloud(String username, String password){
	
	try {
		 logger.info("Login to Jira started.......");
		 	jiraUsername.clear();
	        logger.info("Typing Username: " + username);
	        jiraUsername.sendKeys(username);
	        jiracontinoue.click();
	        CommonUtil.implicitWait(60);
	        jirapassword.clear();
			logger.info("Typing Username: " + password);
			jirapassword.sendKeys(password);
			jiracontinoue.click();
			CommonUtil.implicitWait(60);
			logger.info("Login to Jira cloud Successfully.");
		return true;
	} catch (Exception e) {
		return false;
	}
}
	
       
}