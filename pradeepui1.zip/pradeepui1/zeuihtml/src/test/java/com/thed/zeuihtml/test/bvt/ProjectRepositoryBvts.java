package com.thed.zeuihtml.test.bvt;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.codehaus.groovy.ast.stmt.LoopingStatement;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.thed.zeuihtml.BaseTest;
import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.Constants;
import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;
import com.thed.zeuihtml.ze.impl.zehtmlpages.HomePage;




public class ProjectRepositoryBvts extends BaseTest {
	
	public ProjectRepositoryBvts() {
	logger = Logger.getLogger(this.getClass());
	} 



@Test(enabled = testEnabled, priority=270)
public void bvt264_createPhaseSystemSubSystemProjectrepository() {
	logger.info("Executing bvt270...");
	altID = 270;
	testcaseId = "270";
//	zeNavigator.doLogin(Config.getUsersPropValue("ZE_MANAGER_USERNAME"), Config.getUsersPropValue("ZE_MANAGER_PASSWORD"));
	String releaseName = "Release 1.0";
	String appName = "Test Repository";
	zeNavigator.selectProject("Sample Project");
	Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
	zeNavigator.launchReleaseApp(appName);
	
	//Create a Phase in Project repository
	String phaseName = Config.getTCRPropValue("PRO_PHASE_1");
	String phaseDescription = phaseName + " description";
	String projectRepository = "Project Test Repository";
	Assert.assertTrue(zeNavigator.createProjectRepoPhase(projectRepository, phaseName, phaseDescription),
			"Phase not created successfully.");
	
	//Create a Node in Project repository
	String parentNodeName = Config.getTCRPropValue("PRO_PHASE_1");
	String nodeOneName = Config.getTCRPropValue("PRO_NODE_1");
	String nodeOneDescription = nodeOneName + " description";

	List<String> phases = new ArrayList<String>();
	phases.add(Config.getTCRPropValue("PROJECT_REPO"));
	Assert.assertTrue(zeNavigator.navigateToNodesProjectRepo(phases), "Not navigated to nodes.");
	Assert.assertTrue(zeNavigator.createProjectRepoNode(phases, parentNodeName, nodeOneName, nodeOneDescription),
			"Node not created successfully.");
	
	//Create a Sub-Node in Project Repository
	
	String parentNodeName1 = Config.getTCRPropValue("PRO_NODE_1");
	String nodeOneName1 = Config.getTCRPropValue("PRO_SUBNODE_1");
	String nodeOneDescription1 = nodeOneName1 + " description";

	List<String> phases1 = new ArrayList<String>();
	phases1.add(Config.getTCRPropValue("PROJECT_REPO"));
	phases1.add(Config.getTCRPropValue("PRO_PHASE_1"));
	Assert.assertTrue(zeNavigator.navigateToNodesProjectRepo(phases1), "Not navigated to nodes.");
	Assert.assertTrue(zeNavigator.createProjectRepoNode(phases1, parentNodeName1, nodeOneName1, nodeOneDescription1),
			"Node not created successfully.");
	isSuccess = true;
	logger.info("bvt270 is executed successfully.");
}
@Test(enabled = testEnabled, priority=271)
public void bvt264_createTestcaseProjectrepository() {
	logger.info("Executing bvt270...");
	altID = 270;
	testcaseId = "270";
	
	//Login and Navigate to the App
	//zeNavigator.doLogin(Config.getUsersPropValue("ZE_MANAGER_USERNAME"), Config.getUsersPropValue("ZE_MANAGER_PASSWORD"));
	String releaseName = "Release 1.0";
	String appName = "Test Repository";
	zeNavigator.selectProject("Sample Project");
	Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
	zeNavigator.launchReleaseApp(appName);
	
	List<String> phases = new ArrayList<String>();
	phases.add(Config.getTCRPropValue("PROJECT_REPO"));
	phases.add(Config.getTCRPropValue("PRO_PHASE_1"));
	phases.add(Config.getTCRPropValue("PRO_NODE_1"));
	Assert.assertTrue(zeNavigator.navigateToNodesProjectRepo(phases), "Not navigated to nodes.");
	String nodeName = Config.getTCRPropValue("PRO_SUBNODE_1");
	String testcaseId = zeNavigator.addDefaultTestcaseProjectRepo(nodeName);
	Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");

	System.out.println("Testcase IDs : " + testcaseId);

	Map<String, String> values = new HashMap<String, String>();
	values.put("NODE_NAME", nodeName);
	values.put("TESTCASE_ID", testcaseId);
	values.put("TESTCASE_SUMMARY", "Modified summary");
	values.put("TESTCASE_DESC", "Modified description");
	values.put("TESTCASE_SUMMARY",Config.getTCRPropValue("TESTCASE_FOR_PROJECT_REPO"));
	values.put("TESTCASE_DESC", "Testcase for the Project repository description");
	values.put("Priority", Config.getTCRPropValue("TESTCASE_FOR_PROJECT_REPO_PRIORITY"));
	values.put("Comment", Config.getTCRPropValue("TESTCASE_FOR_PROJECT_REPO_COMMENT"));

	Assert.assertTrue(zeNavigator.modifyTestcaseProjectRepo(values), "Not added default testcase successfully.");
	zeNavigator.verifyTestcaseVersionProjectRepo(Config.getTCRPropValue("TESTCASE_FOR_PROJECT_REPO"), "1");
	isSuccess = true;
	logger.info("bvt270 is executed successfully.");
}
	@Test (enabled= testEnabled, priority=272)
	public void bvt265_Clone_BulkEditDeleteTestcaseProjectRepo() {
		logger.info ("Executing Bvt271...");
		altID = 271;
		testcaseId = "265";
		String releaseName = "Release 1.0";
		String appName = "Test Repository";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("PROJECT_REPO"));
		phases.add(Config.getTCRPropValue("PRO_PHASE_1"));
		phases.add(Config.getTCRPropValue("PRO_NODE_1"));
		
		Assert.assertTrue(zeNavigator.navigateToNodesProjectRepo(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("PRO_SUBNODE_1");
		String testcaseName = Config.getTCRPropValue("TESTCASE_FOR_PROJECT_REPO");
		List<String> testcaseID2= new ArrayList<String>();
		for (int i=1; i<4; i++) {
			Assert.assertTrue(zeNavigator.cloneTestcaseProjectRepo(nodeName, testcaseName, "withoutsteps"), "Testcase is not cloned");
			String testcaseId = zeNavigator.getTestcaseProjectRepo(nodeName);
			System.out.println("Testcase IDs : " + testcaseId);
			testcaseID2.add(testcaseId);
			System.out.println("*****************************"+testcaseID2);
			Map<String, String> values = new HashMap<String, String>();
			values.put("NODE_NAME", nodeName);
			values.put("TESTCASE_ID", testcaseId);
			values.put("TESTCASE_SUMMARY","Clone Testcase Project Repo" + i);
			values.put("TESTCASE_DESC", "Testcase for the Project repository description" + i );
			values.put("Priority", Config.getTCRPropValue("TESTCASE_FOR_PROJECT_REPO_PRIORITY"));
			values.put("Comment", "clone" + i);

			Assert.assertTrue(zeNavigator.modifyTestcaseProjectRepo(values), "Not added default testcase successfully.");
		
		}
		Map<String, String> values = new HashMap<String, String>();
		values.put("ALTID", "12.12.23");
		values.put("Comment", "Bulk Edited testcase");
		values.put("Tags", "Bulk");
		values.put("estimatedTime", Config.getTCRPropValue("NEW_ESTIMATED_TIME"));
		values.put("priority", Config.getTCRPropValue("TC_PRIORITY_2"));
		values.put("Automated", "BVTAutomation" + Constants.CHAR_TO_SPLIT_STRING + "001"
				+ Constants.CHAR_TO_SPLIT_STRING + Config.getTCRPropValue("Automation_Path"));
		Assert.assertTrue(zeNavigator.bulkEditTestCase(values), "Bulk edit not done succefully..");
		
		Assert.assertTrue(zeNavigator.deleteTestcaseProjectRepo(nodeName, testcaseID2 ), "TestCase not deleted" );
		
		
		isSuccess = true;
		logger.info("bvt265 is executed successfully.");
	}

	@Test (enabled= testEnabled, priority=272)
	public void bvt266_DeleteSingleTestcase_Phase()
	{

		logger.info("Executing bvt266...");
		altID = 266;
		testcaseId = "266";
		
		String releaseName = "Release 1.0";
		String appName = "Test Repository";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		String phaseName = Config.getTCRPropValue("PRO_DELETE_PHASE");
		String phaseDescription = phaseName + " description";
		String projectRepository = "Project Test Repository";
		Assert.assertTrue(zeNavigator.createProjectRepoPhase(projectRepository, phaseName, phaseDescription),
				"Phase not created successfully.");
		
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("PROJECT_REPO"));
		phases.add(Config.getTCRPropValue("PRO_DELETE_PHASE"));
		//phases.add(Config.getTCRPropValue("PRO_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesProjectRepo(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("PRO_DELETE_PHASE");
		String deleteNodeName = Config.getTCRPropValue("PRO_DELETE_PHASE");
		String testcaseId = zeNavigator.addDefaultTestcaseProjectRepo(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");
		Assert.assertTrue(zeNavigator.deleteTestcaseProjectRepo(nodeName, Integer.parseInt(testcaseId)), "Not deleted testcase.");
		Assert.assertTrue(zeNavigator.deleteNodeProjectRepo(deleteNodeName), "Node not renamed successfully.");
		isSuccess = true;
		logger.info("bvt266 is executed successfully.");
	}

	@Test (enabled= testEnabled, priority=273)
	public void bvt267ExportTestcaseSummary_Detail_Excel()
	{
		logger.info("Executing bvt267...");
		altID = 267;
		testcaseId = "267";
	String releaseName = "Release 1.0";
	String appName = "Test Repository";
	zeNavigator.selectProject("Sample Project");
	Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
	zeNavigator.launchReleaseApp(appName);
		
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("PROJECT_REPO"));
		phases.add(Config.getTCRPropValue("PRO_PHASE_1"));
		phases.add (Config.getTCRPropValue("PRO_NODE_1"));
		phases.add (Config.getTCRPropValue("PRO_SUBNODE_1"));
		
		Assert.assertTrue(zeNavigator.navigateToNodesProjectRepo(phases), "Not navigated to nodes.");

		// Excel 
		zeNavigator.exportSelectedNodeOfTCCProjectRepo(Config.getTCRPropValue("PRO_SUBNODE_1"), "Excel", null);

		List<String> fileNames = CommonUtil.returnFileNames(Config.getValue("EXPORT_FILE_PATH"));
		CommonUtil.normalWait(1000);
		CommonUtil.renameFile(Config.getValue("EXPORT_FILE_PATH") + "/" + fileNames.get(0),
				Config.getTCRPropValue("EXCEL_EXPORT_FILENAME_PROJECTREPO"));

		List<Integer> ignoreCells = new ArrayList<Integer>();
		ignoreCells.add(0);
		ignoreCells.add(6);
		ignoreCells.add(13);
		ignoreCells.add(24);

		isSuccess = CommonUtil.compareExcel(
				Config.getValue("EXPORT_FILE_PATH") + "/" + Config.getTCRPropValue("EXCEL_EXPORT_FILENAME_PROJECTREPO"),
				Config.getValue("EXPORT_FILE_PATH") + "/backups/" + Config.getTCRPropValue("BACKUP_EXCEL_TO_COMPARE_PROJECTREPO"),
				ignoreCells);

		CommonUtil.moveFile(Config.getValue("EXPORT_FILE_PATH") + "/" + Config.getTCRPropValue("EXCEL_EXPORT_FILENAME_PROJECTREPO"),
				Config.getValue("EXPORT_FILE_PATH") + "/delete");
		// Summary HTML
		zeNavigator.exportSelectedNodeOfTCCProjectRepo(Config.getTCRPropValue("PRO_SUBNODE_1"), "Summary", "HTML");
		List<String> fileNames1 = CommonUtil.returnFileNames(Config.getValue("EXPORT_FILE_PATH"));
		CommonUtil.normalWait(1000);
		System.out.println("Summary File Name: " + fileNames1.get(0));
		CommonUtil.normalWait(1000);
		CommonUtil.renameFile(Config.getValue("EXPORT_FILE_PATH") + "/" + fileNames1.get(0),
				Config.getTCRPropValue("HTML_EXPORT_FILENAME_PROJECTREPO"));
		CommonUtil.moveFile(Config.getValue("EXPORT_FILE_PATH") + "/" + Config.getTCRPropValue("HTML_EXPORT_FILENAME_PROJECTREPO"),
				Config.getValue("EXPORT_FILE_PATH") + "/delete");
		
		//Detail PDF
		zeNavigator.exportSelectedNodeOfTCCProjectRepo(Config.getTCRPropValue("PRO_SUBNODE_1"), "Detailed", "PDF");
		List<String> fileNames2 = CommonUtil.returnFileNames(Config.getValue("EXPORT_FILE_PATH"));
		CommonUtil.normalWait(1000);
		System.out.println("Summary File Name: " + fileNames2.get(0));

		CommonUtil.renameFile(Config.getValue("EXPORT_FILE_PATH") + "/" + fileNames2.get(0),
				Config.getTCRPropValue("PDF_EXPORT_FILENAME_PROJECTREPO"));

		isSuccess = CommonUtil.compareTwoPDFFilesData(
				Config.getValue("EXPORT_FILE_PATH") + "/backups/" + Config.getTCRPropValue("BACKUP_PDF_TO_COMPARE_PROJECTREPO"),
				Config.getValue("EXPORT_FILE_PATH") + "/" + Config.getTCRPropValue("PDF_EXPORT_FILENAME_PROJECTREPO"));

		CommonUtil.moveFile(Config.getValue("EXPORT_FILE_PATH") + "/" + Config.getTCRPropValue("PDF_EXPORT_FILENAME_PROJECTREPO"),
				Config.getValue("EXPORT_FILE_PATH") + "/delete");
		isSuccess = true;
		logger.info("bvt267 is executed successfully.");
	}
	
	@Test (enabled= testEnabled, priority=274)
	public void bvt268ImportTestcase_copy_ProjectRepo()
	{
		logger.info("Executing bvt268...");
		altID = 268;
		String releaseName = "Release 1.0";
		String appName = "Test Repository";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		Assert.assertTrue(zeNavigator.addTestcaseMap("Map2", "2", "By ID Change", "testcase map", "H", "J", "L", "G", "K", null), "Not able to add testcase map");
		Assert.assertTrue(zeNavigator.importTestcase("Job2", "Map2",
				CommonUtil.getCompleteFilePath("\\src\\test\\resources\\export_import\\backups\\tccgridbackuppro.xlsx")), "Testcase not imported");
		zeNavigator.navigateToTCCNodeUnderImportedNode("tccgridbackuppro.xlsx");

		List<String> testcasesNames = new ArrayList<String>();
		testcasesNames.add(Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"));
		testcasesNames.add(Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"));
		testcasesNames.add(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"));

		
		
		Assert.assertTrue(zeNavigator.renameSelectedTCCImportedNodeAndDragToRelease("tccgridbackuppro.xlsx", "Imported Testcase1",
				Config.getTCRPropValue("PROJECT_REPO"), true));

		List<String> nodes = new ArrayList<String>();
		nodes.add(Config.getTCRPropValue("PROJECT_REPO"));
		nodes.add("Imported Testcase1");
		CommonUtil.normalWait(2000);
		Assert.assertTrue(zeNavigator.navigateToNodesProjectRepo(nodes), "Not navigated to nodes.");
		zeNavigator.verifyTestcasesInSelectedNodeOfTestRepositoryProjectRepo(testcasesNames);
		CommonUtil.normalWait(1000);
		CommonUtil.browserRefresh();
		zeNavigator.logout();
		isSuccess = true;
		logger.info("bvt268 is executed successfully.");
	}
	
	@Test (enabled= testEnabled, priority=275)
	public void bvt269_ShareNodeProjectRepoRelease()
	{
		logger.info("Executing bvt269...");
		altID = 269;
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		String releaseName = "Release 1.0";
		String appName = "Test Repository";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("PROJECT_REPO"));
		phases.add(Config.getTCRPropValue("PRO_IMPORTED"));
		Assert.assertTrue(zeNavigator.navigateToNodesProjectRepo(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.dndsharenodeToRelease(Config.getTCRPropValue("PRO_IMPORTED"), Config.getTCRPropValue("RELEASE_NAME"), true), "Not SHare the Testcase Node");
		
		CommonUtil.normalWait(2000);
		CommonUtil.browserRefresh();
		List<String> phases1 = new ArrayList<String>();
		phases1.add(releaseName);
		phases1.add(Config.getTCRPropValue("PRO_IMPORTED"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases1), "Not navigated to nodes.");
		
		List<String> testcasesNames = new ArrayList<String>();
		testcasesNames.add(Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"));
		testcasesNames.add(Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"));
		testcasesNames.add(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"));
		zeNavigator.verifyTestcasesInSelectedNodeOfTestRepository(testcasesNames);
		isSuccess = true;
		logger.info("bvt269 is executed successfully.");
		
	}
	
	@Test (enabled= testEnabled, priority=275)
	public void bvt269_ShareNodeReleaseProjectRepo()
	{
		logger.info("Executing bvt269...");
		altID = 269;
		String releaseName = "Release 1.0";
		String appName = "Test Repository";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		List<String> phases1 = new ArrayList<String>();
		phases1.add(releaseName);
		phases1.add(Config.getTCRPropValue("PHASE_1"));
		phases1.add(Config.getTCRPropValue("NODE_1"));
		phases1.add(Config.getTCRPropValue("SUB_NODE_1"));
		
		Assert.assertTrue(zeNavigator.navigateToNodes(phases1), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.dndsharenodeToProjectRepo(Config.getTCRPropValue("SUB_NODE_1"), Config.getTCRPropValue("PROJECT_REPO"), true), "Not SHare the Testcase Node");
		CommonUtil.normalWait(2000);
		CommonUtil.browserRefresh();
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("PROJECT_REPO"));
		phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesProjectRepo(phases), "Not navigated to nodes.");
		
		
		List<String> testcasesNames = new ArrayList<String>();
		testcasesNames.add(Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"));
		testcasesNames.add(Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"));
		testcasesNames.add(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"));
		zeNavigator.verifyTestcasesInSelectedNodeOfTestRepositoryProjectRepo(testcasesNames);
		zeNavigator.logout();
		isSuccess = true;
		logger.info("bvt269 is executed successfully.");
		
	}
	
	@Test (enabled= testEnabled, priority=276)
	public void bvt270_ShareNodeOtherProject()
	{
		logger.info("Executing bvt270...");
		altID = 270;
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"));
		Assert.assertTrue(zeNavigator.launchAdministration(), "Failed to navigate Administration Page");
		Assert.assertTrue(zeNavigator.launchAdminApps("ProjectSetup"), "Failed to launch Project setup App");
		CommonUtil.normalWait(2000);
		List<String> ProjectNamesToAdd = new ArrayList<String>();
		ProjectNamesToAdd.add(0,Config.getProjectPropValue("PROJECT1_NAME"));
		zeNavigator.editProject(Config.getProjectPropValue("DEFAULT_PROJECT"), null, null, null, null, null, null, 
				null, null, null, null, null, ProjectNamesToAdd );
		String releaseName = "Release 1.0";
		String appName = "Test Repository";
		zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"));
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("PROJECT_REPO"));
		Assert.assertTrue(zeNavigator.navigateToNodesProjectRepo(phases), "Not navigated to nodes.");
		
		zeNavigator.launchShareTCCWindowProjectRepo(Config.getTCRPropValue("PROJECT_REPO"));
		
		List<String> nodeList = new ArrayList<String>();
		nodeList.add("Projects");
		nodeList.add("Sample Project");
		nodeList.add("Release 1.0");
		nodeList.add("Phase 1");
		zeNavigator.navigateToNodeInGlobalTCC(nodeList);
		zeNavigator.DnDGlobalTestcaseToLocalRelease(Config.getTCRPropValue("PROJECT_REPO"), "Phase 1", null);
		isSuccess = true;
		logger.info("bvt270 is executed successfully.");
		
	}
	

	@BeforeMethod
	public void beforeMethod() {
	
		isSuccess = false;
	}

	@AfterMethod
	public void afterMethod() {
		baseAfterMethod();
		if(!isSuccess){
			zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		}
	}
	

	@BeforeClass
	public void beforeClass() {
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
	}
	
	@AfterClass
	public void afterClass() {
		zeNavigator.logout();
	}
}

