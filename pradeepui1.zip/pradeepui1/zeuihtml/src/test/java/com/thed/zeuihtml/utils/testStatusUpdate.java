/**
 * Created by manoj.behera on 18-Apr-2017.
 */
package com.thed.zeuihtml.utils;

import java.util.HashMap;
import java.util.Map;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;

/**
 * @author manoj.behera 18-Apr-2017
 *
 */
public class testStatusUpdate {
	public static Response createCycle(RequestSpecification basicAuth, String payLoad) {
		String api = "/services/rest/latest/cycle";
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		return basicAuth.headers(headers).body(payLoad).when().post(api);
	}
	public static Response assignPhaseToCycle(RequestSpecification basicAuth, String cycleId, String payLoad) {
		String api = "/services/rest/v3/cycle/{cycleId}/phase";
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		return basicAuth.headers(headers).body(payLoad).when().post(api);
	}
	public static Response changeAssignments(RequestSpecification basicAuth, String cyclephaseid, String treeid, int fromid, int toid) {
		String api = "/services/rest/latest/assignmenttree/"+cyclephaseid+"/bulk/tree/"+treeid+"/from/"+fromid+"/to/"+toid+"?cascade=true&easmode=2";
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		return basicAuth.headers(headers).body("{}").when().put(api);
	}
	public static Response executeTests(RequestSpecification basicAuth, String rtsId, int status, int testerId) {
		String api = "/services/rest/v3/execution/"+rtsId+"?status="+status+"&testerid="+testerId;
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		return basicAuth.headers(headers).body("{}").when().put(api);
	}
	public static Response getUsers(RequestSpecification basicAuth) {
		String api = "/services/rest/v3/user";
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		return basicAuth.headers(headers).when().get(api);
	}
}
