package com.thed.zeuihtml.jira;

import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.jira.impl.JiraNavigator70Impl;



public class JiraNavigatorFactory {
	
	private static String SUPPORTED_VERSIONS = "5.2.x,6.1.x,6.2";
	
	public static JiraNavigator getInstance() {
		if (Config.getValue("JIRA_VERSION").equalsIgnoreCase("7.0")){
			return new JiraNavigator70Impl();
		}
	
		else{
			throw new RuntimeException("JIRA versions " + SUPPORTED_VERSIONS + " are supported. "
					+ "Version " + Config.getValue("JIRA_VERSION") + " is not supported");
		}
		
	}

}
