package com.thed.zeuihtml.ze.impl.zehtmlpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;

public class DefectAdminPage {

Logger logger;
	
	public DefectAdminPage() {
		logger = Logger.getLogger(this.getClass());
	}
	
	public static DefectAdminPage getInstance(){
		return PageFactory.initElements(Driver.driver, DefectAdminPage.class);
	}
	
	/******************************************************
	 * 	WEBELEMENTS
	 *****************************************************/
	
	
	@FindBy(xpath="//h4[text()='External DTS Login']")
	private WebElement popupExternalDTSLogin;
	
	@FindBy(xpath="//input[@name='username']")
	private WebElement textBoxUsernameInPopup;
	
	@FindBy(xpath="//input[@name='password']")
	private WebElement textBoxPasswordInPopup;
	
	
	@FindBy(xpath="//input[@name='reEnterPassword']")
	private WebElement textBoxReenterPassword;
	
	@FindBy(xpath="//div[contains(@class,'modal-footer')]//button[text()='Save' and @class='zui-btn zui-btn-primary']")
	private WebElement buttonSavePopup;
	
	@FindBy(xpath="//div[@id='toast-container']/div/div[text()='Success']")
	private WebElement popupSuccess;
	
	@FindBy(xpath="//span[@id='adminDropdown']//i[@class='misc-image setting-image']")
	private WebElement adminDropDown;
	
	@FindBy(xpath="//span[@id='adminDropdown']//following-sibling::div[@class='dropdown-menu dropdown-menu-right']//a[text()='Administration']")
	private WebElement selectAdministration;
	
	@FindBy(xpath="//a[@class='zee-nav-item']//span[text()='Defects Admin']")
	private WebElement selectDefectsAdmin;
	
	@FindBy(xpath="//input[@id='preference-value']")
	private WebElement preferenceValue;
	
	@FindBy(id="preference_tab")
	private WebElement buttonPreferenceTab;
	
	@FindBy(xpath="//div[@class='clearfix form-footer']//button[text()='Save']")
	private WebElement buttonSave;
	
	/******************************************************
	 * 	Methods
	 *****************************************************/
	
	public boolean setUserJiraCredentialsinExternalPopup(){
		logger.info("Waiting for External Popup to set DTS User credentials");
		
		if(CommonUtil.visibilityOfElementLocated(popupExternalDTSLogin)){
			logger.info("Going to clear and send jira username in textbox: " + Config.getValue("JIRA_USERNAME"));
			textBoxUsernameInPopup.clear();
			textBoxUsernameInPopup.sendKeys(Config.getValue("JIRA_USERNAME"));
			CommonUtil.normalWait(500);
			logger.info("Going to send jira password in password textbox: " + Config.getValue("JIRA_PASSWORD"));
			textBoxPasswordInPopup.sendKeys(Config.getValue("JIRA_PASSWORD"));
			CommonUtil.normalWait(500);
			logger.info("Going to send jira password in re-enter password textbox: " + Config.getValue("JIRA_PASSWORD"));
			textBoxReenterPassword.sendKeys(Config.getValue("JIRA_PASSWORD"));
			CommonUtil.normalWait(2000);
			logger.info("Going to click on save button");
			buttonSavePopup.click();
			logger.info("Waiting for success message popup");
			
			if(CommonUtil.visibilityOfElementLocated(popupSuccess)){
				logger.info("success message popup found successfully");
				HomePage.getInstance().closeToastPopup();
				HomePage.getInstance().waitForProgressBarToComplete();
			}else{
				HomePage.getInstance().waitForProgressBarToComplete();
				logger.info("success message not found");
				return false;
			}
		}else{
			logger.info("External DTS popup not displayed");
			return false;
		}
		return true;
	}
	
	public boolean setDefectAdminProperties(String category, String name, String value) {
		try {
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.moveToElement(buttonPreferenceTab);
			buttonPreferenceTab.click();
			CommonUtil.normalWait(700);
			String categoryXpath = "//div[@id='preference']//div[@class='col-md-3 categories-wrapper']//ul//li[text()='"+category+"']";
			CommonUtil.returnWebElement(categoryXpath).click();
			CommonUtil.normalWait(1000);
			WebElement nameWb = CommonUtil.returnWebElement("//div[text()='"+name+"']");
			nameWb.click();
			CommonUtil.normalWait(1000);
			preferenceValue.click();
			preferenceValue.clear();
			preferenceValue.sendKeys(value);
			CommonUtil.normalWait(1000);
			nameWb.click();
			CommonUtil.normalWait(1000);
			buttonSave.click();
			CommonUtil.normalWait(1000);
			buttonSavePopup.click();
		}
		catch (Exception e) {
			logger.info("Failed to set defect admin properties");
			e.printStackTrace();
			return false;
		}
		return true;
	}
}
