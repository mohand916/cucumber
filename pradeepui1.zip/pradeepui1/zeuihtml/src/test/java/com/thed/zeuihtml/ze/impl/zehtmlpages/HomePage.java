package com.thed.zeuihtml.ze.impl.zehtmlpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;

public class HomePage {

	Logger logger;
	int counter = 1;

	public HomePage() {
		logger = Logger.getLogger(this.getClass());
	}

	public static HomePage getInstance() {
		return PageFactory.initElements(Driver.driver, HomePage.class);

	}

	/******************************************************
	 * WEBELEMENTS
	 *****************************************************/

	@FindBy(xpath = "//span[@id='adminDropdown']")
	private WebElement adminDropdown;

	@FindBy(xpath = "//a[@id='Dashboardslink']")
	private WebElement dashboardDropdown;

	@FindBy(xpath = "//a[text()='Administration']")
	private WebElement administrationInDropdown;

	@FindBy(xpath = "//a[@id='adminlink']")
	private WebElement administrationLink;
	
	@FindBy(xpath = "//a[@id='globalRepositoryLink']")
	private WebElement globalRepoLink;
	
	@FindBy(xpath = "//a[text()='Manage Dashboards']")
	private WebElement manageDashboardsInDropdown;

	@FindBy(xpath = "//a[@title='Defect Tracking']")
	private WebElement linkDefectTrackingApp;

	@FindBy(xpath = "//a[@title='Authentication']")
	private WebElement linkUserAuthenticationApp;

	@FindBy(xpath = "//a[@title='Defect Admin']")
	private WebElement linkDefectAdminApp;

	@FindBy(xpath = "//a[@title='Manage Users']")
	private WebElement linkManageUsers;

	@FindBy(xpath = "//a[@title='Manage Projects']")
	private WebElement linkManageProjects;

	@FindBy(xpath = "//a[@title='System Setup']")
	private WebElement linkSystemSetup;

	@FindBy(xpath = "//a[@title='Customizations']")
	private WebElement linkCustomizationApp;

	@FindBy(xpath = "//span[@id='projectDropDown']")
	private WebElement projectDropdown;
	// span[@id='dropdownMenu2']
	@FindBy(xpath = "//a[@class='dropdown-item' and @title='ABC']")
	private WebElement selectProject;

	@FindBy(xpath = "//div[@class='slim-loading-bar-progress']")
	private WebElement progressBar;

	@FindBy(xpath = "//zui-app[contains(text(),'Loading')]")
	private WebElement loadingMessage;

	@FindBy(xpath = "//div[@class='toast-title']")
	private WebElement toastTitle;

	@FindBy(xpath = "//div[@id='toast-container']//button[@class='toast-close-button']")
	private WebElement buttonCloseToastPopup;
	
	@FindBy(xpath = "//div[@class='left-navs']")
	private WebElement closedropdownopen;
	
	@FindBy(xpath = "//span[@id='dropdownMenu5']")
	private WebElement userDropdown;

	@FindBy(xpath = "//a[text()='Logout']")
	private WebElement logoutInDropdown;

	@FindBy(xpath = "//a[text()='Change Password']")
	private WebElement linkChangePassword;
	
	@FindBy(xpath = "//input[@id='current-password']")
	private WebElement textBoxOldPassword;
	
	@FindBy(xpath = "//input[@id='new-password']")
	private WebElement textBoxNewPassword;

	@FindBy(xpath = "//input[@id='confirm-password']")
	private WebElement textBoxConfirmPassword;

	@FindBy(xpath = "//button[text()='Update']")
	private WebElement buttonUpdate;

	@FindBy(xpath = "//h4[text()='Change Password']")
	private WebElement headerChangePassword;

	@FindBy(xpath = "//span[@class='notification-wrapper']")
	private WebElement notification;

	@FindBy(xpath = "//button[text()='Apply']")
	private WebElement applyNotification;

	@FindBy(xpath = "//span[@class='fa fa-chevron-right']")
	private WebElement appDockUndockclose;

	// Force Logout

	@FindBy(xpath = "//div[@id='zee-logout-info']//h4[text()='User Logout']")
	private WebElement headerForceLogout;

	@FindBy(xpath = "//div[@id='zee-logout-info']//label[text()='This account has been logged out from the current session. Please re-login to continue working on this session.']")
	private WebElement textForceLogoutMsg;

	@FindBy(xpath = "//div[@id='zee-logout-info']//button[text()='Ok']")
	private WebElement buttonOkInForceLogoutPopup;

	@FindBy(xpath = ".//a[@title='System Setup']")
	private WebElement systemSetupDropdown;

	@FindBy(xpath = "//a[@title='User Setup']")
	private WebElement userSetupDropDown;

	@FindBy(xpath = "//a[@title='Project Setup']")
	private WebElement ProjectSetupDropDown;

	@FindBy(xpath = "//*[@id='ze-main-app']//header//span[contains(text(),'Back To')]")
	private WebElement backToProject;
	
	@FindBy(xpath = "//a[@title='Summary']")
	private WebElement globalSummary;
	
	@FindBy(xpath = "//a[@title='Test Repository']")
	private WebElement globalTestRepository;
	
	@FindBy(xpath = "//a[@title='Configuration']")
	private WebElement globalConfiguration;
	
	

	/******************************************************
	 * Methods
	 *****************************************************/

	public boolean verifyForceLogoutPopupAndClickOk() {
		try {

			waitForProgressBarToComplete();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerForceLogout),
					"Force Logout header not found");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textForceLogoutMsg),
					"Force Logout popup message not found as: " + textForceLogoutMsg.getText());

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			if (CommonUtil.visibilityOfElementLocated(buttonOkInForceLogoutPopup)) {
				CommonUtil.normalWait(1000);
				buttonOkInForceLogoutPopup.click();
				waitForProgressBarToComplete();
			}
		}
		return true;
	}

	public boolean launchAdministration() {
		try {
			logger.info("launching Administration Page");
			if(Driver.driver.getTitle().contains("Administration")) {
				return true;
			}else {
				// CommonUtil.moveToElement(adminDropdown);
				HomePage.getInstance().waitForProgressBarToComplete();
				// adminDropdown.click();
				CommonUtil.normalWait(1000);
				administrationLink.click();
				logger.info("Clicked Adminstarion");
				CommonUtil.implicitWait(30);
				waitForProgressBarToComplete();
				return true;
			}
		}catch(Exception e) {
			e.printStackTrace();
			return false;
		}
		
	}

	public boolean launchDashboard() {
		logger.info("Launching Dashboard");
		if (dashboardDropdown != null) {
			// CommonUtil.moveToElement(adminDropdown);
			HomePage.getInstance().waitForProgressBarToComplete();
			dashboardDropdown.click();
			CommonUtil.normalWait(1000);
			// manageDashboardsInDropdown.click();
			logger.info("Clicked on Dashboard");
			waitForProgressBarToComplete();
			return true;
		} else {
			logger.info("Dashboard option not found");
			return false;
		}

	}
	
	public boolean launchGlobalRepository() {
		try {
			logger.info("launching GlobalRepository Page");
			if(Driver.driver.getTitle().contains("Global Repository")) {
				return true;
			}else {
				// CommonUtil.moveToElement(adminDropdown);
				HomePage.getInstance().waitForProgressBarToComplete();
				// adminDropdown.click();
				CommonUtil.normalWait(3000);
				globalRepoLink.click();
				logger.info("Clicked Global Reposiotory");
				CommonUtil.implicitWait(30);
				waitForProgressBarToComplete();
				return true;
			}
		}catch(Exception e) {
			e.printStackTrace();
			return false;
		}
		
	}

	public boolean logout() {

		try {
			CommonUtil.actionClass().sendKeys(Keys.ESCAPE).build().perform();
			CommonUtil.actionClass().sendKeys(Keys.ESCAPE).build().perform();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.visibilityOfElementLocated(userDropdown);
			logger.info("Going to Logout");
			if (userDropdown != null) {
				// CommonUtil.moveToElement(adminDropdown);
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.ClickOnElementUsingJS(userDropdown);
//				userDropdown.click();
				CommonUtil.normalWait(1000);
				CommonUtil.ClickOnElementUsingJS(logoutInDropdown);
//				logoutInDropdown.click();
				logger.info("Clicked on logout in Dropdown");
				CommonUtil.normalWait(1000);
				waitForProgressBarToComplete();
				CommonUtil.browserRefresh();
				return true;
			} else {
				logger.info("Logout dropdown not found");
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}

	public boolean changePassword(String newPassword, String oldPassword) {
		try {
			if (userDropdown != null) {
				HomePage.getInstance().waitForProgressBarToComplete();
				userDropdown.click();
				CommonUtil.normalWait(1000);
				linkChangePassword.click();
				logger.info("Clicked on dropdown option Change Password");
				CommonUtil.implicitWait(30);
				waitForProgressBarToComplete();

				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerChangePassword),
						"Header Change Password not found");
				textBoxOldPassword.sendKeys(oldPassword);
				CommonUtil.normalWait(1000);
				textBoxNewPassword.sendKeys(newPassword);
				CommonUtil.normalWait(1000);
				textBoxConfirmPassword.sendKeys(newPassword);
				CommonUtil.normalWait(1000);
				buttonUpdate.click();
				CommonUtil.normalWait(1000);
				HomePage.getInstance().waitForProgressBarToComplete();

				return true;
			} else {
				logger.info("Logout dropdown not found");
				return false;
			}
		} catch (Exception e) {
			logger.info("Failed to change password");
			e.printStackTrace();
			return false;
		}
	}

	private boolean launchDefectAdmin() {
		logger.info("Checking Defect Admin App");
		if (CommonUtil.visibilityOfElementLocated(linkDefectAdminApp)) {
			logger.info("launching Defect Admin App");
			CommonUtil.normalWait(500);
			linkDefectAdminApp.click();
			logger.info("Defect Admin App launched");
			CommonUtil.normalWait(1000);
		} else {
			logger.info(
					"link of DefectAdmin App not found on left pannel, Please check Administration is launched or not");
			return false;
		}
		return true;
	}

	private boolean launchUserSetup() {
		logger.info("launching User setup App");
		userSetupDropdown();
		/*
		 * if(CommonUtil.visibilityOfElementLocated(linkManageUsers,2)){
		 * linkManageUsers.click(); CommonUtil.normalWait(500);
		 * waitForProgressBarToComplete(); }else{ logger.
		 * info("link of Manage Users App not found on left pannel, Please check Administration is launched or not"
		 * ); return false; }
		 */
		return true;
	}

	private boolean launchProjectSetup() {

		logger.info("launching Project setup App");
		projectSetupDropdown();

		/*
		 * if(CommonUtil.visibilityOfElementLocated(linkManageProjects)){
		 * CommonUtil.normalWait(1000); linkManageProjects.click();
		 * CommonUtil.normalWait(500); waitForProgressBarToComplete(); }else{ logger.
		 * info("link of Manage Projects App not found on left pannel, Please check Administration is launched or not"
		 * ); return false; }
		 */
		return true;
	}

	private boolean launchDefectTrackingApp() {
		logger.info("launching Defect Tracking App");
		systemSetupDropdown();
		if (CommonUtil.visibilityOfElementLocated(linkDefectTrackingApp)) {
			linkDefectTrackingApp.click();
			CommonUtil.normalWait(1000);
			waitForProgressBarToComplete();
		} else {
			logger.info(
					"link of DefectTracking App not found on left pannel, Please check Administration is launched or not");
			return false;
		}
		return true;
	}

	private boolean launchUserAuthenticationApp() {
		logger.info("launching User Authentication App");
		// systemSetupDropdown();
		if (CommonUtil.visibilityOfElementLocated(linkUserAuthenticationApp)) {
			linkUserAuthenticationApp.click();
			CommonUtil.normalWait(1000);
			waitForProgressBarToComplete();
		} else {
			logger.info(
					"link of User Authentication App not found on left pannel, Please check Administration is launched or not");
			return false;
		}
		return true;
	}

	private boolean launchCustomizationApp() {
		logger.info("launching Customization App");
		// systemSetupDropdown();
		if (CommonUtil.visibilityOfElementLocated(linkCustomizationApp)) {
			linkCustomizationApp.click();
			CommonUtil.normalWait(1000);
			// linkCustomizationApp.click();
			waitForProgressBarToComplete();
		} else {
			logger.info(
					"link of Customization App not found on left pannel, Please check Administration is launched or not");
			return false;
		}
		return true;
	}

	private boolean systemSetupDropdown() {
		logger.info("cilcking on system setup dropdown");
		if (CommonUtil.visibilityOfElementLocated(systemSetupDropdown)) {
			systemSetupDropdown.click();
			CommonUtil.normalWait(1000);
			waitForProgressBarToComplete();
		} else {
			logger.info("SystemSetupDropdown is not available");
			return false;
		}
		return true;
	}

	private boolean userSetupDropdown() {
		launchAdministration();
		logger.info("cilcking on User setup");
		if (CommonUtil.visibilityOfElementLocated(userSetupDropDown)) {
			CommonUtil.normalWait(1000);
			userSetupDropDown.click();
			CommonUtil.normalWait(1000);
			waitForProgressBarToComplete();
		} else {
			logger.info("User Setup Dropdown is not available");
			return false;
		}
		return true;
	}

	private boolean projectSetupDropdown() {
		launchAdministration();
		logger.info("cilcking on project setup");
		if (CommonUtil.visibilityOfElementLocated(ProjectSetupDropDown)) {
			CommonUtil.normalWait(2000);
			ProjectSetupDropDown.click();
			CommonUtil.normalWait(1000);
			waitForProgressBarToComplete();
		} else {
			logger.info("project Setup is not available");
			return false;
		}
		return true;
	}

	public boolean launchAdminApps(String appNameToBeLaunched) {
		waitForProgressBarToComplete();
		// appDockUndock();
		if (appNameToBeLaunched.equalsIgnoreCase("Customizations")) {
			return launchCustomizationApp();
		} else {
			if (appNameToBeLaunched.equalsIgnoreCase("DefectTracking")) {
				return launchDefectTrackingApp();
			} else {
				if (appNameToBeLaunched.equalsIgnoreCase("DefectAdmin")) {
					return launchDefectAdmin();
				} else {
					if (appNameToBeLaunched.equalsIgnoreCase("UserSetup")) {
						return launchUserSetup();
					} else {
						if (appNameToBeLaunched.equalsIgnoreCase("ProjectSetup")) {
							return launchProjectSetup();
						} else {
							if (appNameToBeLaunched.equalsIgnoreCase("Authentication")) {
								return launchUserAuthenticationApp();
							}

						}
					}
				}

			}
		}

		return false;
	}

	public boolean selectProject(String projectName) {
		if (CommonUtil.isElementClickable(backToProject, 1)) {
			logger.info("Going to click back to project");
			CommonUtil.normalWait(1000);
			backToProject.click();
		}
		logger.info("Going to select project: " + projectName);
		logger.info("Verifying Project Dropdown");

		if (CommonUtil.visibilityOfElementLocated(projectDropdown, 2)) {
			// CommonUtil.moveToElement(projectDropdown);
			// CommonUtil.normalWait(2000);
			logger.info("Going to click Project Dropdown");
			CommonUtil.normalWait(2000);
			CommonUtil.isElementClickable(projectDropdown);
			projectDropdown.click();
			logger.info("Searching of Project By name: '" + projectName + "' in Project Dropdown");
			WebElement we = CommonUtil
					.returnWebElement("//a[@class='dropdown-item']/span[text()='" + projectName + "']");

			if (CommonUtil.visibilityOfElementLocated(we)) {
				logger.info("Going to select project in dropdown by name: " + projectName);
				we.click();
				CommonUtil.normalWait(1000);
			} else {
				logger.info("Project Name not found in dropdown");
				return false;
			}

		} else {
			logger.info("Project Dropdown not found");
			return false;
		}

		return true;
	}

	public boolean waitForProgressBarToComplete() {

		try {
			logger.info("Checking progress bar to complete");
			CommonUtil.normalWait(1000);
			System.out.println("Progress Bar status: " + progressBar.isDisplayed());
			if (counter > 60) {
				logger.info("Progress bar is not completed after 1 min, so failing test");
				return false;
			}
			if (progressBar.isDisplayed()) {
				counter++;
				logger.info("progress bar still inprogress after " + counter + " sec");
				waitForProgressBarToComplete();
			}
			logger.info("Progress bar completed within " + counter + "seconds");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}

	public boolean waitForLoadingToComplete() {
		try {
			logger.info("Checking Loading message");
			// System.out.println("Loading status: " + loadingMessage.isDisplayed() );
			if (counter > 60) {
				logger.info("Loading bar still inprogress after 1 min, So Failing");
				return false;
			}
			if (CommonUtil.visibilityOfElementLocated(loadingMessage, 2)) {
				counter++;
				logger.info("Loading message is Still in progress" + counter + "sec");
				waitForLoadingToComplete();
			}
			logger.info("Loading message completed within" + counter + "sec");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean closeToastPopup() {

		try {
			logger.info("Closing toast popup");
			if (CommonUtil.visibilityOfElementLocated(buttonCloseToastPopup, 2)) {
				buttonCloseToastPopup.click();
				CommonUtil.normalWait(1000);
				closedropdownopen.click();
				logger.info("Closed toast popup");
				
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return false;
	}

	public void verifyAdminAppsToBePresent(boolean systemSetupApp, boolean userSetupApp, boolean projectSetupApp,
			boolean defectsAdminApp) {
		// HomePage.getInstance().appDockUndock();
		if (systemSetupApp) {
			logger.info("Going to verify presence of System Setup App");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkSystemSetup), "System Setup App not found");
		} else {
			logger.info("Going to verify Absence of System Setup App");
			Assert.assertFalse(CommonUtil.visibilityOfElementLocated(linkSystemSetup, 5),
					"System Setup App is not expected to be present");
		}

		if (userSetupApp) {
			logger.info("Going to verify presence of User Setup App");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(userDropdown, 2), "User Setup App not found");
		} else {
			logger.info("Going to verify Absence of User Setup App");
			Assert.assertFalse(CommonUtil.visibilityOfElementLocated(userDropdown, 5),
					"User Setup App is not expected to be present");
		}

		if (projectSetupApp) {
			logger.info("Going to verify presence of Project Setup App");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(ProjectSetupDropDown, 2),
					"Project Setup App not found");
		} else {
			logger.info("Going to verify Absence of Project Setup App");
			Assert.assertFalse(CommonUtil.visibilityOfElementLocated(ProjectSetupDropDown, 5),
					"Project Setup App is not expected to be present");
		}

		if (defectsAdminApp) {
			logger.info("Going to verify presence of Defects Admin App");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkDefectAdminApp, 5),
					"Defects Admin App not found");
		} else {
			logger.info("Going to verify Absence of Defects Admin App");
			Assert.assertFalse(CommonUtil.visibilityOfElementLocated(linkDefectAdminApp, 5),
					"Defects Admin App is not expected to be present");
		}
	}

	public boolean applyNotification(String expectedNotificationCount) {
		try {
			Assert.assertTrue(
					CommonUtil.visibilityOfElementLocated(
							"//notifications//span[text()='" + expectedNotificationCount + "']"),
					"Expected notification count not found as: " + expectedNotificationCount);

			CommonUtil.moveToElement(
					CommonUtil.returnWebElement("//notifications//span[text()='" + expectedNotificationCount + "']"));
			CommonUtil.normalWait(2000);
			applyNotification.click();
			CommonUtil.normalWait(2000);
			HomePage.getInstance().waitForProgressBarToComplete();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean appDockUndock() {
		try {
			if (CommonUtil.visibilityOfElementLocated(appDockUndockclose, 2)) {
				appDockUndockclose.click();
				logger.info("Undock-Dock the left app navigator");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public void verifyGlobalAppsToBePresent(boolean summary, boolean testRepository, boolean configuration) {
		// HomePage.getInstance().appDockUndock();
		if (summary) {
			logger.info("Going to verify presence of Summary App in Global Repository");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(globalSummary), "Summary App not found in Global Repository");
		} else {
			logger.info("Going to verify Absence of Summary");
			Assert.assertFalse(CommonUtil.visibilityOfElementLocated(globalSummary, 5),
					"Summary App in Global Repo is not expected to be present");
		}

		if (testRepository) {
			logger.info("Going to verify presence of Global Test Repository");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(globalTestRepository, 2), "Global Test Repo App not found");
		} else {
			logger.info("Going to verify Absence of Global Test Repo App");
			Assert.assertFalse(CommonUtil.visibilityOfElementLocated(globalTestRepository, 5),
					"Global Test Repo App is not expected to be present");
		}

		if (configuration) {
			logger.info("Going to verify presence of configurationp App");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(globalConfiguration, 2),
					"configuration App not found");
		} else {
			logger.info("Going to verify Absence of configuration App");
			Assert.assertFalse(CommonUtil.visibilityOfElementLocated(globalConfiguration, 5),
					"configuration App is not expected to be present");
		}

	}

	public boolean launchGlobalApps(String appNameToBeLaunched) {
		waitForProgressBarToComplete();
		
		CommonUtil.normalWait(3000);
		// appDockUndock();
		if (appNameToBeLaunched.equalsIgnoreCase("Summary")) {
			return launchglobalsummary();
		} else {
			if (appNameToBeLaunched.equalsIgnoreCase("Test Repository")) {
				return launchTestRepoy();
			} else {
				if (appNameToBeLaunched.equalsIgnoreCase("Configuration")) {
					return launchGlobalConfiguration();
				}
			}
		}

		return false;
	}

	private boolean launchglobalsummary() {
		logger.info("launching Summary Gloabl App");
		// systemSetupDropdown();
		if (CommonUtil.visibilityOfElementLocated(globalSummary)) {
			globalSummary.click();
			CommonUtil.normalWait(1000);
			// linkCustomizationApp.click();
			waitForProgressBarToComplete();
		} else {
			logger.info(
					"link of Global Summary App not found on left pannel, Please check Global Repo is launched or not");
			return false;
		}
		return true;
	}
	
	private boolean launchTestRepoy() {
		logger.info("launching Test Repo Gloabl App");
		// systemSetupDropdown();
		if (CommonUtil.visibilityOfElementLocated(globalTestRepository)) {
			globalTestRepository.click();
			CommonUtil.normalWait(3000);
			// linkCustomizationApp.click();
			waitForProgressBarToComplete();
		} else {
			logger.info(
					"link of Global Test Repo App not found on left pannel, Please check Global Repo is launched or not");
			return false;
		}
		return true;
	}

	private boolean launchGlobalConfiguration() {
		logger.info("launching Configuration Gloabl App");
		// systemSetupDropdown();
		if (CommonUtil.visibilityOfElementLocated(globalConfiguration)) {
			globalConfiguration.click();
			CommonUtil.normalWait(1000);
			// linkCustomizationApp.click();
			waitForProgressBarToComplete();
		} else {
			logger.info(
					"link of Global Configuration App not found on left pannel, Please check Global Repo is launched or not");
			return false;
		}
		return true;
	}
	
	public void verifyAppTopHeader(boolean globalRepos, boolean dashboard, boolean Administration) {
		
		
		if (globalRepos) {
			logger.info("Going to verify presence of Global Repository App ");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(globalRepoLink), "Summary App not found in Global Repository");
		} else {
			logger.info("Going to verify Absence of Global Repo");
			Assert.assertFalse(CommonUtil.visibilityOfElementLocated(globalRepoLink, 5),
					"Global Repo App  is not expected to be present");
		}

		if (dashboard) {
			logger.info("Going to verify presence of Dashboard");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(dashboardDropdown, 2), "Global Test Repo App not found");
		} else {
			logger.info("Going to verify Absence of Dashboard App");
			Assert.assertFalse(CommonUtil.visibilityOfElementLocated(dashboardDropdown, 5),
					"Dashboard App is not expected to be present");
		}
	
		if (Administration) {
			logger.info("Going to verify presence of Administartion App");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(administrationInDropdown, 2),
					"Administarion App not found");
		} else {
			logger.info("Going to verify Absence of Administration App");
			Assert.assertFalse(CommonUtil.visibilityOfElementLocated(administrationInDropdown, 5),
					"Administration App is not expected to be present");
		}

		
	}
}
