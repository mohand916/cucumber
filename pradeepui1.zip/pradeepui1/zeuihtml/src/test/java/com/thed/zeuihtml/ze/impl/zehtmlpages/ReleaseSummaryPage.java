package com.thed.zeuihtml.ze.impl.zehtmlpages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;

import groovyjarjarantlr.CommonAST;

public class ReleaseSummaryPage {

	Logger logger;

	public ReleaseSummaryPage() {
		logger = Logger.getLogger(this.getClass());
	}

	public static ReleaseSummaryPage getInstance() {
		return PageFactory.initElements(Driver.driver, ReleaseSummaryPage.class);
	}

	/******************************************************
	 * WEBELEMENTS
	 *****************************************************/

	@FindBy(xpath = "//div[@class='right-navs']/a[@class='zui-icon-btn']")
	private WebElement linkManageRelease;
	
	@FindBy(xpath="//*[@id='projectReleaseDropdown']/span")
	private WebElement projectReleaseSelector;
	
	@FindBy(xpath=".//*[@id='ze-main-app']/zee-release/zee-release-wrapper//h3")
	private WebElement releaseHeader;
	
	@FindBy(xpath=".//*[@id='sidr']//a[@class='zee-nav-item nav-link']")
	private List<WebElement> releaseAppElements; 
	
	@FindBy(xpath="//a[@title='Requirements']")
	private WebElement linkRequirementApp;
	
	@FindBy(xpath="//a[@title='Test Repository']")
	private WebElement linkTestRepositoryApp;
	
	@FindBy(xpath="//a[@title='Test Planning']")
	private WebElement linkTestPlanningApp;
	
	@FindBy(xpath="//a[@title='Test Execution']")
	private WebElement linkTestExecutionApp;
	
	@FindBy(xpath="//a[@title='Defect Tracking']")
	private WebElement linkDefectTrackingApp;
	
	@FindBy(xpath="//a[@title='Vortex']")
	private WebElement linkVortex;
	
	@FindBy(xpath="//li[@class='custom-disabled']/a[@title='Vortex']")
	private WebElement linkVortexDisable;
	
	@FindBy(xpath="//*[@id='projectReleaseDropdown']/span")
	private WebElement iconLeftNavigationDropdownRelease;
	
	@FindBy(xpath="//span[@id='projectReleaseDropdown']/span")
	private WebElement currentSelectedReleaseName;
	
	@FindBy(xpath="//div[@class='zee-module1-wrapper']//span[text()='Requirements']/preceding-sibling::span")
	private WebElement RequirementCount; 
	
	@FindBy(xpath="//div[@class='zee-module1-wrapper']//span[text()='Test Cases']/preceding-sibling::span")
	private WebElement TestcaseCount; 
	
	@FindBy(xpath="//div[@class='zee-module1-wrapper']//span[text()='Execution Progress']/preceding-sibling::span")
	private WebElement ExecutionProgressCount ; 
	
	@FindBy(xpath="//div[@class='zee-module1-wrapper']//span[text()='Defects Linked to Execution']/preceding-sibling::span")
	private WebElement DefectsLinkedtoExecutionCount ; 
	
	

	/******************************************************
	 * Methods
	 * @return 
	 *****************************************************/
	
	public String getCurrentSelectedRelease(){
		return currentSelectedReleaseName.getText();
	}

	
	public String getTotalRequirementCount(){
		return RequirementCount.getText();
	}
	
	
	public String getTotalTestcaseCount(){
		return TestcaseCount.getText();
	}
	
	public String getExecutionCount(){
		return ExecutionProgressCount.getText();
	}
	
	
	public String getDefectsLinkedCount(){
		return DefectsLinkedtoExecutionCount.getText();
	}
	
	
	
	
	public boolean navigateToReleaseApps(String releaseName, String appName) {
		//HomePage.getInstance().appDockUndock();
		try{
			//Assert.assertTrue(verifyReleaseSummaryPage(releaseName), "Release summary page selected successfully.");
			
			for (Iterator iterator = releaseAppElements.iterator(); iterator.hasNext();) {
				WebElement webElement = (WebElement) iterator.next();
				logger.info(webElement.getText());
				if(webElement.getText().equals(appName)){
					webElement.click();
					logger.info(appName+" selected successfully.");
					if(appName.equals("Test Repository")){
						Assert.assertTrue(TestRepositoryPage.getInstance().verifyTestRepositorySummaryPage(releaseName), "Test Repository page selected successfully.");
					}else if (appName.equals("Test Planning")) {
						Assert.assertTrue(TestPlanningPage.getInstance().verifyTestPlanningPage(releaseName), "Test Planning page selected successfully.");
					}
					
					break;
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
		
	}
	
	public void launchReleaseApp(String appName){
		HomePage.getInstance().appDockUndock();
		if(appName.equalsIgnoreCase("Test Repository")){
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkTestRepositoryApp), "Test Planning App not found");
			linkTestRepositoryApp.click();
			HomePage.getInstance().waitForProgressBarToComplete();
		}else{
			if(appName.equalsIgnoreCase("Test Planning")){
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkTestPlanningApp), "Test Planning App not found");
				linkTestPlanningApp.click();
				HomePage.getInstance().waitForProgressBarToComplete();
			}else{
				if(appName.equalsIgnoreCase("Requirements")){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkRequirementApp), "Requirement App not found");
					linkRequirementApp.click();
					HomePage.getInstance().waitForProgressBarToComplete();
				}else{
					if(appName.equalsIgnoreCase("Test Execution")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkTestExecutionApp), "Test Execution App not found");
						HomePage.getInstance().waitForProgressBarToComplete();
						linkTestExecutionApp.click();
						HomePage.getInstance().waitForProgressBarToComplete();
					}else{
						if(appName.equalsIgnoreCase("Defect Tracking")){
							Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkDefectTrackingApp), "Defect tracking App not found");
							linkDefectTrackingApp.click();
							HomePage.getInstance().waitForProgressBarToComplete();
						}else{
							if(appName.equalsIgnoreCase("Vortex")) {
								Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkVortex), "Vortex App not found");
								linkVortex.click();
								HomePage.getInstance().waitForProgressBarToComplete();
							}
						}
					}
				}
			}
		}
		CommonUtil.normalWait(2000);
	}
	
	public void verifyReleaseAppsToBePresent(boolean requirementApp, boolean testRepository, boolean testPlanningApp,
			boolean testExecutionApp, boolean defectTrackingApp, boolean vortexApp){
		
		if(requirementApp){
			logger.info("Going to verify presence of Requirement App");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkRequirementApp), "Requirement App not found");
		}else{
			logger.info("Going to verify Absence of Requirement App");
			Assert.assertFalse(CommonUtil.visibilityOfElementLocated(linkRequirementApp,5), "Requirement App is not expected to be present");
		}
		
		if(testRepository){
			logger.info("Going to verify presence of Test Repository App");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkTestRepositoryApp), "Test Repository App not found");
		}else{
			logger.info("Going to verify Absence of Test Repository App");
			Assert.assertFalse(CommonUtil.visibilityOfElementLocated(linkTestRepositoryApp,5), "Test Repository App is not expected to be present");
		}
		
		if(testPlanningApp){
			logger.info("Going to verify presence of Test Planning App");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkTestPlanningApp), "Test Planning App not found");
		}else{
			logger.info("Going to verify Absence of Test Planning App");
			Assert.assertFalse(CommonUtil.visibilityOfElementLocated(linkTestPlanningApp,5), "Test Planning App is not expected to be present");
		}
		
		if(testExecutionApp){
			logger.info("Going to verify presence of Test Execution App");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkTestExecutionApp), "Test Execution App not found");
		}else{
			logger.info("Going to verify Absence of Test Planning App");
			Assert.assertFalse(CommonUtil.visibilityOfElementLocated(linkTestExecutionApp,5), "Test Execution App is not expected to be present");
		}
		
		if(defectTrackingApp){
			logger.info("Going to verify presence of Defect Tracking App");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkDefectTrackingApp), "Defect Tracking App not found");
		}else{
			logger.info("Going to verify Absence of Defect Tracking App");
			Assert.assertFalse(CommonUtil.visibilityOfElementLocated(linkDefectTrackingApp,5), "Defect Tracking App is not expected to be present");
		}
		
		if(vortexApp){
			logger.info("Going to verify presence of Vortex App");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkVortex), "Vortex App not found");
		}else{
			logger.info("Going to verify Absence of Vortex App");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkVortexDisable,5), "Vortex App is not expected to be present");
		}
	}

	public boolean verifyReleaseSummaryPage(String releaseName) {
		HomePage.getInstance().appDockUndock();
		try{
			CommonUtil.normalWait(5000);
			Assert.assertEquals(CommonUtil.getTitle(), "Release - Zephyr Enterprise 6.2");
			//Assert.assertTrue(CommonUtil.textToBePresentInElement(releaseHeader, releaseName), "Release Header not found.");
			logger.info("Release header text validated successfully.");
			
			Assert.assertTrue(projectReleaseSelector.getText().equals(releaseName), "Release dropdown not selected.");
			logger.info("Project Release header text validated successfully.");
			
			//Assert.assertTrue(linkManageRelease.getText().equals("Manage") || linkManageRelease.getText().equals("Manage Release"), "Manage btn not found in Release summary page.");
		//	logger.info("Manage btn found successfully in Release summary page.");
			
			logger.info("Release Summay page verified successfully.");
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean launchReleaseSetupPage(){
		
		if(CommonUtil.visibilityOfElementLocated(linkManageRelease)){
			logger.info("Going to click on Manage Release Link");
			linkManageRelease.click();
			logger.info("Clicked on Manage Release Link");
			HomePage.getInstance().waitForProgressBarToComplete();
		}else{
			logger.info("Failed to click Manage Release Link");
			return false;
		}
		
		return true;
	}
	
	public boolean navigateReleaseFromTopDropdown(String releaseName){
		try{
			iconLeftNavigationDropdownRelease.click();
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement("//*[@id='projectReleaseDropdown']/following-sibling::div/a[text()='"+releaseName+"']").click();
			HomePage.getInstance().waitForProgressBarToComplete();
			verifyReleaseSummaryPage(releaseName);
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	
	
	public void verifyCurrentSelectedRelease(String expectedReleaseName) {
		
		
		String failingMsg = "Expected Release to be selected not matching, Expected Release: "
				+ expectedReleaseName +"Actual Selected Release Found: " + getCurrentSelectedRelease();
		
		Assert.assertTrue(getCurrentSelectedRelease().equals(expectedReleaseName), failingMsg);	
	}
	

	public void verifyCurrentRequirementCount(String expecteRrequirementCount) {
		
		String failingMsg = "Expected Requirementcount to be selected not matching, Expected RequirementCount: "
				+ expecteRrequirementCount +"Actual requirementCount Found: " + getTotalRequirementCount();
		
		Assert.assertTrue(getTotalRequirementCount().equals(expecteRrequirementCount), failingMsg);	
	}
	
   public void verifyCurrenttestcaseCount(String expectetestcaseCount) {
		
	String failingMsg = "Expected testcase count to be selected not matching, Expected testcase count: "
				+ expectetestcaseCount +"Actual testcase count Found: " + getTotalTestcaseCount();
		
		Assert.assertTrue(getTotalTestcaseCount().equals(expectetestcaseCount), failingMsg);	
	}

   public void verifyCurrentExecutionCount(String expectedexecutionProgress) {
		
		String failingMsg = "Expected Execution count not matching, Expected Exececution count: "
					+ expectedexecutionProgress +"Actual Execution count Found: " + getExecutionCount();
			
			Assert.assertTrue(getExecutionCount().equals(expectedexecutionProgress), failingMsg);	
		}

   public void verifyCurrentDefectCount(String expectedtotalLinkedDefects) {
		
		String failingMsg = "Expected Defect count not matching, Expected Defect Count: "
					+ expectedtotalLinkedDefects +"Actual Defect count Found: " + getDefectsLinkedCount();
			
			Assert.assertTrue(getDefectsLinkedCount().equals(expectedtotalLinkedDefects), failingMsg);	
		}
	
	
	public void verifyReleaseSummaryPage( String expectedReleaseName, String expecteRrequirementCount
			, String expectetestcaseCount, String expectedexecutionProgress, String expectedtotalLinkedDefects){
		try {
			CommonUtil.normalWait(500);
			if(expectedReleaseName!=null){
				verifyCurrentSelectedRelease(expectedReleaseName);
			}
			CommonUtil.normalWait(500);
			if(expecteRrequirementCount!=null){
			  verifyCurrentRequirementCount(expecteRrequirementCount);
			}
			CommonUtil.normalWait(500);
			if(expectetestcaseCount!=null){
				  verifyCurrenttestcaseCount(expectetestcaseCount);
			}
			CommonUtil.normalWait(500);
			if(expectedexecutionProgress!=null){
				  verifyCurrentExecutionCount(expectedexecutionProgress);
			}
			CommonUtil.normalWait(500);
			if(expectedtotalLinkedDefects!=null){
				  verifyCurrentDefectCount(expectedtotalLinkedDefects);
			}
		}
		catch (Exception e) {
			logger.info("Failed to verify Relese Summary Page");
			e.printStackTrace();
		}
		
	}
	

	
	public Map<String, String> getReleaseSummaryCountDetails(String releaseName){
		
		
		Map<String, String> values = new HashMap<String, String>();
		
		values.put("REQUIREMNT_COUNT", RequirementCount.getText());
		values.put("TESTCASE_COUNT", TestcaseCount.getText());
		values.put("Execution_Count", ExecutionProgressCount.getText());
		values.put("Defect_Count", DefectsLinkedtoExecutionCount.getText());
		
		return values;
	}
		
		/*
		if(expectedReleaseName!=null){
			verifySelectedRelease(expectedReleaseName);
		}
		if(totalReleaseCount!=null){
			verifyTotalReleaseCountInSelectedProject(totalReleaseCount);
		}
		if(totalInprogressRelease!=null){
			verifyTotalInprogressReleaseCountInSelectedProject(totalInprogressRelease);
		}
		if(totalTestcases!=null){
			verifyTotalTestcaseCountInSelectedProject(totalTestcases);
		}
		if(totalExecutions!=null){
			verifyTotalExecutionCountInSelectedProject(totalExecutions);
		}
		if(totalmembers!=null){
			verifyTotalMembersInSelectedProject(totalmembers);
		}
		*/
	
	
}

	
