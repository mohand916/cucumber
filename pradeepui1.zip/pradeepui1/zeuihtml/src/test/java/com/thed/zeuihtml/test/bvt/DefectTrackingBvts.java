package com.thed.zeuihtml.test.bvt;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.thed.zeuihtml.BaseTest;
import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.utils.CommonUtil;

public class DefectTrackingBvts extends BaseTest{

	public DefectTrackingBvts(){
		logger = Logger.getLogger(this.getClass());
	}
	
	@Test(enabled = testEnabled, priority = 138)
	public void bvt138_navigateToTestcaseLinkedWithDefectFromDefectTrackingAppTest(){
		logger.info("Executing bvt138...");
		altID = 138;
		
		String releaseName = "Release 1.0";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp("Defect Tracking");
		String defectIdToSearch = "AP-1";
		zeNavigator.searchByIdOrJqlOrFilter("ID", defectIdToSearch, false, null);
		zeNavigator.navigateToTestcaseLinkedWithDefectFromDefectTrackingApp(Config.getTCEPropValue("DEFECT1_SUMMARY"), "Sample Testcase 1");
		
		isSuccess = true;
		logger.info("bvt138 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 139)
	public void bvt139_createNewDefectFromDefectTrackingWithEnvironmentAndFixVersionTest(){
		logger.info("Executing bvt139...");
		altID = 139;
		
		
		zeNavigator.launchReleaseApp("Defect Tracking");
		
		Map<String, String> values = new HashMap<String, String>();
		values.put("Project", Config.getProjectPropValue("JIRA_PROJECT_NAME"));
		values.put("Issue Type", Config.getProjectPropValue("ISSUE_TYPE"));
		values.put("Summary", Config.getDefectTrackingPropValue("DEFECT_1_SUMMARY"));
		values.put("Description", Config.getDefectTrackingPropValue("DEFECT_1_DESCRIPTION"));
		values.put("Priority", Config.getDefectTrackingPropValue("DEFECT_1_PRIORITY"));
		values.put("Components", Config.getDefectTrackingPropValue("DEFECT_1_COMPONENTS"));
		values.put("FixVersions", Config.getDefectTrackingPropValue("DEFECT_1_FIXVERSIONS"));
		
		zeNavigator.createNewDefectFromDefectTrackingApp(values);
		
		isSuccess = true;
		logger.info("bvt139 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 141)
	public void bvt141_searchDefectByIDTestInDefectTrackingApp(){
		logger.info("Executing bvt141...");
		altID = 141;
		
		String defectIdToSearch = "AP-1";
		Map<String, String> valuesToVerify = new HashMap<String, String>();
		valuesToVerify.put("Summary", Config.getTCEPropValue("DEFECT1_SUMMARY"));
		
		zeNavigator.searchByIdOrJqlOrFilter("ID", defectIdToSearch, false, valuesToVerify);
		
		isSuccess = true;
		logger.info("bvt141 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 142)
	public void bvt144_exportDefectTest() {
		logger.info("Executing bvt144...");
		altID = 144;
		
		zeNavigator.exportSearchedDefectResults();
		
		List<String>  fileNames= CommonUtil.returnFileNames(Config.getValue("EXPORT_FILE_PATH"));
		CommonUtil.renameFile(Config.getValue("EXPORT_FILE_PATH")+"/"+fileNames.get(0), Config.getDefectTrackingPropValue("EXCEL_EXPORT"));
		
		List<Integer> ignoreCells = new ArrayList<Integer>();
		ignoreCells.add(0);
		ignoreCells.add(5);
		ignoreCells.add(18);
		ignoreCells.add(19);
		
//		isSuccess = CommonUtil.compareExcel(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getDefectTrackingPropValue("EXCEL_EXPORT")
//		, Config.getValue("EXPORT_FILE_PATH")+"/backups/"+Config.getDefectTrackingPropValue("BACKUP_EXPORT_TO_COMPARE"),ignoreCells);
		
		CommonUtil.moveFile(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getDefectTrackingPropValue("EXCEL_EXPORT"), Config.getValue("EXPORT_FILE_PATH")+"/delete");
		
		//Assert.assertTrue(isSuccess, "Exported Excel Data is not correct when compared with expected data");
		
		
		isSuccess = true;
		logger.info("bvt144 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 143)
	public void bvt142_searchDefectByJQLTest(){
		logger.info("Executing bvt142...");
		altID = 142;
		
		Map<String, String> valuesToVerify = new HashMap<String, String>();
		valuesToVerify.put("Summary", Config.getTCEPropValue("DEFECT1_SUMMARY"));
		zeNavigator.searchByIdOrJqlOrFilter("JQL", "project = 'Automation Project' AND component = c1", true, valuesToVerify);
		
		isSuccess = true;
		logger.info("bvt142 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 144)
	public void bvt143_searchByMyFilterTest(){
		logger.info("Executing bvt143...");
		altID = 143;
		
		Map<String, String> valuesToVerify = new HashMap<String, String>();
		valuesToVerify.put("Summary", Config.getDefectTrackingPropValue("DEFECT1_MULTI_SUMMARY"));
		zeNavigator.searchByIdOrJqlOrFilter("My Filter", Config.getDefectTrackingPropValue("FILTER_NAME"), true, valuesToVerify);
		isSuccess = true;
		logger.info("bvt132 is executed successfully.");
	}
	
	
	@BeforeMethod
	public void beforeMethod() {
		isSuccess = false;
	}

	@AfterMethod
	public void afterMethod() {
		baseAfterMethod();
		if(!isSuccess){
			zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
			String releaseName = "Release 1.0";
			zeNavigator.selectProject("Sample Project");
			Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
			zeNavigator.launchReleaseApp("Defect Tracking");
		}
	}

	@BeforeClass
	public void beforeClass() {
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
	}
	
	@AfterClass
	public void afterClass() {
		zeNavigator.logout();
	}

}
