package com.thed.zeuihtml.ze.impl.zehtmlpages;

import java.util.List;

import org.apache.log4j.Logger;
import org.omg.CORBA.COMM_FAILURE;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;

public class CustomizationPage {
	
	Logger logger;
	
	public CustomizationPage(){
		logger = Logger.getLogger(this.getClass());
	}

	public static CustomizationPage getInstance(){
		return PageFactory.initElements(Driver.driver, CustomizationPage.class);
	}
	
	/******************************************************
	 * 	WEBELEMENTS
	 *****************************************************/
	
	
	@FindBy(xpath="//button[@id='constant_testcase']")
	private WebElement buttonTestcaseFields;
	
	@FindBy(xpath="//button[@id='constant_requirement']")
	private WebElement buttonRequirementFields;
	
	@FindBy(xpath="//button[@id='constant_projects']")
	private WebElement buttonProjectFields;
	
	@FindBy(xpath="//h4[text()='Customize Fields']")
	private WebElement headerTestcaseCustomizeFields;
	
	@FindBy(xpath="//button[@id='lock-zephyr-access']")
	private WebElement buttonLockZephyrAccess;
	
	@FindBy(xpath="//button[@id='enable-zephyr-access']")
	private WebElement buttonEnableZephyrAccess;
	
	@FindBy(xpath="//button[@value='LOCK_ACCESS']")
	private WebElement buttonYesInConfirmationPopuForCustomField;
	
	@FindBy(xpath="//button[@value='SAVE_EST_TIME']")
	private WebElement buttonYesInConfirmationPopupForESTTime;
	
	@FindBy(xpath="//button[@value='EXECUTION_STATUS_FORM_SUBBMIT']")
	private WebElement buttonYesInConfirmationPopupForExecutionStatus;
	
	@FindBy(xpath="//button[text()='No']")
	private WebElement buttonNoInConfirmationPopup;
	
	@FindBy(xpath="//span[@title='Add New Field']")
	private WebElement addNewField;
	
	@FindBy(xpath="//input[@id='displayName']")
	private WebElement textBoxCustomFieldName;
	
	@FindBy(xpath="//input[@id='description']")
	private WebElement textBoxCustomFieldDescriptionName;
	
	@FindBy(xpath="//select[@id='dataType']")
	private WebElement selectDataTypeOfCustomField;
	
	@FindBy(xpath="//input[@id='searchableCheckbox']")
	private WebElement checkboxSearchable;
	
	@FindBy(xpath="//input[@id='uniqueCheckbox']")
	private WebElement checkboxUnique;
	
	@FindBy(xpath="//select[@id='projects']/following-sibling::span")
	private WebElement dropdownProject;
	
	@FindBy(xpath="//input[@id='mandotryCheckbox']")
	private WebElement checkboxMandotry;
	
	@FindBy(xpath="//div[@id='fields-modal']/div/div/div[3]//button[text()='Save']")
	private WebElement buttonSaveCustomField;
	
	@FindBy(xpath="//div[@id='toast-container']/div[text()='Success']")
	private WebElement successMsg;
	
	@FindBy(xpath=".//*[@id='fields-modal']/div/div/div[1]/div[2]/button")
	private WebElement closeCustomFieldPopup;
	
	@FindBy(xpath="//div[@title='Text Custom Field']/parent::div/parent::div/following-sibling::div//span[@title='Delete']")
	private WebElement iconDeleteCustomField;
	
	//div[@id='change-password-modal']//button[@class='close']
	
	@FindBy(xpath="//div[@class='picklist-input clearfix']/input")
	private WebElement textBoxForPickListValue;
	
	@FindBy(xpath="//div[@class='picklist-input clearfix']/span")
	private WebElement buttonAddPicklistValue;
	
	@FindBy(xpath = "//*[@id='toast-container']")
	private WebElement successContainer;
	
	@FindBy(xpath = "//*[@id='toast-container']//div[@class='toast-title']")
	private WebElement SuccessToastTitle;
	
	//Execution Status Elements
	
	@FindBy(xpath="//button[normalize-space(text())='Execution Status']")
	private WebElement buttonExecutionStatus;
	
	@FindBy(xpath="//h4[text()='Manage Test Execution Status']")
	private WebElement headerManageExecutionStatus;
	
	@FindBy(xpath="//span[@title='Add New Status']")
	private WebElement buttonAddNewExecutionStatus;
	
	@FindBy(xpath="//input[@id='execution-status-value']")
	private WebElement textBoxExecutionStatusName;
	
	@FindBy(xpath="//form[contains(@class,'execution-status-form')]//button[text()='Save']")
	private WebElement buttonSaveExecutionStatus;
	//form[contains(@class,'execution-status-form')]//button[@class='close']
	@FindBy(xpath="//div[@id='execution-status-modal']/div/div/div[1]/div[2]/button")
	private WebElement buttonCloseExecutionWindow;
	
	//Step Execution Status Elements
	
	@FindBy(xpath="//button[normalize-space(text())='Step Execution Status']")
	private WebElement buttonStepExecutionStatus;
	
	@FindBy(xpath="//h4[text()='Manage Test Step Execution Status']")
	private WebElement headerManageStepExecutionStatus;
	
	@FindBy(xpath="//span[@title='Add New Status']")
	private WebElement buttonAddNewStepExecutionStatus;
	
	//Estimated Time Elements
	
	@FindBy(xpath="//button[normalize-space(text())='Estimated Time']")
	private WebElement buttonEstimatedTime;
	
	@FindBy(xpath="//div[@id='estimated-time-modal']//h4[text()='Default Estimated Time Editor']")
	private WebElement headerDefaultEstimatedTimeEditor;
	
	@FindBy(xpath="//div[@id='estimated-time-modal']//input[@id='dayText']")
	private WebElement textBoxEstimatedTimeDay;
	
	@FindBy(xpath="//div[@id='estimated-time-modal']//input[@id='hourText']")
	private WebElement textBoxEstimatedTimeHour;
	
	@FindBy(xpath="//div[@id='estimated-time-modal']//input[@id='minuteText']")
	private WebElement textBoxEstimatedTimeMinute;
	
	@FindBy(xpath="//div[@id='estimated-time-modal']//button[text()='Save']")
	private WebElement buttonSaveEstimatedTime;
	
	@FindBy(xpath="//div[@id='estimated-time-modal']//button[@class='close']")
	private WebElement buttonCloseEstimatedTimePopup;
	
	@FindBy(xpath="//div[@id='estimated-time-modal']//b[normalize-space(text())='Default Estimated Time']/parent::label")
	private WebElement labelDefaultEstimatedTime;
	
	//Roles
	
	@FindBy(xpath="//button[normalize-space(text())='Roles']")
	private WebElement buttonRoles;
	
	@FindBy(xpath="//div[@id='roles-modal']//h4[text()='Customize Roles']")
	private WebElement headerCustomizeRoles;
	
	@FindBy(xpath="//span[@title='Add New Role']")
	private WebElement buttonAddNewRoles;
	
	@FindBy(xpath="//input[@id='role-name']")
	private WebElement textboxRoleName;
	
	@FindBy(xpath="//textarea[@id='role-description']")
	private WebElement textAreaRoleDescription;

	@FindBy(xpath="//label[normalize-space(text())='System Setup']")
	private WebElement checkboxSystemSetup;
	
	@FindBy(xpath="//label[normalize-space(text())='User Setup']")
	private WebElement checkboxUserSetup;
	
	@FindBy(xpath="//label[normalize-space(text())='Project Setup']")
	private WebElement checkboxProjectSetup;
	
	@FindBy(xpath="//label[normalize-space(text())='Defects Admin']")
	private WebElement checkboxDefectsAdmin;
	
	@FindBy(xpath="//label[normalize-space(text())='Release Setup']")
	private WebElement checkboxReleaseSetup;
	
	@FindBy(xpath="//label[normalize-space(text())='Requirements']")
	private WebElement checkboxRequirements;
	
	@FindBy(xpath="//label[normalize-space(text())='Test Planning']")
	private WebElement checkboxTestPlanning;
	
	@FindBy(xpath="//label[normalize-space(text())='Test Repository']")
	private WebElement checkboxTestRepository;
	
	@FindBy(xpath="//label[normalize-space(text())='Test Execution']")
	private WebElement checkboxTestExecution;
	
	@FindBy(xpath="//label[normalize-space(text())='Defect Tracking']")
	private WebElement checkboxDefectTracking;
	
	@FindBy(xpath="//label[normalize-space(text())='Global Test Repository']")
	private WebElement checkboxGlobalTestRepo;
	
	@FindBy(xpath="//label[normalize-space(text())='Global Repository Config']")
	private WebElement checkboxGlobalConfig;
	
	
	@FindBy(xpath="//button[text()='Add']")
	private WebElement buttonAddRole;
	
	@FindBy(xpath="//button[text()='Save'][@type='submit']")
	private WebElement buttonSaveRole;
	
	@FindBy(xpath="//div[@id='roles-modal']//button[@class='close']")
	private WebElement buttonCloseCustomizeRoles;
	
	@FindBy(xpath="//button[normalize-space(text())='Miscellaneous']")
	private WebElement buttonMiscellaneous;
	
	@FindBy(xpath="//label[text()='Enable Secondary Authentication']")
	private WebElement checkboxEnableSecondaryAuthentication;
	
	@FindBy(xpath="//div[@id='miscellaneous-modal']//button[text()='Save']")
	private WebElement buttonSaveSecondaryAuthentication;
	
	@FindBy(xpath="//div[@id='confirmation-modal']//button[text()='Yes']")
	private WebElement buttonYesInConfirmationModalForSecondaryAuthentication;
	
	@FindBy(xpath="//div[@id='miscellaneous-modal']//button[@class='close']")
	private WebElement buttonCloseMiscellaneousPopup;
	
	@FindBy(xpath="//button[normalize-space(text())='Full Reindex']")
	private WebElement buttonFullReindex;
	
	@FindBy(xpath="//h4[text()='Full Reindex']")
	private WebElement headerFullReindex;
	
	@FindBy(xpath="//button[text()='Reindex']")
	private WebElement buttonReindex;
	
	@FindBy(xpath="//div[@id='job-status-modal-reindex']//span[text()='Success']")
	private WebElement textSuccess;
	
	@FindBy(xpath="//div[@id='job-status-modal-reindex']//p[contains(text(),'Completed 100 %')]")
	private WebElement textComplete100;
	
	@FindBy(xpath="//div[@id='job-status-modal-reindex']//p[normalize-space(text())='Full reindexing is completed. Please check logs for any errors.']")
	private WebElement textFullReindexingIsCompleted;
	
	@FindBy(xpath="//div[@id='job-status-modal-reindex']//button[@class='close']")
	private WebElement buttonCloseReindexProgressWindow;
	
	@FindBy(xpath="//button[normalize-space(text())='History']")
	private WebElement buttonHistory;
	
	@FindBy(xpath="//div[@id='history-modal']//h4[text()='Trend Data Collection History']")
	private WebElement headerTrendDataCollectionHistory;
	
	@FindBy(xpath="//div[@id='history-modal']//label[text()='Testcase Creation']")
	private WebElement checkBoxTestcaseCreationForTrend;
	
	@FindBy(xpath="//div[@id='history-modal']//label[text()='Testcase Execution']")
	private WebElement checkboxTestcaseExecutionForTrend;
	
	@FindBy(xpath="//div[@id='history-modal']//label[text()='Defect']")
	private WebElement checkboxDefectForTrend;
	
	@FindBy(xpath="//div[@id='history-modal']//button[text()='Run Now']")
	private WebElement buttonRunNow;
	
	@FindBy(xpath="//div[@id='confirmation-modal']//button[text()='Yes']")
	private WebElement buttonYesInConfirmationModalForTrendDataCollection;
	
	@FindBy(xpath="//div[@id='history-modal']//button[text()='Refresh History']")
	private WebElement buttonRefreshHistory;
	
	@FindBy(xpath="//div[@id='grid-table-etl_history']//div[text()='TestcaseTransformationJob']")
	private WebElement textJobNameTestcaseTransformation;
	
	@FindBy(xpath="//div[@id='grid-table-etl_history']//div[text()='TestcaseTransformationJob']/parent::div/parent::div/following-sibling::div//div[text()='Completed']")
	private WebElement textCompletedStatusForTestcaseTransformationJob;
	
	@FindBy(xpath="//div[@id='grid-table-etl_history']//div[text()='TestcaseExecutionTransformationJob']")
	private WebElement textJobNameTestcaseExecutionTransformation;
	
	@FindBy(xpath="//div[@id='grid-table-etl_history']//div[text()='TestcaseExecutionTransformationJob']/parent::div/parent::div/following-sibling::div//div[text()='Completed']")
	private WebElement textCompletedStatusForTestcaseExecutionTransformationJob;
	
	@FindBy(xpath="//div[@id='grid-table-etl_history']//div[text()='TestcaseExecutionDailySnapshotTransformationJob']")
	private WebElement textJobNameTestcaseExecutionDailySnapshotTransformation;
	
	@FindBy(xpath="//div[@id='grid-table-etl_history']//div[text()='TestcaseExecutionDailySnapshotTransformationJob']/parent::div/parent::div/following-sibling::div//div[text()='Completed']")
	private WebElement textCompletedStatusForTestcaseExecutionDailySnapshotTransformationJob;
	
	@FindBy(xpath="//div[@id='grid-table-etl_history']//div[text()='DefectTrendJob']")
	private WebElement textJobNameDefectTrend;
	
	@FindBy(xpath="//div[@id='grid-table-etl_history']//div[text()='DefectTrendJob']/parent::div/parent::div/following-sibling::div//div[text()='Completed']")
	private WebElement textCompletedStatusForDefectTrendJob;
	
	@FindBy(xpath="//div[@id='history-modal']//button[@class='close']")
	private WebElement buttonCloseTrendJobPopup;
	
	@FindBy(xpath="//div[@id='confirmation-modal']//h4[text()='Performance Warning']")
	private WebElement headerPerformanceWarning;
	
	@FindBy(xpath="//div[@id='confirmation-modal']//button[text()='Continue']")
	private WebElement buttonContinueInPerformanceWarningPopup;
	
	@FindBy(xpath = "//*[@id='projectCheck']")
	private WebElement projectCheckAll;
	
	// Project Reindex
	
	@FindBy(xpath = "//button[text()='Project Reindex']")
	private WebElement buttonProjectReindex;
	
	@FindBy(xpath="//div[@id='confirmation-modal']//h4[text()='Project Reindex']")
	private WebElement headerProjectReindex;
	
	@FindBy(xpath="//div[@id='confirmation-modal']//select[@class='select2-hidden-accessible']")
	private WebElement selectProjectToReindex;
	
	@FindBy(xpath="//div[@id='confirmation-modal']//button[@value='REINDEX']")
	private WebElement buttonReindexInConfirmationModal;
	
	@FindBy(xpath="//div[@id='job-status-modal-reindex']//h4[text()='Re-index Progress']")
	private WebElement headerReindexProgress;
	
	@FindBy(xpath="//div[@id='job-status-modal-reindex']//span[text()='Success']")
	private WebElement textSuccessInProjectReindexStatus;
	
	@FindBy(xpath="//div[@id='job-status-modal-reindex']//p[contains(text(),'Completed 100')]")
	private WebElement textCompleted100InProjectReindex;
	
	@FindBy(xpath="//div[@id='job-status-modal-reindex']//button[text()='Ok']")
	private WebElement buttonOkInProjectReindex;

	@FindBy(xpath = "//h4[text()='Performance Warning']")
	private WebElement performanceWarning;
	
	@FindBy(xpath = "//div[@class='modal-footer modal-draggable-handle']//button[text()='Continue']")
	private WebElement buttonContinue;
	
	@FindBy(xpath = "//input[@id='uniqueCheckbox']//parent::div[@class='zui-checkbox2 disabled']")
	private WebElement uniqueCheckboxdisabled;
	
	@FindBy(xpath =".//*[@id='grid-table-etl_history']//div[1]/div[7]/div/div[@title='In progress']")
	private WebElement statusProgressCheck;
	
	@FindBy(xpath = ".//*[@id='confirmation-modal']//h4[text()='Confirmation']")
	private WebElement deleteConfirmation;
	
	@FindBy(xpath = ".//*[@id='confirmation-modal']//button[text() = 'Yes']")
	private WebElement deleteYesConfirmmation;
	
	@FindBy(xpath = ".//*[@id='confirmation-modal']//button[@value='DELETE_FIELD_SECOND']")
	private WebElement deleteConfirmation2;
	
	@FindBy(xpath="//div/p[text()='Projects']/parent::div//span[@class='forward-image']")
	private WebElement addSelectedProject;
	

	@FindBy(xpath="//button[text()='Save']")
	private WebElement buttonSave;
	
	/******************************************************
	 * 	Public Methods
	 *****************************************************/
	public boolean launchCustomizationOptions(String fieldName){
		if(fieldName.equalsIgnoreCase("TestcaseCustomField")){
			launchTestcaseCustomFieldPopup();
		}else{
			if(fieldName.equalsIgnoreCase("RequirementCustomField")){
				launchRequirementCustomFieldPopup();
			}else{
				if(fieldName.equalsIgnoreCase("ExecutionStatus")){
					launchExecutionStatusPopup();
				}else{
					if(fieldName.equalsIgnoreCase("StepExecutionStatus")){
						launchStepExecutionStatusPopup();
					}else{
						if(fieldName.equalsIgnoreCase("EstimatedTime")){
							launchEstimatedTimePopup();
						}else{
							if(fieldName.equalsIgnoreCase("Roles")){
								launchCustomizeRolesPopup();
							}else{
								if(fieldName.equalsIgnoreCase("ProjectCustomFiled")){
									launchProjectCustomFieldPopup();
								}else{
							
								}
							}
						}
					}
				}
			}
			
		}
		return true;
	}
	
	public boolean updateDefaultEstimatedTime(String estimatedTime){
		CommonUtil.normalWait(3000);
		String time[] = estimatedTime.split(":");
		
		if(CommonUtil.visibilityOfElementLocated(headerDefaultEstimatedTimeEditor)){
			if(CommonUtil.visibilityOfElementLocated(textBoxEstimatedTimeDay)){
				CommonUtil.normalWait(500);
				textBoxEstimatedTimeDay.clear();
				CommonUtil.normalWait(1000);
				textBoxEstimatedTimeDay.sendKeys(time[0]);
				
				if(CommonUtil.visibilityOfElementLocated(textBoxEstimatedTimeHour)){
					CommonUtil.normalWait(500);
					textBoxEstimatedTimeHour.clear();
					CommonUtil.normalWait(1000);
					textBoxEstimatedTimeHour.sendKeys(time[1]);
					
					if(CommonUtil.visibilityOfElementLocated(textBoxEstimatedTimeMinute)){
						CommonUtil.normalWait(500);
						textBoxEstimatedTimeMinute.clear();
						CommonUtil.normalWait(1000);
						textBoxEstimatedTimeMinute.sendKeys(time[2]);
						
						if(CommonUtil.visibilityOfElementLocated(buttonSaveEstimatedTime)){
							CommonUtil.normalWait(2000);
							labelDefaultEstimatedTime.click();
							CommonUtil.normalWait(2000);
							buttonSaveEstimatedTime.click();
							CommonUtil.normalWait(4000);
							if(CommonUtil.visibilityOfElementLocated(buttonYesInConfirmationPopupForESTTime)){
								buttonYesInConfirmationPopupForESTTime.click();
								CommonUtil.normalWait(5000);
							//	HomePage.getInstance().closeToastPopup();
								HomePage.getInstance().waitForProgressBarToComplete();
								CommonUtil.normalWait(5000);
								
								
						/*		if(CommonUtil.visibilityOfElementLocated(buttonCloseEstimatedTimePopup, 5)){
									CommonUtil.normalWait(1000);
									CommonUtil.moveToElement(buttonCloseEstimatedTimePopup);
									buttonCloseEstimatedTimePopup.click();
									CommonUtil.normalWait(3000);
								}else{
									logger.info("Close Estimated Time popup button not found");
									CommonUtil.browserRefresh();
									CommonUtil.visibilityOfElementLocated(buttonEstimatedTime, 5);
									CommonUtil.normalWait(3000);
									return false;
								}*/
							}else{
								logger.info("Yes Button in Confirmation popup button not found");
								return false;
							}
						}else{
							logger.info("Save Estimated Time button not found");
							return false;
						}
						
					}else{
						logger.info("Minute Textbox for Estimated Time not found");
						return false;
					}
					
				}else{
					logger.info("Hour Textbox for Estimated Time not found");
					return false;
				}
				
			}else{
				logger.info("Day Textbox for Estimated Time not found");
				return false;
			}
		}else{
			logger.info("Header Default Estimated Time Editor not found");
			return false;
		}
		
		return true;
	}
	
	public void verifyEstimatedTime(String estimatedTime){
		CommonUtil.normalWait(1000);
		String time[] = estimatedTime.split(":");
		
		if(CommonUtil.visibilityOfElementLocated(headerDefaultEstimatedTimeEditor)){
			if(CommonUtil.visibilityOfElementLocated(textBoxEstimatedTimeDay)){
				Assert.assertTrue(textBoxEstimatedTimeDay.getAttribute("value").equals(time[0]), "Day value not matching, Expected as :"
						+ time[0] + " Found Actual Day value as: " +textBoxEstimatedTimeDay.getAttribute("value"));
				
				if(CommonUtil.visibilityOfElementLocated(textBoxEstimatedTimeHour)){
					Assert.assertTrue(textBoxEstimatedTimeHour.getAttribute("value").equals(time[1]), "Hour value not matching, Expected as :"
							+ time[1] + " Found Actual Hour value as: " +textBoxEstimatedTimeHour.getAttribute("value"));
					
					if(CommonUtil.visibilityOfElementLocated(textBoxEstimatedTimeMinute)){
						Assert.assertTrue(textBoxEstimatedTimeMinute.getAttribute("value").equals(time[2]), "Minute value not matching, Expected as :"
								+ time[2] + " Found Actual Minute value as: " +textBoxEstimatedTimeMinute.getAttribute("value"));
						if(CommonUtil.visibilityOfElementLocated(buttonCloseEstimatedTimePopup)){
							CommonUtil.normalWait(1000);
							CommonUtil.scrollToWebElementAndView(buttonCloseEstimatedTimePopup);
							buttonCloseEstimatedTimePopup.click();
						}else{
							logger.info("Close Estimated Time popup button not found");
							CommonUtil.browserRefresh();
							CommonUtil.visibilityOfElementLocated(buttonEstimatedTime);
						}
						
					}else{
						logger.info("Minute Textbox for Estimated Time not found");
					}
				}else{
					logger.info("Hour Textbox for Estimated Time not found");
				}
				
			}else{
				logger.info("Day Textbox for Estimated Time not found");
			}
		}else{
			logger.info("Header Default Estimated Time Editor not found");
		}

	}
	
	
	public boolean addExecutionStatus(String executionStatusName){
		
		if(CommonUtil.visibilityOfElementLocated(buttonAddNewExecutionStatus)){
			CommonUtil.normalWait(2000);
			buttonAddNewExecutionStatus.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			
			if(CommonUtil.visibilityOfElementLocated(textBoxExecutionStatusName)){
				textBoxExecutionStatusName.sendKeys(executionStatusName);
				if(CommonUtil.visibilityOfElementLocated(buttonSaveExecutionStatus)){
					buttonSaveExecutionStatus.click();
					//buttonYesInConfirmationPopup.click();
					if(CommonUtil.visibilityOfElementLocated(buttonYesInConfirmationPopupForExecutionStatus)){
						buttonYesInConfirmationPopupForExecutionStatus.click();
						HomePage.getInstance().closeToastPopup();
						HomePage.getInstance().waitForProgressBarToComplete();
						return true;
					}else{
						logger.info("Confirmation popup button not found");
						return false;
					}
					
				}else{
					logger.info("Button Save Execution not found");
					return false;
				}
			}else{
				logger.info("TextBox Execution Status Value not found");
				return false;
			}	
			
		}else{
			logger.info("Add New Execution Status Button not found");
			return false;
		}
	}
	
	public void verifyExecutionStatus(String executionStatusName, boolean closeWindowAfterVerifying){
		CommonUtil.normalWait(1000);
		boolean found = CommonUtil.visibilityOfElementLocated("//div[contains(@id,'grid-table-tst')]//div[text()='"+executionStatusName+"']");
		if(closeWindowAfterVerifying){
			HomePage.getInstance().waitForProgressBarToComplete();
			if(CommonUtil.visibilityOfElementLocated(buttonCloseExecutionWindow)){
				//CommonUtil.normalWait(2000);
				buttonCloseExecutionWindow.click();
				CommonUtil.browserRefresh();
				HomePage.getInstance().waitForProgressBarToComplete();
			}else{
				logger.info("Close button not found in Manage Execution Window");
			}
		}
		Assert.assertTrue(found, "Execution Status not found by Name : " + executionStatusName);
	}
	
	public boolean addCustomField(String customFieldName, String customFieldType, String customFieldDescription, 
			boolean searchable, boolean mandatory, String projectName, boolean all){
		//CommonUtil.normalWait(5000);
		logger.info("Going to check Add New Custom field button");
		//CommonUtil.ExplicitWaitForElement(addNewField);
		HomePage.getInstance().waitForProgressBarToComplete();
		
		if(CommonUtil.visibilityOfElementLocated(addNewField)){
			addNewField.click();
			logger.info("Clicked Add New Custom field button successfully");
			//addNewField.click();
			CommonUtil.normalWait(3000);
			
			if(CommonUtil.visibilityOfElementLocated(textBoxCustomFieldName)){
				logger.info("Going to type custom field name: " + customFieldName);
				textBoxCustomFieldName.sendKeys(customFieldName);
				CommonUtil.normalWait(500);
				if(customFieldDescription!=null){
					logger.info("Going to type custom field description: " + customFieldDescription);
					textBoxCustomFieldDescriptionName.sendKeys(customFieldDescription);
					CommonUtil.normalWait(500);
				}
				logger.info("Going to select custom field type: " + customFieldType);
				CommonUtil.selectListWithVisibleText(selectDataTypeOfCustomField, customFieldType);
				CommonUtil.normalWait(500);
				if(searchable){
					logger.info("Going to check checkbox searchable");
					checkboxSearchable.click();
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.normalWait(1000);
				}
				if(all){
					logger.info("Going to select ALL Project");
					projectCheckAll.click();
					CommonUtil.normalWait(1000);
				}
				
				if(projectName!=null){
				logger.info("Going to select project: " + projectName);
				dropdownProject.click();
				CommonUtil.normalWait(1000);
				CommonUtil.returnWebElement("//li[text()='"+projectName+"']").click();
				CommonUtil.normalWait(1000);
				}
				
				logger.info("Going to click on save button to add custom field");
				buttonSaveCustomField.click();
				logger.info("Clicked on save button successfully");
				/*WebElement we;
				try {
					we = Driver.driver.findElement(By.xpath("//h4[text()='Performance Warning']"));
					if(we!=null){
						if(we.isDisplayed()) {
							buttonContinue.click();
							CommonUtil.normalWait(1000);
						}
					}
				} catch (Exception e) {
				}*/
				return HomePage.getInstance().waitForProgressBarToComplete();
				//return verifySuccessPopupForCustomFieldCreation();
			}else{
				logger.info("Textbox custom field name found");
				return false;
			}
			
			
			
		}else{
			logger.info("Add New Customfield button not found");
			return false;
		}
		
		
	}
	
	public boolean addCustomField(String customFieldName, String customFieldType, String customFieldDescription, 
			boolean searchable, boolean mandatory, String projectName, boolean unique, boolean all){
		//CommonUtil.normalWait(5000);
		logger.info("Going to check Add New Custom field button");
		//CommonUtil.ExplicitWaitForElement(addNewField);
		HomePage.getInstance().waitForProgressBarToComplete();
		
		if(CommonUtil.visibilityOfElementLocated(addNewField)){
			addNewField.click();
			logger.info("Clicked Add New Custom field button successfully");
			//addNewField.click();
			CommonUtil.normalWait(3000);
			
			if(CommonUtil.visibilityOfElementLocated(textBoxCustomFieldName)){
				logger.info("Going to type custom field name: " + customFieldName);
				textBoxCustomFieldName.sendKeys(customFieldName);
				CommonUtil.normalWait(500);
				if(customFieldDescription!=null){
					logger.info("Going to type custom field description: " + customFieldDescription);
					textBoxCustomFieldDescriptionName.sendKeys(customFieldDescription);
					CommonUtil.normalWait(500);
				}
				logger.info("Going to select custom field type: " + customFieldType);
				CommonUtil.selectListWithVisibleText(selectDataTypeOfCustomField, customFieldType);
				CommonUtil.normalWait(500);
				if(searchable){
					logger.info("Going to check checkbox searchable");
					checkboxSearchable.click();
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.normalWait(1000);
				}
				if (unique) {
					logger.info("Going to check checkbox unique");
					checkboxUnique.click();
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.normalWait(1000);
				}
				if (all) {
					logger.info("Going to select ALL Project");
					projectCheckAll.click();
					CommonUtil.normalWait(1000);
				}
				else {
				logger.info("Going to select project: " + projectName);
				dropdownProject.click();
				CommonUtil.normalWait(1000);
				CommonUtil.returnWebElement("//li[text()='"+projectName+"']").click();
				CommonUtil.normalWait(1000);
				}
				
				logger.info("Going to click on save button to add custom field");
				buttonSaveCustomField.click();
				logger.info("Clicked on save button successfully");
				
				CommonUtil.normalWait(1000);
				
				WebElement we;
				try {
					we = Driver.driver.findElement(By.xpath("//h4[text()='Performance Warning']"));
					if(we!=null){
						if(we.isDisplayed()) {
							buttonContinue.click();
							CommonUtil.normalWait(1000);
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				return HomePage.getInstance().waitForProgressBarToComplete();
				//return verifySuccessPopupForCustomFieldCreation();
			}else{
				logger.info("Textbox custom field name found");
				return false;
			}
			
			
			
		}else{
			logger.info("Add New Customfield button not found");
			return false;
		}
		
	}
	
	public boolean uncheckUniqueReqCustomField(String customFieldName){
		try {
			logger.info("Going to select Custom field");
			HomePage.getInstance().waitForProgressBarToComplete();
		
			String customFieldXpath ="//div[@id='grid-table-req_fields']//div[text()='"+customFieldName+"']";
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(customFieldXpath), "Custom Field not found");
			CommonUtil.returnWebElement(customFieldXpath).click();
			CommonUtil.normalWait(3000);
			logger.info("Going to uncheck checkbox unique");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(customFieldXpath),"Unique check box not found");
			checkboxUnique.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			logger.info("Going to click on save button to add custom field");
			buttonSaveCustomField.click();
			//HomePage.getInstance().closeToastPopup();
			HomePage.getInstance().waitForProgressBarToComplete();
			logger.info("Clicked on save button successfully");
			CommonUtil.normalWait(1000);
			logger.info("Checking unique check box is unchecked or not");	
			Assert.assertTrue(CommonUtil.isElementPresent(uniqueCheckboxdisabled),"Unique field not unchecked");
			logger.info("Unique checkbox unchecked successfully");
			return true;
			
		}catch (Exception e){
			logger.info("Customfield not found");
			e.printStackTrace();
			return false;
		}
		
	}
	
	public boolean uncheckUniqueTestcaseCustomField(String customFieldName){
		try {
			logger.info("Going to select Custom field");
			CommonUtil.normalWait(1000);
			String customFieldXpath ="//*[@id='grid-table-tst_fields']//div[@class='grid-content']//div[text()='"+customFieldName+"']";
			CommonUtil.scrollToWebElement(CommonUtil.returnWebElement(customFieldXpath));
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(customFieldXpath), "Custom Field not found");
			CommonUtil.returnWebElement(customFieldXpath).click();
			CommonUtil.normalWait(3000);
			logger.info("Going to uncheck checkbox unique");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(customFieldXpath),"Unique check box not found");
			checkboxUnique.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			logger.info("Going to click on save button to add custom field");
			buttonSaveCustomField.click();
			Assert.assertTrue(verifySuccessPopup());
			//HomePage.getInstance().closeToastPopup();
			HomePage.getInstance().waitForProgressBarToComplete();
			logger.info("Clicked on save button successfully");
			CommonUtil.normalWait(1000);
			logger.info("Checking unique check box is unchecked or not");	
			Assert.assertTrue(CommonUtil.isElementPresent(uniqueCheckboxdisabled),"Unique field not unchecked");
			logger.info("Unique checkbox unchecked successfully");
			return true;
			
		}catch (Exception e){
			logger.info("Customfield not found");
			e.printStackTrace();
			return false;
		}
		
	}
	
	public boolean addCustomFieldPicklist(String customFieldName, String customFieldType, String customFieldDescription, 
			boolean searchable, boolean mandatory, List<String> picklistValues, String projectName, boolean all){
		
		try{
			logger.info("Going to check Add New Custom field button");
			//CommonUtil.ExplicitWaitForElement(addNewField);
			HomePage.getInstance().waitForProgressBarToComplete();
			
			if(CommonUtil.visibilityOfElementLocated(addNewField)){
				addNewField.click();
				logger.info("Clicked Add New Custom field button successfully");
				//addNewField.click();
				CommonUtil.normalWait(3000);
				
				if(CommonUtil.visibilityOfElementLocated(textBoxCustomFieldName)){
					logger.info("Going to type custom field name: " + customFieldName);
					textBoxCustomFieldName.sendKeys(customFieldName);
					CommonUtil.normalWait(500);
					if(customFieldDescription!=null){
						logger.info("Going to type custom field description: " + customFieldDescription);
						textBoxCustomFieldDescriptionName.sendKeys(customFieldDescription);
						CommonUtil.normalWait(500);
					}
					logger.info("Going to select custom field type: " + customFieldType);
					CommonUtil.selectListWithVisibleText(selectDataTypeOfCustomField, customFieldType);
					CommonUtil.normalWait(500);
					if(searchable){
						logger.info("Going to check checkbox searchable");
						checkboxSearchable.click();
						HomePage.getInstance().waitForProgressBarToComplete();
						CommonUtil.normalWait(1000);
					}
					
					for(String value: picklistValues){
						if(CommonUtil.visibilityOfElementLocated(textBoxForPickListValue)){
							logger.info("Adding picklist value : " +value);
							textBoxForPickListValue.sendKeys(value);
							CommonUtil.normalWait(1000);
							if(CommonUtil.visibilityOfElementLocated(buttonAddPicklistValue)){
								buttonAddPicklistValue.click();
								logger.info("Clicked Add button");
							}else{
								logger.info("Button to add value to picklist not found");
								return false;
							}
						}else{
							logger.info("Text Box to type value of picklist not found");
							return false;
						}
					}
					
					if(all){
						logger.info("Going to select ALL Project");
						projectCheckAll.click();
						CommonUtil.normalWait(1000);	
					}
					if(projectName!=null)
					{
					logger.info("Going to select project: " + projectName);
					dropdownProject.click();
					CommonUtil.normalWait(1000);
					CommonUtil.returnWebElement("//li[text()='"+projectName+"']").click();
					CommonUtil.normalWait(1000);
					}
					
					logger.info("Going to click on save button to add custom field");
					buttonSaveCustomField.click();
					logger.info("Clicked on save button successfully");
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.normalWait(2000);
					
					try {
						if(headerPerformanceWarning.isDisplayed()) {
							buttonContinueInPerformanceWarningPopup.click();
							CommonUtil.normalWait(1000);
					}
					} catch (Exception e) {
						e.printStackTrace();
						return true;
					}
				
					
					return HomePage.getInstance().waitForProgressBarToComplete();
				}else{
					logger.info("Picklist custom field name found");
					return false;
				}
		
			}else{
				logger.info("Add New Customfield button not found");
				return false;
			}
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
	}

	
	public boolean lockZephyrAccess(boolean lock){
		if(lock){
			return lockZephyrAccess();
		}else{
			return enableZephyrAccess();
		}
	}
	
	public boolean verifyCustomFields(String customFieldName, String customFieldType, String customFieldDescriptio, 
			boolean searchable, boolean mandatory){
		
		if(customFieldName!=null){
			logger.info("Going to verify created custom field name: " + customFieldName);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@title='"+customFieldName+"']"),"Custom Field By Name not found");
		}
		if(customFieldType!=null){
			logger.info("Going to verify created custom field type: " + customFieldType);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@title='"+customFieldName+"']/parent::div/parent::div/following-sibling::div//div[@title='"+customFieldDescriptio+"']")
					, "Custom field description not found");
		}
		if(customFieldDescriptio!=null){
			logger.info("Going to verify created custom field description: " + customFieldDescriptio);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@title='"+customFieldName+"']/parent::div/parent::div/following-sibling::div//div[@title='"+customFieldType+"']")
					, "Custom field description not found");
		}
		//Inprogress to develop searchable and mandatory verification
		return true;
	}
	
	public boolean editCustomfield(String customFieldName, String customfieldUpdate){
		CommonUtil.normalWait(1000);
		try {
			logger.info("Going to select Custom field");
			HomePage.getInstance().waitForProgressBarToComplete();
		
			String customFieldXpath =".//*[@id='grid-table-project_fields']//div[text()='"+customFieldName+"']";
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(customFieldXpath), "Custom Field not found");
			CommonUtil.returnWebElement(customFieldXpath).click();
			CommonUtil.normalWait(3000);
			logger.info("Going to update the customfield");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(customFieldXpath),"Customfield found");
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			textBoxCustomFieldName.clear();
			textBoxCustomFieldName.sendKeys(customfieldUpdate);
			CommonUtil.normalWait(1000);
			logger.info("Going to click on save button to add custom field");
			buttonSaveCustomField.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			logger.info("Clicked on save button successfully");
			CommonUtil.normalWait(1000);
			Assert.assertTrue(CommonUtil.isElementPresent(".//*[@id='grid-table-project_fields']//div[text()='"+customfieldUpdate+"']"));
			logger.info("customfield Updated successfully..");
			return true;
			
		}catch (Exception e){
			logger.info("Customfield not found");
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean deleteCustomfield(String customFieldName){
		
		try {
			logger.info("Going to select Custom field");
			HomePage.getInstance().waitForProgressBarToComplete();
			String customFieldXpath =".//*[@id='grid-table-project_fields']//div[text()='"+customFieldName+"']";
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(customFieldXpath), "Custom Field not found");
			CommonUtil.returnWebElement(customFieldXpath).click();
			CommonUtil.normalWait(3000);
			String customfieldXpathDelete = "//*[@id='grid-table-project_fields']//div[text()='"+customFieldName+"']/parent::div/parent::div/following-sibling::div[@data-col-index='4']//span[@data-action='delete']";
			CommonUtil.returnWebElement(customfieldXpathDelete).click();
			CommonUtil.normalWait(1000);
			if (CommonUtil.visibilityOfElementLocated(deleteConfirmation)){
				CommonUtil.normalWait(500);
				deleteYesConfirmmation.click();
				CommonUtil.normalWait(1000);
				deleteConfirmation2.click();
				CommonUtil.normalWait(1000);
				
				logger.info("customfild deleted successfully");
			}
			return true;
			
		}catch(Exception e){
			logger.info("Customfield not found");
			e.printStackTrace();
			return false;
		
		}
		
	}
	
	public boolean addNewRole(String roleName, String roleDescription, boolean systemSetup, boolean userSetup, boolean projectSetup
			, boolean defectsAdmin, boolean releaseSetup, boolean requirements, boolean testPlanning, boolean testRepository
			, boolean testExecution, boolean defectTracking, boolean closeWindowAfterCreation){
		CommonUtil.normalWait(500);
		try{
			logger.info("Going to click on Add New Role button");
			buttonAddNewRoles.click();
			logger.info("Clicked Successfully on Add New Role button");
			
			if(CommonUtil.visibilityOfElementLocated(textboxRoleName)){
				CommonUtil.normalWait(500);
				textboxRoleName.sendKeys(roleName);
				logger.info("Typed Role name in textbox successfully, Role Name : " + roleName);
				CommonUtil.normalWait(500);
				textAreaRoleDescription.sendKeys(roleDescription);
				logger.info("Typed Role Description in textbox successfully, Role Name : " + roleDescription);
				CommonUtil.normalWait(500);
				
				if(systemSetup){
					checkboxSystemSetup.click();
					logger.info("Checked System Setup App Successfully");
					CommonUtil.normalWait(500);
				}
				
				if(userSetup){
					checkboxUserSetup.click();
					logger.info("Checked User Setup App Successfully");
					CommonUtil.normalWait(500);
				}
				
				if(projectSetup){
					checkboxProjectSetup.click();
					logger.info("Checked Project Setup App Successfully");
					CommonUtil.normalWait(500);
				}
				
				if(defectsAdmin){
					checkboxDefectsAdmin.click();
					logger.info("Checked Defects Admin App Successfully");
					CommonUtil.normalWait(500);
				}
				
				if(releaseSetup){
					checkboxReleaseSetup.click();
					logger.info("Checked Release Setup App Successfully");
					CommonUtil.normalWait(500);
				}
				
				if(requirements){
					checkboxRequirements.click();
					logger.info("Checked Requirements App Successfully");
					CommonUtil.normalWait(500);
				}
				
				if(testPlanning){
					checkboxTestPlanning.click();
					logger.info("Checked Test Planning App Successfully");
					CommonUtil.normalWait(500);
				}
				
				if(testRepository){
					checkboxTestRepository.click();
					logger.info("Checked Test Repository App Successfully");
					CommonUtil.normalWait(500);
				}
				
				if(testExecution){
					checkboxTestExecution.click();
					logger.info("Checked Test Execution App Successfully");
					CommonUtil.normalWait(500);
				}
				
				if(defectTracking){
					checkboxDefectTracking.click();
					logger.info("Checked Defect Tracking App Successfully");
					CommonUtil.normalWait(500);
				}
				
				buttonAddRole.click();
				logger.info("Clicked on Add button to save custom role Successfully");
				HomePage.getInstance().closeToastPopup();
				HomePage.getInstance().waitForProgressBarToComplete();
				
				
				if(closeWindowAfterCreation){
					CommonUtil.normalWait(1000);
					CommonUtil.scrollToWebElementAndView(buttonCloseCustomizeRoles);
					buttonCloseCustomizeRoles.click();
					CommonUtil.normalWait(1000);
				}
				
			}else{
				logger.info("Textbox Role Name not found");
			}
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean editRole(String roleName, String roleDescription, boolean systemSetup, boolean userSetup, boolean projectSetup
			, boolean defectsAdmin, boolean releaseSetup, boolean requirements, boolean testPlanning, boolean testRepository
			, boolean testExecution, boolean defectTracking, boolean closeWindowAfterCreation, boolean globalTestRepository, boolean globalRepoConfig){
		CommonUtil.normalWait(500);
		try{
			
			logger.info("Going to click on Role button ");
			
			
			
			//buttonAddNewRoles.click();
			//logger.info("Clicked Successfully on Add New Role button");
				CommonUtil.normalWait(3000);
				CommonUtil.returnWebElement("//div[@title='"+roleName+"']").click();
				CommonUtil.normalWait(2000);
				if(systemSetup){
					checkboxSystemSetup.click();
					logger.info("Checked System Setup App Successfully");
					CommonUtil.normalWait(500);
				}
				
				if(userSetup){
					checkboxUserSetup.click();
					logger.info("Checked User Setup App Successfully");
					CommonUtil.normalWait(500);
				}
				
				if(projectSetup){
					checkboxProjectSetup.click();
					logger.info("Checked Project Setup App Successfully");
					CommonUtil.normalWait(500);
				}
				
				if(defectsAdmin){
					checkboxDefectsAdmin.click();
					logger.info("Checked Defects Admin App Successfully");
					CommonUtil.normalWait(500);
				}
				
				if(releaseSetup){
					checkboxReleaseSetup.click();
					logger.info("Checked Release Setup App Successfully");
					CommonUtil.normalWait(500);
				}
				
				if(requirements){
					checkboxRequirements.click();
					logger.info("Checked Requirements App Successfully");
					CommonUtil.normalWait(500);
				}
				
				if(testPlanning){
					checkboxTestPlanning.click();
					logger.info("Checked Test Planning App Successfully");
					CommonUtil.normalWait(500);
				}
				
				if(testRepository){
					checkboxTestRepository.click();
					logger.info("Checked Test Repository App Successfully");
					CommonUtil.normalWait(500);
				}
				
				if(testExecution){
					checkboxTestExecution.click();
					logger.info("Checked Test Execution App Successfully");
					CommonUtil.normalWait(500);
				}
				
				if(defectTracking){
					checkboxDefectTracking.click();
					logger.info("Checked Defect Tracking App Successfully");
					CommonUtil.normalWait(500);
				}
				
				if(globalTestRepository) {
					checkboxGlobalTestRepo.click();
					logger.info("checked Global Test Repo App");
					CommonUtil.normalWait(500);
				
				}
				
				if(globalRepoConfig) {
					checkboxGlobalConfig.click();
					logger.info("checked Global Test config App");
					CommonUtil.normalWait(500);
				
				}
				
				
				buttonSaveRole.click();
				logger.info("Clicked on Save button to save role Successfully");
				HomePage.getInstance().closeToastPopup();
				HomePage.getInstance().waitForProgressBarToComplete();
				
				
				if(closeWindowAfterCreation){
					CommonUtil.normalWait(1000);
					CommonUtil.scrollToWebElementAndView(buttonCloseCustomizeRoles);
					buttonCloseCustomizeRoles.click();
					CommonUtil.normalWait(1000);
					
				}
				
			
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public void verifyRole(String roleName, String RoleDescription, boolean closeWindowAferVerifying){
		
		
		boolean roleNameStatus = CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-roles']//div[@title='"+roleName+"']");
		
		boolean roleDescriptionStatus = CommonUtil.visibilityOfElementLocated
				("//div[@id='grid-table-roles']//div[@title='"+roleName+"']/parent::div/parent::div/parent::div//div[@title='"+RoleDescription+"']");
		
		if(closeWindowAferVerifying){
			buttonCloseCustomizeRoles.click();
			CommonUtil.normalWait(1000);
		}
		Assert.assertTrue(roleNameStatus, "Role Name not found as : " + roleName);
		Assert.assertTrue(roleDescriptionStatus, "Role Description not found as : " + RoleDescription + " for Role : " + roleName);
		
	}
	
	public boolean enableDisableSecondaryAuthentication(){
		try{
			HomePage.getInstance().waitForProgressBarToComplete();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonMiscellaneous), "Button Miscellaneous not found");
			buttonMiscellaneous.click();
			CommonUtil.normalWait(1000);
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(checkboxEnableSecondaryAuthentication)
					, "Checkbox Secondary Authentication not found");
			checkboxEnableSecondaryAuthentication.click();
			CommonUtil.normalWait(1000);
			buttonSaveSecondaryAuthentication.click();
			CommonUtil.normalWait(1000);
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonYesInConfirmationModalForSecondaryAuthentication)
					, "Yes button not found in confirmation popup");
			buttonYesInConfirmationModalForSecondaryAuthentication.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			buttonCloseMiscellaneousPopup.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			
			
		}catch(Exception e){
			e.printStackTrace();
			logger.info("Failed to change Seconday Authentication");
			Assert.assertTrue(false, "Failed to change Seconday Authentication");
		}
		return true;
	}
	
	public boolean doFullReindex(){
		try{
			HomePage.getInstance().waitForProgressBarToComplete();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonFullReindex), "Button Full reindex not found");
			buttonFullReindex.click();
			CommonUtil.normalWait(1000);

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerFullReindex), "Header Full Reindex not found");
			CommonUtil.normalWait(1000);
			buttonReindex.click();
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textSuccess), "Status as Success not found");

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textComplete100), "Text Completed 100% not found");
	
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textFullReindexingIsCompleted)
					, "Not found text as: Full reindexing is completed. Please check logs for any errors.");
			
			HomePage.getInstance().waitForProgressBarToComplete();
			buttonCloseReindexProgressWindow.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			
		}catch(Exception e){
			e.printStackTrace();
			logger.info("Failed to reindex cleanly");
			Assert.assertTrue(false, "Failed to reindex cleanly");
		}
		return true;
	}
	
	public void doProjectLevelReindex(String projectName) {
		try {
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonProjectReindex), "Button Project Reindex not found");
			buttonProjectReindex.click();
			CommonUtil.normalWait(2000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerProjectReindex), "Header Project Reindex not found in Popup");
//			CommonUtil.selectListWithVisibleText(selectProjectToReindex, projectName);
			CommonUtil.returnWebElement("//*[@id='select2--container']/span[text()='Select Project']").click();
			CommonUtil.normalWait(2000);
			CommonUtil.returnWebElement("//ul[@id='select2--results']//li[text()='"+projectName+"']").click();
			CommonUtil.normalWait(3000);
			buttonReindexInConfirmationModal.click();
			CommonUtil.normalWait(2000);
			HomePage.getInstance().waitForProgressBarToComplete();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerReindexProgress), "Header 'Re-index Progress' not found");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textSuccessInProjectReindexStatus), "Text 'Success' not found in 'Re-index Progress' popup");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textCompleted100InProjectReindex), "Text 'Completed 100 %' not found in 'Re-index Progress' popup");
			buttonOkInProjectReindex.click();
			CommonUtil.normalWait(3000);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Failed to reindex project cleanly");
			Assert.assertTrue(false, "Failed to reindex project cleanly");
		}
	}
	
	public boolean runETLJobForTrendForToday(boolean testcase, boolean execution){
		try{
			HomePage.getInstance().waitForProgressBarToComplete();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonHistory), "Button History not found");
			buttonHistory.click();
			CommonUtil.normalWait(1000);
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerTrendDataCollectionHistory), "Header Trend Data Collection History not found after clicking on History button");
			
			logger.info("Counting older job counts with status completed");
			
			List<WebElement> previousTestcaseTransformationJobsWithStatusComplete = CommonUtil.returnWebElements("//div[@id='grid-table-etl_history']//div[text()='TestcaseTransformationJob']/parent::div/parent::div/following-sibling::div//div[text()='Completed']");
			int previuosTestcaseJobCount = previousTestcaseTransformationJobsWithStatusComplete.size();
		
			List<WebElement> previousTestcaseExecutionTransformationJobWithStatusComplete  = CommonUtil.returnWebElements("//div[@id='grid-table-etl_history']//div[text()='TestcaseExecutionTransformationJob']/parent::div/parent::div/following-sibling::div//div[text()='Completed']");
			int previuosExecutionJobCount = previousTestcaseExecutionTransformationJobWithStatusComplete.size();
			
			List<WebElement> previousTestcaseExecutionDailySnapshotTransformationJobWithStatusComplete = CommonUtil.returnWebElements("//div[@id='grid-table-etl_history']//div[text()='TestcaseExecutionDailySnapshotTransformationJob']/parent::div/parent::div/following-sibling::div//div[text()='Completed']");
			int previuosExecutionSnapshotJobCount = previousTestcaseExecutionDailySnapshotTransformationJobWithStatusComplete.size();
			
			if(execution){
				checkboxTestcaseExecutionForTrend.click();
				CommonUtil.normalWait(1000);
			}
			
			String xpathLastJobId = "(//div[@id='grid-table-etl_history']//div[@class='grid-content']//div[@data-index='0']/div/div/div)[1]";
			WebElement wbLastJobId = CommonUtil.returnWebElement(xpathLastJobId);
			String lastJobId = wbLastJobId.getText();
			
			buttonRunNow.click();
		
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='confirmation-modal']//p[contains(text(),'Do you wish to collect trend data for "+CommonUtil.returnTodaysDate()+" ?')]")
					, "Confirmation text message not found as: " + "Do you wish to collect trend data for "+CommonUtil.returnTodaysDate()+" ?");
			CommonUtil.normalWait(1000);
			buttonYesInConfirmationModalForTrendDataCollection.click();
			CommonUtil.normalWait(3000);
			HomePage.getInstance().closeToastPopup();
			HomePage.getInstance().waitForProgressBarToComplete();
			
			buttonRefreshHistory.click();
			CommonUtil.normalWait(2000);
			HomePage.getInstance().closeToastPopup();
			CommonUtil.normalWait(2000);
			buttonRefreshHistory.click();
			HomePage.getInstance().closeToastPopup();
			HomePage.getInstance().waitForProgressBarToComplete();
			
			//TODO implement assert
			
			/*if(testcase){
				List<WebElement> newTestcaseTransformationJobsWithStatusComplete = CommonUtil.returnWebElements("//div[@id='grid-table-etl_history']//div[text()='TestcaseTransformationJob']/parent::div/parent::div/following-sibling::div//div[text()='Completed']");
				int newTestcaseJobCount = newTestcaseTransformationJobsWithStatusComplete.size();
				System.out.println("+++++++++++ " + previuosTestcaseJobCount +" ++++" + newTestcaseJobCount);
				Assert.assertTrue(previuosTestcaseJobCount+1 == newTestcaseJobCount, "Job not found by with complete status for TestcaseTransformationJob");
			}
	
			if(execution){
				List<WebElement> newTestcaseExecutionTransformationJobWithStatusComplete  = CommonUtil.returnWebElements("//div[@id='grid-table-etl_history']//div[text()='TestcaseExecutionTransformationJob']/parent::div/parent::div/following-sibling::div//div[text()='Completed']");
				int newExecutionJobCount = newTestcaseExecutionTransformationJobWithStatusComplete.size();
				System.out.println("+++++++++++ " + previuosExecutionJobCount +" ++++" + newExecutionJobCount);
				Assert.assertTrue(previuosExecutionJobCount+1 == newExecutionJobCount, "Job not found by with complete status for TestcaseExecutionTransformationJob");
				
				List<WebElement> newTestcaseExecutionDailySnapshotTransformationJobWithStatusComplete = CommonUtil.returnWebElements("//div[@id='grid-table-etl_history']//div[text()='TestcaseExecutionDailySnapshotTransformationJob']/parent::div/parent::div/following-sibling::div//div[text()='Completed']");
				int newExecutionSnapshotJobCount = newTestcaseExecutionDailySnapshotTransformationJobWithStatusComplete.size();
				System.out.println("+++++++++++ " + previuosExecutionSnapshotJobCount +" ++++" + newExecutionSnapshotJobCount);
				Assert.assertTrue(previuosExecutionSnapshotJobCount+1 == newExecutionSnapshotJobCount, "Job not found by with complete status for TestcaseExecutionDailySnapshotTransformationJob");
			}*/
			
			buttonCloseTrendJobPopup.click();
			CommonUtil.normalWait(1000);
	
		}catch(Exception e){
			e.printStackTrace();
			logger.info("Trend ETL Job not executed cleanly");
			Assert.assertTrue(false, "Trend ETL Job not executed cleanly");
		}
		return true;
	}
	
	/******************************************************
	 * 	Private Methods
	 *****************************************************/
	
	
	private boolean launchTestcaseCustomFieldPopup(){
		logger.info("Waiting for Testcase Custom Field Button");
		CommonUtil.normalWait(3000);
		if(CommonUtil.visibilityOfElementLocated(buttonTestcaseFields)){
			logger.info("Found Testcase Custom Field Button successfully.. Going to click on it.");
			HomePage.getInstance().waitForProgressBarToComplete();
			buttonTestcaseFields.click();
			logger.info("After Clicking Testcase Custom Field Button, Waiting for Lock Zephyr Button to be visible");
			
		}else{
			logger.info("Testcase Custom Field Button not found");
			return false;
		}
		return true;
	}
	
	private boolean launchProjectCustomFieldPopup(){
		logger.info("Waiting for Project Custom Field Button");
		CommonUtil.normalWait(3000);
		if(CommonUtil.visibilityOfElementLocated(buttonProjectFields)){
			logger.info("Found Project Custom Field Button successfully.. Going to click on it.");
			HomePage.getInstance().waitForProgressBarToComplete();
			buttonProjectFields.click();
			logger.info("After Clicking Project Custom Field Button");
			
		}else{
			logger.info("Project Custom Field Button not found");
			return false;
		}
		return true;
	}
	
	private boolean launchRequirementCustomFieldPopup(){
		logger.info("Waiting for Requirement Custom Field Button");
		CommonUtil.normalWait(3000);
		if(CommonUtil.visibilityOfElementLocated(buttonRequirementFields)){
			logger.info("Found Requirement Custom Field Button successfully.. Going to click on it.");
			HomePage.getInstance().waitForProgressBarToComplete();
			buttonRequirementFields.click();
			logger.info("After Clicking Requirement Custom Field Button, Waiting for Lock Zephyr Button to be visible");
			}else{
			logger.info("Requirement Custom Field Button not found");
			return false;
		}
		return true;
	}
	
	private boolean launchExecutionStatusPopup(){
		logger.info("Waiting for Execution Status Button");
		CommonUtil.normalWait(3000);
		if(CommonUtil.visibilityOfElementLocated(buttonExecutionStatus)){
			logger.info("Found Execution Button successfully.. Going to click on it.");
			HomePage.getInstance().waitForProgressBarToComplete();
			buttonExecutionStatus.click();
			logger.info("After Clicking Execution Status Button, Waiting for Header 'Manage Test Execution Status' to be visible");
			if(CommonUtil.visibilityOfElementLocated(headerManageExecutionStatus)){
				logger.info("Manage Test Execution Status Header found successfully");
			}else{
				logger.info("Manage Test Execution Status Header not found");
				return false;
			}
		}else{
			logger.info("Execution Status Button not found");
			return false;
		}
		return true;
	}
	
	private boolean launchStepExecutionStatusPopup(){
		logger.info("Waiting for Step Execution Status Button");
		CommonUtil.normalWait(3000);
		if(CommonUtil.visibilityOfElementLocated(buttonStepExecutionStatus)){
			logger.info("Found Step Execution Button successfully.. Going to click on it.");
			HomePage.getInstance().waitForProgressBarToComplete();
			buttonStepExecutionStatus.click();
			logger.info("After Clicking Step Execution Status Button, Waiting for Header 'Manage Test Step Execution Status' to be visible");
			if(CommonUtil.visibilityOfElementLocated(headerManageStepExecutionStatus)){
				logger.info("Manage Test Step Execution Status Header found successfully");
			}else{
				logger.info("Manage Test Step Execution Status Header not found");
				return false;
			}
		}else{
			logger.info("Step Execution Status Button not found");
			return false;
		}
		return true;
	}
	
	private boolean launchEstimatedTimePopup(){
		logger.info("Waiting for Estimated Time Button");
		CommonUtil.normalWait(3000);
		if(CommonUtil.visibilityOfElementLocated(buttonEstimatedTime)){
			logger.info("Found Estimated Time Button successfully.. Going to click on it.");
			HomePage.getInstance().waitForProgressBarToComplete();
			buttonEstimatedTime.click();
			logger.info("After Clicking Estimated Time Button, Waiting for Header 'Default Estimated Time Editor' to be visible");
			if(CommonUtil.visibilityOfElementLocated(headerDefaultEstimatedTimeEditor)){
				logger.info("Default Estimated Time Editor Header found successfully");
			}else{
				logger.info("Default Estimated Time Editor Header not found");
				return false;
			}
		}else{
			logger.info("Estimated Time Button not found");
			return false;
		}
		return true;
	}
	
	private boolean launchCustomizeRolesPopup(){
		logger.info("Waiting for Roles Button");
		CommonUtil.normalWait(3000);
		if(CommonUtil.visibilityOfElementLocated(buttonRoles)){
			logger.info("Found Roles Button successfully.. Going to click on it.");
			HomePage.getInstance().waitForProgressBarToComplete();
			buttonRoles.click();
			logger.info("After Clicking Role Button, Waiting for Header 'Customize Roles' to be visible");
			if(CommonUtil.visibilityOfElementLocated(headerCustomizeRoles)){
				logger.info("Customize Roles Header found successfully");
			}else{
				logger.info("Customize Roles Header not found");
				return false;
			}
		}else{
			logger.info("Roles Button not found");
			return false;
		}
		return true;
	}
	
	private boolean lockZephyrAccess(){
		logger.info("Going to click on LockZephyr Button");
		buttonLockZephyrAccess.click();
		CommonUtil.normalWait(1000);
		if(CommonUtil.visibilityOfElementLocated(buttonYesInConfirmationPopuForCustomField)){
			logger.info("Clicking on Yes in confirmation popup");
			buttonYesInConfirmationPopuForCustomField.click();
			if(CommonUtil.visibilityOfElementLocated(addNewField)){
				logger.info("Add New Custom Field button found successfully");
			}else{
				logger.info("Add New Custom Field button not found");
				return false;
			}
		}else{
			logger.info("Confirmation Popup not found");
			return false;
		}
		
		return true;
	}
	
	private boolean enableZephyrAccess(){
		logger.info("Going to Enable Zephyr Access");
		
		if(CommonUtil.visibilityOfElementLocated("//button[@id='enable-zephyr-access']")){
			CommonUtil.returnWebElement("//button[@id='enable-zephyr-access']").click();
			logger.info("Enable Zephyr Access Successfully");
		}else{
			logger.info("Failed to Enable Zephyr Access");
			return false;
		}
		HomePage.getInstance().waitForProgressBarToComplete();
		//buttonEnableZephyrAccess.click();
		//CommonUtil.ExplicitWaitForElement(successMsg);
		//CommonUtil.normalWait(5000);
		//CommonUtil.moveToElement(closeCustomFieldPopup);
		closeCustomFieldPopup.click();
		logger.info("Refreshing Browser Page");
		CommonUtil.browserRefresh();
		if(CommonUtil.visibilityOfElementLocated(buttonTestcaseFields)){
			logger.info("After Refreshing Browser Found Customization App successully by verifying Testcase Custom Field button");
		}else{
			logger.info("After Refreshing Browser Customization App not found, unable to view Custom Field Button");
			return false;
		}
		return true;
	}
	
	public boolean closeCustomfield(){
		try {
			HomePage.getInstance().waitForProgressBarToComplete();
			closeCustomFieldPopup.click();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}
	
	
	
	private boolean verifySuccessPopupForCustomFieldCreation(){
		
		if(CommonUtil.visibilityOfElementLocated("//div[@class='toast-message' and @text()='New field added successfully']")){
			logger.info("Success Message verified in popup : New field added successfully");	
		}else{
			logger.info("Success Message not found after creating custom field");
			return false;
		}
		
		return true;
	}
	
	private boolean verifySuccessPopupForCustomFieldEdit(){
		
		if(CommonUtil.visibilityOfElementLocated("//div[@class='toast-message' and @text()='Field edited successfully']")){
			logger.info("Success Message verified in popup : Field edited successfully");	
		}else{
			logger.info("Success Message not found after editing custom field");
			return false;
		}
		
		return true;
	}
	
	public boolean verifySuccessPopup() {
		try {
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(successContainer));
			logger.info("Success Message verified Successfully.");

			Assert.assertTrue(SuccessToastTitle.getText().equals("Success"), "Not found Success message");
			logger.info("Success message popup text verified.");

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean globalRepoProjectAssignment(List<String> projectNames)
	{
		try {
		for(String projectName : projectNames){
			
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement("//div[@class='unselected-list']//label[text()='"+ projectName +"']").click();
			CommonUtil.normalWait(500);
		}
		addSelectedProject.click();
		CommonUtil.normalWait(500);
		CommonUtil.normalWait(1000);
		CommonUtil.isElementClickable(buttonSave);
		buttonSave.click();
		HomePage.getInstance().closeToastPopup();
		CommonUtil.normalWait(1000);
		HomePage.getInstance().waitForProgressBarToComplete();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	return true;
	}
}
