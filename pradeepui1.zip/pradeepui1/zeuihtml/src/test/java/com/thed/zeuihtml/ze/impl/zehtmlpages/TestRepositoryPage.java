package com.thed.zeuihtml.ze.impl.zehtmlpages;

import java.beans.Visibility;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.omg.CORBA.COMM_FAILURE;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.Constants;
import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;

import bsh.util.Util;

public class TestRepositoryPage {

	Logger logger;

	public TestRepositoryPage() {
		logger = Logger.getLogger(this.getClass());
	}

	public static TestRepositoryPage getInstance() {
		return PageFactory.initElements(Driver.driver, TestRepositoryPage.class);
	}

	/******************************************************
	 * WEBELEMENTS
	 *****************************************************/

	@FindBy(xpath = "//*[@id='ze-main-app']/zee-test-repository/test-repository-component//*[@class='zui-tcr-folder-view']//span/i[contains(@class,'zui-search-icon')]")
	private WebElement searchView;

//	@FindBy(xpath = "//*[@id='ze-main-app']/zee-test-repository/test-repository-component//*[@class='zui-tcr-folder-view']//span/i[contains(@class,'fa-folder-open')]")
	@FindBy(xpath = "//*[@class='zui-tcr-folder-view']//span/i[contains(@class,'fa-folder-open')]/parent::span/parent::a")
	private WebElement folderView;
	
	@FindBy(xpath = "//*[@id='ze-main-app']/zee-test-repository/test-repository-component//div/a/span[normalize-space(text())='Detail']")
	private WebElement detailView;
	
	@FindBy(xpath = "//*[@id='ze-main-app']/zee-test-repository/test-repository-component//div/a/span[normalize-space(text())='List']")
	private WebElement listView;

	@FindBy(xpath = "//*[@id='zephyr-tree-tcr']//li[@data-parenttype='import']/a[@data-name='Imported']")
	private WebElement importedBtn;

	@FindBy(xpath = "//*[@id='ze-main-app']/zee-test-repository/test-repository-component//*[@class='left-navs']//h3")
	private WebElement testRepositoryPageHeader;
	
	@FindBy(xpath="//head/title[contains(text(),'Test Repository')]")
	private WebElement testRepoPageHeader;

	@FindBy(xpath = "//li[@data-parenttype='release']")
	private WebElement releasesInTestRepository;
	
	@FindBy(xpath = "//li[@data-parenttype='project_repo']")
	private WebElement projectRepoInTestRepository;
	

	@FindBy(xpath = "//*[@id='zephyr-tree-tcr']//li[@data-parenttype='release']/a")
	private WebElement releasesInTestRepository1;

	@FindBy(xpath = "//*[@id='zephyr-tree-tcr']//li[@data-parenttype='release']/a/div")
	private WebElement releaseOptionsBtn;
	
	
	@FindBy(xpath = "//ul[@class='vakata-context jstree-contextmenu jstree-default-contextmenu']")
	private WebElement nodeOptionsMenu;

	@FindBy(xpath = "//ul[@class='vakata-context jstree-contextmenu jstree-default-contextmenu']//a")
	private List<WebElement> releaseOptionsLink;

	@FindBy(id = "tcrAddNodeModal")
	private WebElement createPhaseDialogBox;

	@FindBy(xpath = "//*[@id='tcrAddNodeModal']//*[@class='modal-title']")
	private WebElement createPhaseDialogBoxHeader;

	@FindBy(id = "addNodeName")
	private WebElement addNodeNameTextBox;

	@FindBy(id = "addNodeDescription")
	private WebElement addNodeDescriptionTextArea;

	@FindBy(id = "tcrAddNodeModalSave")
	private WebElement tcrAddNodeModalSaveBtn;

	@FindBy(xpath = "//li[@data-parenttype='release']//a[@data-type='Phase']")
	private List<WebElement> listOfPhases;

	// Node details
	@FindBy(xpath = "//*[@id='zephyr-tree-tcr']//li[@data-parenttype='release']/a/div[contains(@class,'contextMenuIcon')]")
	private WebElement nodeOptionsBtn;

	@FindBy(id = "tcrRenameNodeModal")
	private WebElement renameNodeDialogBox;

	@FindBy(id = "testcaseNodeName")
	private WebElement renameNodeNameTextBox;

	@FindBy(id = "nodeDescription")
	private WebElement renameNodeDescriptionTextArea;

	@FindBy(id = "tcrRenameNodeModalSave")
	private WebElement tcrRenameNodeModalSaveBtn;

	@FindBy(xpath = "//*[@id='tcrRenameNodeModal']//*[@class='modal-title']")
	private WebElement renamePhaseDialogBoxHeader;

	// Delete Node details
	@FindBy(id = "tcrDeleteNodeModal")
	private WebElement deleteNodeDialogBox;

	@FindBy(id = "tcrDeleteNodeModalSave")
	private WebElement tcrDeleteNodeModalSaveBtn;

	@FindBy(xpath = "//*[@id='tcrDeleteNodeModal']//*[@class='modal-title']")
	private WebElement deleteNodeDialogBoxHeader;

	@FindBy(xpath = "//*[@id='toast-container']")
	private WebElement successContainer;

	@FindBy(xpath = "//*[@id='toast-container']//div[@class='toast-title']")
	private WebElement deleteSuccessToastTitle;

	@FindBy(xpath = "//*[@id='toast-container']//div[@class='toast-message']")
	private WebElement deleteSuccessToastMsg;

	// Filter elements
	@FindBy(id = "tree-view-filter-tcr")
	private WebElement tcrFilterSearchBox;

	@FindBy(xpath = "//a[contains(@class,'jstree-search')]")
	private List<WebElement> tcrSearchText;

	@FindBy(id = "zui-modal-trigger-tcr_1")
	private WebElement addTestcaseBtn;

	// Testcase Summary details
	@FindBy(xpath = "//*[@class='zephyr-testcase-name']//span[contains(@class,'zephyr-inline-field-name')]")
	private WebElement testcaseSummaryElement;

	@FindBy(xpath = "//*[@class='zephyr-testcase-name']//span[contains(@class,'zui-fa-pencil')]")
	private WebElement testcaseSummaryEditBtn;

	@FindBy(xpath = "//*[@class='zephyr-testcase-name']//*[@class='zephyr-editable-field-edit-mode']//input[contains(@class,'js-zephyr-inline-edit-text')]")
	private WebElement testcaseSummaryEditTextBox;

	@FindBy(xpath = "//*[@class='zephyr-testcase-name']//*[@class='zephyr-editable-field-edit-mode']//button[@type='submit']")
	private WebElement testcaseSummarySubmitBtn;

	@FindBy(xpath = "//*[@class='zephyr-testcase-name']//*[@class='zephyr-editable-field-edit-mode']//button[@type='cancel']")
	private WebElement testcaseSummaryCancelBtn;

	// Testcase Description details
	@FindBy(xpath = ".//div[@id='testcaseDescription']//textarea[@id='testcase_description']")
	private WebElement testcaseDescElement;
	
	@FindBy(xpath = ".//*[@id='tinymce']")
	private WebElement testcaseDescElementEditor;
	@FindBy(xpath = "//*[@class='zee-testcase-description']//span[contains(@class,'zui-fa-pencil')]")
	private WebElement testcaseDescriptionEditBtn;

	@FindBy(xpath = "//*[@class='zee-testcase-description']//*[@class='zephyr-editable-field-edit-mode']//textarea[contains(@class,'js-zephyr-inline-edit-textarea')]")
	private WebElement testcaseDescriptionEditTextBox;

	@FindBy(xpath = "//*[@id='testDescriptionDetails']//h5")
	private WebElement testcaseDescriptionSubmitBtn;
	
	@FindBy(xpath = "//a[text()='Top']")
	private WebElement topLink;

	@FindBy(xpath = "//*[@class='zee-testcase-description']//*[@class='zephyr-editable-field-edit-mode']//button[@type='cancel']")
	private WebElement testcaseDescriptionCancelBtn;

	// Testcase Attachment details
//	@FindBy(xpath = "//*[@id='zee-testcase-attachment-details-module']//h5[@class='zee-module-title']")
	@FindBy(xpath = "//*[@id='testcase-details']//a[text()='Attachment']")
	private WebElement testcaseAttachmentTitle;
	
//	@FindBy(xpath = "//*[@id='zee-testcase-attachment-details-module']//input[@id='uploadFile']")
	@FindBy(xpath = "//*[@id='zee-testcase-attachment-details-module']//input[contains(@id,'uploadFiletestcasetestcase')]")
	private WebElement testcaseUploadLink;
	
	@FindBy(xpath = "//*[@id='zee-testcase-attachment-details-module']//*[@class='attachment-information']/p[contains(@class,'attachment-name')]/span[1]")
	private List<WebElement> testcaseAttachmentsDetails;
	
	@FindBy (xpath = "//*[@id='testcase-details']//div[@title='Back to list']/i")
	private WebElement backToTcList;
	
	//TestStep details
//	@FindBy(xpath = "//*[@id='zee-testcase-step-details-module']//h5[@class='zee-module-title']")
	@FindBy(xpath = "//*[@id='testcase-details']//a[text()='Test Step']")
	private WebElement testcaseStepHeader;
	
	@FindBy(id = "zee-add-step")
	private WebElement stepInTestcase;
	
	@FindBy(id = "zee-add-test-data")
	private WebElement dataInTestcase;
	
	@FindBy(id = "zee-add-expected-result")
	private WebElement stepresInTestcase;
	
	@FindBy(xpath = "//*[@id='zee-test-rows']/following-sibling::tfoot//button[contains(@class,'zui-btn zui-btn-plus')]/span")
	private WebElement plusBtnInStepSection;
	
	@FindBy(xpath = ".//*[@id='zee-testcase-step-details-module']//button[text()='Save']")
	private WebElement saveBtnInStepSection;
	
	@FindBy(xpath = "//*[@id='zee-testcase-step-details-module']//button[text()='Cancel']")
	private WebElement cancelBtnInStepSection;
	
	//Delete Testcase details
	@FindBy(id = "zui-modal-trigger-tcr_4")
	private WebElement deleteTestcaseBtn;
	
	@FindBy(xpath = "//*[@id='zee-delete-modal-tcr_4']")
	private WebElement deleteTestcaseModalPopup;
	
	@FindBy(xpath = "//*[@id='zee-delete-modal-tcr_4']//h4[@class='modal-title']")
	private WebElement deleteTestcaseModalPopupHeader;
	
	@FindBy(xpath = "//*[@id='zee-delete-modal-tcr_4']//zui-modal-body/p")
	private WebElement deleteTestcaseModalPopupBodyConfirmationText;
	
	@FindBy(xpath = ".//*[@id='zee-delete-modal-tcr_4']//zui-modal-footer/button[text()='Delete']")
	private WebElement deleteTestcaseModalPopupDeleteBtn;
	
	@FindBy(xpath = ".//*[@id='zee-delete-modal-tcr_4']//zui-modal-footer/button[text()='Cancel']")
	private WebElement deleteTestcaseModalPopupCancelBtn;
	
	@FindBy(xpath = "//*[@id='grid-table-tcr']/div[@class='grid-content']/div/div[@data-col-index='2']")
	private List<WebElement> listOfTestcaseIds;
	
//	Tetscase customfield Detail
//	@FindBy(xpath = "//*[@id='zee-testcase-details-module']/div/h5[text()='Custom Fields']")
	@FindBy(xpath = "//*[@id='testcase-details']//a[text()='Test Detail']")
	private WebElement testcaseCustomfieldHeader;
	
	@FindBy(xpath="//h4[text()='Duplicate Custom field value']")
	private WebElement popUpDuplicateValue;
	
	@FindBy(xpath="//*[@id='custom-field-error-modal']//button[text()='Ok']")
	private WebElement buttonOk;
	
	//Customfield Picklist
	@FindBy(xpath="//div/zee-custom-fields//strong[contains(@title, 'Sample Custom 6')]/following-sibling::span/")
	private WebElement customfieldFindPicklist;

	@FindBy(xpath = "//*[@id='grid-table-tcr']/div[@class='grid-content']/div[div[@data-col-index='3']]//div[text()='Modified summary']/parent::div/parent::div/preceding-sibling::div[3]//input[@name='testcase_select']")
	private WebElement checkCloneTestcase;
	
	@FindBy(xpath = "//*[@id='zui-modal-trigger-tcr_2']")
	private WebElement buttonClone;

	
	@FindBy(xpath="//span[@placeholder='Enter alt ID']")
	private WebElement elementAltID;
	
//	@FindBy(xpath="//strong/b[text()='Alt ID']/parent::strong/following-sibling::span//input")
	@FindBy(xpath="//strong[text()='Alt ID']/parent::span/following-sibling::span//input")
	private WebElement textBoxAltID;
	
//	@FindBy(xpath="//strong/b[text()='Alt ID']/parent::strong/following-sibling::span//input/parent::div/parent::div/following-sibling::div/button[2]")
	@FindBy(xpath="//strong[text()='Alt ID']/parent::span/following-sibling::span//input/parent::div/parent::div/following-sibling::div/button[@type='submit']")
	private WebElement buttonSubmitAltId;
	
	@FindBy(xpath="//span[@placeholder='Enter priority']")
	private WebElement elementPriority;
	
	@FindBy(xpath="//span[@placeholder='Enter comment']")
	private WebElement elementEnterComment;
	
	@FindBy(xpath=".//*[@id='testcaseComments']/span/zephyr-inline-edit//div/textarea")
	private WebElement textAreaComment;
	
	@FindBy(xpath=".//*[@id='testcaseComments']/span/zephyr-inline-edit//button[@type='submit']")
	private WebElement buttonSubmitComment;
	

	@FindBy(xpath="//*[@id='zee-testcase-details-module-heading']/h5[text()='Step Details History']")
	private WebElement stepDetailsHistoryHeadder;
	
	@FindBy(xpath="//*[@id='zephyr-testcase-panel']//div/paginator/ul[@class='pager']/li[3]/a//span[@class='fa fa-caret-down']")
	private WebElement testcaseDetailDownArrow;
	
	@FindBy(xpath="//*[@id='zephyr-testcase-panel']//div/paginator/ul[@class='pager']/li[2]/a//span[@class='fa fa-caret-up']")
	private WebElement testcaseDetailUpArrow;
	
	//Find And Add
	@FindBy(xpath="//*[@id='find-and-add-modal']//h4[text()='Find and Add']")
	private WebElement headerFindAndAdd;
	
	@FindBy(xpath="//input[@id='zql-search-input-tcr-find-add']")
	private WebElement advanceSearchField;
	
	@FindBy(xpath="//*[@id='find-and-add-modal']//div[@class='row zui-search-area-wrapper']//button[text()='Go']")
	private WebElement buttonGoFindAndAdd;
	
	@FindBy(xpath="//div[@id='grid-table-find_add']//input[@id='testcase_select_all']")
	private WebElement selectAllFindAndAdd;
	
	@FindBy(xpath="//*[@id='find-and-add-modal']//zui-modal-footer/button[text()='Add']")
	private WebElement buttonAddFindAndAdd;
	
	@FindBy(xpath="//*[@id='find-and-add-modal']//zui-modal-footer/button[text()='Cancel']")
	private WebElement buttonCancelFindAndAdd;
	
	//Copy From Other Projects
	@FindBy(xpath="//*[@id='zee-global-tcr-tree-modal']//h4[text()='Copy from Project Releases']")
	private WebElement headerCopyFromOtherProjects;
	
	@FindBy(xpath="//div[@class='local-tc']//i[@class='pull-right fa fa-chevron-right cursor-pointer dock']")
	private WebElement undockLocalGrid;
	
	@FindBy(xpath="//*[@id='grid-table-local']/div[@class='grid-header']")
	private WebElement localGridHeader;
	
	@FindBy(xpath="//*[@id='grid-table-local']//div[@class='grid-content']")
	private WebElement localGridContent;

	@FindBy(xpath="//*[@id='zee-global-tcr-tree-modal']//div[@class='local-tc open']//div[@class='grid-pagination']")
	private WebElement localGridPagination;

	@FindBy(xpath="//div[@class='local-tc open']//i[@class='pull-right fa cursor-pointer dock fa-chevron-left']")
	private WebElement dockLocalGrid;
	
	@FindBy(xpath="//*[@id='zephyr-tree-globalTree']//a[text()='Projects']")
	private WebElement globalTreeProjectsNode;
	
	@FindBy(xpath="//*[@id='zephyr-tree-globalTree']//a[text()='Imported']")
	private WebElement globalTreeImportedNode;
	
	@FindBy(xpath="//div[@id='grid-table-global']/div[@class='grid-header']")
	private WebElement globalGridHeader;
	
	@FindBy(xpath="//div[@id='grid-table-global']/div[@class='grid-content']")
	private WebElement globalGridContent;
	
	@FindBy(xpath="//div[@class='global-tc']//i[@class='pull-right fa fa-chevron-left cursor-pointer dock']")
	private WebElement dockGlobalGrid;
	
	@FindBy(xpath="//div[@class='global-tc']//i[@class='pull-right fa cursor-pointer dock fa-chevron-right']")
	private WebElement undockGlobalGrid;
	
	@FindBy(xpath="//div[@id='zee-global-tcr-tree-modal']//h4[text()='Copy from Project Releases']/parent::div/following-sibling::div//button[@class='close']")
	private WebElement buttonCloseGlobalWindow;
	
	//Search
	@FindBy(xpath="//zui-zephyr-search//h3[normalize-space(text())='Search']")
	private WebElement headerSearch;
	
	@FindBy(xpath="//span[text()='Quick']")
	private WebElement radioButtonQuick;
	
	@FindBy(xpath="//span[text()='Advanced']")
	private WebElement radioButtonAdvanced;
	
	@FindBy(xpath="//input[@id='zui-search-textarea']")
	private WebElement textAreaForQuickSearch;
	
	@FindBy(xpath="//input[@id='zql-search-input-tcr-search']")
	private WebElement textAreaForAdvanceSearch;
	
	@FindBy(xpath="//input[@id='zui-search-textarea']/following-sibling::button[text()='Go']")
	private WebElement buttonGoQuick;
	
	@FindBy(xpath="//input[@id='zql-search-input-tcr-search']/following-sibling::button[text()='Go']")
	private WebElement buttonGoZql;
	
	//Detail View
	@FindBy(xpath = "//*[@id='th-TCR_DETAIL_VIEW_COLUMN']//div[normalize-space(text())='Testcases']")
	private WebElement detailViewTestcaseHeader;
	
	@FindBy(xpath = "//div[@id='tcr-h-resizer']//span/i[@class='fa fa-tree']")
	private WebElement detailViewTreeIcon;
	
	@FindBy(xpath = "//div[@class='tree-view']/div/span[@class='tree-collapse-icon']")
	private WebElement treecollapseIcon;
	
	@FindBy(xpath="//div[@id='tcr-grid']//input[@id='testcase_select_all']")
	private WebElement gridSelectALLcheckbox;
	
	@FindBy(xpath="//div[@id='tcr-grid']//input[@id='testcase_select_all']")
	private WebElement gridSelectALLcheckboxProjectRepo;
	
	@FindBy(xpath="//*[@id='zui-modal-trigger-tcr_3']")
	private WebElement buttonEdit;
	
	@FindBy(xpath="//select[@id='tcr-bulk-tag']/following-sibling::span//ul[@class='select2-selection__rendered']")
	private WebElement bulkSelectBoxTag;
	
	@FindBy(xpath="//*[@id='zee-create-edit-modal-tcr_3']//input[@class='select2-search__field']")
	private WebElement bulkTextBoxTag;
	
	@FindBy (xpath= "//*[@id='release-externalid']")
	private WebElement bulkTestBoxAltID;
	
	@FindBy(xpath =".//*[@id='release-comments']")
	private WebElement bulkTextBoxComment;
	
	@FindBy(xpath = "//*[@id='tcr-bulk-priority']/following-sibling::span[@class='select2 select2-container select2-container--default']")
	private WebElement selectBulkPrority;
	
	@FindBy(xpath = "//*[@id='dayText']")
	private WebElement bulkTextBoxDay;
	
	@FindBy(xpath="//*[@id='hourText']")
	private WebElement bulkTextBoxHour;
	
	@FindBy(xpath ="//*[@id='minuteText']")
	private WebElement bulkTextBoxMinute;
	
	@FindBy(xpath=".//*[@id='zee-create-edit-modal-tcr_3']//button[@class='zui-btn zui-btn-primary']")
	private WebElement buttonBulkSave;
	
	@FindBy(xpath =".//*[@id='bulk-confirm-modal']//button[@class='zui-btn zui-btn-primary']")
	private WebElement buttonBulkSave2;
	
	@FindBy(xpath="//*[@id='release-automated']")
	private WebElement bulkCheckboxAutomated;
	
	@FindBy (xpath = "//*[@id='release-scriptname']")
	private WebElement bulkAutomatedName;
	
	@FindBy(xpath = "//*[@id='release-scriptid']")
	private WebElement bulkAutomateID;
	
	@FindBy (xpath = "//*[@id='release-scriptpath']")
	private WebElement bulkAutomatePath;

	//Export
	
	@FindBy(xpath="//span[text()='Data (Excel only)']")
	private WebElement radioButtonDataExcel;
	
	@FindBy(xpath="//span[text()='Detailed']")
	private WebElement radioButtonDetailed;
	
	@FindBy(xpath="//span[text()='HTML']")
	private WebElement radioButtonHtml;
	
	@FindBy(xpath="//span[text()='PDF']")
	private WebElement radioButtonPdf;
	
	@FindBy(xpath="//span[text()='Word']")
	private WebElement radioButtonWord;
	
	@FindBy(xpath="//span[text()='Summary']")
	private WebElement radioButtonSummary;
	
	@FindBy(xpath="//div[@id='zui-export-modal-tcr_5']//button[text()='Save']")
	private WebElement buttonSaveExport;
	
	@FindBy(xpath="//div[@id='zui-export-modal-tcr_5-download']//h4[text()='Download File']")
	private WebElement headerDownloadFileInPopup;
	
	@FindBy(xpath="//div[@id='zui-export-modal-tcr_5-download']//button[text()='Download']")
	private WebElement buttonDownload;
	
	@FindBy(xpath="//input[@id='testcase_select_all']")
	private WebElement checboxSelectAllTestcases;
	
	@FindBy(xpath="//button[text()='Export']")
	private WebElement buttonExportFromGrid;
	
	@FindBy(xpath="//input[@id='testcase_select_all']")
	private WebElement checkboxSelectAllSearchedTestcase;
	
	@FindBy(xpath="//button[@id='zui-export-modal-trigger-tcr_5']")
	private WebElement buttonExportInSearch;
	
	//Pagination
	
	@FindBy(xpath="//select[@id='pagination-page-size-tcr']")
	private WebElement selectPaginationPageSize;
	
	@FindBy(xpath="//div[@id='tcr-grid']//span[text()='Next']/parent::a")
	private WebElement linkNextPage;
	
	@FindBy(xpath="//div[@id='tcr-grid']//span[text()='Prev']/parent::a")
	private WebElement linkPrevPage;

	@FindBy(xpath="//*[@id='testcase-details']//a[text()='Mapped Requirement']")
	private WebElement headerMappedRequirementModule;
	
	@FindBy(xpath="//button[@id='mapTest']")
	private WebElement buttonMapReq;
	
	@FindBy(xpath=".//*[@id='mapReq']/div/div/zee-expander/div[2]/zee-panel-content5/ul/li/div/a")
	private WebElement mapReq;
	
	@FindBy(xpath="//button//strong[text()='Back to Test Repository']")
	private WebElement BackToTestRepository;
	
	@FindBy(xpath="//div[@id='zee-map-modal']//div[@class='modal-footer modal-draggable-handle']//div//button[text()='Save']")
	private WebElement buttonSaveInMapWindow;
	
	@FindBy(xpath = "//*[@id='zee-testcase-details-module']//b[text()='Automated Script']")
	private WebElement automatedCheckBox;
	
	@FindBy(xpath="//h5[text()='Automation']")
	private WebElement headerAutomationModule;
	
	@FindBy(xpath="//strong[text()='Name']/parent::span/following-sibling::div")
	private WebElement automationNameBox;
	
	@FindBy(xpath="//strong[text()='ID']/parent::span/following-sibling::div")
	private WebElement automationIdBox;
	
	@FindBy(xpath="//strong[text()='Path']/parent::span/following-sibling::div")
	private WebElement automationPathBox;
	
	@FindBy(xpath="//div[@class='zephyr-editable-field-edit-mode']/form/div/div/input")
	private WebElement writeBox;
	
	//Import
	
	@FindBy(xpath="//button[text()='Import']")
	private WebElement buttonImport;
	
	@FindBy(xpath="//h4[text()='Import Test Cases']")
	private WebElement headerImportTestcases;
	
	@FindBy(xpath="//div[@id='zee-import-modal-testcase']//button[text()='Next']")
	private WebElement buttonNext;
	
	@FindBy(xpath="//div[@id='zee-import-modal-testcase']//p[text()='Saved Maps']")
	private WebElement textSavedMaps;
	
	@FindBy(xpath="//div[@id='zee-import-modal-testcase']//button[text()='Add New Map']")
	private WebElement buttonAddMap;
	
	@FindBy(xpath="//input[@name='mapName']")
	private WebElement textboxMapName;
	
	@FindBy(xpath="//input[@name='rowNumber']")
	private WebElement textboxRowNumber;
	
	@FindBy(xpath="//select[@name='selectedMapDiscriminator']")
	private WebElement selectMapDiscriminator;
	
	@FindBy(xpath="//textarea[@name='mapDescription']")
	private WebElement textareaMapDescription;
	
	@FindBy(xpath="//input[@name='savedMaps.fields.1']")
	private WebElement textboxZephyrFieldName;
	
	@FindBy(xpath="//input[@name='savedMaps.fields.2']")
	private WebElement textboxZephyrFieldTestSteps;
	
	@FindBy(xpath="//input[@name='savedMaps.fields.3']")
	private WebElement textboxZephyrFieldExpectedResults;
	
	@FindBy(xpath="//input[@name='savedMaps.fields.21']")
	private WebElement textboxZephyrFieldExternalID;
	
	@FindBy(xpath="//input[@name='savedMaps.fields.22']")
	private WebElement textboxZephyrFieldTestData;
	
	@FindBy(xpath="//input[@name='savedMaps.fields.23']")
	private WebElement textboxZephyrFieldPriority;
	
	@FindBy(xpath="//div[@id='update-savedMaps']//button[text()='Save']")
	private WebElement buttonSaveMap;
	
	//@FindBy(xpath="//p[text()='Saved Maps']/parent::div/parent::div//button[@class='close']")
	@FindBy(xpath="//p[text()='Saved Maps']/parent::b/parent::div/parent::div//button[@class='close']")
	private WebElement buttonCloseImportMapWindow;
	
	@FindBy(xpath="//div[@id='zee-import-modal-testcase']//p[text()='Import Jobs']")
	private WebElement textImportJobs;
	
	@FindBy(xpath="//p[text()='Import Jobs']/parent::b/parent::div/parent::div//button[@class='close']")
	private WebElement buttonCloseImportJobWindow;
	
	@FindBy(xpath="//div[@id='zee-import-modal-testcase']//button[text()='Add New Job']")
	private WebElement buttonAddJob;
	
	@FindBy(xpath="//input[@id='job-name']")
	private WebElement textboxJobName;
	
	//@FindBy(xpath="//span[@id='importJobs-fields']//select[@name='selectedFieldMap']")
	//@FindBy(xpath="//span[@id='importJobs-fields']//select[@class='select2-hidden-accessible']")
	@FindBy(xpath="//span[@id='importJobs-fields']//span[@class='selection']")
	private WebElement selectMap;
	
	@FindBy(xpath="//input[@id='uploadFileimport']")
	private WebElement inputUploadFile;
	
	//input[@id='uploadFileDrag']
	@FindBy(xpath="//div[@id='update-importJobs']//button[text()='Save']")
	private WebElement buttonSaveImportJob;
	
	@FindBy(xpath="//div[@id='job-status-modal-importJob']//h4[text()='Import Job Progress']")
	private WebElement headerImportJobProgress;
	
	@FindBy(xpath="//div[@id='job-status-modal-importJob']//span[normalize-space(text())='Status :']/following-sibling::span[text()='Success']")
	private WebElement textStatusSuccess;
	
	@FindBy(xpath="//div[@id='job-status-modal-importJob']//button[text()='Ok']")
	private WebElement buttonOkInImportJobProgress;
	
	@FindBy(xpath="//div[contains(@class,'contextMenuIcon')]")
	private WebElement iconContextMenu;
	
	@FindBy(xpath="//a[text()='Rename']")
	private WebElement linkRenameInContextMenu;
	
	//Customize grid
	
	@FindBy(xpath="//*[@id='tcr-grid']//a[@class='inline-dialog-trigger']")
	private WebElement linkInlineDialogTrigger;
	
	@FindBy(xpath="//div[@id='tcr-grid']//span[@title='Reset to Default View']")
	private WebElement iconResetToDefault;
	
	@FindBy(xpath="//div[@id='reset-warning-popup-tcr']//button[text()='Yes']")
	private WebElement buttonYesInResetWarningPopup;
	
	//Project Repository Elememt
	@FindBy(xpath = "//*[@id='zephyr-tree-tcr']//li[@data-parenttype='project_repo']/a/div")
	private WebElement ProjectOptionsBtn;
	
	//Share from Project Release
	@FindBy(xpath="//*[@id='zee-global-tcr-tree-modal']//h4[text()='Share from Project Releases']")
	private WebElement headerShareFromOtherProjects;
	
	@FindBy(xpath="//div[@id='zee-global-tcr-tree-modal']//h4[text()='Share from Project Releases']/parent::div/following-sibling::div//button[@class='close']")
	private WebElement buttonCloseShareWindow;
	
	@FindBy(xpath=".//*[@id='zee-testcase-step-details-module']//input[@name='select_all_grid_rows']")
	private WebElement selectALLTestStep;
	
	@FindBy(xpath=".//*[@id='testStepCopy']")
	private WebElement copySteps;
	
	@FindBy(xpath=".//*[@id='testStepPaste']")
	private WebElement pasteSteps;
	
	@FindBy(xpath=".//*[@id='tcr-grid']//button[text()='TC Reorder']")
	private WebElement buttonTestaseReorder;
	
	@FindBy(xpath= ".//*[@id='testcase-reorder']//input[@placeholder='Enter the Order ID.']")
	private WebElement textMoveto;
	
	@FindBy(xpath=".//*[@id='testcase-reorder']//button[text()='Move']")
	private WebElement buttonMove;
	
	@FindBy(xpath=".//*[@id='testcase-reorder']//zui-modal-footer/button[text()='Save']")
	private WebElement buttonSaveTestcaseOrderID;
	

	/******************************************************
	 * Methods
	 * 
	 * @return
	 *****************************************************/
	
	public boolean resetTestcaseGridToDefaultAndVerifyAbsenceOfCustomizedFields(List<String> fieldNamesNotToBePresent) {
		try {
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			
			iconResetToDefault.click();
			CommonUtil.normalWait(1000);
			
			CommonUtil.visibilityOfElementLocated(buttonYesInResetWarningPopup);
			buttonYesInResetWarningPopup.click();
			
			for(String fieldName : fieldNamesNotToBePresent) {	
				Assert.assertFalse(CommonUtil.visibilityOfElementLocated("//div[@id='header-parent-tcr']//div[text()='"+fieldName+"']", 5)
						, "Field "+fieldName+" not found in TCC Grid header after adding.");	
			}
			
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean checkOrUncheckTestcaseFieldsInGridAndVerify(List<String> fieldNames, boolean check) {
		
		try {
			
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkInlineDialogTrigger)
					, "Link to Inline Dialog Trigger not found to add fields in Grid");
			
			linkInlineDialogTrigger.click();
			
			for(String fieldName : fieldNames) {
				CommonUtil.normalWait(1000);
				CommonUtil.returnWebElement("//div[contains(@class,'inline-dialog-content')]//label[text()='"+fieldName+"']/preceding-sibling::input")
				.click();
			}
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement("//div[@class='inline-dialog-body top-right-arrow']").click();
			CommonUtil.browserRefresh();
			CommonUtil.normalWait(3000);
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(3000);
			
			if(check) {
				for(String fieldName : fieldNames) {	
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='header-parent-tcr']//div[text()='"+fieldName+"']")
							, "Field "+fieldName+" not found in TCC Grid header after adding.");	
				}
			}else {
				for(String fieldName : fieldNames) {	
					Assert.assertFalse(CommonUtil.visibilityOfElementLocated("//div[@id='header-parent-tcr']//div[text()='"+fieldName+"']", 5)
							, "Field "+fieldName+" not found in TCC Grid header after adding.");	
				}
			}
	
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	
	public boolean navigateToTCCNodeUnderImportedNode(String nodeNameContains) {
		try {
			
			//a[@data-name='Imported']/parent::li
			CommonUtil.normalWait(2000);
			String expandStatus = CommonUtil.returnWebElement("//a[@data-name='Imported']/parent::li").getAttribute("aria-expanded");
			System.out.println("Expand status of Node "+nodeNameContains+" :" + expandStatus);
			if(expandStatus!=null) {
				if(expandStatus.equals("false")) {
					CommonUtil.returnWebElement("//a[@data-name='Imported']/parent::li/i")
					.click();
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.normalWait(1000);
				}else {
					logger.info("Imported node is already expanded");
				}
			
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//li[@data-parenttype='import']//ul//a[contains(@data-name,'"+nodeNameContains+"')]")
						, "Node not found under imported node which contians text in name as: "+ nodeNameContains);
				CommonUtil.returnWebElement("//li[@data-parenttype='import']//ul//a[contains(@data-name,'"+nodeNameContains+"')]")
				.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean renameSelectedTCCImportedNodeAndDragToRelease(String nodeNameContains,String renameImportedNode, String releaseNodeNameToDrop, boolean dragWithControl) {
		try {
			CommonUtil.scrollToWebElementAndView(CommonUtil.returnWebElement("//li[@data-parenttype='import']//ul//a[contains(@data-name,'"+nodeNameContains+"')]"));
			CommonUtil.normalWait(1000);
			iconContextMenu.click();
			CommonUtil.normalWait(1000);
			linkRenameInContextMenu.click();
			CommonUtil.normalWait(1000);
			CommonUtil.visibilityOfElementLocated(renameNodeNameTextBox);
			CommonUtil.normalWait(1000);
			renameNodeNameTextBox.clear();
			CommonUtil.normalWait(1000);
			renameNodeNameTextBox.sendKeys(renameImportedNode);
			CommonUtil.normalWait(1000);
			tcrRenameNodeModalSaveBtn.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			WebElement sourceNode = CommonUtil.returnWebElement("//li[@data-parenttype='import']//ul//a[contains(@data-name,'"+renameImportedNode+"')]");
			WebElement destNode = CommonUtil.returnWebElement("//a[@data-name='"+releaseNodeNameToDrop+"']");
			Actions actions = CommonUtil.actionClass();
			if(dragWithControl) {
				Action action = actions.clickAndHold(sourceNode).moveToElement(destNode).keyDown(Keys.CONTROL).release().build();
				CommonUtil.normalWait(1000);
				action.perform();
			}else {
				Action action = actions.dragAndDrop(sourceNode, destNode).build();
				CommonUtil.normalWait(1000);
				action.perform();
			}
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean importTestcase(String jobName, String mapName, String importFileNameWithPath) {
		try {
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonImport)
					, "Import button not found in the Grid");
			buttonImport.click();
			CommonUtil.normalWait(500);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerImportTestcases)
					, "Import window failed to launch");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonNext)
					, "Button Next not found to navigate to map screen");
			CommonUtil.normalWait(1000);
			buttonNext.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textSavedMaps)
					, "Text 'Saved Maps' not found after clicking on Next button to navigate to Map Window");
			CommonUtil.normalWait(1000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonNext)
					, "Button Next not found to navigate to map screen");
			CommonUtil.normalWait(1000);
			buttonNext.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textImportJobs)
					, "Text 'Import Job' not found after clicking on Next button to navigate to Job Window");
			CommonUtil.normalWait(1000);
			buttonAddJob.click();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textboxJobName)
					, "Textbox Job Name not found after clicking on Add Job button");	
			CommonUtil.normalWait(1000);
			textboxJobName.sendKeys(jobName);
			CommonUtil.normalWait(1000);
			//CommonUtil.selectListWithValue(selectMap, mapName);
			selectMap.click();
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement("//li[text()='"+mapName+"']").click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(3000);
			//Driver.driver.switchTo().frame("uploadFileFormDrag");
			CommonUtil.normalWait(1000);
			//Assert.assertTrue(CommonUtil.visibilityOfElementLocated(inputUploadFile,60), "Element input to uploadFile not found");
			inputUploadFile.sendKeys(importFileNameWithPath);
			HomePage.getInstance().waitForProgressBarToComplete();
			//Driver.driver.switchTo().defaultContent();
			CommonUtil.normalWait(3000);
			buttonSaveImportJob.click();
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-import_jobs']//div[text()='"+jobName+"']"), "Job not found after saving in grid by name: "+ jobName);
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-import_jobs']//div[text()='"+jobName+"']/parent::div/parent::div/following-sibling::div//i[contains(@class,'runJobs')]"), "Run Job Icon not found for Job: " + jobName);
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement("//div[@id='grid-table-import_jobs']//div[text()='"+jobName+"']/parent::div/parent::div/following-sibling::div//i[contains(@class,'runJobs')]")
			.click();

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerImportJobProgress), "Job Progress Popup not found after running the job");
			
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textStatusSuccess), "Status as success not found in import progress job popup");
			HomePage.getInstance().waitForProgressBarToComplete();
			
			
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}finally {
			
			if(CommonUtil.visibilityOfElementLocated(buttonOkInImportJobProgress,3)) {
				buttonOkInImportJobProgress.click();
				CommonUtil.normalWait(1000);
			}
			if(CommonUtil.visibilityOfElementLocated(buttonCloseImportJobWindow,3)) {
				buttonCloseImportJobWindow.click();
				CommonUtil.normalWait(1000);
			}else {
				if(CommonUtil.visibilityOfElementLocated(buttonCloseImportMapWindow,3)) {
					buttonCloseImportMapWindow.click();
					CommonUtil.normalWait(1000);
				}
			}
		}
		return true;
	}
	
	public boolean addTestcaseMap(String mapName, String rowNumber, String selectDiscriminator
			, String mapDescription, String testcaseNameColumn, String testStepColumn,
			String expectedResultColumn, String externalIdColumn, String testDataColumn, List<String> otherFieldsMappingIfAny) {
		try {

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonImport)
					, "Import button not found in the Grid");
			buttonImport.click();
			CommonUtil.normalWait(1000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerImportTestcases)
					, "Import window failed to launch");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonNext)
					, "Button Next not found to navigate to map screen");
			CommonUtil.normalWait(1000);
			buttonNext.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textSavedMaps)
					, "Text 'Saved Maps' not found after clicking on Next button to navigate to Map Window");
			CommonUtil.normalWait(1000);
			buttonAddMap.click();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textboxMapName)
					, "Textbox Map Name not found after clicking on Add button");
			CommonUtil.normalWait(1000);
			textboxMapName.sendKeys(mapName);
			CommonUtil.normalWait(1000);
			textboxRowNumber.sendKeys(rowNumber);
			CommonUtil.normalWait(1000);
			CommonUtil.selectListWithVisibleText(selectMapDiscriminator, selectDiscriminator);
			CommonUtil.normalWait(1000);
			textareaMapDescription.sendKeys(mapDescription);
			CommonUtil.normalWait(1000);
			textboxZephyrFieldName.sendKeys(testcaseNameColumn);
			CommonUtil.normalWait(1000);
			textboxZephyrFieldTestSteps.sendKeys(testStepColumn);
			CommonUtil.normalWait(1000);
			textboxZephyrFieldExpectedResults.sendKeys(expectedResultColumn);
			CommonUtil.normalWait(1000);
			textboxZephyrFieldExternalID.sendKeys(externalIdColumn);
			CommonUtil.normalWait(1000);
			
			
			buttonSaveMap.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}finally {
			CommonUtil.normalWait(1000);
			buttonCloseImportMapWindow.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
		}
		return true;
	}
	
	

	public boolean createPhase(String releaseName, String phaseName, String phaseDescription) {
		try {
			CommonUtil.normalWait(1000);
			
			
			String xpathForRelease = "//li[@data-parenttype='release']/a[@data-name='"+releaseName+"']";
			CommonUtil.returnWebElement(xpathForRelease).click();
			
			
			CommonUtil.normalWait(1000);
			// boolean flag =
			// CommonUtil.isElementPresent("//li[@data-parenttype='release']");
			// System.out.println(flag);
			// Driver.driver.findElement(By.xpath("//li[@data-parenttype='release']")).click();
			// CommonUtil.actionClass().moveToElement(releasesInTestRepository).build().perform();

			logger.info("Hovered on Release successfully.");

			releaseOptionsBtn.click();
			logger.info("Clicked on Node Options on the Release successfully.");
			CommonUtil.normalWait(1000);
			Assert.assertTrue(navigateToReleaseOptions("Add Folder"), "Not clicked on Add Button.");
			logger.info("Clicked on Add Btn to create Phase");

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(createPhaseDialogBox),
					"Create phase Dialog box not visible.");
			logger.info("Create phase Dialog box visible to create phase.");

			Assert.assertTrue(createPhaseDialogBoxHeader.getText().trim().equals("Add Folder"),
					"Create  phase dialog box header not validated.");
			logger.info("Create  phase dialog box header validated successsfully.");
			CommonUtil.normalWait(2000);
			addNodeNameTextBox.sendKeys(phaseName);
			logger.info("Phase name : " + phaseName + " given successfully to the text box successfully.");

			if (phaseDescription != null) {
				CommonUtil.normalWait(1000);
				addNodeDescriptionTextArea.sendKeys(phaseDescription);
				logger.info("Phase name : " + phaseDescription + " given successfully to the text area successfully.");
			}
			CommonUtil.normalWait(1000);
			tcrAddNodeModalSaveBtn.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(3000);
			logger.info("Clicked on the save button successfully.");

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return verifyPhase(phaseName, phaseDescription);

	}
	
	

	public boolean navigateToNodes(List<String> nodeList) {
		boolean flag = false;
		try {
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);

			for (int i = 0; i < nodeList.size(); i++) {
				
				if(!CommonUtil.visibilityOfElementLocated("//*[*[@data-name='" + nodeList.get(i) + "']]",5)) {
				//	CommonUtil.browserRefresh();
					CommonUtil.normalWait(3000);
					HomePage.getInstance().waitForProgressBarToComplete();
				}
				
				String x = CommonUtil.returnWebElement("//*[*[@data-name='" + nodeList.get(i) + "']]").getAttribute("aria-expanded");
				if(x!=null) {
					if(x.equals("true")){
						logger.info("Node is already in Open state.");
						WebElement we = CommonUtil.returnWebElement("//*[@data-name='" + nodeList.get(i) + "']");
						we.click();
						HomePage.getInstance().waitForProgressBarToComplete();
					}else{
						CommonUtil.normalWait(2000);
						WebElement we = CommonUtil.returnWebElement("//*[@data-name='" + nodeList.get(i) + "']");
						CommonUtil.doubleClick(we);
						HomePage.getInstance().waitForProgressBarToComplete();
						CommonUtil.normalWait(4000);
						logger.info("Waiting for the phases.");
						CommonUtil.visibilityOfElementLocated("//li[@data-parenttype='release']//a[@data-name='"
								+ nodeList.get(i) + "']/following-sibling::ul/li",5);
						logger.info("Expanded the release successfully and Child nodes are visible now.");
					}
				}else {
					WebElement we = CommonUtil.returnWebElement("//li[@data-parenttype='release']//a[@data-name='" + nodeList.get(i) + "']");
					we.click();
					HomePage.getInstance().waitForProgressBarToComplete();
				}
				
				
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return flag;
		}
		return flag;
	}
	public boolean closeNodes(List<String> nodeList) {
		boolean flag = false;
		try {
			
			CommonUtil.normalWait(1000);
			releasesInTestRepository.click();
			CommonUtil.doubleClick(releasesInTestRepository);

			logger.info("Waiting for the phasees.");
			CommonUtil.visibilityOfElementLocated("//li[@data-parenttype='release']//a[@data-type='Phase']",5);
			logger.info("Expanded the release successfully and verifing the phases.");
			List<WebElement> elements = CommonUtil.returnWebElements("//div[contains(@class,'zui-content-layout')]//*[contains(@class,'fa-folder-open')]");
			
			for (int i = 0; i < elements.size(); i++) {
				CommonUtil.normalWait(1000);
				WebElement we = CommonUtil.returnWebElement("//*[@data-name='" + elements.get(i) + "']");
//				if(){
//					
//				}
				CommonUtil.doubleClick(we);
				CommonUtil.normalWait(4000);
				logger.info("Waiting for the phases.");
				CommonUtil.visibilityOfElementLocated("//li[@data-parenttype='release']//a[@data-name='"
						+ nodeList.get(i) + "']/following-sibling::ul/li",5);
				logger.info("Expanded the release successfully and Child nodes are visible now.");
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return flag;
		}
		return flag;
	}

	public boolean createNode(List<String> parentTee, String parentNodeName, String nodeName, String nodeDescription) {
		try {
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + parentNodeName + "']";
//			String xpath = "//*[@data-name = 'Release 1.0']/following-sibling::ul//*[@data-name = '" + parentNodeName + "']";
			;
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(xpath), "Node not found by name: " + parentNodeName);
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			CommonUtil.actionClass().moveToElement(we).build().perform();
			CommonUtil.normalWait(1000);
			logger.info("Hovered on Phase successfully.");

			releaseOptionsBtn.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			logger.info("Clicked on Node Options on the Phase successfully.");

			Assert.assertTrue(navigateToReleaseOptions("Add Folder"), "Not clicked on Add Button.");
			logger.info("Clicked on Add Btn to create Phase");

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(createPhaseDialogBox),
					"Create Node Dialog box not visible.");
			logger.info("Create Node Dialog box visible to create phase.");

			Assert.assertTrue(createPhaseDialogBoxHeader.getText().trim().equals("Add Folder"),
					"Create  phase dialog box header not validated.");
			logger.info("Create  phase dialog box header validated successsfully.");
			CommonUtil.normalWait(1000);
			addNodeNameTextBox.sendKeys(nodeName);
			logger.info("Phase name : " + nodeName + " given successfully to the text box successfully.");
			CommonUtil.normalWait(1000);
			if (nodeDescription != null) {
				CommonUtil.normalWait(1000);
				addNodeDescriptionTextArea.sendKeys(nodeDescription);
				logger.info("Node name : " + nodeDescription + " given successfully to the text area successfully.");
			}
			CommonUtil.normalWait(1000);
			tcrAddNodeModalSaveBtn.click();
			logger.info("Clicked on the save button successfully.");
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(3000);

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return verifyNode(parentTee,parentNodeName, nodeName, nodeDescription);
	}
	
	
	public boolean createNode(String parentNodeName, String nodeName, String nodeDescription) {
		try {
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + parentNodeName + "']";
//			String xpath = "//*[@data-name = 'Release 1.0']/following-sibling::ul//*[@data-name = '" + parentNodeName + "']";
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(xpath,5), "Node not found by name: " + parentNodeName);
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			CommonUtil.actionClass().moveToElement(we).build().perform();
			CommonUtil.normalWait(1000);
			logger.info("Hovered on Phase successfully.");

			releaseOptionsBtn.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			logger.info("Clicked on Node Options on the Phase successfully.");

			Assert.assertTrue(navigateToReleaseOptions("Add Folder"), "Not clicked on Add Button.");
			logger.info("Clicked on Add Btn to create Phase");

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(createPhaseDialogBox),
					"Create Node Dialog box not visible.");
			logger.info("Create Node Dialog box visible to create phase.");

			Assert.assertTrue(createPhaseDialogBoxHeader.getText().trim().equals("Add Folder"),
					"Create  phase dialog box header not validated.");
			logger.info("Create  phase dialog box header validated successsfully.");
			CommonUtil.normalWait(1000);
			addNodeNameTextBox.sendKeys(nodeName);
			logger.info("Phase name : " + nodeName + " given successfully to the text box successfully.");
			CommonUtil.normalWait(1000);
			if (nodeDescription != null) {
				CommonUtil.normalWait(1000);
				addNodeDescriptionTextArea.sendKeys(nodeDescription);
				logger.info("Node name : " + nodeDescription + " given successfully to the text area successfully.");
			}
			CommonUtil.normalWait(1000);
			tcrAddNodeModalSaveBtn.click();
			logger.info("Clicked on the save button successfully.");
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(3000);

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return verifyNode(parentNodeName, nodeName, nodeDescription);
	}

	public boolean renameNode(String renameNodeName, String newNodeName, String newNodeDescription) {
		try {
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + renameNodeName + "']";
			System.out.println(xpath);
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			CommonUtil.normalWait(3000);
			CommonUtil.actionClass().moveToElement(we).build().perform();
			CommonUtil.normalWait(2000);
			logger.info("Hovered on Node successfully.");

			releaseOptionsBtn.click();
			logger.info("Clicked on Node Options on the Phase successfully.");

			Assert.assertTrue(navigateToReleaseOptions("Rename"), "Not clicked on Add Button.");
			logger.info("Clicked on Rename Btn to create Phase");

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(renameNodeDialogBox),
					"Rename Node Dialog box not visible.");
			logger.info("Rename Node Dialog box visible to rename phase.");

			Assert.assertTrue(renamePhaseDialogBoxHeader.getText().trim().equals("Rename Folder"),
					"Rename  phase dialog box header not validated.");
			logger.info("Rename  phase dialog box header validated successsfully.");
			CommonUtil.normalWait(2000);
			renameNodeNameTextBox.clear();
			CommonUtil.normalWait(2000);
			renameNodeNameTextBox.sendKeys(newNodeName);
			logger.info("Phase name : " + newNodeName + " given successfully to the text box successfully.");
			CommonUtil.normalWait(2000);
			if (newNodeDescription != null) {
				CommonUtil.normalWait(2000);
				renameNodeDescriptionTextArea.clear();
				CommonUtil.normalWait(2000);
				renameNodeDescriptionTextArea.sendKeys(newNodeDescription);
				logger.info("Node Description : " + newNodeDescription
						+ " given successfully to the text area successfully.");
				
			}
			CommonUtil.normalWait(2000);
			tcrRenameNodeModalSaveBtn.click();
			logger.info("Clicked on the save button successfully.");
			CommonUtil.normalWait(5000);

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return verifyRenamedNode(renameNodeName, newNodeName, newNodeDescription);

	}
	public boolean moveNode(String moveNodeName, String oldParentNodeName, String newParentNodeName, List<String> nodeList) {
		try {
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + moveNodeName + "']";
			System.out.println(xpath);
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			CommonUtil.normalWait(3000);
			CommonUtil.actionClass().moveToElement(we).build().perform();
			CommonUtil.normalWait(2000);
			logger.info("Hovered on Node successfully.");

			releaseOptionsBtn.click();
			logger.info("Clicked on Node Options on the Phase successfully.");
			CommonUtil.normalWait(2000);
			Assert.assertTrue(navigateToReleaseOptions("Move"), "Not clicked on Move Button.");
			logger.info("Clicked on Move Btn to create Phase");
			if(nodeList != null ){
				Assert.assertTrue(navigateToNodes(nodeList), "Not Moved to the Node for perform Move operation.");
				logger.info("Navigated to the parent node for move, Now we can paste the node.");
			}
			
			
			CommonUtil.normalWait(3000);
			String xpath1 = "//*[@data-name = '" + newParentNodeName + "']";
			System.out.println(xpath1);
			WebElement we1 = CommonUtil.returnWebElement(xpath1);
			we1.click();
			CommonUtil.normalWait(3000);
			CommonUtil.actionClass().moveToElement(we1).build().perform();
			CommonUtil.normalWait(2000);
			logger.info("Hovered on Node successfully.");

			releaseOptionsBtn.click();
			CommonUtil.normalWait(3000);
			logger.info("Clicked on Node Options on the Phase successfully.");

			Assert.assertTrue(navigateToReleaseOptions("Paste"), "Not clicked on Move Button.");
			logger.info("Clicked on Paste Btn to Complete the Move operation.");
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(2000);
			Assert.assertTrue(verifyNode(nodeList, newParentNodeName, moveNodeName, null), "Moved node not verified from the new parent node.");
			logger.info("Moved node verified successfully from the new parent node.");
//			Assert.assertFalse(verifyNode(null, oldParentNodeName, moveNodeName, null), "Moved node is still present in the parent node.verified successfully from the Old parent node.");
			logger.info("Moved node verified successfully from the Old parent node.");
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;

	}
	public boolean copyNode(String moveNodeName, String oldParentNodeName, String newParentNodeName, List<String> nodeList) {
		try {
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + moveNodeName + "']";
			System.out.println(xpath);
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			CommonUtil.normalWait(2000);
			CommonUtil.actionClass().moveToElement(we).build().perform();
			CommonUtil.normalWait(2000);
			logger.info("Hovered on Node successfully.");

			releaseOptionsBtn.click();
			logger.info("Clicked on Node Options on the Phase successfully.");
			CommonUtil.normalWait(2000);
			Assert.assertTrue(navigateToReleaseOptions("Copy"), "Not clicked on Move Button.");
			logger.info("Clicked on Move Btn to create Phase");
			if(nodeList != null ){
				Assert.assertTrue(navigateToNodes(nodeList), "Not Moved to the Node for perform Move operation.");
				logger.info("Navigated to the parent node for move, Now we can paste the node.");
			}
			
			CommonUtil.normalWait(2000);
			String xpath1 = "//*[@data-name = '" + newParentNodeName + "']";
			System.out.println(xpath1);
			WebElement we1 = CommonUtil.returnWebElement(xpath1);
			we1.click();
			CommonUtil.normalWait(3000);
			CommonUtil.actionClass().moveToElement(we1).build().perform();
			CommonUtil.normalWait(2000);
			logger.info("Hovered on Node successfully.");

			releaseOptionsBtn.click();
			logger.info("Clicked on Node Options on the Phase successfully.");

			Assert.assertTrue(navigateToReleaseOptions("Paste"), "Not clicked on Move Button.");
			logger.info("Clicked on Paste Btn to Complete the Move operation.");
			CommonUtil.normalWait(5000);
//			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(renameNodeDialogBox),
//					"Rename Node Dialog box not visible.");
//			logger.info("Rename Node Dialog box visible to rename phase.");
//
//			Assert.assertTrue(renamePhaseDialogBoxHeader.getText().trim().equals("Rename Node"),
//					"Rename  phase dialog box header not validated.");
//			logger.info("Rename  phase dialog box header validated successsfully.");
//
//			renameNodeNameTextBox.clear();
//			renameNodeNameTextBox.sendKeys(newNodeName);
//			logger.info("Phase name : " + newNodeName + " given successfully to the text box successfully.");
//
//			if (newNodeDescription != null) {
//				renameNodeDescriptionTextArea.clear();
//				renameNodeDescriptionTextArea.sendKeys(newNodeDescription);
//				logger.info("Node Description : " + newNodeDescription
//						+ " given successfully to the text area successfully.");
//			}
//
//			tcrRenameNodeModalSaveBtn.click();
//			logger.info("Clicked on the save button successfully.");
			
			Assert.assertTrue(verifyNode(nodeList, newParentNodeName, moveNodeName, null), "Copied node not verified from the new parent node.");
			logger.info("Copied node verified successfully from the new parent node.");
			Assert.assertTrue(verifyNode(null, oldParentNodeName, moveNodeName, null), "Copied node is still present in the parent node.verified successfully from the Old parent node.");
			logger.info("Copied node verified successfully from the Old parent node.");
			
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;

	}

	public boolean deleteNode(String deleteNodeName) {
		try {
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + deleteNodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			CommonUtil.normalWait(2000);
			CommonUtil.actionClass().moveToElement(we).build().perform();
			CommonUtil.normalWait(2000);
			logger.info("Hovered on Phase successfully.");

			releaseOptionsBtn.click();
			logger.info("Clicked on Node Options on the Phase successfully.");

			Assert.assertTrue(navigateToReleaseOptions("Delete"), "Not clicked on Add Button.");
			logger.info("Clicked on Delete Btn to Delete Node");

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(deleteNodeDialogBox),
					"Delete Node Dialog box not visible.");
			logger.info("Delete Node Dialog box visible to Delete Node.");

			Assert.assertTrue(deleteNodeDialogBoxHeader.getText().trim().equals("Delete Folder"),
					"Delete  phase dialog box header not validated.");
			logger.info("Delete Node dialog box header validated successsfully.");
			CommonUtil.normalWait(3000);
			tcrDeleteNodeModalSaveBtn.click();
			logger.info("Clicked on the Delete button successfully.");
			CommonUtil.normalWait(3000);

			//Assert.assertTrue(verifySuccessPopup("delete"), "Not verified success popup.");

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;

	}

	public boolean filterNodes(String filterText) {
		boolean flag = false;
		int count = 0;
		try {

			CommonUtil.normalWait(1000);
			logger.info("Searching filter text.");
			tcrFilterSearchBox.clear();
			logger.info("Cleared the filter text box.");
			tcrFilterSearchBox.sendKeys(filterText);
			logger.info("Givin value to the filter text box.");
			tcrFilterSearchBox.sendKeys(Keys.RETURN);
			logger.info("Searching filter text.");
			CommonUtil.normalWait(1000);
			for (Iterator iterator = tcrSearchText.iterator(); iterator.hasNext();) {
				WebElement webElement = (WebElement) iterator.next();
				logger.info(webElement.getText());
				if (tcrSearchText.size() > 0) {
					logger.info(webElement.getText().trim() + ":" + filterText);
					Assert.assertTrue(webElement.getText().trim().contains(filterText)
							|| webElement.getText().trim().equals(filterText), "Not searched filtered text.");

					flag = true;
					count++;
				}
				// if(webElement.getText().trim().contains(filterText)){
				//
				// logger.info(filterText+" verified successfully.");
				// flag = true;
				// count ++;
				// }
			}

			logger.info("Searched Text found : " + count + " times .");
		} catch (Exception e) {
			e.printStackTrace();
			return flag;
		}
		return flag;

	}

	public String addDefaultTestcase(String nodeName) {
		String testcaseId = null;
		try {
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + nodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			logger.info("Node selected successfully.");

			int sizeOfTestcasesBefore=0;
			
			WebElement we2;
			try {
				we2 = Driver.driver.findElement(By.xpath("//*[@id='grid-table-tcr']/div[@class='grid-content']/div"));
				if(we2!=null){
					if(we2.isDisplayed()) {
						sizeOfTestcasesBefore = CommonUtil
								.returnSizeOfElements("//*[@id='grid-table-tcr']/div[@class='grid-content']/div");
						logger.info("Size of elements before : " + sizeOfTestcasesBefore);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			logger.info("Creating default testcase.");
			CommonUtil.normalWait(1000);
			addTestcaseBtn.click();
			//Assert.assertTrue(verifySuccessPopup("add"), "Not verified success popup.");
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(2000);
			logger.info("Clickeed on Add testcase btn.");

			logger.info("Added default testcase successfully.");

			int sizeOfTestcasesAfter = CommonUtil
					.returnSizeOfElements("//*[@id='grid-table-tcr']/div[@class='grid-content']/div");
			logger.info("Size of elements after : " + sizeOfTestcasesAfter);

			Assert.assertTrue(sizeOfTestcasesBefore + 1 == sizeOfTestcasesAfter, "Testcase size not increased.");
			logger.info("Test case size verified Successfully.");

			testcaseId = verifyDefaultTestcase(sizeOfTestcasesAfter);
			logger.info("Testcase Id : " + testcaseId);
			Assert.assertTrue(testcaseId != null, "Testcase not created.");
			logger.info("Testcase created and verified Successfully.");
			CommonUtil.normalWait(2000);
			verifyTestcaseVersion(Integer.parseInt(testcaseId),"1");
		} catch (Exception e) {
			e.printStackTrace();
			return testcaseId;
		}
		return testcaseId;

	}
	
	
	
	public boolean clickOnTestcase (String tctId) {
		try {
			logger.info("Going to click testcase name");
			String xpathForTestcaseName = "//*[@id='grid-table-tcr']/div[@class='grid-content']//div[text()='"+tctId+"']//parent::div//parent::div//following-sibling::div//div//div[@class='name-as-link']";
			CommonUtil.returnWebElement(xpathForTestcaseName).click();
			CommonUtil.normalWait(2000);
		}
		catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean navigateBackToTestcaseList() {
		try {
			logger.info("Going to click back button");
			backToTcList.click();
			CommonUtil.normalWait(2000);
		}
		catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}

	public boolean modifyTestcase(Map<String, String> values) {
		try {
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + values.get("NODE_NAME") + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(4000);
			logger.info("Node selected successfully.");

			int sizeOfTestcasesBefore = CommonUtil
					.returnSizeOfElements("//*[@id='grid-table-tcr']/div[@class='grid-content']/div");
			logger.info("Size of elements before : " + sizeOfTestcasesBefore);
			logger.info("Modifing default testcase.");

//			String xpathForTestcaseId = "//*[@id='grid-table-tcr']/div[@class='grid-content']/div/div[@data-col-index='2']//div[text()='"+ values.get("TESTCASE_ID") + "']";
			String xpathForTestcaseName = "//*[@id='grid-table-tcr']/div[@class='grid-content']/div/div[@data-col-index='2']//div[text()='"+ values.get("TESTCASE_ID") + "']//parent::div//parent::div//following-sibling::div//div//div[@class='name-as-link']"; 
			WebElement selectTestcase = CommonUtil.returnWebElement(xpathForTestcaseName);
			selectTestcase.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			logger.info("Clicked on the testcase Name for modification.");
			CommonUtil.normalWait(3000);
			if (values.containsKey("TESTCASE_SUMMARY")) {
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.scrollToWebElementAndView(testcaseSummaryElement);
				CommonUtil.normalWait(2000);
				CommonUtil.scrollToWebElementAndView(testcaseSummaryElement);
				CommonUtil.normalWait(1000);
				testcaseSummaryElement.click();
				CommonUtil.normalWait(2000);
				CommonUtil.visibilityOfElementLocated(testcaseSummaryEditTextBox);
				testcaseSummaryEditTextBox.clear();
				logger.info("Testcase Summary Cleared successfully.");
				CommonUtil.normalWait(2000);
				testcaseSummaryEditTextBox.sendKeys(values.get("TESTCASE_SUMMARY"));
				logger.info("Testcase Summary provided to the testcase sussessfully, Summary is : "
						+ values.get("TESTCASE_SUMMARY"));
				CommonUtil.normalWait(2000);
				testcaseSummarySubmitBtn.click();
				logger.info("Testcase Summary Submitted successfully.");
				CommonUtil.normalWait(5000);
				
				//Assert.assertTrue(verifySuccessPopup("testcase_update"), "Testcase modified successful popup not verified."); 
			}
			if (values.containsKey("TESTCASE_DESC")) {
				HomePage.getInstance().waitForProgressBarToComplete();
//				CommonUtil.moveToElement(testcaseDescElement);
				CommonUtil.switchiframe("testcase_description_ifr",values.get("TESTCASE_DESC"));
			//	testcaseDescElement.click();
			//	CommonUtil.normalWait(2000);
		//		CommonUtil.visibilityOfElementLocated(testcaseDescElement);
		//		testcaseDescElementEditor.clear();
		//		CommonUtil.normalWait(2000);
				logger.info("Testcase Description Cleared successfully.");
		//		testcaseDescElementEditor.sendKeys(values.get("TESTCASE_DESC"));
				logger.info("Testcase Deescription provided to the testcase sussessfully, Deescription is : "
						+ values.get("TESTCASE_DESC"));
				testcaseDescriptionSubmitBtn.click();
				CommonUtil.normalWait(500);
				testcaseDescriptionSubmitBtn.click();
				logger.info("Testcase Deescription Submitted successfully.");
				CommonUtil.normalWait(4000);
//				Assert.assertTrue(verifySuccessPopup("testcase_update"), "Testcase modified successful popup not verified.");
			}
			
			if(values.containsKey("Priority")){
				CommonUtil.normalWait(1000);
				HomePage.getInstance().waitForProgressBarToComplete();
				elementPriority.click();
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//span[@class='select2-results']/ul/li[text()='"+values.get("Priority")+"']"), "failed to select Priority: "+values.get("Priority"));
				CommonUtil.normalWait(1000);
				CommonUtil.returnWebElement("//span[@class='select2-results']/ul/li[text()='"+values.get("Priority")+"']").click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(3000);
			}
			
			if(values.containsKey("ALT_ID")){
				CommonUtil.normalWait(1000);
				HomePage.getInstance().waitForProgressBarToComplete();
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(elementAltID),"AltID field not found");
				elementAltID.click();
				CommonUtil.normalWait(2000);
				textBoxAltID.sendKeys(values.get("ALT_ID"));
				CommonUtil.normalWait(2000);
				buttonSubmitAltId.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(2000);
			}
			
			if(values.containsKey("Comment")){
				CommonUtil.normalWait(1000);
				HomePage.getInstance().waitForProgressBarToComplete();
				elementEnterComment.click();
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textAreaComment), "Failed to add comment, Comment textarea not found");
				CommonUtil.normalWait(1000);
				textAreaComment.clear();
				CommonUtil.normalWait(1000);
				textAreaComment.sendKeys(values.get("Comment"));
				CommonUtil.normalWait(2000);
				buttonSubmitComment.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(2000);
			}
			
			
			if (values.containsKey("TESTCASE_ATTACHMENT")) {
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
				testcaseAttachmentTitle.click();
				logger.info("Uploading Attachment To Testcase, Attachment : "+values.get("TESTCASE_ATTACHMENT"));
				CommonUtil.normalWait(1000);
				File file = new File(values.get("TESTCASE_ATTACHMENT"));
				System.out.println(file.getAbsolutePath());
				testcaseUploadLink.sendKeys(file.getAbsolutePath());
				logger.info("Testcase Uploaded successfully, Attachment is : "
						+ values.get("TESTCASE_ATTACHMENT"));
				CommonUtil.normalWait(3000);
//				Assert.assertTrue(verifyAttachments(values.get("TESTCASE_ATTACHMENT")), "Testcase Attachment not verified.");
//				logger.info("Attachments verified successfully.");
			}
			if (values.containsKey("TESTCASE_STEPS")) {
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
				testcaseStepHeader.click();
				CommonUtil.normalWait(1000);
				logger.info("Adding Teststeps To Testcase, Teststeps : "+values.get("TESTCASE_STEPS"));
				CommonUtil.normalWait(2000);
//				JSONObject steps = new JSONObject(values.get("teststeps"));
				JSONArray stepArray = new JSONArray(values.get("TESTCASE_STEPS"));
				for (int i = 0; i < stepArray.length(); i++) {
					JSONObject stepDetails = (JSONObject) stepArray.get(i);
					String step = (String) stepDetails.get("step");
					String data = (String) stepDetails.get("data");
					String result = (String) stepDetails.get("result");
					CommonUtil.normalWait(2000);
					stepInTestcase.sendKeys(step);
					CommonUtil.normalWait(2000);
					dataInTestcase.sendKeys(data);
					CommonUtil.normalWait(2000);
					stepresInTestcase.sendKeys(result);
					CommonUtil.normalWait(2000);
					plusBtnInStepSection.click();
					CommonUtil.normalWait(2000);
					logger.info("Clicked on Add button successfully.");
				
				}
				
				if(values.containsKey("TESTCASE_STEPS_CANCEL") && values.get("TESTCASE_STEPS_CANCEL").equals("true")){
//					cancelBtnInStepSection.click();
					CommonUtil.actionClass().sendKeys(Keys.ESCAPE).perform();
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.normalWait(2000);
				}else{
//					saveBtnInStepSection.click();
					CommonUtil.actionClass().sendKeys(Keys.TAB).perform();
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.normalWait(2000);
				}
				CommonUtil.normalWait(2000);
				logger.info("Testcase saved successfully.");
			}
			CommonUtil.normalWait(1000);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		finally {
			backToTcList.click();
			CommonUtil.normalWait(1000);
		}
		return true;

	}
	

	public boolean addCustomfieldToTestcase(String customfieldName, String customfieldValue, String customfieldType){
		
		try{
			
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.scrollToWebElementAndView(testcaseCustomfieldHeader);
			testcaseCustomfieldHeader.click();
			logger.info("Adding customfield : " + customfieldType);
			
			//Xpath for the getting all the Customfiled
			String xpathForcustomfiled = "//div/zee-custom-fields//span[contains(@title, '"+customfieldName+"')]/following-sibling::span";
			WebElement we = CommonUtil.returnWebElement(xpathForcustomfiled);
			
			CommonUtil.normalWait(1000);
			we.click();
			CommonUtil.normalWait(1000);
			
			if(customfieldType.equals("Text (1024)") || customfieldType.equals("Long Text (32000)") || customfieldType.equals("Number") || customfieldType.equals("Picklist"))
			{
				//Xpath for the Submit Field for the Customfiled text, textarea, number, selectlist
				
				String xpathForCustomfiledSubmit = "//span[contains(@title, '"+customfieldName+"')]/following-sibling::span//button[@type='submit']";
				WebElement customfieldSubmit = CommonUtil.returnWebElement(xpathForCustomfiledSubmit);
				if (customfieldType.equals("Text (1024)")  || customfieldType.equals("Number"))
				{
					//Xpath for the Input filed for text,checkbox,number
					String xpathForCustomfieldInput = "//div/zee-custom-fields//span[contains(@title, '"+customfieldName+"')]/following-sibling::span//input";
					WebElement customFieldInput = CommonUtil.returnWebElement(xpathForCustomfieldInput);
					
					customFieldInput.sendKeys(customfieldValue);
					CommonUtil.normalWait(1000);
					customfieldSubmit.click();
					CommonUtil.normalWait(1000);
					HomePage.getInstance().waitForProgressBarToComplete();
					testcaseCustomfieldHeader.click();
					CommonUtil.normalWait(1000);
				}
				
				if (customfieldType.equals("Long Text (32000)"))
				{
					//Xpath for the Input field for textarea
					String XpathForCustomfieldTextareaInput = "//div/zee-custom-fields//span[contains(@title, '"+customfieldName+"')]/following-sibling::span//textarea";
					WebElement customFieldTextareaInput = CommonUtil.returnWebElement(XpathForCustomfieldTextareaInput);
					
					customFieldTextareaInput.sendKeys(customfieldValue);
					CommonUtil.normalWait(1000);
					testcaseCustomfieldHeader.click();
					CommonUtil.normalWait(1000);
				}
				
				if(customfieldType.equals("Picklist"))
				{
					//xpath for the picklist
					// //span[@class='select2-results']/ul/li[text()='two']
					//String xpathForPicklistSelect="//*[@id='select2--results']/li[text()='"+customfieldValue+"']";
					String xpathForPicklistSelect="//span[@class='select2-results']/ul/li[text()='"+customfieldValue+"']";
					WebElement picklistSelect = CommonUtil.returnWebElement(xpathForPicklistSelect);
					picklistSelect.click();
					CommonUtil.normalWait(1000);
					testcaseCustomfieldHeader.click();
					CommonUtil.normalWait(1000);
				}
			}
			
			if(customfieldType.equals("Checkbox"))
			{
				//Xpath for the Input filed for text,checkbox,number
				
				String xpathForCustomfieldInput = "//div/zee-custom-fields//span[contains(@title, '"+customfieldName+"')]/following-sibling::span//input";
				WebElement customFieldInput = CommonUtil.returnWebElement(xpathForCustomfieldInput);
				customFieldInput.click();
				CommonUtil.normalWait(1000);
				testcaseCustomfieldHeader.click();
				CommonUtil.normalWait(1000);
			}
			
			if(customfieldType.equals("Date"))
			{
				String xpathForCurrentdate = "//span[contains(@title, '"+customfieldName+"')]/following-sibling::span//button[@class = 'btn btn-sm active btn-default']";
				WebElement currentDate = CommonUtil.returnWebElement(xpathForCurrentdate);
				currentDate.click();
				CommonUtil.normalWait(1000);
				testcaseCustomfieldHeader.click();
				CommonUtil.normalWait(1000);
			}	
		}
		catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean attemptToAddDuplicateValueToTestcaseHavingUniqueCustomField(String customfieldName, String customfieldValue, String customfieldType){
		
		try{
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.scrollToWebElement(testcaseCustomfieldHeader);
			CommonUtil.normalWait(1000);
			CommonUtil.scrollToWebElementAndView(testcaseCustomfieldHeader);
			testcaseCustomfieldHeader.click();
			logger.info("Adding customfield : " + customfieldType);
			
			//Xpath for the getting all the Customfiled
			String xpathForcustomfiled = "//div/zee-custom-fields//span[contains(@title, '"+customfieldName+"')]/following-sibling::span";
			WebElement we = CommonUtil.returnWebElement(xpathForcustomfiled);
			
			CommonUtil.normalWait(1000);
			we.click();
			CommonUtil.normalWait(1000);
			
			String xpathForCustomfiledSubmit = "//span[contains(@title, '"+customfieldName+"')]/following-sibling::span//button[@type='submit']";
			WebElement customfieldSubmit = CommonUtil.returnWebElement(xpathForCustomfiledSubmit);
			if (customfieldType.equals("Text (1024)")  || customfieldType.equals("Number"))
			{
				//Xpath for the Input filed for text,number
				String xpathForCustomfieldInput = "//div/zee-custom-fields//span[contains(@title, '"+customfieldName+"')]/following-sibling::span//input";
				WebElement customFieldInput = CommonUtil.returnWebElement(xpathForCustomfieldInput);
				
				customFieldInput.sendKeys(customfieldValue);
				CommonUtil.normalWait(1000);
				customfieldSubmit.click();
				CommonUtil.normalWait(3000);
				
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(popUpDuplicateValue), "Error message for duplicate value is not shown");
				buttonOk.click();
				CommonUtil.normalWait(2000);
			}
			else {
				logger.info("Invalid Custom field type");
				return false;
			}
		}
			
		catch(Exception e){
			e.printStackTrace();
			return false;
		}
		finally {
			CommonUtil.normalWait(1000);
			backToTcList.click();
			CommonUtil.normalWait(1000);
		}
		return true;
	}
	
	public String getTestcaseCustomFieldValue(String customfieldName,String customfieldType, String TcId){
		String fieldValue = null;
		try{
			HomePage.getInstance().waitForProgressBarToComplete();
			
			logger.info("Going to verify Testcase in grid");
			String  tcXpath= "//*[@id='grid-table-tcr']//div[@class='grid-content']//div[@class='grid-column-div']//div[text()='"+TcId+"']/parent::div/parent::div/following-sibling::div[2]/div/div";
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(tcXpath), "Testcase not found : "+ tcXpath);
			logger.info("Verified testcase in grid");
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement(tcXpath).click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			
			CommonUtil.scrollToWebElement(testcaseCustomfieldHeader);
			CommonUtil.normalWait(1000);
			CommonUtil.scrollToWebElementAndView(testcaseCustomfieldHeader);
			testcaseCustomfieldHeader.click();
			
			//Xpath for the getting all the Customfiled
			String xpathForcustomfiled = "//div/zee-custom-fields//span[contains(@title, '"+customfieldName+"')]/following-sibling::span";
			
			WebElement we = CommonUtil.returnWebElement(xpathForcustomfiled);
			CommonUtil.normalWait(1000);
			
			if (customfieldType.equals("Text (1024)")  || customfieldType.equals("Number"))
			{
				//Xpath for the Input filed for text,checkbox,number
				String xpathForCustomfieldInput = "//strong[@class='custom-field-name']/span[text()='"+customfieldName+"']//parent::strong//parent::span//following-sibling::span//span[@class='zephyr-inline-field-name fourth']";
				WebElement customFieldInput = CommonUtil.returnWebElement(xpathForCustomfieldInput);
				System.out.println("Text custom field value :" + customFieldInput.getText());
				fieldValue = customFieldInput.getText();
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally {
			CommonUtil.normalWait(1000);
			backToTcList.click();
			CommonUtil.normalWait(1000);
		}
		
		return fieldValue;
		
	}
	
	public boolean verifyCustomfieldToTestcase(String customfieldName, String customfieldValue, String customfieldType)
	{
		try
		{
			if(customfieldType.equals("Text (1024)") || customfieldType.equals("Number") || customfieldType.equals("Picklist"))
			{
				logger.info("Going to verify " + customfieldName);
				testcaseCustomfieldHeader.click();
				CommonUtil.normalWait(1000);
				String xpathForcustomfield = "//div/zee-custom-fields//span[contains(@title, '"+customfieldName+"')]/following-sibling::span//span[contains(@class,'zephyr-inline-field-name')]";
				String customfield = CommonUtil.getText(xpathForcustomfield);
				System.out.println(customfield);
				System.out.println(customfieldValue);
				Assert.assertTrue(customfield.equals(customfieldValue), "customfield"  + customfieldType +  "not verified.");
				logger.info("Customfield" + customfieldType + "verified successfully, Name is : " + customfield);
				CommonUtil.normalWait(1000);
				testcaseCustomfieldHeader.click();
			}
			
			if(customfieldType.equals("Long Text (32000)"))
			{
				logger.info("Going to verify " + customfieldName);
				testcaseCustomfieldHeader.click();
				String xpathForcustomfiledTextarea = "//div/zee-custom-fields//span[contains(@title, '"+customfieldName+"')]/following-sibling::span//span[contains(@class,'zephyr-inline-field-name')]";
				String customfieldLongText = CommonUtil.getText(xpathForcustomfiledTextarea);
				Assert.assertTrue(customfieldLongText.equals(customfieldValue), "customfield Long text not verified");
				logger.info("Customfield long text name verified successfully, Name is : " + customfieldLongText);
				testcaseCustomfieldHeader.click();
			}
			
//			if(customfieldType.equals("Date"))
//			{
//				String xpathForCustomfieldDate = "//div/zee-custom-fields//strong[contains(@title, '"+customfieldName+"')]/following-sibling::span//span[@class='zephyr-inline-field-name']";
//				String customfieldDate = CommonUtil.getText(xpathForCustomfieldDate);
//				Assert.assertTrue(customfieldDate.equals(), "customfield Date not verified.");
//				logger.info("Customfield Number verified successfully, Name is : " + customfieldDate);
//				CommonUtil.normalWait(1000);
//			}
			
		
	}
		catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}
	


	public String getTestcase(String nodeName){
		String testcaseId = null;
		try {
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + nodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			CommonUtil.normalWait(3000);
			logger.info("Node selected successfully.");

			int sizeOfTestcasesBefore = CommonUtil
					.returnSizeOfElements("//*[@id='grid-table-tcr']/div[@class='grid-content']/div");
			logger.info("Size of elements before : " + sizeOfTestcasesBefore);
			String xpathForClonedTestcaseid = "//*[@id='grid-table-tcr']/div[@class='grid-content']/div[" + sizeOfTestcasesBefore
					+ "]/div[@data-col-index='2']";
			testcaseId = CommonUtil.getText(xpathForClonedTestcaseid);
			
			logger.info("Testcase Id : " + testcaseId);
		} catch (Exception e) {
			e.printStackTrace();
			return testcaseId;
		}
		return testcaseId;
	}
	
	public String getTestcase(String nodeName, String testcaseName){
		String tcName = null;
		try{
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + nodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			CommonUtil.normalWait(1000);
			logger.info("Node selected successfully.");
			String xpathForTestcase = "//*[@id='grid-table-tcr']/div[@class='grid-content']//div[@data-col-index='3']//div[contains(text(),'"+testcaseName+"')]";
			tcName = CommonUtil.getText(xpathForTestcase);
			logger.info("Testcase Name is : " +tcName);
		}catch(Exception e){
			e.printStackTrace();
			return tcName;
		}
		return tcName;
	}
	
	
	public boolean modifyTeststep(Map<String, String> values) {
		try {
			
			
			String versionNumBeforeEdit = verifyStepDetailsHistory(values);
			String versionNumAfterEdit = StringUtils.EMPTY;
			if (values.containsKey("TESTCASE_STEPS")) {
//				CommonUtil.scrollToWebElement(testcaseStepHeader);
				CommonUtil.normalWait(1000);
				CommonUtil.scrollToWebElementAndView(testcaseStepHeader);
//				CommonUtil.normalWait(1000);
//				testcaseStepHeader.click();
				int sizeOfTestSteps = CommonUtil.returnSizeOfElements("//tbody[@id='zee-test-rows']/tr");
				//logger.info("Test Case Id "+testcaseId+"'s steps count:::."+sizeOfTestSteps);
				Assert.assertTrue(sizeOfTestSteps>0, "no test steps found");
				logger.info("Editing Teststeps of a, Teststeps : "+values.get("TESTCASE_STEPS"));
				CommonUtil.normalWait(500);
//				JSONObject steps = new JSONObject(values.get("teststeps"));
			//	JSONArray stepArray = new JSONArray(values.get("TESTCASE_STEPS"));
				List<String> stepsToBeModifiedList = Arrays.asList(values.get("TESTCASE_STEPS").split(","));
				
				for (int i = 0; i < stepsToBeModifiedList.size(); i++) {
					
					
					//JSONObject stepDetails = (JSONObject) stepsToBeModifiedList.get(i);
					
					
					String stepEditedText =  stepsToBeModifiedList.get(i)+" edited";
					
					logger.info("step value: "+stepEditedText);
					
					String dataEditedText = "data "+stepsToBeModifiedList.get(i).split(" ")[1]+" edited"; 
					logger.info("data value: "+dataEditedText);
					String resultEditedText = "result "+stepsToBeModifiedList.get(i).split(" ")[1]+" edited";
					logger.info("result value: "+resultEditedText);
					
					String xpathForEditStep = "//*[@id='zee-test-rows']//tr//span[@class='zephyr-inline-row-name']/span[text()='"+stepsToBeModifiedList.get(i)+"']";
					WebElement weStep = CommonUtil.returnWebElement(xpathForEditStep);
					weStep.click();
					CommonUtil.normalWait(2000);
					String teststepEditTextBox = xpathForEditStep+"/parent::span/parent::div/following-sibling::div//div/textarea[@data-key='step']";
					WebElement wStep = CommonUtil.returnWebElement(teststepEditTextBox);
					CommonUtil.visibilityOfElementLocated(teststepEditTextBox);
		//			wStep.clear();
		//			CommonUtil.normalWait(2000);
					wStep.sendKeys(Keys.HOME,Keys.chord(Keys.SHIFT,Keys.END),stepEditedText);
					wStep.sendKeys(Keys.TAB);
					
					CommonUtil.normalWait(2000);
					String datattext="//*[@id='zee-test-rows']//tr//span[@class='zephyr-inline-row-name']/span[text()='data "+stepsToBeModifiedList.get(i).split(" ")[1]+"']";
					String testdataEditTextBox = datattext+"/parent::span/parent::div/following-sibling::div//div/textarea[@data-key='data']";
					WebElement wData = CommonUtil.returnWebElement(testdataEditTextBox);
					CommonUtil.visibilityOfElementLocated(testdataEditTextBox);
		//			wData.clear();
		//			CommonUtil.normalWait(2000);
					wData.sendKeys(Keys.HOME,Keys.chord(Keys.SHIFT,Keys.END),dataEditedText);
					wData.sendKeys(Keys.TAB);
					
					CommonUtil.normalWait(2000);
					String resultText="//*[@id='zee-test-rows']//tr//span[@class='zephyr-inline-row-name']/span[text()='result "+stepsToBeModifiedList.get(i).split(" ")[1]+"']";
					String testResultEditTextBox = resultText+"/parent::span/parent::div/following-sibling::div//div/textarea[@data-key='result']";
					WebElement wResult = CommonUtil.returnWebElement(testResultEditTextBox);
					CommonUtil.visibilityOfElementLocated(testResultEditTextBox);
		//			wResult.clear();
		//			CommonUtil.normalWait(2000);
					wResult.sendKeys(Keys.HOME,Keys.chord(Keys.SHIFT,Keys.END),resultEditedText);
					
					CommonUtil.normalWait(2000);
					logger.info("Step Edited successfullt");
				}
				if(values.containsKey("TESTCASE_STEPS_CANCEL") && values.get("TESTCASE_STEPS_CANCEL").equals("true")){
		//			cancelBtnInStepSection.click();
					CommonUtil.actionClass().sendKeys(Keys.ESCAPE).perform();
					CommonUtil.normalWait(2000);
				}else{
		//			saveBtnInStepSection.click();
					CommonUtil.actionClass().sendKeys(Keys.TAB).perform();
					CommonUtil.normalWait(2000);
					
				}
				if( values.get("VERSIONVERIFY").equalsIgnoreCase("true")){ 
				CommonUtil.browserRefresh();
				CommonUtil.normalWait(3000);
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(2000);
				versionNumAfterEdit=verifyStepDetailsHistory(values);
				Assert.assertFalse(versionNumAfterEdit.equals(versionNumBeforeEdit), "Teststep Version history did not change ");
				logger.info("Teststep Version history changed.");
				}
				CommonUtil.normalWait(1000);
				logger.info("Teststep saved successfully.");
			}
			navigateBackToTestcaseList();
			
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean cloneTestcase(String nodeName,String testcaseName,String stepstatus){
		boolean clonestatus = false;
		try {
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + nodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(2000);
			logger.info("Node selected successfully.");

			int sizeOfTestcasesBefore = CommonUtil
					.returnSizeOfElements("//*[@id='grid-table-tcr']/div[@class='grid-content']/div");
			logger.info("Size of elements before : " + sizeOfTestcasesBefore);
			String actualTestcaseId=StringUtils.EMPTY;

			if(sizeOfTestcasesBefore>0){
				logger.info("Test case count::"+sizeOfTestcasesBefore);
				
				
				//String clonetestcaseString = "//*[@id='grid-table-tcr']/div[@class='grid-content']/div["+cloneTestCaseGridNum+"]/div[@data-col-index='0']//input";
				String clonetestcaseString = "//*[@id='grid-table-tcr']/div[@class='grid-content']//div[text()='"+testcaseName+"']/parent::div/parent::div/preceding-sibling::div[4]//input[@name='testcase_select']";
				
				String xpathactualTestcaseId = "//*[@id='grid-table-tcr']/div[@class='grid-content']/div//div[@data-col-index='4']//div[text()='"+testcaseName+"']/parent::div/parent::div/preceding-sibling::div[2]//div[@title]";
				 actualTestcaseId = CommonUtil.getText(xpathactualTestcaseId);
				
				CommonUtil.normalWait(2000);
				WebElement web = CommonUtil.returnWebElement(clonetestcaseString);
				web.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(4000);
				buttonClone.click();
				HomePage.getInstance().closeToastPopup();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(3000);
				web.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(2000);
				int sizeOfTestcasesAfter = CommonUtil
						.returnSizeOfElements("//*[@id='grid-table-tcr']/div[@class='grid-content']/div");
				
				logger.info("Size of elements after : " + sizeOfTestcasesAfter);

				Assert.assertTrue(sizeOfTestcasesBefore + 1 == sizeOfTestcasesAfter, "Testcase size not increased (clone).");
				logger.info("Test case size verified Successfully (clone).");
				
				if(StringUtils.equalsIgnoreCase(stepstatus, "withoutsteps")){
					//verifying test cases with no steps 
					clonestatus = verifyClonedTestcaseName(testcaseName,sizeOfTestcasesAfter);
					logger.info("clone status  : " + clonestatus);
					Assert.assertTrue(clonestatus, "Test cases with no steps not cloned.");
					logger.info(" Test cases with no steps cloned Successfully.");
					String xpathForClonedTestcaseid = "//*[@id='grid-table-tcr']/div[@class='grid-content']/div[" + sizeOfTestcasesAfter
							+ "]/div[@data-col-index='2']";
					String clonedTestcaseId = CommonUtil.getText(xpathForClonedTestcaseid);
					verifyTestcaseVersion(Integer.parseInt(clonedTestcaseId),"1");
				}else if(StringUtils.equalsIgnoreCase(stepstatus, "withsteps")){
					//verifying test cases with steps 
					boolean cloneNameStatus=false;
					cloneNameStatus = verifyClonedTestcaseName(testcaseName,sizeOfTestcasesAfter);
					Assert.assertTrue(cloneNameStatus, "Test cases with steps not cloned.");
					String xpathForClonedTestcaseid = "//*[@id='grid-table-tcr']/div[@class='grid-content']/div[" + sizeOfTestcasesAfter
							+ "]/div[@data-col-index='2']";
					String clonedTestcaseId = CommonUtil.getText(xpathForClonedTestcaseid);
					logger.info("clonedTestcaseId::"+clonedTestcaseId);
					clonestatus = vefifyTestSteps(actualTestcaseId,clonedTestcaseId);
					Assert.assertTrue(clonestatus, "Test cases with steps not cloned.");
					logger.info("clone status  : " + clonestatus);
					//Assert.assertTrue(clonestatus == true, "Test cases with steps not cloned.");
					logger.info(" Test cases with  steps cloned Successfully.");
					verifyTestcaseVersion(Integer.parseInt(clonedTestcaseId),"1");
					
				}
				CommonUtil.normalWait(3000);
				
			}else{
				logger.info("No test cases : test case count::"+sizeOfTestcasesBefore);
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			return clonestatus;
		}
		return clonestatus;
		
			
			
	}
	
	public boolean verifyclonetestcasecoverage(String testcaseId, String coverage)
	
	
	{
		
			CommonUtil.normalWait(1500);
			try {
				logger.info("Locating testcase coverage number...");
				String coverageXpath = "//*[@id='grid-table-tcr']/div[2]/div/div[3]/div/div[text()='"+testcaseId+"']//parent::div//parent::div//following-sibling::div[9]/div/div";
				WebElement CoverageWb = CommonUtil.returnWebElement(coverageXpath);
				logger.info("Found coverage :"+ CoverageWb.getText());
				Assert.assertTrue(CoverageWb.getText().equals(coverage), "Testcase version number does not match");
				logger.info("Verified testcase Coverage");
			}
			catch (Exception e) {
				e.printStackTrace();
				return false;
			}
			return true;
	}
	
	
	public boolean vefifyTestSteps(String actualTestcaseId,String clonedTestcaseId){
		boolean status=false;
		List <String> actualTcStepsName=getStepsName(actualTestcaseId);
		List <String> clonedTcStepsName=getStepsName(clonedTestcaseId);
		
		Assert.assertTrue(actualTcStepsName.size()==clonedTcStepsName.size() && actualTcStepsName.containsAll(clonedTcStepsName), "test cases steps are not matched.");
		status=true;
		logger.info("test case steps a alike");
		logger.info("verified test case with steps count "+actualTcStepsName.size());
		
		
		return status;
		
	}
	
	private List<String> getStepsName(String testCaseId){
	
		List <String> TcStepsName=new ArrayList<String>();
		//Forming String  "Test Steps-Test Data-Expected Results". 
		String xpathForTestcase ="//*[@id='grid-table-tcr']/div[@class='grid-content']/div/div[@data-col-index='2']//div[@title='"+testCaseId+"']/parent::div/parent::div/following-sibling::div//div[@class='name-as-link']";
		WebElement selectTestcase = CommonUtil.returnWebElement(xpathForTestcase);
		selectTestcase.click();
		logger.info("Test Case Id "+testCaseId+" Selected.");
		CommonUtil.normalWait(1000);
		CommonUtil.scrollToWebElement(testcaseStepHeader);
		CommonUtil.normalWait(1000);
		CommonUtil.scrollToWebElementAndView(testcaseStepHeader);
		testcaseStepHeader.click();
		CommonUtil.normalWait(500);
		
		
		int sizeOfTestSteps = CommonUtil.returnSizeOfElements("//tbody[@id='zee-test-rows']/tr");
		logger.info("Test Case Id "+testCaseId+"'s steps count:::."+sizeOfTestSteps);
		Assert.assertTrue(sizeOfTestSteps>0,"no test steps found");
		for(int count=1;count<=sizeOfTestSteps;count++){
			
			String generatedText=StringUtils.EMPTY;
			for(int value=0;value<3;value++){
			String xpathForStepindex = "//*[@id='zephyr-editable-row-"+count+"']/td["+(4+value)+"]/div/div[1]/span/span";
			String spanText = CommonUtil.getText(xpathForStepindex);
			generatedText=generatedText.concat(spanText).concat("-"); 
			}
			logger.info("generatedText:: "+generatedText);
			TcStepsName.add(generatedText);
		}
		
		logger.info("List TcStepsName returned:: "+TcStepsName);
		backToTcList.click();
		CommonUtil.normalWait(1000);
		return TcStepsName;
		
		
	}
	
	
	
	public boolean verifyClonedTestcaseName(String actualTcName ,int clonedTcnum){
		boolean clonedStaus = false;
		try {
			CommonUtil.normalWait(2000);
			String xpathForClonedTestcaseName = "//*[@id='grid-table-tcr']/div[@class='grid-content']/div[" + clonedTcnum
					+ "]/div[@data-col-index='4']";
			String clonedTestcaseName = CommonUtil.getText(xpathForClonedTestcaseName);
			
			Assert.assertTrue(actualTcName.equals(clonedTestcaseName), "Cloned Testcase  name verification failed.");
			clonedStaus = true;
			logger.info("Cloned Testcase  name verified successful, Name is : " + clonedTestcaseName);
			
			
		} catch (Exception e) {
			e.printStackTrace();
			return clonedStaus;
		}
		return clonedStaus;
	}
	
	public String verifyStepDetailsHistory(Map<String, String> values){
		String versionNumber = StringUtils.EMPTY;
		try{
			
			
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + values.get("NODE_NAME") + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			CommonUtil.normalWait(1000);
			logger.info("Node selected successfully.");

			int sizeOfTestcasesBefore = CommonUtil
					.returnSizeOfElements("//*[@id='grid-table-tcr']/div[@class='grid-content']/div");
			logger.info("Size of elements before : " + sizeOfTestcasesBefore);
			logger.info("Modifing default testcase.");
			
			//String xpathForTestcaseId = "//*[@id='grid-table-tcr']/div[@class='grid-content']/div/div[@data-col-index='2']//div[@title='"+ values.get("TESTCASE_ID") + "']";
			String xpathForTestcase = "//*[@id='grid-table-tcr']/div[@class='grid-content']//div[@data-col-index='4']//div[contains(text(),'"+values.get("TESTCASE_SUMMARY")+"')]";
			WebElement selectTestcase = CommonUtil.returnWebElement(xpathForTestcase);
			selectTestcase.click();
			logger.info("Clicked on the testcase Id for modification.");
			CommonUtil.normalWait(1000);
			
			
			
			if( values.get("VERSIONVERIFY").equalsIgnoreCase("true")){ 
			CommonUtil.scrollToWebElement(stepDetailsHistoryHeadder);
			CommonUtil.normalWait(500);
			CommonUtil.scrollToWebElementAndView(stepDetailsHistoryHeadder);
			stepDetailsHistoryHeadder.click();
			CommonUtil.normalWait(500);
			int versionSizeBefore = CommonUtil.returnSizeOfElements("//*[@id='grid-table-testcase_history']//div[@class='flex-bar']");
			logger.info("Version count:"+versionSizeBefore);
			String xpathForVersionNumber = "//*[@id='grid-table-testcase_history']//div[@data-index='"+(versionSizeBefore-1)+"']//div[@data-col-index='2']//div[@title]";
			versionNumber = CommonUtil.getText(xpathForVersionNumber);
			logger.info("Testatep Details History is:"+versionNumber);
			}
		}catch (Exception e){
			e.printStackTrace();
			return versionNumber;
		}
		return versionNumber;
	}

	
	public boolean navigateBetweenTestcases(String nodeName, String testcaseName){
		//String tcName = null;
		try{
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + nodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			logger.info("Node selected successfully.");
			int sizeOfTestcase = CommonUtil
					.returnSizeOfElements("//*[@id='grid-table-tcr']/div[@class='grid-content']/div");
			logger.info("Size of elements before : " + sizeOfTestcase);
			CommonUtil.normalWait(500);
			if(sizeOfTestcase>0){
				logger.info("Test case count::"+sizeOfTestcase);                     
				for(int i=1;i<=sizeOfTestcase;i++){
			String xpathForTestcase = "//*[@id='grid-table-tcr']/div[@class='grid-content']//div[@data-col-index='3']//div[text()='"+(testcaseName+i)+"']";
			String tcName = CommonUtil.getText(xpathForTestcase);
			WebElement selectTestcase = CommonUtil.returnWebElement(xpathForTestcase);
			selectTestcase.click();
			logger.info("Testcase selected in the grid is : " +tcName);
			
			String xpathForTestcaseInDetail = "//*[@class='zephyr-testcase-name']//span[@class='zephyr-inline-field-name fourth' and text()='"+(testcaseName+i)+"']";
			String tcNameInDetails = CommonUtil.getText(xpathForTestcaseInDetail);
			logger.info("Testcase selected in the Details is : " +tcNameInDetails);
			
			Assert.assertTrue(tcName.equals(tcNameInDetails), "Testcases selected in grid and details do not match.");
			String xpathForTestcaseDetailsCount = "//*[@id='zephyr-testcase-panel']//div/paginator/ul[@class='pager']//li[@class='showing']";
			String testcaseDetailsCount = CommonUtil.getText(xpathForTestcaseDetailsCount);
			
			String[] detailsCount = testcaseDetailsCount.split(" of ");
			int startIndexBeforeClk = Integer.parseInt(detailsCount[0]);
			logger.info("startIndexBeforeClk:"+startIndexBeforeClk);
			int endIndexBeforeClk = Integer.parseInt(detailsCount[1]);
			logger.info("endIndexBeforeClk:"+endIndexBeforeClk);
			//Assert.assertTrue(CommonUtil.visibilityOfElementLocated(testcaseDetailsCount), "Testcase count not found");
			if(i<sizeOfTestcase){
				CommonUtil.normalWait(1000);
			testcaseDetailDownArrow.click();
			CommonUtil.normalWait(3000);
			CommonUtil.browserRefresh();
			CommonUtil.normalWait(3000);
			String testcaseDetailsCountAfterClk = CommonUtil.getText(xpathForTestcaseDetailsCount);
			
			String[] detailsCountAfterClk = testcaseDetailsCountAfterClk.split(" of ");
			int startIndexAfterClk = Integer.parseInt(detailsCountAfterClk[0]);
			logger.info("startIndexAfterClk:"+startIndexAfterClk);
			int endIndexAfterClk = Integer.parseInt(detailsCountAfterClk[1]);
			logger.info("endIndexAfterClk:"+endIndexAfterClk);
			Assert.assertTrue(startIndexBeforeClk+1 == startIndexAfterClk && endIndexBeforeClk == endIndexAfterClk,"Index count not increamented");
			logger.info("Index count increamented");
			}
			
			//End of For loop
			}
			
			}else{
				logger.info("No test cases : test case count::"+sizeOfTestcase);
				
			}	
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean findAndAddTestcase(String nodeName, String searchQuery){
		try{
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + nodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			CommonUtil.normalWait(1000);
			logger.info("Node selected successfully.");
			releaseOptionsBtn.click();
			logger.info("Clicked on Node Options on the Release successfully.");

			Assert.assertTrue(navigateToReleaseOptions("Find and Add"), "Not clicked on Find and Add Button.");
			logger.info("Clicked on Find and Add Button");
			CommonUtil.normalWait(1000);
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerFindAndAdd),"Header Find And Add not found");
			logger.info("Find And Add window launched successfully");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(advanceSearchField),"ZQL field not found");
			advanceSearchField.sendKeys(searchQuery);
			CommonUtil.normalWait(1000);
			buttonGoFindAndAdd.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			selectAllFindAndAdd.click();
			CommonUtil.normalWait(500);
			buttonAddFindAndAdd.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean dockUndockGlobalTree(String nodeName){
		try{
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + nodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			CommonUtil.normalWait(1000);
			logger.info("Node selected successfully.");
			releaseOptionsBtn.click();
			logger.info("Clicked on Node Options on the Release successfully.");

			Assert.assertTrue(navigateToReleaseOptions("Copy from Project Releases"), "Not clicked on 'Copy from Project Releases'.");
			logger.info("Clicked on 'Copy from Project Releases'");
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerCopyFromOtherProjects),"Header 'Copy from Project Releases' not found"); 
			logger.info("'Copy from Project Releases' window launched successfully");
		//	undockLocalGrid.click();
			CommonUtil.normalWait(1000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(localGridContent), "Local Grid Header not found");
			logger.info("Verified Header of Local Grid");
	//		dockLocalGrid.click();
			CommonUtil.normalWait(1000);
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(globalTreeProjectsNode), "Global Projects Node not found");
			logger.info("Verified Global Projects Node");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(globalTreeImportedNode), "Global Imported node not found");
			logger.info("Verified Global Imported Node");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(globalGridHeader),"Global Grid header not found");
			logger.info("Verified Header of Global Grid");
			CommonUtil.normalWait(1000);
	//		dockGlobalGrid.click();
			CommonUtil.normalWait(1000);
		//	undockGlobalGrid.click();
			CommonUtil.normalWait(1000);
			buttonCloseGlobalWindow.click();
			
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	
	public boolean searchTescases(String searchType, String searchQuery, List<String> expectedTestcases, boolean navigateBackToFolder){
		try{
			CommonUtil.normalWait(1000);
			logger.info("Going to launch Search Window");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(searchView),"Search Button not found");
			CommonUtil.moveToElement(searchView);
			CommonUtil.normalWait(3000);
			searchView.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
//			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerSearch),"Header Search not found");
			logger.info("Search Window launched Successfully");
			
			if(searchType.equalsIgnoreCase("Quick")){
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonQuick), "Radio button Quick not found");
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textAreaForQuickSearch), "Text Area for Quick search not found");
				CommonUtil.normalWait(1000);
				textAreaForQuickSearch.sendKeys(searchQuery);
				CommonUtil.normalWait(1000);
				buttonGoQuick.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
				
				/*for(String fetchedTestcase : expectedTestcases){
					logger.info("Going to verify searched testcase by name: " + fetchedTestcase);
					String searchResult = "//div[@id='tcr-grid']//div[text()='"+fetchedTestcase+"']";
					WebElement weSearchResult = CommonUtil.returnWebElement(searchResult);
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(weSearchResult),"Testcase not found after search by name: " + fetchedTestcase);
					weSearchResult.click();
					CommonUtil.normalWait(1000);
					String xpathForSearchTestcase = "//div[@class='zephyr-editable-field-view-mode']/span[text()='"+fetchedTestcase+"']";
					WebElement weSearchTestcase = CommonUtil.returnWebElement(xpathForSearchTestcase);
					CommonUtil.scrollToWebElement(weSearchTestcase);
					CommonUtil.normalWait(1000);
					CommonUtil.moveToElement(weSearchTestcase);
					String tcName = CommonUtil.getText(xpathForSearchTestcase);
					String tcName = CommonUtil.getText(searchResult);
					Assert.assertTrue(fetchedTestcase.equals(tcName), "Testcase did not match with the search result");
					logger.info("Verified searched testcase by name: " + fetchedTestcase);
					//String xpathForAltId = "//span[text()='"+searchQuery+"']";
					//String altId = CommonUtil.getText(xpathForAltId);
					//Assert.assertTrue(searchQuery.equals(altId),"AltId did not match");
				}*/
				if(navigateBackToFolder) {
					folderView.click();
					CommonUtil.normalWait(1000);
				}
				
			}else{
				if(searchType.equalsIgnoreCase("Advanced")){
					CommonUtil.normalWait(1000);
					logger.info("Going to select Advanced Search Option");
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonAdvanced), "Radio button Advanced not found");
					radioButtonAdvanced.click();
					CommonUtil.normalWait(1000);
					logger.info("Clicked on Advanced Search Option successfully");
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textAreaForAdvanceSearch), "Text Area for Advance search not found");
					CommonUtil.normalWait(1000);
					textAreaForAdvanceSearch.sendKeys(searchQuery);
					CommonUtil.normalWait(1000);
					buttonGoZql.click();
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.normalWait(1000);
					/*for(String fetchedTestcase : expectedTestcases){
						logger.info("Going to verify searched testcase by name: " + fetchedTestcase);
						String searchResult = "//div[@id='grid-table-tcr']//div[text()='"+fetchedTestcase+"']";
						WebElement weSearchResult = CommonUtil.returnWebElement(searchResult);
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(weSearchResult),"Testcase not found after search by name: " + fetchedTestcase);
						weSearchResult.click();
						CommonUtil.normalWait(1000);
						String xpathForSearchTestcase = "//div[@class='zephyr-editable-field-view-mode']/span[text()='"+fetchedTestcase+"']";
						WebElement weSearchTestcase = CommonUtil.returnWebElement(xpathForSearchTestcase);
						CommonUtil.scrollToWebElement(weSearchTestcase);
						CommonUtil.normalWait(1000);
						CommonUtil.moveToElement(weSearchTestcase);
						String tcName = CommonUtil.getText(xpathForSearchTestcase);
						String tcName = CommonUtil.getText(searchResult);
						Assert.assertTrue(fetchedTestcase.equals(tcName), "Testcase did not mactch with the search result");
						logger.info("Verified searched testcase by name: " + fetchedTestcase);
						//String xpathForAltId = "//span[text()='"+searchQuery+"']";
						//String altId = CommonUtil.getText(xpathForAltId);
						//Assert.assertTrue(searchQuery.equals(altId),"AltId did not match");
					}*/
					
					if(navigateBackToFolder) {
						folderView.click();
						CommonUtil.normalWait(1000);
					}
					
					
				}else{
					Assert.assertTrue(false, "Please provide proper search Type in Test, Expected values are: Quick, Advanced");
				}
			}
			
			
			
			
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean switchBetweenSearchFolderListDetailView(String nodeName){
		try{
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + nodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			logger.info("Node selected successfully.");
			
			
			logger.info("Going to Navigate to Search View");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(searchView), "Search button not found");
			searchView.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			//Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerSearch),"Header Search not found");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonQuick));
			logger.info("Navigated to Search View Successfully");
			
			CommonUtil.normalWait(1000);
			logger.info("Going to Navigate to Folder View");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(folderView),"Folder Button not found");
			folderView.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(addTestcaseBtn));
			logger.info("Navigated to Folder View Successfully");
			
			CommonUtil.normalWait(1000);
			logger.info("Going to Navigate to Detail View");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(detailView),"Detail Button not found");
			detailView.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//*[@id='zephyr-testcase-panel']//a[text()='Top']"),"Testcase Detail View not found");
			logger.info("Navigated to Detail View Successfully");
			
			CommonUtil.normalWait(1000);
			logger.info("Going to Navigate to List View");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(listView),"List Button not found");
			listView.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(tcrFilterSearchBox),"Filter search box not found");
			logger.info("Navigated to List View Successfully");
			
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	
	public boolean deleteTestcase(String nodeName, String testcaseName) {
		try {
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + nodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			CommonUtil.normalWait(1000);
			logger.info("Node selected successfully.");

			int sizeOfTestcasesBefore = CommonUtil
					.returnSizeOfElements("//*[@id='grid-table-tcr']/div[@class='grid-content']/div");
			logger.info("Size of elements before : " + sizeOfTestcasesBefore);
			logger.info("Creating default testcase.");

			String xpathForTestcaseId = "//*[@id='grid-table-tcr']/div[@class='grid-content']/div/div[@data-col-index='4']//div[text()='"+testcaseName+"']";
			WebElement selectTestcase = CommonUtil.returnWebElement(xpathForTestcaseId);
			CommonUtil.moveToElement(selectTestcase);
			logger.info("Clicked on the testcase Id for Deletion.");
			CommonUtil.normalWait(3000);
			
			String xpathForTestcaseCheckBox = "//*[@id='grid-table-tcr']/div[@class='grid-content']/div[div[@data-col-index='4']//div[text()='"+testcaseName+"']]//input[@name='testcase_select']";
			CommonUtil.returnWebElement(xpathForTestcaseCheckBox).click();
			CommonUtil.normalWait(1000);
			logger.info("Selected the checkbox for Deletion.");
			deleteTestcaseBtn.click();
			logger.info("Clicked on the Delete btn for Deletion.");
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(deleteTestcaseModalPopup), "Not Found Delete Modal Confirmation Popup.");
			logger.info("Found Delete Modal Confirmation Popup and now continuing with delete.");
			
			Assert.assertTrue(deleteTestcaseModalPopupHeader.getText().equals("Delete"), "Delete Modal popup header text not verified.");
			logger.info("Delete Modal popup header text verified successfully.");
			
			Assert.assertTrue(deleteTestcaseModalPopupBodyConfirmationText.getText().equals("Continue with deleting testcase(s)?"), "Delete Modal popup Body text not verified.");
			logger.info("Delete Modal popup Body text verified successfully.");
			
			deleteTestcaseModalPopupDeleteBtn.click();
			logger.info("Clicked on Delete Modal popup Delete Button successfully.");
			
			CommonUtil.normalWait(1000);
			/*int sizeOfTestcasesAfter = CommonUtil
					.returnSizeOfElements("//*[@id='grid-table-tcr']/div[@class='grid-content']/div");
			logger.info("Size of elements after : " + sizeOfTestcasesAfter);

			Assert.assertTrue((sizeOfTestcasesBefore - 1) == sizeOfTestcasesAfter, "Testcase size not decreased.");
			logger.info("Test case size verified Successfully.");

			boolean flag = false ;
			for (Iterator iterator = listOfTestcaseIds.iterator(); iterator.hasNext();) {
				WebElement webElement = (WebElement) iterator.next();
				// logger.info(webElement.getText());
				if (webElement.getText().trim().equals(testcaseId)) {
					logger.info(testcaseId + " found again after deletion successfully.");
					flag = true;
					break;
				}
			}
			Assert.assertFalse(flag, "Testcase id found again after deleted.");*/
			logger.info("Testcase Deleted and verified Successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean deleteTestcase(String nodeName, int testcaseId) {
		try {
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + nodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			CommonUtil.normalWait(1000);
			logger.info("Node selected successfully.");

			int sizeOfTestcasesBefore = CommonUtil
					.returnSizeOfElements("//*[@id='grid-table-tcr']/div[@class='grid-content']/div");
			logger.info("Size of elements before : " + sizeOfTestcasesBefore);
			logger.info("Creating default testcase.");

			String xpathForTestcaseId = "//*[@id='grid-table-tcr']/div[@class='grid-content']/div/div[@data-col-index='2']//div[text()='"+testcaseId+"']";
			WebElement selectTestcase = CommonUtil.returnWebElement(xpathForTestcaseId);
			selectTestcase.click();
			logger.info("Clicked on the testcase Id for Deletion.");
			CommonUtil.normalWait(3000);
			
			String xpathForTestcaseCheckBox = "//*[@id='grid-table-tcr']/div[@class='grid-content']/div[div[@data-col-index='2']//div[text()='"+testcaseId+"']]//input[@name='testcase_select']";
			CommonUtil.returnWebElement(xpathForTestcaseCheckBox).click();
			CommonUtil.normalWait(1000);
			logger.info("Selected the checkbox for Deletion.");
			deleteTestcaseBtn.click();
			logger.info("Clicked on the Delete btn for Deletion.");
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(deleteTestcaseModalPopup), "Not Found Delete Modal Confirmation Popup.");
			logger.info("Found Delete Modal Confirmation Popup and now continuing with delete.");
			
			Assert.assertTrue(deleteTestcaseModalPopupHeader.getText().equals("Delete"), "Delete Modal popup header text not verified.");
			logger.info("Delete Modal popup header text verified successfully.");
			
			Assert.assertTrue(deleteTestcaseModalPopupBodyConfirmationText.getText().equals("Continue with deleting testcase(s)?"), "Delete Modal popup Body text not verified.");
			logger.info("Delete Modal popup Body text verified successfully.");
			
			deleteTestcaseModalPopupDeleteBtn.click();
			logger.info("Clicked on Delete Modal popup Delete Button successfully.");
			
			CommonUtil.normalWait(1000);
			/*int sizeOfTestcasesAfter = CommonUtil
					.returnSizeOfElements("//*[@id='grid-table-tcr']/div[@class='grid-content']/div");
			logger.info("Size of elements after : " + sizeOfTestcasesAfter);

			Assert.assertTrue((sizeOfTestcasesBefore - 1) == sizeOfTestcasesAfter, "Testcase size not decreased.");
			logger.info("Test case size verified Successfully.");

			boolean flag = false ;
			for (Iterator iterator = listOfTestcaseIds.iterator(); iterator.hasNext();) {
				WebElement webElement = (WebElement) iterator.next();
				// logger.info(webElement.getText());
				if (webElement.getText().trim().equals(testcaseId)) {
					logger.info(testcaseId + " found again after deletion successfully.");
					flag = true;
					break;
				}
			}
			Assert.assertFalse(flag, "Testcase id found again after deleted.");*/
			logger.info("Testcase Deleted and verified Successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean verifyAttachments(String attachment) {
		boolean flag = false;
		try{
			if(testcaseAttachmentsDetails.size() > 0){
				CommonUtil.visibilityOfElementLocated(testcaseAttachmentsDetails.get(0));
			}
			for (Iterator iterator = testcaseAttachmentsDetails.iterator(); iterator.hasNext();) {
				WebElement webElement = (WebElement) iterator.next();
				// logger.info(webElement.getText());
				if (webElement.getText().trim().equals(attachment)) {

					logger.info(attachment + " verified successfully.");
					flag = true;
					break;
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			return flag;
		}
		return flag;
	}
	
	public String verifyDefaultTestcase(int testcaseNum) {
		String testcaseId = null;
		System.out.println("Tecase size: " + testcaseNum);
		try {
			String xpathForTestcaseId = "//*[@id='grid-table-tcr']/div[@class='grid-content']/div[" + testcaseNum
					+ "]/div[@data-col-index='2']";
			testcaseId = CommonUtil.getText(xpathForTestcaseId);

			Assert.assertNotNull(testcaseId, "Test case id is null.");
			logger.info("Testcase Id is : " + testcaseId);

			String xpathForTestcaseName = "//*[@id='grid-table-tcr']/div[@class='grid-content']/div[" + testcaseNum
					+ "]/div[@data-col-index='4']";
			String testcaseName = CommonUtil.getText(xpathForTestcaseName);

			Assert.assertTrue(testcaseName.equals("Untitled"), "Testcase default name not verified.");
			logger.info("Testcase default name verified successfully, Name is : " + testcaseName);

			String xpathForTestcaseStatus = "//*[@id='grid-table-tcr']/div[@class='grid-content']/div['" + testcaseNum
					+ "']/div[@data-col-index='6']";
			String testcaseStatus = CommonUtil.getText(xpathForTestcaseStatus);

			Assert.assertTrue(testcaseStatus.equals("M"), "Testcase default status not verified.");
			logger.info("Testcase default status verified successfully, Status is : " + testcaseStatus);

			
			/*String xpathForTestcaseEstimatedTime = "//*[@id='grid-table-tcr']/div[@class='grid-content']/div["
					+ testcaseNum + "]/div[@data-col-index='9']";
			String testcaseEstimatedTime = CommonUtil.getText(xpathForTestcaseEstimatedTime);

			Assert.assertTrue(testcaseEstimatedTime.equals("00:00:10"),
				"Testcase default Estimated time not verified.");
			logger.info("Testcase default Estimated time verified successfully, Estimated time is : "
					+ testcaseEstimatedTime);

			String xpathForTestcaseCreatedBy = "//*[@id='grid-table-tcr']/div[@class='grid-content']/div[" + testcaseNum
					+ "]/div[@data-col-index='10']";
			String testcaseCreatedBy = CommonUtil.getText(xpathForTestcaseCreatedBy);

			Assert.assertTrue(
					testcaseCreatedBy.replace(" ", ".").equalsIgnoreCase(Config.getValue("ZE_MANAGER_USERNAME")),
					"Testcase created by not verified.");
			logger.info("Testcase Created By verified successfully, Created by is : " + testcaseCreatedBy);

			String xpathForTestcaseCreatedOn = "//*[@id='grid-table-tcr']/div[@class='grid-content']/div[" + testcaseNum
					+ "]/div[@data-col-index='11']";
			String testcaseCreateOn = CommonUtil.getText(xpathForTestcaseCreatedOn);

			Assert.assertNotNull(testcaseCreateOn, "Created date is null.");
			logger.info("Testcase Created On verified successfully, Created On is : " + testcaseCreateOn);*/

			
			logger.info("Testcase Default data verified successfully.");
		} catch (Exception e) {
			return testcaseId;
		}
		return testcaseId;
	}
	
	public String verifyDefaultTestcaseProjectRepo(int testcaseNum) {
		String testcaseId = null;
		System.out.println("Tecase size: " + testcaseNum);
		try {
			String xpathForTestcaseId = "//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div[" + testcaseNum
					+ "]/div[@data-col-index='2']";
			testcaseId = CommonUtil.getText(xpathForTestcaseId);

			Assert.assertNotNull(testcaseId, "Test case id is null.");
			logger.info("Testcase Id is : " + testcaseId);

			String xpathForTestcaseName = "//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div[" + testcaseNum
					+ "]/div[@data-col-index='4']";
			String testcaseName = CommonUtil.getText(xpathForTestcaseName);

			Assert.assertTrue(testcaseName.equals("Untitled"), "Testcase default name not verified.");
			logger.info("Testcase default name verified successfully, Name is : " + testcaseName);

			String xpathForTestcaseStatus = "//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div['" + testcaseNum
					+ "']/div[@data-col-index='6']";
			String testcaseStatus = CommonUtil.getText(xpathForTestcaseStatus);

			Assert.assertTrue(testcaseStatus.equals("M"), "Testcase default status not verified.");
			logger.info("Testcase default status verified successfully, Status is : " + testcaseStatus);
	
			logger.info("Testcase Default data verified successfully.");
		} catch (Exception e) {
			return testcaseId;
		}
		return testcaseId;
	}

	public boolean verifyPhase(String phaseName, String phaseDescription) {
		try {
			CommonUtil.normalWait(1000);
			CommonUtil.doubleClick(releasesInTestRepository);
			// CommonUtil.actionClass().moveToElement(releasesInTestRepository).doubleClick().build().perform();
			logger.info("Waiting for the phasees.");
			CommonUtil.visibilityOfElementLocated("//li[@data-parenttype='release']//a[@data-type='Phase']");
			logger.info("Expanded the release successfully and verifing the phases.");

			for (Iterator iterator = listOfPhases.iterator(); iterator.hasNext();) {
				WebElement webElement = (WebElement) iterator.next();
				// logger.info(webElement.getText());
				if (webElement.getText().trim().equals(phaseName)) {

					logger.info(phaseName + " verified successfully.");
					// webElement.click();
					if (phaseDescription != null) {
						String desc = webElement.getAttribute("data-desc");
						Assert.assertEquals(desc, phaseDescription, "Phase Description not verified.");
						logger.info("Phase description verified successfully.");
					}
					break;
				}
			}

//			CommonUtil.normalWait(1000);
//			CommonUtil.doubleClick(releasesInTestRepository);
			logger.info("Phase verified successfully.");

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;

	}

	
	public boolean verifyNode(List<String> parentTree, String parentNodename, String nodeName, String nodeDescription) {
		boolean verifyFlag = false;
		try {
			CommonUtil.normalWait(1000);
			
			
			if(!CommonUtil.visibilityOfElementLocated("//*[@data-name = '" + parentNodename + "']", 5)) {
			CommonUtil.browserRefresh();
			CommonUtil.normalWait(3000);
				HomePage.getInstance().waitForProgressBarToComplete();
				if(parentTree!=null) {
					navigateToNodes(parentTree);
				}	
			}
			
			String xpath = "//*[@data-name = '" + parentNodename + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);

			
			CommonUtil.normalWait(1000);
			// CommonUtil.actionClass().moveToElement(releasesInTestRepository).doubleClick().build().perform();
			logger.info("Waiting for the phasees.");
			boolean flag = CommonUtil.visibilityOfElementLocated("//a[@data-name='" + parentNodename + "']/following-sibling::ul/li",5);
			if(flag){
				logger.info("Expanded the release successfully and verifing the nodes.");
			}else{
				CommonUtil.doubleClick(we);
				if(!CommonUtil.visibilityOfElementLocated("//a[@data-name='" + parentNodename + "']/following-sibling::ul/li", 5)) {
					CommonUtil.browserRefresh();
					CommonUtil.normalWait(3000);
					HomePage.getInstance().waitForProgressBarToComplete();
					if(parentTree!=null) {
						navigateToNodes(parentTree);
						boolean flag1 = CommonUtil.visibilityOfElementLocated("//a[@data-name='" + parentNodename + "']/following-sibling::ul/li",5);
						if(flag1){
							logger.info("Expanded the release successfully and verifing the nodes.");
						}else {
							CommonUtil.doubleClick(we);
						}
					}	
				}
			}
			List<WebElement> list = CommonUtil.returnWebElements("//a[@data-name='" + parentNodename + "']/following-sibling::ul/li/a");

			for (Iterator iterator = list.iterator(); iterator.hasNext();) {
				WebElement webElement = (WebElement) iterator.next();
				 logger.info(webElement.getText());
				if (webElement.getText().trim().equals(nodeName)) {

					logger.info(nodeName + " verified successfully.");
					verifyFlag = true;
					// webElement.click();
					if (nodeDescription != null) {
						String desc = webElement.getAttribute("data-desc");
						Assert.assertEquals(desc, nodeDescription, "Phase Description not verified.");
						logger.info("Phase description verified successfully.");
					}
					break;
				}
			}

			CommonUtil.normalWait(1000);
			CommonUtil.doubleClick(we);
			CommonUtil.normalWait(500);
			logger.info("Node verified successfully.");

		} catch (Exception e) {
			e.printStackTrace();
			return verifyFlag;
		}
		return verifyFlag;

	}
	
	public boolean verifyNode(String parentNodename, String nodeName, String nodeDescription) {
		boolean verifyFlag = false;
		try {
			CommonUtil.normalWait(1000);
			
			
			if(!CommonUtil.visibilityOfElementLocated("//*[@data-name = '" + parentNodename + "']", 5)) {
				CommonUtil.browserRefresh();
				CommonUtil.normalWait(3000);
				HomePage.getInstance().waitForProgressBarToComplete();
			}
			
			String xpath = "//*[@data-name = '" + parentNodename + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);

			
			CommonUtil.normalWait(1000);
			// CommonUtil.actionClass().moveToElement(releasesInTestRepository).doubleClick().build().perform();
			logger.info("Waiting for the phasees.");
			boolean flag = CommonUtil.visibilityOfElementLocated("//a[@data-name='" + parentNodename + "']/following-sibling::ul/li",5);
			if(flag){
				logger.info("Expanded the release successfully and verifing the nodes.");
			}else{
				CommonUtil.doubleClick(we);
			}
			List<WebElement> list = CommonUtil.returnWebElements("//a[@data-name='" + parentNodename + "']/following-sibling::ul/li/a");

			for (Iterator iterator = list.iterator(); iterator.hasNext();) {
				WebElement webElement = (WebElement) iterator.next();
				 logger.info(webElement.getText());
				if (webElement.getText().trim().equals(nodeName)) {

					logger.info(nodeName + " verified successfully.");
					verifyFlag = true;
					// webElement.click();
					if (nodeDescription != null) {
						String desc = webElement.getAttribute("data-desc");
						Assert.assertEquals(desc, nodeDescription, "Phase Description not verified.");
						logger.info("Phase description verified successfully.");
					}
					break;
				}
			}

			CommonUtil.normalWait(1000);
			CommonUtil.doubleClick(we);
			CommonUtil.normalWait(500);
			logger.info("Node verified successfully.");

		} catch (Exception e) {
			e.printStackTrace();
			return verifyFlag;
		}
		return verifyFlag;

	}

	public boolean verifyRenamedNode(String parentNodename, String nodeName, String nodeDescription) {
		boolean flag = false;
		try {
			CommonUtil.normalWait(1000);
			parentNodename = nodeName;
			// String xpath = "//*[@data-name = '"+parentNodename+"']";
			// WebElement we = CommonUtil.returnWebElement(xpath);
			//
			// CommonUtil.doubleClick(we);
			// CommonUtil.normalWait(1000);
			//// CommonUtil.actionClass().moveToElement(releasesInTestRepository).doubleClick().build().perform();
			// logger.info("Waiting for the phasees.");
			// CommonUtil.visibilityOfElementLocated("//a[@data-name='"+parentNodename+"']/following-sibling::ul/li");
			// logger.info("Expanded the release successfully and verifing the
			// nodes.");
//			String xpath = "//a[@data-name='" + parentNodename + "']/following-sibling::ul/li/a";
			String xpath = "//a[@data-name='" + parentNodename + "']";
			List<WebElement> listOfNodes = CommonUtil.returnWebElements(xpath);
			for (Iterator iterator = listOfNodes.iterator(); iterator.hasNext();) {
				WebElement webElement = (WebElement) iterator.next();
				logger.info(webElement.getText());
				if (webElement.getText().trim().equals(nodeName)) {

					logger.info(nodeName + " verified successfully.");
					// webElement.click();
					if (nodeDescription != null) {
						String desc = webElement.getAttribute("data-desc");
						logger.info(desc);
						Assert.assertEquals(desc, nodeDescription, "Phase Description not verified.");
						logger.info("Phase description verified successfully.");
					}
					flag = true;
					break;
				}
			}

			// CommonUtil.normalWait(1000);
			// CommonUtil.doubleClick(releasesInTestRepository);
			logger.info("Phase verified successfully.");

		} catch (Exception e) {
			e.printStackTrace();
			return flag;
		}
		return flag;

	}

	private boolean navigateToReleaseOptions(String optionsName) {
		Assert.assertTrue(CommonUtil.visibilityOfElementLocated(nodeOptionsMenu,5),
				"Release node options menu's are not visible.");
		logger.info("Release node options menu's are visible.");

		for (Iterator iterator = releaseOptionsLink.iterator(); iterator.hasNext();) {
			WebElement webElement = (WebElement) iterator.next();
			logger.info(webElement.getText());
			if (webElement.getText().trim().equals(optionsName)) {
				webElement.click();
				logger.info(optionsName + " selected successfully.");
				break;
			}
		}

		return true;
	}
	
	public boolean bulkEditTestCase(Map<String, String> values){
		try {
			CommonUtil.normalWait(1000);
			gridSelectALLcheckbox.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			logger.info("All the testcase selected");
			CommonUtil.normalWait(1000);
			buttonEdit.click();
			
			logger.info("Edit window Open successfully...");
			CommonUtil.normalWait(1000);		
			if (values.containsKey("ALTID")) {	
				bulkTestBoxAltID.click();
				bulkTestBoxAltID.sendKeys(values.get("ALTID"));
				logger.info("Alt Id Added");
			}
			
			if (values.containsKey("Comment")){
				bulkTextBoxComment.click();
				bulkTextBoxComment.sendKeys(values.get("Comment"));
				logger.info("Comment Added");
			}
			
			if (values.containsKey("Tags")){
				bulkTextBoxTag.click();
				CommonUtil.normalWait(1000);
				bulkTextBoxTag.sendKeys(values.get("Tags"));
				CommonUtil.normalWait(1000);
				bulkTextBoxTag.sendKeys(Keys.ENTER);
				logger.info("Tags Added for the Tags");
			}
			
			if(values.containsKey("estimatedTime")){
				String time[] = values.get("estimatedTime").split(":");
				CommonUtil.normalWait(500);
				bulkTextBoxDay.clear();
				bulkTextBoxDay.sendKeys(time[0]);
				CommonUtil.normalWait(500);
				bulkTextBoxHour.clear();
				bulkTextBoxHour.sendKeys(time[1]);
				CommonUtil.normalWait(500);
				bulkTextBoxMinute.clear();
				bulkTextBoxMinute.sendKeys(time[2]);
				CommonUtil.normalWait(500);
				logger.info("Estimation Time Added");
				
			}
			
			if(values.containsKey("priority")){
			String priority =	values.get("priority");
				CommonUtil.normalWait(500);
				selectBulkPrority.click();
				String we = ".//*[@id='select2-tcr-bulk-priority-results']/li[text()='"+priority+"']";
				WebElement selectPriority = CommonUtil.returnWebElement(we);
				selectPriority.click();
				
			}
				
			if(values.containsKey("Automated")){
			String automatedValues[]= values.get("Automated").split(Constants.CHAR_TO_SPLIT_STRING);
			CommonUtil.normalWait(500);
			bulkCheckboxAutomated.click();
			CommonUtil.normalWait(500);
			bulkAutomatedName.click();
			bulkAutomatedName.sendKeys(automatedValues[0]);
			CommonUtil.normalWait(500);
			bulkAutomateID.click();
			bulkAutomateID.sendKeys(automatedValues[1]);
			CommonUtil.normalWait(500);
			bulkAutomatePath.click();
			bulkAutomatePath.sendKeys(automatedValues[2]);
			CommonUtil.normalWait(500);
			}
			
			CommonUtil.normalWait(1000);
			buttonBulkSave.click();
			CommonUtil.normalWait(1000);
			buttonBulkSave2.click();
			logger.info("values updated successfully...");
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean verifySuccessPopup(String type) {
		try {
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(successContainer));
			logger.info("Success Message verified Successfully.");

			Assert.assertTrue(deleteSuccessToastTitle.getText().equals("Success"), "Not found Success message");
			logger.info("Success message popup text not verified.");

			String successMessage = deleteSuccessToastMsg.getText();
			if (type.equals("delete")) {
				Assert.assertTrue(successMessage.contains("Deleted node with id(s)"), "Not found Success message");
			} else if (type.equals("add")) {
				Assert.assertTrue(successMessage.contains("Created testcase with id(s)"), "Not found Success message");
			} else if (type.equals("testcase_update")) {
				Assert.assertTrue(successMessage.contains("Testcase with id"), "Not found Success message");
				Assert.assertTrue(successMessage.contains("updated successfully"), "Not found Success message");
			}
			logger.info("Success message popup message verified, Message : " + successMessage);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean verifyTestRepositorySummaryPage(String releaseName) {
		try {
			
			Assert.assertEquals(CommonUtil.getTitle(), "Test Repository - Zephyr Enterprise 6.2");
		//	Assert.assertTrue(CommonUtil.visibilityOfElementLocated(testRepoPageHeader,2),
			//		"Test Repository Header not found.");
			logger.info("Test Repository header text validated successfully.");

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(searchView),
					"searchView not present in Test repository page.");
			logger.info("searchView verified in Test repository page.");

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(folderView),
					"folderView not present in Test repository page.");
			logger.info("folderView verified in Test repository page.");

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(importedBtn),
					"importedBtn not present in Test repository page.");
			logger.info("importedBtn verified in Test repository page.");

			Assert.assertTrue(releasesInTestRepository1.getAttribute("data-name").equals(releaseName),
					releaseName + " not verified in Test Repository page.");
			logger.info(releaseName + " verified successfully on Test repository.");

			logger.info("Test Repository page verified successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean exportSelectedNodeOfTCC(String nodeName, String reportType, String outputAs){
		try{
			logger.info("Going to launch Export Window");
			CommonUtil.normalWait(1000);
			WebElement we = CommonUtil.returnWebElement("//*[@data-name = '" + nodeName + "']");
			we.click();
			CommonUtil.normalWait(1000);
			CommonUtil.actionClass().moveToElement(we).build().perform();

			logger.info("Hovered on Phase successfully.");

			releaseOptionsBtn.click();
			logger.info("Clicked on Node Options on the Phase successfully.");

			Assert.assertTrue(navigateToReleaseOptions("Export Tests"), "Not clicked on Export Tests.");
			logger.info("Clicked on Export Tests");
			
			CommonUtil.normalWait(5000);
			
			if(reportType.equalsIgnoreCase("Excel")){
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDataExcel), "Excel export not found in Export window");
				CommonUtil.scrollToWebElement(radioButtonDataExcel);
				radioButtonDataExcel.click();
					
			}else{
				if(reportType.equalsIgnoreCase("Summary")){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonSummary), "Summary export not found in Export window");
					CommonUtil.scrollToWebElement(radioButtonSummary);
					radioButtonSummary.click();
					
				}else{
					if(reportType.equalsIgnoreCase("Detailed")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDetailed), "Detailed export not found in Export window");
						CommonUtil.scrollToWebElement(radioButtonDetailed);
						radioButtonDetailed.click();
					}
				}
				CommonUtil.normalWait(1000);
				if(outputAs.equalsIgnoreCase("HTML")){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonHtml), "HTML type not found in Export window");
					radioButtonHtml.click();
				}else{
					if(outputAs.equalsIgnoreCase("PDF")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonPdf), "PDF type not found in Export window");
						radioButtonPdf.click();
					}else{
						if(outputAs.equalsIgnoreCase("Word")){
							Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonWord), "Word type not found in Export window");
							radioButtonWord.click();
						}
					}
				}
				
			}
			CommonUtil.normalWait(1000);
			buttonSaveExport.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerDownloadFileInPopup), "Header Download File not found");
			buttonDownload.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(10000);
			
		}catch(Exception e){
			logger.info("Failed to export node successfully");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean exportGridTestcaseOfTCC(String reportType, String outputAs){
		try{
			HomePage.getInstance().waitForProgressBarToComplete();
			logger.info("Going to launch Export Window");
			CommonUtil.normalWait(1000);
			
			checboxSelectAllTestcases.click();
			CommonUtil.normalWait(1000);
			buttonExportFromGrid.click();
			CommonUtil.normalWait(5000);
			
			if(reportType.equalsIgnoreCase("Excel")){
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDataExcel), "Excel export not found in Export window");
				CommonUtil.scrollToWebElement(radioButtonDataExcel);
				radioButtonDataExcel.click();
					
			}else{
				if(reportType.equalsIgnoreCase("Summary")){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonSummary), "Summary export not found in Export window");
					CommonUtil.scrollToWebElement(radioButtonSummary);
					radioButtonSummary.click();
					
				}else{
					if(reportType.equalsIgnoreCase("Detailed")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDetailed), "Detailed export not found in Export window");
						CommonUtil.scrollToWebElement(radioButtonDetailed);
						radioButtonDetailed.click();
					}
				}
				CommonUtil.normalWait(1000);
				if(outputAs.equalsIgnoreCase("HTML")){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonHtml), "HTML type not found in Export window");
					radioButtonHtml.click();
				}else{
					if(outputAs.equalsIgnoreCase("PDF")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonPdf), "PDF type not found in Export window");
						radioButtonPdf.click();
					}else{
						if(outputAs.equalsIgnoreCase("Word")){
							Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonWord), "Word type not found in Export window");
							radioButtonWord.click();
						}
					}
				}
				
			}
			CommonUtil.normalWait(1000);
			buttonSaveExport.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerDownloadFileInPopup), "Header Download File not found");
			buttonDownload.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(10000);
			
		}catch(Exception e){
			logger.info("Failed to export node successfully");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean exportAllSearchedTestcaseInTCC(String reportType, String outputAs, boolean navigateBackToFolder){
		try{
			HomePage.getInstance().waitForProgressBarToComplete();
			logger.info("Going to launch Export Window");
			CommonUtil.normalWait(1000);
			
			checkboxSelectAllSearchedTestcase.click();
			CommonUtil.normalWait(1000);
			buttonExportInSearch.click();
			CommonUtil.normalWait(5000);
			
			if(reportType.equalsIgnoreCase("Excel")){
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDataExcel), "Excel export not found in Export window");
				CommonUtil.scrollToWebElement(radioButtonDataExcel);
				radioButtonDataExcel.click();
					
			}else{
				if(reportType.equalsIgnoreCase("Summary")){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonSummary), "Summary export not found in Export window");
					CommonUtil.scrollToWebElement(radioButtonSummary);
					radioButtonSummary.click();
					
				}else{
					if(reportType.equalsIgnoreCase("Detailed")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDetailed), "Detailed export not found in Export window");
						CommonUtil.scrollToWebElement(radioButtonDetailed);
						radioButtonDetailed.click();
					}
				}
				CommonUtil.normalWait(1000);
				if(outputAs.equalsIgnoreCase("HTML")){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonHtml), "HTML type not found in Export window");
					radioButtonHtml.click();
				}else{
					if(outputAs.equalsIgnoreCase("PDF")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonPdf), "PDF type not found in Export window");
						radioButtonPdf.click();
					}else{
						if(outputAs.equalsIgnoreCase("Word")){
							Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonWord), "Word type not found in Export window");
							radioButtonWord.click();
						}
					}
				}
				
			}
			CommonUtil.normalWait(1000);
			buttonSaveExport.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerDownloadFileInPopup), "Header Download File not found");
			buttonDownload.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(10000);
			if(navigateBackToFolder) {
				folderView.click();
				CommonUtil.normalWait(1000);
			}
			
		}catch(Exception e){
			logger.info("Failed to export node successfully");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean setPaginationPageSizeInTestRepository(String size) {
		try {
			
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			CommonUtil.selectListWithVisibleText(selectPaginationPageSize, size);
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			
		}catch (Exception e) {
			logger.info("Failed to change page size to: "+ size);
			e.printStackTrace();
		}
		return true;
	}

	public boolean mapRequirementToTestcase(String testcaseName, List<String> navigateToReqTreeNodes, String requirementName){
		
		try{
			//HomePage.getInstance().waitForProgressBarToComplete();
			logger.info("Going to verify testcase in grid");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-tcr']//div[text()='"+testcaseName+"']")
					, "Testcase not found by name: "+ testcaseName);
			logger.info("Verified testcase in grid");
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement("//div[@id='grid-table-tcr']//div[text()='"+testcaseName+"']").click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);	
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerMappedRequirementModule), "Header Map testcases To Requirements not found");
			headerMappedRequirementModule.click();
			CommonUtil.normalWait(2000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonMapReq), "Map Req button not found");
			buttonMapReq.click();
			CommonUtil.normalWait(2000);
			expandTreeNodeInMapWindow(navigateToReqTreeNodes);
	
			CommonUtil.normalWait(1000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='map-grid']//div[text()='"+requirementName+"']")
					, "requirement not found in grid to map by name: "+ requirementName);
			CommonUtil.returnWebElement("//div[@id='map-grid']//div[text()='"+requirementName+"']").click();
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement("//div[@id='map-grid']//div[text()='"+requirementName+"']/parent::div/parent::div/preceding-sibling::div//input").click();
			CommonUtil.normalWait(1000);
			buttonSaveInMapWindow.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//a[text()='Maps to 1 requirement']"), "Map Count not found as 1 after mapping");
			
		}catch(Exception e){
			logger.info("Failed to map requirement to testcase");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean verifyTestcasesInSelectedNodeOfTestRepository(List<String> testcasesNames) {
		try {
			
			for(String testcaseName: testcasesNames) {
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-tcr']//div[text()='"+testcaseName+"']"), "Testcase not found by name: "+ testcaseName);
			}
			
		}catch (Exception e) {
			logger.info("Failed to verify testcases successfully");
			e.printStackTrace();
		}
		return true;
	}


	public boolean expandTreeNodeInMapWindow(List<String> treeNodes) {
		try{
			for(int nodeLevel=0; nodeLevel<treeNodes.size();nodeLevel++) {
				if(nodeLevel==treeNodes.size()-1){
					CommonUtil.returnWebElement("//div[@id='zee-map-modal']//a[@data-name='"+treeNodes.get(nodeLevel)+"']").click();
					CommonUtil.normalWait(1000);
					HomePage.getInstance().waitForProgressBarToComplete();
				}else{
					CommonUtil.returnWebElement("//div[@id='zee-map-modal']//a[@data-name='"+treeNodes.get(nodeLevel)+"']/preceding-sibling::i").click();
					CommonUtil.normalWait(1000);
				}
			}
		}
		catch(Exception e) {
			logger.info("Failed to expand tree node in map window");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean navigateToNextOrPrevPageInTestRepositoryGrid(String nextOrPrev) {
		try {
			if(nextOrPrev.equalsIgnoreCase("Next")) {
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkNextPage), "Link Next page not found");
				linkNextPage.click();
			}else {
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkPrevPage), "Link Prev page not found");
				linkPrevPage.click();
			}
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
		}
		catch (Exception e) {
			logger.info("Failed to navigate ot "+nextOrPrev+" Page.");
			e.printStackTrace();
		}
		return true;
	}

	public boolean changeTestcaseFromManualToAutomated(String tcName, String scriptName, String id, String path) {
		try {
			HomePage.getInstance().waitForProgressBarToComplete();
			String tcXpath = "//div[@id='grid-table-tcr']//div[text()='"+tcName+"']";
			CommonUtil.returnWebElement(tcXpath).click();
			CommonUtil.normalWait(1000);
			/*if (CommonUtil.visibilityOfElementLocated(automatedCheckBox)) {
				headerAutomationModule.click();
				automatedCheckBox.click();
				CommonUtil.normalWait(2000);
			} 
			else {
				automatedCheckBox.click();
				CommonUtil.normalWait(2000);
			}*/
			automatedCheckBox.click();
			CommonUtil.normalWait(2000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(automationNameBox),"Automation name box not found");
			automationNameBox.click();
			writeBox.clear();
			writeBox.sendKeys(scriptName);
			CommonUtil.returnWebElement("//div[@class='zephyr-editable-field-edit-mode']//button[@type='submit']").click();
			CommonUtil.normalWait(1000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(automationIdBox),"Automation id box not found");
			automationIdBox.click();
			CommonUtil.normalWait(2000);
			writeBox.clear();
			writeBox.sendKeys(id);
			CommonUtil.returnWebElement("//div[@class='zephyr-editable-field-edit-mode']//button[@type='submit']").click();
			CommonUtil.normalWait(1000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(automationPathBox),"Automation path box not found");
			automationPathBox.click();
			CommonUtil.normalWait(2000);
			writeBox.clear();
			writeBox.sendKeys(path);
			CommonUtil.returnWebElement("//div[@class='zephyr-editable-field-edit-mode']//button[@type='submit']").click();
			CommonUtil.normalWait(2000);
			String verifyAutomatedXpath = "//div[@id='grid-table-tcr']//div[text()='"+tcName+"']//parent::div//parent::div//following-sibling::div//div[text()='A']";
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(CommonUtil.returnWebElement(verifyAutomatedXpath)), "Testcase is not changed to Automated");
		}
		catch (Exception e) {
			logger.info("Failed to change testcase from manual to automated");
			e.printStackTrace();
			return false;
		}
		finally {
			navigateBackToTestcaseList();
		}
		return true;
	}
	
	public boolean SelectTestcase(String tcName) {
		try {
			logger.info("Going to select testcase");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[text()='"+tcName+"']"), "Testcase not found");
			CommonUtil.returnWebElement("//div[text()='"+tcName+"']").click();
			logger.info("Testcase selected");
		}
		catch (Exception e) {
			logger.info("Failed to select testcase");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean launchGlobalTCCWindow(String releaseName) {
		try {
			
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + releaseName + "']";
			CommonUtil.returnWebElement(xpath).click();
			CommonUtil.normalWait(1000);
			logger.info("Node selected successfully.");
			releaseOptionsBtn.click();
			logger.info("Clicked on Node Options on the Release successfully.");

			Assert.assertTrue(navigateToReleaseOptions("Copy from Project Releases"), "Not clicked on 'Copy from Project Releases'.");
			logger.info("Clicked on 'Copy from Project Releases'");
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(2000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerCopyFromOtherProjects),"Header 'Copy from Project Releases' not found");
			logger.info("'Copy from Project Releases' window launched successfully");
			
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return false;
	}
	
	public boolean navigateToNodeInGlobalTCC(List<String> nodeList) {
		try {
			HomePage.getInstance().waitForProgressBarToComplete();
			for(String node : nodeList) {
				WebElement selectNode = CommonUtil.returnWebElement("//div[@class='global-tc']//a[@data-name='"+node+"']");
				selectNode.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(2000);
				String isExpanded = CommonUtil.returnWebElement("//div[@class='global-tc']//a[@data-name='"+node+"']/parent::li").getAttribute("aria-expanded");
				
				if(isExpanded!=null) {
					if(isExpanded.equals("true")) {
						logger.info("Node "+node+" is already expanded");
					}else {
						CommonUtil.doubleClick(selectNode);
						HomePage.getInstance().waitForProgressBarToComplete();
						CommonUtil.normalWait(2000);
					}
				}	
			}
				
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean navigateToLocalReleaseNodeInGlobalTCC(List<String> nodeList) {
		try {
			HomePage.getInstance().waitForProgressBarToComplete();
			for(String node : nodeList) {
				WebElement selectNode = CommonUtil.returnWebElement("//div[@id='zephyr-tree-localTree']//a[@data-name='"+node+"']");
				selectNode.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(2000);
				String isExpanded = CommonUtil.returnWebElement("//div[@id='zephyr-tree-localTree']//a[@data-name='"+node+"']/parent::li").getAttribute("aria-expanded");
				
				if(isExpanded!=null) {
					if(isExpanded.equals("true")) {
						logger.info("Node "+node+" is already expanded");
					}else {
						CommonUtil.doubleClick(selectNode);
						HomePage.getInstance().waitForProgressBarToComplete();
						CommonUtil.normalWait(2000);
					}
				}	
			}
				
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean DnDGlobalTestcaseToLocalRelease(String  localReleaseNodeName,String globalSelectedNodeNameOrNull, List<String> elseTestcaseNamesToDraged) {
		try {
			
			if(globalSelectedNodeNameOrNull!=null) {
				WebElement sourceNode = CommonUtil.returnWebElement("//div[@class='global-tc']//a[@data-name='"+globalSelectedNodeNameOrNull+"']");
				WebElement destNode = CommonUtil.returnWebElement("//div[@id='zephyr-tree-localTree']//a[@data-name='"+localReleaseNodeName+"']");
				
				Actions actions = CommonUtil.actionClass();
				Action action = actions.dragAndDrop(sourceNode, destNode).build();
				CommonUtil.normalWait(2000);
				action.perform();
				
			}else {
				
				for(String testName : elseTestcaseNamesToDraged) {
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-global']//div[@title='"+testName+"']//parent::div/parent::div/preceding-sibling::div[2]",5)
							, "testcase not found to select and drag by name: "+ testName);
					CommonUtil.returnWebElement("//div[@id='grid-table-global']//div[@title='"+testName+"']//parent::div/parent::div/preceding-sibling::div[2]")
					.click();
					CommonUtil.normalWait(2000);
				}
				WebElement sourceTestcase = CommonUtil.returnWebElement("//div[@id='grid-table-global']//div[@title='"+elseTestcaseNamesToDraged.get(0)+"']");
				WebElement destNode = CommonUtil.returnWebElement("//div[@id='zephyr-tree-localTree']//a[@data-name='"+localReleaseNodeName+"']");
				Actions actions = CommonUtil.actionClass();
				Action action = actions.dragAndDrop(sourceTestcase, destNode).build();
				CommonUtil.normalWait(2000);
				action.perform();
			}
			
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(2000);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		finally {
			if(CommonUtil.visibilityOfElementLocated(buttonCloseGlobalWindow,5)) {
				buttonCloseGlobalWindow.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(2000);
			}
			
			else {
				buttonCloseShareWindow.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(2000);
			}
		}
		return true;
	}
	

	
	public boolean verifyTestcaseVersion(int testcaseId, String versionNo) {
		CommonUtil.normalWait(1500);
		try {
			logger.info("Locating testcase version number...");
			String versionXpath = "//*[@id='grid-table-tcr']/div[2]/div/div[3]/div/div[text()='"+testcaseId+"']//parent::div//parent::div//following-sibling::div[7]/div/div";
			WebElement versionWb = CommonUtil.returnWebElement(versionXpath);
			logger.info("Found Version Number :"+ versionWb.getText());
			Assert.assertTrue(versionWb.getText().equals(versionNo), "Testcase version number does not match");
			logger.info("Verified testcase version number");
		}
		catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	
	public boolean verifyTestcaseVersion(String testcaseName, String versionNo) {
		CommonUtil.normalWait(1500);
		try {
			logger.info("Locating testcase version number...");
			String versionXpath = "//*[@id='grid-table-tcr']/div[2]/div/div[5]/div/div[text()='"+testcaseName+"']//parent::div//parent::div//following-sibling::div[5]/div/div";
			WebElement versionWb = CommonUtil.returnWebElement(versionXpath);
			logger.info("Found Version Number :"+ versionWb.getText());
			Assert.assertTrue(versionWb.getText().equals(versionNo), "Testcase version number does not match");
			logger.info("Verified testcase version number");
		}
		catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	
	
	public boolean clickonReqCoverageLink(String TcName) {
		CommonUtil.normalWait(1500);
		try {
			
			HomePage.getInstance().waitForProgressBarToComplete();
			mapReq.click();
			logger.info("Clicked on requirement coverage link.");
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//span[text()='"+TcName+"']"),"Not searching for mapped testcase");
			logger.info("Searched for mapped requirement");
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			BackToTestRepository.click();
			logger.info("Navigating back to test repository");
			
			}
		catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	
	//Project Repository Methods
	public boolean createProjectRepoPhase(String releaseName, String phaseName, String phaseDescription) {
		try {
			CommonUtil.normalWait(1000);
			
				String xpathForRelease = "//li[@data-parenttype='project_repo']/a[@data-name='"+releaseName+"']";
				CommonUtil.returnWebElement(xpathForRelease).click();
				CommonUtil.normalWait(1000);
				logger.info("Hovered on Project Repository successfully.");

				ProjectOptionsBtn.click();
				logger.info("Clicked on Node Options on the Project Test Repository successfully.");
				CommonUtil.normalWait(1000);
				Assert.assertTrue(navigateToReleaseOptions("Add Folder"), "Not clicked on Add Button.");
				logger.info("Clicked on Add Btn to create Phase");

				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(createPhaseDialogBox),
					"Create phase Dialog box not visible.");
				logger.info("Create phase Dialog box visible to create phase.");

				Assert.assertTrue(createPhaseDialogBoxHeader.getText().trim().equals("Add Folder"),
					"Create  phase dialog box header not validated.");
				logger.info("Create  phase dialog box header validated successsfully.");
			CommonUtil.normalWait(2000);
			addNodeNameTextBox.sendKeys(phaseName);
			logger.info("Phase name : " + phaseName + " given successfully to the text box successfully.");

			if (phaseDescription != null) {
				CommonUtil.normalWait(1000);
				addNodeDescriptionTextArea.sendKeys(phaseDescription);
				logger.info("Phase name : " + phaseDescription + " given successfully to the text area successfully.");
			}
			CommonUtil.normalWait(1000);
			tcrAddNodeModalSaveBtn.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(3000);
			logger.info("Clicked on the save button successfully.");

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return verifyProjectRepoPhase(phaseName, phaseDescription);

	}
	
	public boolean createProjectRepoNode(List<String> parentTee, String parentNodeName, String nodeName, String nodeDescription) {
		try {
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + parentNodeName + "']";
//			String xpath = "//*[@data-name = 'Release 1.0']/following-sibling::ul//*[@data-name = '" + parentNodeName + "']";
			;
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(xpath), "Node not found by name: " + parentNodeName);
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			CommonUtil.actionClass().moveToElement(we).build().perform();
			CommonUtil.normalWait(1000);
			logger.info("Hovered on Phase successfully.");

			ProjectOptionsBtn.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			logger.info("Clicked on Node Options on the Phase successfully.");

			Assert.assertTrue(navigateToReleaseOptions("Add Folder"), "Not clicked on Add Button.");
			logger.info("Clicked on Add Btn to create Phase");

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(createPhaseDialogBox),
					"Create Node Dialog box not visible.");
			logger.info("Create Node Dialog box visible to create phase.");

			Assert.assertTrue(createPhaseDialogBoxHeader.getText().trim().equals("Add Folder"),
					"Create  phase dialog box header not validated.");
			logger.info("Create  phase dialog box header validated successsfully.");
			CommonUtil.normalWait(1000);
			addNodeNameTextBox.sendKeys(nodeName);
			logger.info("Phase name : " + nodeName + " given successfully to the text box successfully.");
			CommonUtil.normalWait(1000);
			if (nodeDescription != null) {
				CommonUtil.normalWait(1000);
				addNodeDescriptionTextArea.sendKeys(nodeDescription);
				logger.info("Node name : " + nodeDescription + " given successfully to the text area successfully.");
			}
			CommonUtil.normalWait(1000);
			tcrAddNodeModalSaveBtn.click();
			logger.info("Clicked on the save button successfully.");
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(3000);

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return verifyNode(parentTee,parentNodeName, nodeName, nodeDescription);
	}
	
	public String addDefaultTestcaseProjectRepo(String nodeName) {
		String testcaseId = null;
		try {
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + nodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			logger.info("Node selected successfully.");

			int sizeOfTestcasesBefore=0;
			
			WebElement we2;
			try {
				we2 = Driver.driver.findElement(By.xpath("//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div"));
				if(we2!=null){
					if(we2.isDisplayed()) {
						sizeOfTestcasesBefore = CommonUtil
								.returnSizeOfElements("//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div");
						logger.info("Size of elements before : " + sizeOfTestcasesBefore);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			logger.info("Creating default testcase.");
			CommonUtil.normalWait(1000);
			addTestcaseBtn.click();
			//Assert.assertTrue(verifySuccessPopup("add"), "Not verified success popup.");
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(2000);
			logger.info("Clickeed on Add testcase btn.");

			logger.info("Added default testcase successfully.");

			int sizeOfTestcasesAfter = CommonUtil
					.returnSizeOfElements("//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div");
			logger.info("Size of elements after : " + sizeOfTestcasesAfter);

			Assert.assertTrue(sizeOfTestcasesBefore + 1 == sizeOfTestcasesAfter, "Testcase size not increased.");
			logger.info("Test case size verified Successfully.");

			testcaseId = verifyDefaultTestcaseProjectRepo(sizeOfTestcasesAfter);
			logger.info("Testcase Id : " + testcaseId);
			Assert.assertTrue(testcaseId != null, "Testcase not created.");
			logger.info("Testcase created and verified Successfully.");
			CommonUtil.normalWait(2000);
			verifyTestcaseVersionProjectRepo(Integer.parseInt(testcaseId),"1");
		} catch (Exception e) {
			e.printStackTrace();
			return testcaseId;
		}
		return testcaseId;

	}
	
	public boolean verifyProjectRepoPhase(String phaseName, String phaseDescription) {
		try {
			CommonUtil.normalWait(1000);
	//		CommonUtil.doubleClick(projectRepoInTestRepository);
			// CommonUtil.actionClass().moveToElement(releasesInTestRepository).doubleClick().build().perform();
			logger.info("Waiting for the phasees.");
			CommonUtil.visibilityOfElementLocated("//li[@data-parenttype='project_repo']//a[@data-type='Phase']");
			logger.info("Expanded the release successfully and verifing the phases.");

			for (Iterator iterator = listOfPhases.iterator(); iterator.hasNext();) {
				WebElement webElement = (WebElement) iterator.next();
				// logger.info(webElement.getText());
				if (webElement.getText().trim().equals(phaseName)) {

					logger.info(phaseName + " verified successfully.");
					// webElement.click();
					if (phaseDescription != null) {
						String desc = webElement.getAttribute("data-desc");
						Assert.assertEquals(desc, phaseDescription, "Phase Description not verified.");
						logger.info("Phase description verified successfully.");
					}
					break;
				}
			}

//			CommonUtil.normalWait(1000);
//			CommonUtil.doubleClick(releasesInTestRepository);
			logger.info("Phase verified successfully.");

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;

	}

	public boolean verifyProjectNode(List<String> parentTree, String parentNodename, String nodeName, String nodeDescription) {
		boolean verifyFlag = false;
		try {
			CommonUtil.normalWait(1000);
			
			
			if(!CommonUtil.visibilityOfElementLocated("//*[@data-name = '" + parentNodename + "']", 5)) {
			CommonUtil.browserRefresh();
			CommonUtil.normalWait(3000);
				HomePage.getInstance().waitForProgressBarToComplete();
				if(parentTree!=null) {
					navigateToNodes(parentTree);
				}	
			}
			
			String xpath = "//*[@data-name = '" + parentNodename + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);

			
			CommonUtil.normalWait(1000);
			// CommonUtil.actionClass().moveToElement(releasesInTestRepository).doubleClick().build().perform();
			logger.info("Waiting for the phasees.");
			boolean flag = CommonUtil.visibilityOfElementLocated("//a[@data-name='" + parentNodename + "']/following-sibling::ul/li",5);
			if(flag){
				logger.info("Expanded the release successfully and verifing the nodes.");
			}else{
				CommonUtil.doubleClick(we);
				if(!CommonUtil.visibilityOfElementLocated("//a[@data-name='" + parentNodename + "']/following-sibling::ul/li", 5)) {
					CommonUtil.browserRefresh();
					CommonUtil.normalWait(3000);
					HomePage.getInstance().waitForProgressBarToComplete();
					if(parentTree!=null) {
						navigateToNodes(parentTree);
						boolean flag1 = CommonUtil.visibilityOfElementLocated("//a[@data-name='" + parentNodename + "']/following-sibling::ul/li",5);
						if(flag1){
							logger.info("Expanded the release successfully and verifing the nodes.");
						}else {
							CommonUtil.doubleClick(we);
						}
					}	
				}
			}
			List<WebElement> list = CommonUtil.returnWebElements("//a[@data-name='" + parentNodename + "']/following-sibling::ul/li/a");

			for (Iterator iterator = list.iterator(); iterator.hasNext();) {
				WebElement webElement = (WebElement) iterator.next();
				 logger.info(webElement.getText());
				if (webElement.getText().trim().equals(nodeName)) {

					logger.info(nodeName + " verified successfully.");
					verifyFlag = true;
					// webElement.click();
					if (nodeDescription != null) {
						String desc = webElement.getAttribute("data-desc");
						Assert.assertEquals(desc, nodeDescription, "Phase Description not verified.");
						logger.info("Phase description verified successfully.");
					}
					break;
				}
			}

			CommonUtil.normalWait(1000);
			CommonUtil.doubleClick(we);
			CommonUtil.normalWait(500);
			logger.info("Node verified successfully.");

		} catch (Exception e) {
			e.printStackTrace();
			return verifyFlag;
		}
		return verifyFlag;

	}
	
	public boolean verifyTestcaseVersionProjectRepo(int testcaseId, String versionNo) {
		CommonUtil.normalWait(1500);
		try {
			logger.info("Locating testcase version number...");
			String versionXpath = "//*[@id='grid-table-tcr_global_project']/div[2]/div/div[3]/div/div[text()='"+testcaseId+"']//parent::div//parent::div//following-sibling::div[7]/div/div";
			WebElement versionWb = CommonUtil.returnWebElement(versionXpath);
			logger.info("Found Version Number :"+ versionWb.getText());
			Assert.assertTrue(versionWb.getText().equals(versionNo), "Testcase version number does not match");
			logger.info("Verified testcase version number");
		}
		catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean verifyTestcaseVersionProjectRepo(String testcaseName, String versionNo) {
		CommonUtil.normalWait(1500);
		try {
			logger.info("Locating testcase version number...");
			String versionXpath = "//*[@id='grid-table-tcr_global_project']/div[2]/div/div[5]/div/div[text()='"+testcaseName+"']//parent::div//parent::div//following-sibling::div[5]/div/div";
			WebElement versionWb = CommonUtil.returnWebElement(versionXpath);
			logger.info("Found Version Number :"+ versionWb.getText());
			Assert.assertTrue(versionWb.getText().equals(versionNo), "Testcase version number does not match");
			logger.info("Verified testcase version number");
		}
		catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean modifyTestcaseProjectRepo(Map<String, String> values) {
		try {
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + values.get("NODE_NAME") + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(4000);
			logger.info("Node selected successfully.");

			int sizeOfTestcasesBefore = CommonUtil
					.returnSizeOfElements("//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div");
			logger.info("Size of elements before : " + sizeOfTestcasesBefore);
			logger.info("Modifing default testcase.");
			String xpathForTestcaseName = "//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div/div[@data-col-index='2']//div[text()='"+ values.get("TESTCASE_ID") + "']//parent::div//parent::div//following-sibling::div//div//div[@class='name-as-link']"; 
			WebElement selectTestcase = CommonUtil.returnWebElement(xpathForTestcaseName);
			selectTestcase.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			logger.info("Clicked on the testcase Name for modification.");
			CommonUtil.normalWait(3000);
			if (values.containsKey("TESTCASE_SUMMARY")) {
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.scrollToWebElementAndView(testcaseSummaryElement);
				CommonUtil.normalWait(2000);
				CommonUtil.scrollToWebElementAndView(testcaseSummaryElement);
				CommonUtil.normalWait(1000);
				testcaseSummaryElement.click();
				CommonUtil.normalWait(2000);
				CommonUtil.visibilityOfElementLocated(testcaseSummaryEditTextBox);
				testcaseSummaryEditTextBox.clear();
				logger.info("Testcase Summary Cleared successfully.");
				CommonUtil.normalWait(2000);
				testcaseSummaryEditTextBox.sendKeys(values.get("TESTCASE_SUMMARY"));
				logger.info("Testcase Summary provided to the testcase sussessfully, Summary is : "
						+ values.get("TESTCASE_SUMMARY"));
				CommonUtil.normalWait(2000);
				testcaseSummarySubmitBtn.click();
				logger.info("Testcase Summary Submitted successfully.");
				CommonUtil.normalWait(5000);
			}
			if (values.containsKey("TESTCASE_DESC")) {
				HomePage.getInstance().waitForProgressBarToComplete();			
				CommonUtil.switchiframe("testcase_description_ifr",values.get("TESTCASE_DESC"));
				logger.info("Testcase Description Cleared successfully.");
				logger.info("Testcase Deescription provided to the testcase sussessfully, Deescription is : "
						+ values.get("TESTCASE_DESC"));
				topLink.click();
				CommonUtil.normalWait(3000);
				topLink.click();
				logger.info("Testcase Deescription Submitted successfully.");
				CommonUtil.normalWait(4000);
			}
			
			if(values.containsKey("Priority")){
				CommonUtil.normalWait(1000);
				HomePage.getInstance().waitForProgressBarToComplete();
				elementPriority.click();
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//span[@class='select2-results']/ul/li[text()='"+values.get("Priority")+"']"), "failed to select Priority: "+values.get("Priority"));
				CommonUtil.normalWait(1000);
				CommonUtil.returnWebElement("//span[@class='select2-results']/ul/li[text()='"+values.get("Priority")+"']").click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(3000);
			}
			
			if(values.containsKey("ALT_ID")){
				CommonUtil.normalWait(1000);
				HomePage.getInstance().waitForProgressBarToComplete();
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(elementAltID),"AltID field not found");
				elementAltID.click();
				CommonUtil.normalWait(2000);
				textBoxAltID.sendKeys(values.get("ALT_ID"));
				CommonUtil.normalWait(2000);
				buttonSubmitAltId.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(2000);
			}
			
			if(values.containsKey("Comment")){
				CommonUtil.normalWait(1000);
				HomePage.getInstance().waitForProgressBarToComplete();
				elementEnterComment.click();
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textAreaComment), "Failed to add comment, Comment textarea not found");
				CommonUtil.normalWait(1000);
				textAreaComment.clear();
				CommonUtil.normalWait(1000);
				textAreaComment.sendKeys(values.get("Comment"));
				CommonUtil.normalWait(2000);
				buttonSubmitComment.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(2000);
			}
			
			
			if (values.containsKey("TESTCASE_ATTACHMENT")) {
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
				testcaseAttachmentTitle.click();
				logger.info("Uploading Attachment To Testcase, Attachment : "+values.get("TESTCASE_ATTACHMENT"));
				CommonUtil.normalWait(1000);
				File file = new File(values.get("TESTCASE_ATTACHMENT"));
				System.out.println(file.getAbsolutePath());
				testcaseUploadLink.sendKeys(file.getAbsolutePath());
				logger.info("Testcase Uploaded successfully, Attachment is : "
						+ values.get("TESTCASE_ATTACHMENT"));
				CommonUtil.normalWait(3000);
//				Assert.assertTrue(verifyAttachments(values.get("TESTCASE_ATTACHMENT")), "Testcase Attachment not verified.");
//				logger.info("Attachments verified successfully.");
			}
			if (values.containsKey("TESTCASE_STEPS")) {
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
				testcaseStepHeader.click();
				CommonUtil.normalWait(1000);
				logger.info("Adding Teststeps To Testcase, Teststeps : "+values.get("TESTCASE_STEPS"));
				CommonUtil.normalWait(2000);
//				JSONObject steps = new JSONObject(values.get("teststeps"));
				JSONArray stepArray = new JSONArray(values.get("TESTCASE_STEPS"));
				for (int i = 0; i < stepArray.length(); i++) {
					JSONObject stepDetails = (JSONObject) stepArray.get(i);
					String step = (String) stepDetails.get("step");
					String data = (String) stepDetails.get("data");
					String result = (String) stepDetails.get("result");
					CommonUtil.normalWait(2000);
					stepInTestcase.sendKeys(step);
					CommonUtil.normalWait(2000);
					dataInTestcase.sendKeys(data);
					CommonUtil.normalWait(2000);
					stepresInTestcase.sendKeys(result);
					CommonUtil.normalWait(2000);
					plusBtnInStepSection.click();
					CommonUtil.normalWait(2000);
					logger.info("Clicked on Add button successfully.");
				
				}
				
				if(values.containsKey("TESTCASE_STEPS_CANCEL") && values.get("TESTCASE_STEPS_CANCEL").equals("true")){
//					cancelBtnInStepSection.click();
					CommonUtil.actionClass().sendKeys(Keys.ESCAPE).perform();
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.normalWait(2000);
				}else{
//					saveBtnInStepSection.click();
					CommonUtil.actionClass().sendKeys(Keys.TAB).perform();
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.normalWait(2000);
				}
				CommonUtil.normalWait(2000);
				logger.info("Testcase saved successfully.");
			}
			CommonUtil.normalWait(1000);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		finally {
			CommonUtil.normalWait(2000);
			backToTcList.click();
			CommonUtil.normalWait(1000);
		}
		return true;

	}
	
	public boolean cloneTestcaseProjectRepo(String nodeName,String testcaseName,String stepstatus){
		boolean clonestatus = false;
		try {
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + nodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(2000);
			logger.info("Node selected successfully.");

			int sizeOfTestcasesBefore = CommonUtil
					.returnSizeOfElements("//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div");
			logger.info("Size of elements before : " + sizeOfTestcasesBefore);
			String actualTestcaseId=StringUtils.EMPTY;

			if(sizeOfTestcasesBefore>0){
				logger.info("Test case count::"+sizeOfTestcasesBefore);
				
				
				//String clonetestcaseString = "//*[@id='grid-table-tcr']/div[@class='grid-content']/div["+cloneTestCaseGridNum+"]/div[@data-col-index='0']//input";
				String clonetestcaseString = "//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']//div[text()='"+testcaseName+"']/parent::div/parent::div/preceding-sibling::div[4]//input[@name='testcase_select']";
				
				String xpathactualTestcaseId = "//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div//div[@data-col-index='4']//div[text()='"+testcaseName+"']/parent::div/parent::div/preceding-sibling::div[2]//div[@title]";
				 actualTestcaseId = CommonUtil.getText(xpathactualTestcaseId);
				
				CommonUtil.normalWait(2000);
				WebElement web = CommonUtil.returnWebElement(clonetestcaseString);
				web.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(4000);
				buttonClone.click();
				HomePage.getInstance().closeToastPopup();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(3000);
				web.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(2000);
				int sizeOfTestcasesAfter = CommonUtil
						.returnSizeOfElements("//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div");
				
				logger.info("Size of elements after : " + sizeOfTestcasesAfter);

				Assert.assertTrue(sizeOfTestcasesBefore + 1 == sizeOfTestcasesAfter, "Testcase size not increased (clone).");
				logger.info("Test case size verified Successfully (clone).");
				
				if(StringUtils.equalsIgnoreCase(stepstatus, "withoutsteps")){
					//verifying test cases with no steps 
					clonestatus = verifyClonedTestcaseNameProjectRepo(testcaseName,sizeOfTestcasesAfter);
					logger.info("clone status  : " + clonestatus);
					Assert.assertTrue(clonestatus, "Test cases with no steps not cloned.");
					logger.info(" Test cases with no steps cloned Successfully.");
					String xpathForClonedTestcaseid = "//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div[" + sizeOfTestcasesAfter
							+ "]/div[@data-col-index='2']";
					String clonedTestcaseId = CommonUtil.getText(xpathForClonedTestcaseid);
					verifyTestcaseVersionProjectRepo(Integer.parseInt(clonedTestcaseId),"1");
				}else if(StringUtils.equalsIgnoreCase(stepstatus, "withsteps")){
					//verifying test cases with steps 
					boolean cloneNameStatus=false;
					cloneNameStatus = verifyClonedTestcaseNameProjectRepo(testcaseName,sizeOfTestcasesAfter);
					Assert.assertTrue(cloneNameStatus, "Test cases with steps not cloned.");
					String xpathForClonedTestcaseid = "//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div[" + sizeOfTestcasesAfter
							+ "]/div[@data-col-index='2']";
					String clonedTestcaseId = CommonUtil.getText(xpathForClonedTestcaseid);
					logger.info("clonedTestcaseId::"+clonedTestcaseId);
					clonestatus = vefifyTestSteps(actualTestcaseId,clonedTestcaseId);
					Assert.assertTrue(clonestatus, "Test cases with steps not cloned.");
					logger.info("clone status  : " + clonestatus);
					//Assert.assertTrue(clonestatus == true, "Test cases with steps not cloned.");
					logger.info(" Test cases with  steps cloned Successfully.");
					verifyTestcaseVersionProjectRepo(Integer.parseInt(clonedTestcaseId),"1");
				}
				CommonUtil.normalWait(3000);
				
			}else{
				logger.info("No test cases : test case count::"+sizeOfTestcasesBefore);
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			return clonestatus;
		}
		return clonestatus;
	}
	
	public boolean verifyClonedTestcaseNameProjectRepo(String actualTcName ,int clonedTcnum){
		boolean clonedStaus = false;
		try {
			CommonUtil.normalWait(2000);
			String xpathForClonedTestcaseName = "//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div[" + clonedTcnum
					+ "]/div[@data-col-index='4']";
			String clonedTestcaseName = CommonUtil.getText(xpathForClonedTestcaseName);
			
			Assert.assertTrue(actualTcName.equals(clonedTestcaseName), "Cloned Testcase  name verification failed.");
			clonedStaus = true;
			logger.info("Cloned Testcase  name verified successful, Name is : " + clonedTestcaseName);
			
			
		} catch (Exception e) {
			e.printStackTrace();
			return clonedStaus;
		}
		return clonedStaus;
	}
	
	public String getTestcaseProjectRepo(String nodeName){
		String testcaseId = null;
		try {
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + nodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			CommonUtil.normalWait(3000);
			logger.info("Node selected successfully.");

			int sizeOfTestcasesBefore = CommonUtil
					.returnSizeOfElements("//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div");
			logger.info("Size of elements before : " + sizeOfTestcasesBefore);
			String xpathForClonedTestcaseid = "//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div[" + sizeOfTestcasesBefore
					+ "]/div[@data-col-index='2']";
			testcaseId = CommonUtil.getText(xpathForClonedTestcaseid);
			
			logger.info("Testcase Id : " + testcaseId);
		} catch (Exception e) {
			e.printStackTrace();
			return testcaseId;
		}
		return testcaseId;
	}
	
	public String getTestcaseProjectRepo(String nodeName, String testcaseName){
		String tcName = null;
		try{
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + nodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			CommonUtil.normalWait(1000);
			logger.info("Node selected successfully.");
			String xpathForTestcase = "//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']//div[@data-col-index='3']//div[contains(text(),'"+testcaseName+"')]";
			tcName = CommonUtil.getText(xpathForTestcase);
			logger.info("Testcase Name is : " +tcName);
		}catch(Exception e){
			e.printStackTrace();
			return tcName;
		}
		return tcName;
	}
	
	public boolean deleteTestcaseProjectRepo(String nodeName, int testcaseId) {
		try {
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + nodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			CommonUtil.normalWait(1000);
			logger.info("Node selected successfully.");

			int sizeOfTestcasesBefore = CommonUtil
					.returnSizeOfElements("//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div");
			logger.info("Size of elements before : " + sizeOfTestcasesBefore);
			logger.info("Creating default testcase.");

			String xpathForTestcaseId = "//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div/div[@data-col-index='2']//div[text()='"+testcaseId+"']";
			WebElement selectTestcase = CommonUtil.returnWebElement(xpathForTestcaseId);
			selectTestcase.click();
			logger.info("Clicked on the testcase Id for Deletion.");
			CommonUtil.normalWait(3000);
			
			String xpathForTestcaseCheckBox = "//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div[div[@data-col-index='2']//div[text()='"+testcaseId+"']]//input[@name='testcase_select']";
			CommonUtil.returnWebElement(xpathForTestcaseCheckBox).click();
			CommonUtil.normalWait(1000);
			logger.info("Selected the checkbox for Deletion.");
			deleteTestcaseBtn.click();
			logger.info("Clicked on the Delete btn for Deletion.");
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(deleteTestcaseModalPopup), "Not Found Delete Modal Confirmation Popup.");
			logger.info("Found Delete Modal Confirmation Popup and now continuing with delete.");
			
			Assert.assertTrue(deleteTestcaseModalPopupHeader.getText().equals("Delete"), "Delete Modal popup header text not verified.");
			logger.info("Delete Modal popup header text verified successfully.");
			
			Assert.assertTrue(deleteTestcaseModalPopupBodyConfirmationText.getText().equals("Continue with deleting testcase(s)?"), "Delete Modal popup Body text not verified.");
			logger.info("Delete Modal popup Body text verified successfully.");
			
			deleteTestcaseModalPopupDeleteBtn.click();
			logger.info("Clicked on Delete Modal popup Delete Button successfully.");
			
			CommonUtil.normalWait(1000);
	
			logger.info("Testcase Deleted and verified Successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean deleteTestcaseProjectRepo(String nodeName, String testcaseName) {
		try {
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + nodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			CommonUtil.normalWait(1000);
			logger.info("Node selected successfully.");

			int sizeOfTestcasesBefore = CommonUtil
					.returnSizeOfElements("//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div");
			logger.info("Size of elements before : " + sizeOfTestcasesBefore);
			logger.info("Creating default testcase.");

			String xpathForTestcaseId = "//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div/div[@data-col-index='4']//div[text()='"+testcaseName+"']";
			WebElement selectTestcase = CommonUtil.returnWebElement(xpathForTestcaseId);
			CommonUtil.moveToElement(selectTestcase);
			logger.info("Clicked on the testcase Id for Deletion.");
			CommonUtil.normalWait(3000);
			
			String xpathForTestcaseCheckBox = "//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div[div[@data-col-index='4']//div[text()='"+testcaseName+"']]//input[@name='testcase_select']";
			CommonUtil.returnWebElement(xpathForTestcaseCheckBox).click();
			CommonUtil.normalWait(1000);
			logger.info("Selected the checkbox for Deletion.");
			deleteTestcaseBtn.click();
			logger.info("Clicked on the Delete btn for Deletion.");
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(deleteTestcaseModalPopup), "Not Found Delete Modal Confirmation Popup.");
			logger.info("Found Delete Modal Confirmation Popup and now continuing with delete.");
			
			Assert.assertTrue(deleteTestcaseModalPopupHeader.getText().equals("Delete"), "Delete Modal popup header text not verified.");
			logger.info("Delete Modal popup header text verified successfully.");
			
			Assert.assertTrue(deleteTestcaseModalPopupBodyConfirmationText.getText().equals("Continue with deleting testcase(s)?"), "Delete Modal popup Body text not verified.");
			logger.info("Delete Modal popup Body text verified successfully.");
			
			deleteTestcaseModalPopupDeleteBtn.click();
			logger.info("Clicked on Delete Modal popup Delete Button successfully.");
			
			CommonUtil.normalWait(1000);
			logger.info("Testcase Deleted and verified Successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
		}
	
	public boolean deleteTestcaseProjectRepo(String nodeName, List<String> testcaseId) {
		try {
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + nodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			CommonUtil.normalWait(1000);
			logger.info("Node selected successfully.");

			int sizeOfTestcasesBefore = CommonUtil
					.returnSizeOfElements("//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div");
			logger.info("Size of elements before : " + sizeOfTestcasesBefore);
			logger.info("Creating default testcase.");
				
			List<Integer> listOfInt = new ArrayList<>();
			for (String str : testcaseId) {
			listOfInt.add(Integer.parseInt(str));
			}
			
			for (int i = 0; i < listOfInt.size();i++) 
				{
					String xpathForTestcaseId = "//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div/div[@data-col-index='2']//div[text()='"+listOfInt.get(i)+"']";
					WebElement selectTestcase = CommonUtil.returnWebElement(xpathForTestcaseId);
					selectTestcase.click();
					logger.info("Clicked on the testcase Id for Deletion.");
					CommonUtil.normalWait(3000);
					
					String xpathForTestcaseCheckBox = "//*[@id='grid-table-tcr_global_project']/div[@class='grid-content']/div[div[@data-col-index='2']//div[text()='"+listOfInt.get(i)+"']]//input[@name='testcase_select']";
					CommonUtil.returnWebElement(xpathForTestcaseCheckBox).click();
					CommonUtil.normalWait(1000);
					logger.info("Selected the checkbox for Deletion.");
			}
		
			
			deleteTestcaseBtn.click();
			logger.info("Clicked on the Delete btn for Deletion.");
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(deleteTestcaseModalPopup), "Not Found Delete Modal Confirmation Popup.");
			logger.info("Found Delete Modal Confirmation Popup and now continuing with delete.");
			
			Assert.assertTrue(deleteTestcaseModalPopupHeader.getText().equals("Delete"), "Delete Modal popup header text not verified.");
			logger.info("Delete Modal popup header text verified successfully.");
			
			Assert.assertTrue(deleteTestcaseModalPopupBodyConfirmationText.getText().equals("Continue with deleting testcase(s)?"), "Delete Modal popup Body text not verified.");
			logger.info("Delete Modal popup Body text verified successfully.");
			
			deleteTestcaseModalPopupDeleteBtn.click();
			logger.info("Clicked on Delete Modal popup Delete Button successfully.");
			
			CommonUtil.normalWait(1000);
	
			logger.info("Testcase Deleted and verified Successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean deleteNodeProjectRepo(String deleteNodeName) {
		try {
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + deleteNodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			CommonUtil.normalWait(2000);
			CommonUtil.actionClass().moveToElement(we).build().perform();
			CommonUtil.normalWait(2000);
			logger.info("Hovered on Phase successfully.");

			ProjectOptionsBtn.click();
			logger.info("Clicked on Node Options on the Phase successfully.");

			Assert.assertTrue(navigateToReleaseOptions("Delete"), "Not clicked on Add Button.");
			logger.info("Clicked on Delete Btn to Delete Node");

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(deleteNodeDialogBox),
					"Delete Node Dialog box not visible.");
			logger.info("Delete Node Dialog box visible to Delete Node.");

			Assert.assertTrue(deleteNodeDialogBoxHeader.getText().trim().equals("Delete Folder"),
					"Delete  phase dialog box header not validated.");
			logger.info("Delete Node dialog box header validated successsfully.");
			CommonUtil.normalWait(3000);
			tcrDeleteNodeModalSaveBtn.click();
			logger.info("Clicked on the Delete button successfully.");
			CommonUtil.normalWait(3000);

			//Assert.assertTrue(verifySuccessPopup("delete"), "Not verified success popup.");

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;

	}

	
	public boolean exportSelectedNodeOfTCCProjectRepo(String nodeName, String reportType, String outputAs){
		try{
			logger.info("Going to launch Export Window");
			CommonUtil.normalWait(1000);
			WebElement we = CommonUtil.returnWebElement("//*[@data-name = '" + nodeName + "']");
			we.click();
			CommonUtil.normalWait(1000);
			CommonUtil.actionClass().moveToElement(we).build().perform();

			logger.info("Hovered on Phase successfully.");

			ProjectOptionsBtn.click();
			logger.info("Clicked on Node Options on the Phase successfully.");

			Assert.assertTrue(navigateToReleaseOptions("Export Tests"), "Not clicked on Export Tests.");
			logger.info("Clicked on Export Tests");
			
			CommonUtil.normalWait(5000);
			
			if(reportType.equalsIgnoreCase("Excel")){
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDataExcel), "Excel export not found in Export window");
				CommonUtil.scrollToWebElement(radioButtonDataExcel);
				radioButtonDataExcel.click();
					
			}else{
				if(reportType.equalsIgnoreCase("Summary")){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonSummary), "Summary export not found in Export window");
					CommonUtil.scrollToWebElement(radioButtonSummary);
					radioButtonSummary.click();
					
				}else{
					if(reportType.equalsIgnoreCase("Detailed")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDetailed), "Detailed export not found in Export window");
						CommonUtil.scrollToWebElement(radioButtonDetailed);
						radioButtonDetailed.click();
					}
				}
				CommonUtil.normalWait(1000);
				if(outputAs.equalsIgnoreCase("HTML")){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonHtml), "HTML type not found in Export window");
					radioButtonHtml.click();
				}else{
					if(outputAs.equalsIgnoreCase("PDF")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonPdf), "PDF type not found in Export window");
						radioButtonPdf.click();
					}else{
						if(outputAs.equalsIgnoreCase("Word")){
							Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonWord), "Word type not found in Export window");
							radioButtonWord.click();
						}
					}
				}
				
			}
			CommonUtil.normalWait(1000);
			buttonSaveExport.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerDownloadFileInPopup), "Header Download File not found");
			buttonDownload.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(10000);
			
		}catch(Exception e){
			logger.info("Failed to export node successfully");
			e.printStackTrace();
			return false;
		}
		return true;
		
	}
	
	public boolean verifyTestcasesInSelectedNodeOfTestRepositoryProjectRepo(List<String> testcasesNames) {
		try {
			
			for(String testcaseName: testcasesNames) {
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-tcr_global_project']//div[text()='"+testcaseName+"']"), "Testcase not found by name: "+ testcaseName);
			}
			
		}catch (Exception e) {
			logger.info("Failed to verify testcases successfully");
			e.printStackTrace();
		}
		return true;
	}
	
	public boolean dndsharenodeToRelease(String sourceNodeSelection, String destinationNode, boolean dragWithControl)
	{
		try {
			WebElement sourceNode = CommonUtil.returnWebElement("//li[@data-parenttype='project_repo']//ul//a[contains(@data-name,'"+sourceNodeSelection+"')]");
			WebElement destNode = CommonUtil.returnWebElement("//a[@data-name='"+destinationNode+"']");
			Actions actions = CommonUtil.actionClass();
			if(dragWithControl) {
				Action action = actions.clickAndHold(sourceNode).moveToElement(destNode).keyDown(Keys.CONTROL).release().build();
				CommonUtil.normalWait(1000);
				action.perform();
			}else {
				Action action = actions.dragAndDrop(sourceNode, destNode).build();
				CommonUtil.normalWait(1000);
				action.perform();
			}
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			
			
		}catch(Exception e) {
			logger.info("Fail to share the node to Release from Project");
			e.printStackTrace();
		}
		return true;
	}
	
	public boolean dndsharenodeToProjectRepo(String sourceNodeSelection, String destinationNode, boolean dragWithControl)
	{
		try {
			WebElement sourceNode = CommonUtil.returnWebElement("//li[@data-parenttype='release']//ul//a[contains(@data-name,'"+sourceNodeSelection+"')]");
			WebElement destNode = CommonUtil.returnWebElement("//a[@data-name='"+destinationNode+"']");
			Actions actions = CommonUtil.actionClass();
			if(dragWithControl) {
				Action action = actions.clickAndHold(sourceNode).moveToElement(destNode).keyDown(Keys.CONTROL).release().build();
				CommonUtil.normalWait(1000);
				action.perform();
			}else {
				Action action = actions.dragAndDrop(sourceNode, destNode).build();
				CommonUtil.normalWait(1000);
				action.perform();
			}
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			
			
		}catch(Exception e) {
			logger.info("Fail to share the node to Release from Project");
			e.printStackTrace();
		}
		return true;
	}
	public boolean navigateToNodesProjectRepo(List<String> nodeList) {
		boolean flag = false;
		try {
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);

			for (int i = 0; i < nodeList.size(); i++) {
				
				if(!CommonUtil.visibilityOfElementLocated("//*[*[@data-name='" + nodeList.get(i) + "']]",5)) {
				//	CommonUtil.browserRefresh();
					CommonUtil.normalWait(3000);
					HomePage.getInstance().waitForProgressBarToComplete();
				}
				
				String x = CommonUtil.returnWebElement("//*[*[@data-name='" + nodeList.get(i) + "']]").getAttribute("aria-expanded");
				if(x!=null) {
					if(x.equals("true")){
						logger.info("Node is already in Open state.");
						WebElement we = CommonUtil.returnWebElement("//*[@data-name='" + nodeList.get(i) + "']");
						we.click();
						HomePage.getInstance().waitForProgressBarToComplete();
					}else{
						CommonUtil.normalWait(2000);
						WebElement we = CommonUtil.returnWebElement("//*[@data-name='" + nodeList.get(i) + "']");
						CommonUtil.doubleClick(we);
						HomePage.getInstance().waitForProgressBarToComplete();
						CommonUtil.normalWait(4000);
						logger.info("Waiting for the phases.");
						CommonUtil.visibilityOfElementLocated("//li[@data-parenttype='project_repo']//a[@data-name='"
								+ nodeList.get(i) + "']/following-sibling::ul/li",5);
						logger.info("Expanded the release successfully and Child nodes are visible now.");
					}
				}else {
					WebElement we = CommonUtil.returnWebElement("//li[@data-parenttype='project_repo']//a[@data-name='" + nodeList.get(i) + "']");
					we.click();
					HomePage.getInstance().waitForProgressBarToComplete();
				}
				
				
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return flag;
		}
		return flag;
	}
	public boolean launchShareTCCWindowProjectRepo(String releaseName) {
		try {
			
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + releaseName + "']";
			CommonUtil.returnWebElement(xpath).click();
			CommonUtil.normalWait(1000);
			logger.info("Node selected successfully.");
			ProjectOptionsBtn.click();
			logger.info("Clicked on Node Options on the Release successfully.");

			Assert.assertTrue(navigateToReleaseOptions("Share from Project Releases"), "Not clicked on 'Share from Project Releases'.");
			logger.info("Clicked on 'Share from Project Releases'");
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(2000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerShareFromOtherProjects),"Header 'Share from Project Releases' not found");
			logger.info("'SHare from Project Releases' window launched successfully");
			
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return false;
	}
	
	public boolean VerifyToReleaseOptionsNotpresent(String optionsName, String nodeName) {
	
		CommonUtil.normalWait(1000);
		String xpath = "//*[@data-name = '" + nodeName + "']";
		System.out.println(xpath);
		WebElement we = CommonUtil.returnWebElement(xpath);
		we.click();
		CommonUtil.normalWait(2000);
		CommonUtil.actionClass().moveToElement(we).build().perform();
		CommonUtil.normalWait(2000);
		logger.info("Hovered on Node successfully.");

		releaseOptionsBtn.click();
		logger.info("Clicked on Node Options on the Phase successfully.");
	
		CommonUtil.normalWait(2000);
		
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(nodeOptionsMenu,5),
					"Release node options menu's are not visible.");
			logger.info("Release node options menu's are visible.");
			List<String> optionName1= new ArrayList<String>();
			for (Iterator iterator = releaseOptionsLink.iterator(); iterator.hasNext();) {
				WebElement webElement = (WebElement) iterator.next();
				logger.info(webElement.getText());
				optionName1.add(webElement.getText());
			}
			
			
			for (int i = 0; i < optionName1.size();i++) {
				String option2 = optionName1.get(i).trim();
				System.out.println("************" +option2 +"********");
				logger.info("Option is not present");
				Assert.assertTrue(!optionsName.equals(option2), "Option is Present");
				}
			
		
return true;
	}
	
public boolean copyPasteSteps(Map<String, String> values) {
	try {
	HomePage.getInstance().waitForProgressBarToComplete();
	CommonUtil.normalWait(1000);
	String xpath = "//*[@data-name = '" + values.get("NODE_NAME") + "']";
	WebElement we = CommonUtil.returnWebElement(xpath);
	we.click();
	HomePage.getInstance().waitForProgressBarToComplete();
	CommonUtil.normalWait(4000);
	logger.info("Node selected successfully.");

	int sizeOfTestcasesBefore = CommonUtil
			.returnSizeOfElements("//*[@id='grid-table-tcr']/div[@class='grid-content']/div");
	logger.info("Size of elements before : " + sizeOfTestcasesBefore);
	logger.info("Modifing default testcase.");

//	String xpathForTestcaseId = "//*[@id='grid-table-tcr']/div[@class='grid-content']/div/div[@data-col-index='2']//div[text()='"+ values.get("TESTCASE_ID") + "']";
	String xpathForTestcaseName = "//*[@id='grid-table-tcr']/div[@class='grid-content']/div/div[@data-col-index='2']//div[text()='"+ values.get("TESTCASE_ID") + "']//parent::div//parent::div//following-sibling::div//div//div[@class='name-as-link']"; 
	WebElement selectTestcase = CommonUtil.returnWebElement(xpathForTestcaseName);
	selectTestcase.click();
	HomePage.getInstance().waitForProgressBarToComplete();
	logger.info("Clicked on the testcase Name for modification.");
	CommonUtil.normalWait(3000);
	CommonUtil.normalWait(1000);
	selectALLTestStep.click();
	CommonUtil.normalWait(1000);
	copySteps.click();
	CommonUtil.normalWait(1000);
	pasteSteps.click();
	CommonUtil.normalWait(1000);
	
	}catch (Exception e) {
		e.printStackTrace();
		return false;
	}
		
	finally {
		backToTcList.click();
		CommonUtil.normalWait(1000);
	}
	return true;
}

public boolean testcaseReorder(String testcaseName) {
	
	CommonUtil.normalWait(1000);
	buttonTestaseReorder.click();
	String selecttestcasecheckbox="//div[@id='grid-table-tcrReorderGridType']//div[@title='"+testcaseName+"']/parent::div/parent::div/preceding-sibling::div//input";
	CommonUtil.normalWait(2000);
	WebElement we = CommonUtil.returnWebElement(selecttestcasecheckbox);
	//String testcaseOrderId =  CommonUtil.getText("//div[@id='grid-table-tcrReorderGridType']//div[@title='"+testcaseName+"']/parent::div/parent::div/preceding-sibling::div[2]/div/div");
	//String orderId = CommonUtil.getText(testcaseOrderId);
	CommonUtil.normalWait(3000);
	HomePage.getInstance().waitForProgressBarToComplete();
	CommonUtil.scrollToWebElement(we);
	we.click();
	CommonUtil.normalWait(1000);
	textMoveto.sendKeys("1");
	CommonUtil.normalWait(1000);
	buttonMove.click();
	CommonUtil.normalWait(1000);
	buttonSaveTestcaseOrderID.click();
	CommonUtil.normalWait(1000);
	HomePage.getInstance().waitForProgressBarToComplete();
	Assert.assertEquals(CommonUtil.getText("//div[@class='grid-content']/div[1]//div[5]/div/div"), testcaseName);
	return true;
}

public boolean checkUsageHistory(Map<String, String> values) {
	
	HomePage.getInstance().waitForProgressBarToComplete();
	CommonUtil.normalWait(1000);
	String xpath = "//*[@data-name = '" + values.get("NODE_NAME") + "']";
	WebElement we = CommonUtil.returnWebElement(xpath);
	we.click();
	HomePage.getInstance().waitForProgressBarToComplete();
	CommonUtil.normalWait(4000);
	logger.info("Node selected successfully.");

	String xpathForTestcaseName = ".//*[@id='grid-table-tcr']//div[@class='name-as-link'][text()='"+values.get("TESTCASE_NAME")+"']"; 
	WebElement selectTestcase = CommonUtil.returnWebElement(xpathForTestcaseName);
	selectTestcase.click();
	HomePage.getInstance().waitForProgressBarToComplete();
	logger.info("Clicked on the testcase Name for modification.");
	CommonUtil.normalWait(3000);
	
	if (values.containsKey("CYCLE_NAME")) {
		Assert.assertEquals(CommonUtil.getText(".//*[@id='grid-table-testcase-usage']//div[@class='grid-content']/div/div[3]//div[text()='"+values.get("CYCLE_NAME")+"']"), values.get("CYCLE_NAME"));
	}
	
	if (values.containsKey("STATUS")){
		
	
		if (CommonUtil.isElementPresent("//*[@id='grid-table-testcase-usage']//div[@class='grid-content']/div/div[6]//div/span[text()='\"+values.get(\"STATUS\")+\"']"))
		{
			WebElement actulStatus = CommonUtil
					.returnWebElement("//*[@id='grid-table-testcase-usage']//div[@class='grid-content']/div/div[6]//div/span[text()='"+values.get("STATUS")+"']");
		Assert.assertEquals(actulStatus.getText(), values.get("STATUS"), "Status not updated to: " + values.containsKey("STATUS") + " Status found as: "
				+ actulStatus.getText());
		}else
		{
			return false;
		}
	}
	
	if (values.containsKey("DEFECT")) {
		
		WebElement defectID = CommonUtil.returnWebElement(".//*[@id='grid-table-testcase-usage']//div[@class='grid-content']/div/div[7]//div/span[2]");
		CommonUtil.scrollToWebElement(defectID);
		System.out.println(defectID.getText());
		//Assert.assertEquals(defectID.getText(), );
		
		Assert.assertEquals(defectID.getText(), values.get("DEFECT"), "the Defect ID doesnot match");
		
	}
	
	if (values.containsKey("")) {
		
	}
	return true;
			
}


}

