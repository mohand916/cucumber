package com.thed.zeuihtml.test.bvt;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.omg.CORBA.COMM_FAILURE;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.thed.zeuihtml.BaseTest;
import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.Constants;
import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;
import com.thed.zeuihtml.ze.impl.zehtmlpages.HomePage;

public class TestRepositoryBvts extends BaseTest {

	public TestRepositoryBvts() {
		logger = Logger.getLogger(this.getClass());
	}

	@Test(enabled = testEnabled, priority = 40)
	public void bvt40_clickOnTestRepository() {
		logger.info("Executing bvt40...");
		altID = 40;
		testcaseId = "252";
		
		String releaseName = "Release 1.0";
		String appName = "Test Repository";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);

		isSuccess = true;
		logger.info("bvt40 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 41)
	public void bvt41_createPhase() {
		logger.info("Executing bvt41...");
		altID = 41;
		testcaseId = "253";

		String releaseName = "Release 1.0";
		String phaseName = Config.getTCRPropValue("PHASE_1");
		String phaseDescription = phaseName + " description";
		Assert.assertTrue(zeNavigator.createPhase(releaseName, phaseName, phaseDescription),
				"Phase not created successfully.");

		phaseName = Config.getTCRPropValue("PHASE_2");
		phaseDescription = phaseName + " description";
		Assert.assertTrue(zeNavigator.createPhase(releaseName, phaseName, phaseDescription),
				"Phase not created successfully.");

		phaseName = Config.getTCRPropValue("PHASE_3");
		phaseDescription = phaseName + " description";
		Assert.assertTrue(zeNavigator.createPhase(releaseName, phaseName, phaseDescription),
				"Phase not created successfully.");

		logger.info("Phases are created successsfully.");
		isSuccess = true;
		logger.info("bvt41 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 42)
	public void bvt42_createNode() {
		logger.info("Executing bvt42...");
		altID = 42;
		testcaseId = "254";
		String parentNodeName = Config.getTCRPropValue("PHASE_1");
		String nodeOneName = Config.getTCRPropValue("NODE_1");
		String nodeOneDescription = nodeOneName + " description";

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");

		String nodeTwoName = Config.getTCRPropValue("NODE_2");
		String nodeTwoDescription = nodeTwoName + " description";
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeTwoName, nodeTwoDescription),
				"Node not created successfully.");
		logger.info("Created nodes for " + parentNodeName + " Successfully.");

		parentNodeName = Config.getTCRPropValue("PHASE_2");
		nodeOneName = Config.getTCRPropValue("NODE_3");
		nodeOneDescription = nodeOneName + " description";

		// Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated
		// to nodes.");
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");

		nodeTwoName = Config.getTCRPropValue("NODE_4");
		nodeTwoDescription = nodeTwoName + " description";
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeTwoName, nodeTwoDescription),
				"Node not created successfully.");
		logger.info("Created nodes for " + parentNodeName + " Successfully.");

		parentNodeName = Config.getTCRPropValue("PHASE_3");
		nodeOneName = Config.getTCRPropValue("NODE_5");
		nodeOneDescription = nodeOneName + " description";

		// Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not
		// navigated to nodes.");
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");

		nodeTwoName = Config.getTCRPropValue("NODE_6");
		nodeTwoDescription = nodeTwoName + " description";
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeTwoName, nodeTwoDescription),
				"Node not created successfully.");
		logger.info("Created nodes for " + parentNodeName + " Successfully.");

		isSuccess = true;
		logger.info("bvt42 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 43)
	public void bvt43_createSubNodes() {
		logger.info("Executing bvt43...");
		altID = 43;
		testcaseId = "255";
		String parentNodeName = Config.getTCRPropValue("NODE_1");
		String nodeOneName = Config.getTCRPropValue("SUB_NODE_1");
		String nodeOneDescription = nodeOneName + " description";

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");

		String nodeTwoName = Config.getTCRPropValue("SUB_NODE_2");
		String nodeTwoDescription = nodeTwoName + " description";
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeTwoName, nodeTwoDescription),
				"Node not created successfully.");
		logger.info("Created nodes for " + parentNodeName + " Successfully.");

		parentNodeName = Config.getTCRPropValue("NODE_2");
		nodeOneName = Config.getTCRPropValue("SUB_NODE_3");
		nodeOneDescription = nodeOneName + " description";

		// List<String> phases = new ArrayList<String>();
		// phases.add(Config.getTCRPropValue("PHASE_1"));
		// Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not
		// navigated to nodes.");
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");

		nodeTwoName = Config.getTCRPropValue("SUB_NODE_4");
		nodeTwoDescription = nodeTwoName + " description";
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeTwoName, nodeTwoDescription),
				"Node not created successfully.");
		logger.info("Created nodes for " + parentNodeName + " Successfully.");

		parentNodeName = Config.getTCRPropValue("NODE_3");
		nodeOneName = Config.getTCRPropValue("SUB_NODE_5");
		nodeOneDescription = nodeOneName + " description";

		phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_2"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");

		nodeTwoName = Config.getTCRPropValue("SUB_NODE_6");
		nodeTwoDescription = nodeTwoName + " description";
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeTwoName, nodeTwoDescription),
				"Node not created successfully.");
		logger.info("Created nodes for " + parentNodeName + " Successfully.");

		parentNodeName = Config.getTCRPropValue("NODE_4");
		nodeOneName = Config.getTCRPropValue("SUB_NODE_7");
		nodeOneDescription = nodeOneName + " description";

		// List<String> phases = new ArrayList<String>();
		// phases.add(Config.getTCRPropValue("PHASE_1"));
		// Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated
		// to nodes.");
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");

		nodeTwoName = Config.getTCRPropValue("SUB_NODE_8");
		nodeTwoDescription = nodeTwoName + " description";
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeTwoName, nodeTwoDescription),
				"Node not created successfully.");
		logger.info("Created nodes for " + parentNodeName + " Successfully.");

		parentNodeName = Config.getTCRPropValue("NODE_5");
		nodeOneName = Config.getTCRPropValue("SUB_NODE_9");
		nodeOneDescription = nodeOneName + " description";

		phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_3"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");

		nodeTwoName = Config.getTCRPropValue("SUB_NODE_10");
		nodeTwoDescription = nodeTwoName + " description";
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeTwoName, nodeTwoDescription),
				"Node not created successfully.");
		logger.info("Created nodes for " + parentNodeName + " Successfully.");

		parentNodeName = Config.getTCRPropValue("NODE_6");
		nodeOneName = Config.getTCRPropValue("SUB_NODE_11");
		nodeOneDescription = nodeOneName + " description";

		// List<String> phases = new ArrayList<String>();
		// phases.add(Config.getTCRPropValue("PHASE_1"));
		// Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");

		nodeTwoName = Config.getTCRPropValue("SUB_NODE_12");
		nodeTwoDescription = nodeTwoName + " description";
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeTwoName, nodeTwoDescription),
				"Node not created successfully.");
		logger.info("Created nodes for " + parentNodeName + " Successfully.");

		logger.info("Created Sub systems for all systems Successfully.");

		isSuccess = true;
		logger.info("bvt43 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 44)
	public void bvt44_renameNode() {
		logger.info("Executing bvt44...");
		altID = 44;
		testcaseId = "256";
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_3"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");

		String renameNodeName = Config.getTCRPropValue("NODE_5");
		String nodeName = Config.getTCRPropValue("NODE_EDIT");
		String nodeDescription = nodeName + " Description";

		Assert.assertTrue(zeNavigator.renameNode(renameNodeName, nodeName, nodeDescription),
				"Node not renamed successfully.");
		isSuccess = true;
		logger.info("bvt44 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 45)
	public void bvt45_moveNode() {
		logger.info("Executing bvt45...");
		altID = 45;
		testcaseId = "257";
		String moveNodeName = Config.getTCRPropValue("NODE_MOVE");

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_3"));
		phases.add(Config.getTCRPropValue("NODE_EDIT"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");

		Assert.assertTrue(zeNavigator.moveNode(moveNodeName, Config.getTCRPropValue("NODE_EDIT"),
				Config.getTCRPropValue("PHASE_3"), null), "Node not moved successfully.");

		logger.info("Moved sub-system Successfully to the System Node");
		CommonUtil.javaWait(1000);
		CommonUtil.browserRefresh();
		CommonUtil.javaWait(1000);
		// List<String> phases1 = new ArrayList<String>();
		// phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		// phases.add(Config.getTCRPropValue("PHASE_3"));
		// phases.add(Config.getTCRPropValue("NODE_EDIT"));
		// Assert.assertTrue(zeNavigator.navigateToNodes(phases1), "Not navigated to nodes.");
		//Assert.assertTrue(zeNavigator.moveNode(moveNodeName, Config.getTCRPropValue("PHASE_3"), Config.getTCRPropValue("RELEASE_NAME"), null), "Node not moved successfully.");
		logger.info("Moved System Successfully to the Release Node");
		isSuccess = true;
		logger.info("bvt45 is executed successfully.");
	}

	/**
	 * DnD (move) a sub-system to a system and a system to a phase
	 */
	@Test(enabled = testEnabled, priority = 46)
	public void bvt46_moveNodeToRelease() {
		logger.info("Executing bvt46...");
		altID = 46;
		testcaseId = "257";
		String moveNodeName = Config.getTCRPropValue("NODE_MOVE1");

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_3"));
		phases.add(Config.getTCRPropValue("NODE_EDIT"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");

		Assert.assertTrue(zeNavigator.moveNode(moveNodeName, Config.getTCRPropValue("NODE_EDIT"),
				Config.getTCRPropValue("RELEASE_NAME"), null), "Node not moved successfully.");

		logger.info("Moved Sub-System Successfully to the Release Node");
		isSuccess = true;
		logger.info("bvt46 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 47)
	public void bvt47_copyNodeToRelease() {
		logger.info("Executing bvt47...");
		altID = 47;
		testcaseId = "257";
		String copyNodeName = Config.getTCRPropValue("PHASE_3");

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_3"));
		// phases.add(Config.getTCRPropValue("NODE_EDIT"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");

		List<String> phases1 = new ArrayList<String>();
		phases1.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases1.add(Config.getTCRPropValue("PHASE_2"));
		Assert.assertTrue(zeNavigator.copyNode(copyNodeName, Config.getTCRPropValue("RELEASE_NAME"),
				Config.getTCRPropValue("NODE_4"), phases1), "Node not moved successfully.");

		logger.info("Moved Sub-System Successfully to the Release Node");
		isSuccess = true;
		logger.info("bvt47 is executed successfully.");
	}

	/**
	 * Ctrl+DnD (copy) a phase to a system of another phase to create new
	 * sub-system
	 */
	@Test(enabled = testEnabled, priority = 48)
	public void bvt48_deleteNode() {
		logger.info("Executing bvt48...");
		altID = 48;
		testcaseId = "257";
		String deleteNodeName = Config.getTCRPropValue("NODE_DELETE");

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		// phases.add(Config.getTCRPropValue("PHASE_3"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.deleteNode(deleteNodeName), "Node not renamed successfully.");
		isSuccess = true;
		logger.info("bvt48 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 49)
	public void bvt49_filterNodes() {
		logger.info("Executing bvt49...");
		altID = 49;
		testcaseId = "261";
		String filterText = "N";

		Assert.assertTrue(zeNavigator.filterNodes(filterText), "Node not filtered successfully.");
		filterText = "No";
		Assert.assertTrue(zeNavigator.filterNodes(filterText), "Node not filtered successfully.");
		filterText = "Node 1";
		Assert.assertTrue(zeNavigator.filterNodes(filterText), "Node not filtered successfully.");
		isSuccess = true;
		logger.info("bvt49 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 50)
	public void bvt50_createTestcase() {
		logger.info("Executing bvt50...");
		altID = 50;
		testcaseId = "262";

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		// phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");

		System.out.println("Testcase IDs : " + testcaseId);

		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY", "Modified summary");
		values.put("TESTCASE_DESC", "Modified description");
		values.put("TESTCASE_SUMMARY",Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"));
		values.put("TESTCASE_DESC", "Testcase without steps description");
		values.put("Priority", Config.getTCRPropValue("TESTCASE_WITHOUT_STEP_PRIORITY"));
		values.put("Comment", Config.getTCRPropValue("TESTCASE_WITHOUT_STEP_COMMENT"));

		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
		zeNavigator.verifyTestcaseVersion(Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"), "1");
		isSuccess = true;
		logger.info("bvt50 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 51)
	public void bvt51_CreateTestcaseWithcustomfield() {
		logger.info("Executing bvt51...");
		altID = 51;

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_2"));
		phases.add(Config.getTCRPropValue("NODE_3"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_5");
		String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");
		System.out.println("Testcase IDs : " + testcaseId);
		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY", Config.getTCRPropValue("TESTCASE_WITH_ALL_CUSTOM_FIELDS"));
		values.put("TESTCASE_DESC", "Testcase with all the customfield");
		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
		Assert.assertTrue(zeNavigator.clickOnTestcase(testcaseId), "Not able to click on testcase");
		Assert.assertTrue(
				zeNavigator.addCustomfieldToTestcase(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_1"),
						"Customfield Text", Config.getTCRPropValue("TEXT_CUSTOM_FIELD_TYPE")),
				"Customfield Field text not added");
		Assert.assertTrue(
				zeNavigator.addCustomfieldToTestcase(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_2"),
						"CustomField text Area", Config.getTCRPropValue("LONGTEXT_CUSTOM_FIELD_TYPE")),
				"Customfield Text area not added");
		Assert.assertTrue(zeNavigator.addCustomfieldToTestcase(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_5"), "12",
				Config.getTCRPropValue("NUMBER_CUSTOM_FIELD_TYPE")), "Customfield Number not added");
		Assert.assertTrue(zeNavigator.addCustomfieldToTestcase(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_6"),
				Config.getTCRPropValue("TC_PICKLIST_VALUE_2"), Config.getTCRPropValue("PICKLIST_CUSTOM_FIELD_TYPE")),
				"Picklist custom filed is not Added");
		Assert.assertTrue(zeNavigator.addCustomfieldToTestcase(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_3"), "true",
				Config.getTCRPropValue("CHECKBOX_CUSTOM_FIELD_TYPE")), "Customfield checkbox not added");
		Assert.assertTrue(zeNavigator.addCustomfieldToTestcase(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_4"),
				"currentdate", Config.getTCRPropValue("DATE_CUSTOM_FIELD_TYPE")), "Customfield Date not added");

		Assert.assertTrue(
				zeNavigator.verifyCustomfieldToTestcase(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_1"),
						Config.getTCRPropValue("TC_TEXT_VALUE"), Config.getTCRPropValue("TEXT_CUSTOM_FIELD_TYPE")),
				"custom field text not verified");
		Assert.assertTrue(zeNavigator.verifyCustomfieldToTestcase(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_2"),
				Config.getTCRPropValue("TC_LONGTEXT_VALUE"), Config.getTCRPropValue("LONGTEXT_CUSTOM_FIELD_TYPE")),
				"custom field textArea not verified");
		Assert.assertTrue(
				zeNavigator.verifyCustomfieldToTestcase(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_5"),
						Config.getTCRPropValue("TC_NUMBER_VALUE"), Config.getTCRPropValue("NUMBER_CUSTOM_FIELD_TYPE")),
				"custom field Number not verified");
		Assert.assertTrue(zeNavigator.verifyCustomfieldToTestcase(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_6"),
				Config.getTCRPropValue("TC_PICKLIST_VALUE_2"), Config.getTCRPropValue("PICKLIST_CUSTOM_FIELD_TYPE")),
				"custom field picklist not verified");
		zeNavigator.navigateBackToTestcaseList();

		isSuccess = true;
		logger.info("bvt51 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 52)
	public void bvt52_AddTeststeps() {
		logger.info("Executing bvt52...");
		altID = 52;
		testcaseId = "264";

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		// phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");
		System.out.println("Testcase IDs : " + testcaseId);
		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY", Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"));
		values.put("TESTCASE_DESC", "Testcase having single step");
		values.put("Comment", Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP_COMMENT"));

		JSONArray stepArray = new JSONArray();

		// JSONObject steps = new JSONObject();
		JSONObject step1 = new JSONObject();
		step1.put("step", "step 1");
		step1.put("data", "data 1");
		step1.put("result", "result 1");
		// steps.put("step1", step1);
		stepArray.put(step1);
		values.put("TESTCASE_STEPS", stepArray.toString());
		// values.put("TESTCASE_STEPS_CANCEL", "true");
		System.out.println(values.get("TESTCASE_STEPS"));

		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");

		isSuccess = true;
		logger.info("bvt52 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 55)
	public void bvt55_cancelTeststep() {
		logger.info("Executing bvt55...");
		altID = 55;
		testcaseId = "265";

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		// phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");

		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY", "Cancel teststep after adding to this testcase");
		values.put("TESTCASE_DESC", "Modified description");

		JSONArray stepArray = new JSONArray();

		// JSONObject steps = new JSONObject();
		JSONObject step1 = new JSONObject();
		step1.put("step", "step 1");
		step1.put("data", "data 1");
		step1.put("result", "result 1");
		// steps.put("step1", step1);
		stepArray.put(step1);
		values.put("TESTCASE_STEPS", stepArray.toString());
		values.put("TESTCASE_STEPS_CANCEL", "true");
		System.out.println(values.get("TESTCASE_STEPS"));

		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");

		isSuccess = true;
		logger.info("bvt55 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 56)
	public void bvt56_CreatingTestcaseWithMultipleStepsAndCancelTheChangesDoneToTeststeps() {
		logger.info("Executing bvt56...");
		altID = 56;
		testcaseId = "266";

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		// phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");

		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		// values.put("TESTCASE_SUMMARY", "Cancel teststeps after adding to this
		// testcase");
		// values.put("TESTCASE_DESC", "Cancel teststeps after adding to this
		// testcase");
		values.put("TESTCASE_SUMMARY", Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"));
		values.put("TESTCASE_DESC", "Adding testcase with multiple teststeps");

		JSONArray stepArray = new JSONArray();

		// JSONObject steps = new JSONObject();
		JSONObject step1 = new JSONObject();
		step1.put("step", "step 1");
		step1.put("data", "data 1");
		step1.put("result", "result 1");
		JSONObject step2 = new JSONObject();
		step2.put("step", "step 2");
		step2.put("data", "data 2");
		step2.put("result", "result 2");
		JSONObject step3 = new JSONObject();
		step3.put("step", "step 3");
		step3.put("data", "data 3");
		step3.put("result", "result 3");
		// steps.put("step1", step1);
		stepArray.put(step1);
		stepArray.put(step2);
		stepArray.put(step3);
		values.put("TESTCASE_STEPS", stepArray.toString());
		// values.put("TESTCASE_STEPS_CANCEL", "true");
		System.out.println(values.get("TESTCASE_STEPS"));

		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");

		isSuccess = true;
		logger.info("bvt56 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 57)
	public void bvt57_CloneTestcaseWithoutStep() {
		logger.info("Executing bvt57...");
		altID = 57;
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		String testcaseName = Config.getTCRPropValue("TESTCASE_WITHOUT_STEP");
		Assert.assertTrue(zeNavigator.cloneTestcase(nodeName, testcaseName, "withoutsteps"), "Testcase is not cloned");
		isSuccess = true;
		logger.info("bvt57 is executed successfully.");

	}

	@Test(enabled = testEnabled, priority = 58)
	public void bvt58_CloneTestcaseWithOneStep() {
		logger.info("Executing bvt58...");
		altID = 58;
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		String testcaseName = Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP");
		zeNavigator.cloneTestcase(nodeName, testcaseName, "withsteps");
		isSuccess = true;
		logger.info("bvt58 is executed successfully.");

	}

	@Test(enabled = testEnabled, priority = 59)
	public void bvt59_CloneTestcaseWithMultipleStep() {
		logger.info("Executing bvt59...");
		altID = 59;
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		String testcaseName = Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP");
		zeNavigator.cloneTestcase(nodeName, testcaseName, "withsteps");
		isSuccess = true;
		logger.info("bvt59 is executed successfully.");

	}

	@Test(enabled = testEnabled, priority = 60)
	public void bvt53_60_EditNameAndStepsOfClonedTestcase() {
		logger.info("Executing bvt60...");
		altID = 60;
		altID = 53;
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		String testcaseId = zeNavigator.getTestcase(nodeName);
		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY", Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"));
		values.put("TESTCASE_DESC", "Testcase created with three steps is Modified");
		values.put("ALT_ID", Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP_ALTID"));
		values.put("VERSIONVERIFY", "false");
		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
		String testStepToBeModified = Config.getTCRPropValue("TESTSTEPS_TO_BE_MODIFIED");
		values.put("TESTCASE_STEPS", testStepToBeModified);
		Assert.assertTrue(zeNavigator.modifyTeststep(values), "Not added default testcase successfully.");

		isSuccess = true;
		logger.info("bvt53_60 is executed successfully.");
	}

	//@Test(enabled = false, priority = 54)
	public void bvt61_ViewTestcaseVersionHistory() {
		logger.info("Executing bvt61...");
		altID = 61;
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		String testcaseId = zeNavigator.getTestcase(nodeName);
		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY", Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"));
		values.put("TESTCASE_DESC", "Testcase created with three steps is Modified");
		values.put("VERSIONVERIFY", "true");
		// Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added
		// default testcase successfully.");
		String testStepToBeModified = Config.getTCRPropValue("TESTSTEPS_VERSIONCHECK");
		values.put("TESTCASE_STEPS", testStepToBeModified);

		Assert.assertTrue(zeNavigator.modifyTeststep(values), "Not added default testcase successfully.");
		isSuccess = true;
		logger.info("bvt61 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 62)
	public void bvt62_Create5TestcasesAndNavigateBetweenTestcases() {
		logger.info("Executing bvt62...");
		altID = 62;
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("NODE_1");
		for (int i = 1; i <= 5; i++) {
			String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
			Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");
			Map<String, String> values = new HashMap<String, String>();
			values.put("NODE_NAME", nodeName);
			values.put("TESTCASE_ID", testcaseId);
			values.put("TESTCASE_SUMMARY", "Sample Testcase " + i);
			values.put("TESTCASE_DESC", "Descriptionof Sample Testcase " + i);
			Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
		}
		//Assert.assertTrue(zeNavigator.navigateBetweenTestcases(nodeName, "Sample Testcase "),"Not navigated to next testcase");
		isSuccess = true;
		logger.info("bvt62 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 63)
	public void bvt63_BulkEditTestcase() {
		int i;
		logger.info("Executing bvt63...");
		altID = 63;

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_2");
		for (i = 0; i <= 2; i++) {
			String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
			Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");

			Map<String, String> values = new HashMap<String, String>();
			values.put("NODE_NAME", nodeName);
			values.put("TESTCASE_ID", testcaseId);
			values.put("TESTCASE_SUMMARY", "Testcase for Bulk Edit");
			values.put("TESTCASE_DESC", "Testcase for Bulk Edit");
			Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
		}

		Map<String, String> values = new HashMap<String, String>();
		values.put("ALTID", "12.12.23");
		values.put("Comment", "Bulk Edited testcase");
		values.put("Tags", "Bulk");
		values.put("estimatedTime", Config.getTCRPropValue("NEW_ESTIMATED_TIME"));
		values.put("priority", Config.getTCRPropValue("TC_PRIORITY_2"));
		values.put("Automated", "BVTAutomation" + Constants.CHAR_TO_SPLIT_STRING + "001"
				+ Constants.CHAR_TO_SPLIT_STRING + Config.getTCRPropValue("Automation_Path"));
		Assert.assertTrue(zeNavigator.bulkEditTestCase(values), "Bulk edit not done succefully..");
		isSuccess = true;
		logger.info("bvt63 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 64)
	public void bvt64_AddAttachmentToTestcase() {
		logger.info("Executing bvt64...");
		altID = 64;
		testcaseId = "274";

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		// phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");

		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY", "Add attachment to testcase");
		values.put("TESTCASE_DESC", "Add attachment to testcase");
		values.put("TESTCASE_ATTACHMENT", Config.getTCRPropValue("TESTCASE_ATTACHMENT"));
		// values.put("TESTCASE_ATTACHMENT",
		// "D:\\workspace\\zeuihtml\\src\\test\\resources\\attachments\\attachment.png");

		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");

		isSuccess = true;
		logger.info("bvt64 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 66)
	public void bvt66_deleteTestcase() {
		logger.info("Executing bvt66...");
		altID = 66;
		testcaseId = "276";

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");

		Assert.assertTrue(zeNavigator.deleteTestcase(nodeName, Integer.parseInt(testcaseId)), "Not deleted testcase.");

		isSuccess = true;
		logger.info("bvt66 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 69)
	public void bvt69_FindAndAddTestcaseTo_P_S_SS() {
		logger.info("Executing bvt69...");
		altID = 69;
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("PHASE_2");
		// name ~ "sample"

		Assert.assertTrue(
				zeNavigator.findAndAddTestcase(nodeName,
						"name ~ \"" + Config.getTCRPropValue("TESTCASE_FOR_PHASE_FIND_AND_ADD_") + "\""),
				"Not clicked on Find And Add");

		phases.add(Config.getTCRPropValue("PHASE_2"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		nodeName = Config.getTCRPropValue("NODE_3");
		// priority = "P1"
		Assert.assertTrue(
				zeNavigator.findAndAddTestcase(nodeName,
						"priority = \"" + Config.getTCRPropValue("TESTACSE_FOR_SYSTEM_FIND_AND_ADD") + "\""),
				"Not clicked on Find And Add");

		phases.add(Config.getTCRPropValue("NODE_3"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		nodeName = Config.getTCRPropValue("SUB_NODE_5");
		// comment ~ "comment1"
		Assert.assertTrue(
				zeNavigator.findAndAddTestcase(nodeName,
						"comment ~ \"" + Config.getTCRPropValue("TESTCASE_FOR_SUBSYSTEM_FIND_AND_ADD") + "\""),
				"Not clicked on Find And Add");
		phases.add(Config.getTCRPropValue("SUB_NODE_5"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		isSuccess = zeNavigator.verifyTestcaseVersion(Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"), "1");
		logger.info("bvt69 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 70)
	public void bvt72_Dock_UnDock_GlobalTree() {
		logger.info("Executing bvt72...");
		altID = 72;
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("NODE_2");
		Assert.assertTrue(zeNavigator.dockUndockGlobalTree(nodeName), "Not clicked on Copy From other Projects");
		isSuccess = true;
		logger.info("bvt72 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 71)
	public void bvt79_quickSearchTescaseByAltId() {
		logger.info("Executing bvt79...");
		altID = 79;
		List<String> expectedTestcases = new ArrayList<String>();
		expectedTestcases.add(0, Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"));
		Assert.assertTrue(zeNavigator.searchTescases("Quick",
				Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP_ALTID"), expectedTestcases, true),
				"Not performed Quick Search");
		isSuccess = true;
		logger.info("bvt79 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 72)
	public void bvt80_zqlSearchTescaseByCheckBox() {
		logger.info("Executing bvt80...");
		altID = 80;
		List<String> expectedTestcases = new ArrayList<String>();
		expectedTestcases.add(0, Config.getTCRPropValue("TESTCASE_WITH_ALL_CUSTOM_FIELDS"));
		Assert.assertTrue(zeNavigator.searchTescases("Advanced", "sample-custom-3 = true", expectedTestcases, true),
				"Not performed Advance Search");
		isSuccess = true;
		logger.info("bvt80 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 73)
	public void bvt81_exportMultiSelectedZQLInTestcaseTest() {
		logger.info("Executing bvt81...");
		altID = 81;

		List<String> expectedTestcases = new ArrayList<String>();
		expectedTestcases.add(0, Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"));
		expectedTestcases.add(1, Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"));

		Assert.assertTrue(zeNavigator.searchTescases("Advanced", "comment ~ \"comment1\"", expectedTestcases, false),
				"Not performed Advance Search");

		zeNavigator.exportAllSearchedTestcaseInTCC("Excel", null, true);

		List<String> fileNames = CommonUtil.returnFileNames(Config.getValue("EXPORT_FILE_PATH"));
		CommonUtil.normalWait(1000);
		CommonUtil.renameFile(Config.getValue("EXPORT_FILE_PATH") + "/" + fileNames.get(0),
				Config.getTCRPropValue("EXCEL_EXPORT_SEARCH_FILENAME"));

		List<Integer> ignoreCells = new ArrayList<Integer>();
		ignoreCells.add(3);
		ignoreCells.add(11);
		ignoreCells.add(22);

		isSuccess = CommonUtil.compareExcel(
				Config.getValue("EXPORT_FILE_PATH") + "/" + Config.getTCRPropValue("EXCEL_EXPORT_SEARCH_FILENAME"),
				Config.getValue("EXPORT_FILE_PATH") + "/backups/"
						+ Config.getTCRPropValue("BACKUP_EXCEL_SEARCH_TO_COMPARE"),
				ignoreCells);

		CommonUtil.moveFile(
				Config.getValue("EXPORT_FILE_PATH") + "/" + Config.getTCRPropValue("EXCEL_EXPORT_SEARCH_FILENAME"),
				Config.getValue("EXPORT_FILE_PATH") + "/delete");

		//Assert.assertTrue(isSuccess, "Exported Excel Data is not correct when compared with expected data");

		isSuccess = true;
		logger.info("bvt81 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 74)
	public void bvt82_switchFromSearchToFolder() {
		logger.info("Executing bvt82...");
		altID = 82;
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		Assert.assertTrue(zeNavigator.switchBetweenSearchFolderListDetailView(nodeName),
				"Not Switched between List and Detail view");
		isSuccess = true;
		logger.info("bvt82 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 75)
	public void bvt75_exportExcelDataForTCCNodeTest() {
		logger.info("Executing bvt75...");
		altID = 75;

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");

		zeNavigator.exportSelectedNodeOfTCC(Config.getTCRPropValue("PHASE_1"), "Excel", null);

		List<String> fileNames = CommonUtil.returnFileNames(Config.getValue("EXPORT_FILE_PATH"));
		CommonUtil.normalWait(1000);
		CommonUtil.renameFile(Config.getValue("EXPORT_FILE_PATH") + "/" + fileNames.get(0),
				Config.getTCRPropValue("EXCEL_EXPORT_FILENAME"));

		List<Integer> ignoreCells = new ArrayList<Integer>();
		ignoreCells.add(6);
		ignoreCells.add(13);
		ignoreCells.add(24);

		isSuccess = CommonUtil.compareExcel(
				Config.getValue("EXPORT_FILE_PATH") + "/" + Config.getTCRPropValue("EXCEL_EXPORT_FILENAME"),
				Config.getValue("EXPORT_FILE_PATH") + "/backups/" + Config.getTCRPropValue("BACKUP_EXCEL_TO_COMPARE"),
				ignoreCells);

		CommonUtil.moveFile(Config.getValue("EXPORT_FILE_PATH") + "/" + Config.getTCRPropValue("EXCEL_EXPORT_FILENAME"),
				Config.getValue("EXPORT_FILE_PATH") + "/delete");

		//Assert.assertTrue(isSuccess, "Exported Excel Data is not correct when compared with expected data");
		
		logger.info("bvt75 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 76)
	public void bvt76_exportInSummaryViewForTCCNodeTest() {
		logger.info("Executing bvt76...");
		altID = 76;

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		zeNavigator.exportSelectedNodeOfTCC(Config.getTCRPropValue("PHASE_1"), "Summary", "HTML");
		List<String> fileNames = CommonUtil.returnFileNames(Config.getValue("EXPORT_FILE_PATH"));
		CommonUtil.normalWait(1000);
		System.out.println("Summary File Name: " + fileNames.get(0));
		CommonUtil.normalWait(1000);
		CommonUtil.renameFile(Config.getValue("EXPORT_FILE_PATH") + "/" + fileNames.get(0),
				Config.getTCRPropValue("HTML_EXPORT_FILENAME"));
		CommonUtil.moveFile(Config.getValue("EXPORT_FILE_PATH") + "/" + Config.getTCRPropValue("HTML_EXPORT_FILENAME"),
				Config.getValue("EXPORT_FILE_PATH") + "/delete");
		isSuccess = true;
		logger.info("bvt76 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 77)
	public void bvt77_exportInDetailedViewForTCCNodeTest() {
		logger.info("Executing bvt77...");
		altID = 77;

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		zeNavigator.exportSelectedNodeOfTCC(Config.getTCRPropValue("PHASE_1"), "Detailed", "PDF");
		List<String> fileNames = CommonUtil.returnFileNames(Config.getValue("EXPORT_FILE_PATH"));
		CommonUtil.normalWait(1000);
		System.out.println("Summary File Name: " + fileNames.get(0));

		CommonUtil.renameFile(Config.getValue("EXPORT_FILE_PATH") + "/" + fileNames.get(0),
				Config.getTCRPropValue("PDF_EXPORT_FILENAME"));

		isSuccess = CommonUtil.compareTwoPDFFilesData(
				Config.getValue("EXPORT_FILE_PATH") + "/backups/" + Config.getTCRPropValue("BACKUP_PDF_TO_COMPARE"),
				Config.getValue("EXPORT_FILE_PATH") + "/" + Config.getTCRPropValue("PDF_EXPORT_FILENAME"));

		CommonUtil.moveFile(Config.getValue("EXPORT_FILE_PATH") + "/" + Config.getTCRPropValue("PDF_EXPORT_FILENAME"),
				Config.getValue("EXPORT_FILE_PATH") + "/delete");

		//Assert.assertTrue(isSuccess, "PDF exported is not matching to expected data");

		isSuccess = true;
		logger.info("bvt69 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 78)
	public void bvt78_exportGridTestcaseTest() {
		logger.info("Executing bvt78...");
		altID = 78;

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		zeNavigator.exportGridTestcaseOfTCC("Excel", null);
		List<String> fileNames = CommonUtil.returnFileNames(Config.getValue("EXPORT_FILE_PATH"));
		CommonUtil.normalWait(1000);
		CommonUtil.renameFile(Config.getValue("EXPORT_FILE_PATH") + "/" + fileNames.get(0),
				Config.getTCRPropValue("EXCEL_GRID_EXPORT_FILENAME"));

		List<Integer> ignoreCells = new ArrayList<Integer>();
		ignoreCells.add(6);
		ignoreCells.add(13);
		ignoreCells.add(24);

		isSuccess = CommonUtil.compareExcel(
				Config.getValue("EXPORT_FILE_PATH") + "/" + Config.getTCRPropValue("EXCEL_GRID_EXPORT_FILENAME"),
				Config.getValue("EXPORT_FILE_PATH") + "/backups/"
						+ Config.getTCRPropValue("BACKUP_GRID_EXCEL_TO_COMPARE"),
				ignoreCells);

		CommonUtil.moveFile(
				Config.getValue("EXPORT_FILE_PATH") + "/" + Config.getTCRPropValue("EXCEL_GRID_EXPORT_FILENAME"),
				Config.getValue("EXPORT_FILE_PATH") + "/delete");

		//Assert.assertTrue(isSuccess, "Exported Excel Data is not correct when compared with expected data");

		isSuccess = true;
		logger.info("bvt70 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 79)
	public void bvt83_changeManualTestcaseToAutomated() {
		logger.info("Executing bvt83...");
		altID = 83;

		String tcName = (Config.getTCRPropValue("TESTCASE_WITH_ATTACHMENT"));
		String scriptName = "Script 1";
		String id = "1001";
		String path = "Sample_path";
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		zeNavigator.navigateToNodes(phases);
		CommonUtil.normalWait(1000);
		Assert.assertTrue(zeNavigator.changeTestcaseFromManualToAutomated(tcName, scriptName, id, path), "Testcase not changed to Automated");

		isSuccess = true;
		logger.info("bvt83 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 80)
	public void bvt73_importTestcasesByDiscriminatorIDChangeTest() {
		logger.info("Executing bvt73...");
		altID = 73;

		Assert.assertTrue(zeNavigator.addTestcaseMap("Map1", "2", "By ID Change", "testcase map", "H", "J", "L", "G", "K", null), "Not able to add testcase map");
		Assert.assertTrue(zeNavigator.importTestcase("Job1", "Map1",
				CommonUtil.getCompleteFilePath("\\src\\test\\resources\\export_import\\backups\\tccgridbackup.xlsx")), "Testcase not imported");
		zeNavigator.navigateToTCCNodeUnderImportedNode("tccgridbackup.xlsx");

		List<String> testcasesNames = new ArrayList<String>();
		testcasesNames.add(Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"));
		testcasesNames.add(Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"));
		testcasesNames.add(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"));

		zeNavigator.verifyTestcasesInSelectedNodeOfTestRepository(testcasesNames);

		isSuccess = true;
		logger.info("bvt73 is executed successfully.");
	}

	@Test(enabled = false, priority = 81)
	public void bvt74_copyTCCImportedNodeToReleaseLevelTest() {
		logger.info("Executing bvt74...");
		altID = 74;

		Assert.assertTrue(zeNavigator.renameSelectedTCCImportedNodeAndDragToRelease("tccgridbackup.xls", "Imported Testcase",
				"Release 1.0", true));

		List<String> nodes = new ArrayList<String>();
		nodes.add(Config.getTCRPropValue("RELEASE_NAME"));
		nodes.add("Imported Testcase");
		Assert.assertTrue(zeNavigator.navigateToNodes(nodes), "Not navigated to nodes.");

		List<String> testcasesNames = new ArrayList<String>();
		testcasesNames.add(Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"));
		testcasesNames.add(Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"));
		testcasesNames.add(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"));

		zeNavigator.verifyTestcasesInSelectedNodeOfTestRepository(testcasesNames);

		isSuccess = true;
		logger.info("bvt74 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 82)
	public void bvt70_DnDCopyGlobalPhaseWithSystemSubSystemToReleaseTest() {
		logger.info("Executing bvt70...");
		altID = 70;

		zeNavigator.selectProject("Sample Project");
		String releaseName = Config.getReleasePropValue("RELEASE_NAME_1");
		String appName = "Test Repository";
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		zeNavigator.launchGlobalTCCWindow(releaseName);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add("Projects");
		nodeList.add("Sample Project");
		nodeList.add("Release 1.0");
		nodeList.add("Phase 1");

		zeNavigator.navigateToNodeInGlobalTCC(nodeList);

		zeNavigator.DnDGlobalTestcaseToLocalRelease(releaseName, "Phase 1", null);
		List<String> phases = new ArrayList<String>();
		phases.add(releaseName);
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");

		isSuccess = true;
		logger.info("bvt63 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 83)
	public void bvt71_DnDCopyGlobalTestToReleaseTest() {
		logger.info("Executing bvt71...");
		altID = 71;

		String releaseName = Config.getReleasePropValue("RELEASE_NAME_1");
		zeNavigator.launchGlobalTCCWindow(releaseName);

		List<String> localNodeList = new ArrayList<String>();
		localNodeList.add(releaseName);
		localNodeList.add(Config.getTCRPropValue("PHASE_1"));
		zeNavigator.navigateToLocalReleaseNodeInGlobalTCC(localNodeList);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add("Projects");
		nodeList.add("Sample Project");
		nodeList.add("Release 1.0");
		nodeList.add(Config.getTCRPropValue("PHASE_1"));
		nodeList.add(Config.getTCRPropValue("NODE_1"));
		nodeList.add(Config.getTCRPropValue("SUB_NODE_1"));

		zeNavigator.navigateToNodeInGlobalTCC(nodeList);

		List<String> testcasesNames = new ArrayList<String>();
		testcasesNames.add(Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"));
		testcasesNames.add(Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"));
		testcasesNames.add(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"));

		zeNavigator.DnDGlobalTestcaseToLocalRelease("Phase 1", null, testcasesNames);

		List<String> phases = new ArrayList<String>();
		phases.add(releaseName);
		phases.add(Config.getTCRPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");

		zeNavigator.verifyTestcasesInSelectedNodeOfTestRepository(testcasesNames);

		isSuccess = true;
		logger.info("bvt71 is executed successfully.");
	}
	
	@Test(enabled=testEnabled, priority=84)
	public void bvt_copyPasteSteps() {
		logger.info("Executing bvt...");
		altID = 52;
		testcaseId = "264";

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		// phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");
		System.out.println("Testcase IDs : " + testcaseId);
		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY", Config.getTCRPropValue("TESTCASE_WITH_COPY_PASTE"));
		values.put("TESTCASE_DESC", "Testcase copy paste step");
		values.put("Comment", Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP_COMMENT"));

		JSONArray stepArray = new JSONArray();

		// JSONObject steps = new JSONObject();
		JSONObject step1 = new JSONObject();
		step1.put("step", "step 1");
		step1.put("data", "data 1");
		step1.put("result", "result 1");
		// steps.put("step1", step1);
		stepArray.put(step1);
		values.put("TESTCASE_STEPS", stepArray.toString());
		// values.put("TESTCASE_STEPS_CANCEL", "true");
		System.out.println(values.get("TESTCASE_STEPS"));

		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
		zeNavigator.copyPasteSteps(values);
		isSuccess = true;
		logger.info("bvt.. is executed successfully.");
		
	}
	
	@Test(enabled=testEnabled, priority=85)
	public void BVT_testcaseReorder() {
		logger.info("Executing bvt...");
		altID = 53;
		testcaseId = "265";
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		//String nodeName = Config.getTCRPropValue("SUB_NODE_1");
	//	HomePage.getInstance().waitForProgressBarToComplete();
		//CommonUtil.normalWait(4000);
		zeNavigator.testcaseReorder(Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"));
		isSuccess = true;
		logger.info("bvt.. is executed successfully.");
		
		
	}
	
	

	@BeforeMethod
	public void beforeMethod() {
		if(! Driver.driver.getTitle().contains("Test Repository")) {
			String releaseName = "Release 1.0";
			String appName = "Test Repository";
			zeNavigator.selectProject("Sample Project");
			Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
			zeNavigator.launchReleaseApp(appName);
		}
		isSuccess = false;
	}

	@AfterMethod
	public void afterMethod() {
		baseAfterMethod();
		if(!isSuccess){
			zeNavigator.logout();
			zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
			String releaseName = "Release 1.0";
			String appName = "Test Repository";
			zeNavigator.selectProject("Sample Project");
			Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
			zeNavigator.launchReleaseApp(appName);
		}
	}

	@BeforeClass
	public void beforeClass() {
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
	}
	
	@AfterClass
	public void afterClass() {
		zeNavigator.logout();
	}

}
