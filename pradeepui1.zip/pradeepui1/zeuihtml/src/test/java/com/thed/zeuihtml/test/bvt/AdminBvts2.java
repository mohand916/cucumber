package com.thed.zeuihtml.test.bvt;


import java.util.Map;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.thed.zeuihtml.BaseTest;
import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;

public class AdminBvts2 extends BaseTest {


	public AdminBvts2() {
		logger = Logger.getLogger(this.getClass());
	}
	
	
    @Test(enabled= testEnabled,priority=226)
	 public void bvt198_cloneRelease() {
    	CommonUtil.alertMsg("executing bvt198...");
		logger.info("Executing bvt198...");
		altID = 198;
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("DEFAULT_PROJECT"))
				, "Failed to select Project : " + Config.getProjectPropValue("DEFAULT_PROJECT"));
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("DEFAULT_RELEASE_NAME")), "Release not found by name: " +Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
		zeNavigator.verifyReleaseSummaryPage(Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
		Map<String, String> values = zeNavigator.getReleaseSummaryCountDetails("DEFAULT_RELEASE_NAME");
		Assert.assertTrue(zeNavigator.launchReleaseSetupPage(), "Failed to launch Release Setup , View Logs for details");
		zeNavigator.verifyReleaseSetupPage();
		logger.info("verified default release setup");
		zeNavigator.CloneRelease(Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
		logger.info("cloned and navigate to release summary page");
		
		Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("DEFAULT_PROJECT"))
				, "Failed to select Project : " + Config.getProjectPropValue("DEFAULT_PROJECT"));
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("RELEASE_CLONE_NAME")), "Release not found by name: " +Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
		
		
		zeNavigator.verifyReleaseSummaryPage(Config.getReleasePropValue("RELEASE_CLONE_NAME"), values.get("REQUIREMNT_COUNT"), values.get("TESTCASE_COUNT"), values.get("Execution_Count"), values.get("Defect_Count"));
		isSuccess = true;
		logger.info("cloned Release 1.0");

		
		}

	
	@Test(enabled= testEnabled,priority=227)
   public void bvt199_renameRelease() {
		CommonUtil.alertMsg("executing bvt189...");
		logger.info("Executing bvt199...");
		altID = 199;
		
		Assert.assertTrue(zeNavigator.launchReleaseSetupPage(), "Failed to launch Release Setup , View Logs for details");
		zeNavigator.verifyReleaseSetupPage();
		zeNavigator.renameRelease(Config.getReleasePropValue("CLONED_RELEASE"),Config.getReleasePropValue("CLONED_RELEASE_RENAME"),  Config.getReleasePropValue("CLONED_RELEASE_DESCRIPTION"),Config.getReleasePropValue("RELEASE_ENDDATE_1") );
		isSuccess = true;
		logger.info("Cloned relase name is renamed");
	
	}
	
	
	@Test(enabled= testEnabled, priority=228)
	public void bvt200_deleteRelease() {
		CommonUtil.alertMsg("executing bvt200...");
		logger.info("Executing bvt200..");
		altID = 200;
	//	zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("DEFAULT_PROJECT"))
				, "Failed to select Project : " + Config.getProjectPropValue("DEFAULT_PROJECT"));
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("DEFAULT_RELEASE_NAME")), "Release not found by name: " +Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
	//	zeNavigator.verifyReleaseSummaryPage(Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
		Assert.assertTrue(zeNavigator.launchReleaseSetupPage(), "Failed to launch Release Setup , View Logs for details");
		zeNavigator.verifyReleaseSetupPage();
		logger.info("verified default release setup");
		
		
		zeNavigator.createNewRelease(Config.getReleasePropValue("RELEASE_DELETE"), Config.getReleasePropValue("RELEASE_DELETE_DESCRIPTION"),false,Config.getReleasePropValue("RELEASE_DELETE_STARTDATE"),Config.getReleasePropValue("RELEASE_DELETE_ENDDATE"));
		logger.info("Created release");
		zeNavigator.verifyReleaseInReleaseSetup(Config.getReleasePropValue("RELEASE_DELETE"), Config.getReleasePropValue("RELEASE_DELETE_DESCRIPTION"),false,Config.getReleasePropValue("RELEASE_DELETE_STARTDATE"),null);
		zeNavigator.DeleteRelease(Config.getReleasePropValue("RELEASE_DELETE"));
		isSuccess = true;
		logger.info("bvt190 is executed successfully.");
			
	}
	
	
	@Test(enabled = testEnabled, priority = 229)
	public void bvt201_launchTrendHistoryAndRunETLJobForTodayTest(){
		CommonUtil.alertMsg("executing bvt201...");
		logger.info("Executing bvt201...");
		altID = 201;
		zeNavigator.launchAdministration();
		Assert.assertTrue(zeNavigator.launchAdminApps("Customizations"), "Failed to launch Customization App");
		zeNavigator.runETLJobForTrendForToday(true, true);
		
		isSuccess = true;
		logger.info("bvt201 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 230)
	public void bvt203_changePasswordAndReloginTest() {
		CommonUtil.alertMsg("executing bvt203...");
		logger.info("Executing bvt203...");
		altID = 203;
		
		zeNavigator.logout();
		zeNavigator.doLogin(Config.getUsersPropValue("USER4_USERNAME"), Config.getUsersPropValue("USER_CHANGEPASSWORD"));
		zeNavigator.changePassword("password1",Config.getUsersPropValue("USER_CHANGEPASSWORD"));
		zeNavigator.logout();
		zeNavigator.doLogin(Config.getUsersPropValue("USER4_USERNAME"), "password1");
//		zeNavigator.verifyProjectSummaryPage("Success Meet", "Mark Waugh", null, null, null, null, null);
		zeNavigator.logout();
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		isSuccess = true;
		logger.info("bvt203 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 231)
	public void bvt204_setUserAuthenticationToLdapTest(){
		CommonUtil.alertMsg("executing bvt204...");
		logger.info("Executing bvt204...");
		altID = 204;
		zeNavigator.launchAdministration();
		zeNavigator.launchAdminApps("Authentication");
		zeNavigator.setUserAuthenticationToLdap(Config.getValue("LDAP_HOST"), Config.getValue("BASE_DN"), Config.getValue("BIND_DN"), 
				Config.getValue("BIND_PASSWORD"), Config.getValue("SEARCH_ATTRIBUTE"), Config.getValue("LDAP_USERNAME")
				, Config.getValue("LDAP_PASSWORD"));
		
		isSuccess = true;
		logger.info("bvt204 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 232)
	public void bvt205_loginToZephyrWithLdapTest(){
		CommonUtil.alertMsg("executing bvt205...");
		logger.info("Executing bvt205...");
		
		
		altID = 205;
		
		zeNavigator.logout();
		zeNavigator.doLogin(Config.getValue("LDAP_USERNAME"), Config.getValue("LDAP_PASSWORD"));
		zeNavigator.verifyProjectSummaryPage("Sample Project", "Test Lead", null, null, null, null, null);
		zeNavigator.logout();
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		
		
		isSuccess = true;
		logger.info("bvt205 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 233)
	public void bvt206_setUserAuthenticationToCrowdTest(){
		CommonUtil.alertMsg("executing bvt206...");
		logger.info("Executing bvt206...");
		altID = 206;
		zeNavigator.launchAdministration();
		zeNavigator.launchAdminApps("Authentication");
		zeNavigator.setUserAuthenticationToCrowd(Config.getValue("SERVICE_URL"), Config.getValue("APPLICATION_NAME")
				, Config.getValue("APPLICATION_PWD"), Config.getValue("CROWD_USERNAME"), Config.getValue("CROWD_PASSWORD"));
		
		isSuccess = true;
		logger.info("bvt206 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 234)
	public void bvt207_loginToZephyrWithCrowdTest(){
		CommonUtil.alertMsg("executing bvt207...");
		logger.info("Executing bvt207...");
		altID = 207;
		
		zeNavigator.logout();
		zeNavigator.doLogin(Config.getValue("CROWD_USERNAME"), Config.getValue("CROWD_PASSWORD"));
		zeNavigator.verifyProjectSummaryPage("Sample Project", "Test Lead", null, null, null, null, null);
		zeNavigator.logout();
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		
		isSuccess = true;
		logger.info("bvt207 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 235)
	public void bvt208_setUserAuthenticationToWebservice(){
		CommonUtil.alertMsg("executing bvt208...");
		logger.info("Executing bvt208...");
		altID = 208;
		
		zeNavigator.launchAdministration();
		zeNavigator.launchAdminApps("Authentication");
		zeNavigator.setUserAuthenticationToWebService(Config.getValue("WEBSERVICE_URL"), 
				Config.getValue("WEBSERVICE_USERNAME"), Config.getValue("WEBSERVICE_PASSWORD"));
		
		isSuccess = true;
		logger.info("bvt208 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 236)
	public void bvt209_loginToZephyrWithWebserviceTest(){
		CommonUtil.alertMsg("executing bvt209...");
		logger.info("Executing bvt209...");
		altID = 209;
		
		zeNavigator.logout();
		zeNavigator.doLogin(Config.getValue("WEBSERVICE_USERNAME"), Config.getValue("WEBSERVICE_USERNAME"));
		zeNavigator.verifyProjectSummaryPage("Sample Project", "Test Lead", null, null, null, null, null);
		zeNavigator.logout();
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		
		
		isSuccess = true;
		logger.info("bvt209 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 237)
	public void bvt210_enableSecondaryAuthenticationAndLoginTest(){
		CommonUtil.alertMsg("executing bvt210...");
		logger.info("Executing bvt210...");
		altID = 210;
		//zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		
		zeNavigator.launchAdministration();
		Assert.assertTrue(zeNavigator.launchAdminApps("Customizations"), "Failed to launch Customization App");
		zeNavigator.enableDisableSecondaryAuthentication();
		zeNavigator.logout();
		zeNavigator.doLogin(Config.getUsersPropValue("USER4_USERNAME"), "password1");
		zeNavigator.verifyProjectSummaryPage("Success Meet", "Mark Waugh", null, null, null, null, null);
		zeNavigator.logout();
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		isSuccess = true;
		logger.info("bvt210 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 238)
	public void bvt212_performFullReindexTest(){
		CommonUtil.alertMsg("executing bvt212...");
		logger.info("Executing bvt212...");
		altID = 212;
		
		zeNavigator.launchAdministration();
		Assert.assertTrue(zeNavigator.launchAdminApps("Customizations"), "Failed to launch Customization App");
		zeNavigator.doFullReindex();
		
		isSuccess = true;
		logger.info("bvt212 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 239)
	public void bvt234_performProjectLevelReindexTest() {
		CommonUtil.alertMsg("executing bvt234...");
		logger.info("Executing bvt234...");
		altID = 234;
		zeNavigator.launchAdministration();
		Assert.assertTrue(zeNavigator.launchAdminApps("Customizations"), "Failed to launch Customization App");
		zeNavigator.doProjectLevelReindex(Config.getProjectPropValue("DEFAULT_PROJECT"));
		
		isSuccess = true;
		logger.info("bvt234 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 240)
	public void bvt211_loginAsSameUserToForceLogoutTest() {
		CommonUtil.alertMsg("executing bvt211...");
		logger.info("Executing bvt211...");
		altID = 211;
		
		WebDriver temp = Driver.driver;
		WebDriver d = CommonUtil.getNewWebDriver();
		d.navigate().to(Config.getValue("ZE_URL"));
		Driver.driver = d;
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		Driver.driver = temp;
		CommonUtil.normalWait(2000);
		d.quit();
		zeNavigator.verifyForceLogoutPopupAndClickOk();
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		isSuccess = true;
		logger.info("bvt211 is executed successfully.");
	}
	
	@Test(enabled= testEnabled, priority=241)
	public void bvt230_deleteReleaseAsOtherUser() {
		CommonUtil.alertMsg("executing bvt230...");
		logger.info("Executing bvt230..");
		altID = 230;
		zeNavigator.logout();
		zeNavigator.doLogin(Config.getUsersPropValue("USER4_USERNAME"), "password1");
		Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"))
				, "Failed to select Project : " + Config.getProjectPropValue("PROJECT1_NAME"));
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("DEFAULT_RELEASE_NAME")), "Release not found by name: " +Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
		Assert.assertTrue(zeNavigator.launchReleaseSetupPage(), "Failed to launch Release Setup , View Logs for details");
		zeNavigator.verifyReleaseSetupPage();
		logger.info("verified default release setup");
		
		zeNavigator.createNewRelease(Config.getReleasePropValue("RELEASE_DELETE"), Config.getReleasePropValue("RELEASE_DELETE_DESCRIPTION"),false,Config.getReleasePropValue("RELEASE_DELETE_STARTDATE"),Config.getReleasePropValue("RELEASE_DELETE_ENDDATE"));
		logger.info("Created release");
		zeNavigator.verifyReleaseInReleaseSetup(Config.getReleasePropValue("RELEASE_DELETE"), Config.getReleasePropValue("RELEASE_DELETE_DESCRIPTION"),false,Config.getReleasePropValue("RELEASE_DELETE_STARTDATE"),Config.getReleasePropValue("RELEASE_DELETE_ENDDATE"));
		zeNavigator.DeleteRelease(Config.getReleasePropValue("RELEASE_DELETE"));
		isSuccess = true;
		
	}
	
	@BeforeMethod
	public void beforeMethod() {
		isSuccess = false;
	}

	@AfterMethod
	public void afterMethod() {
		baseAfterMethod();
		if(!isSuccess){
			zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		}
	}

	@BeforeClass
	public void beforeClass() {
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
	}
	
	@AfterClass
	public void afterClass() {
		zeNavigator.logout();
	}

}
