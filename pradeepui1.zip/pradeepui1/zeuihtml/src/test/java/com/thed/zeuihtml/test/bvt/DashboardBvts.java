package com.thed.zeuihtml.test.bvt;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.thed.zeuihtml.BaseTest;
import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.ze.ZeNavigator;
import com.thed.zeuihtml.ze.impl.zehtmlpages.HomePage;

public class DashboardBvts extends BaseTest {


	public DashboardBvts() {
		logger = Logger.getLogger(this.getClass());
	}
	
	@Test(enabled = testEnabled, priority = 202)
	public void bvt147_createDashboardTest(){
		logger.info("Executing bvt147...");
		altID = 147;
		
		zeNavigator.launchDashboard();
		zeNavigator.createDashboard("Sample Dashboard", "description", "1", "Any logged in user");
		zeNavigator.verifyDashboard("Sample Dashboard", "description");
		isSuccess = true;
		logger.info("bvt147 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority=203)
	public void bvt148_editDashboardTest(){
		logger.info("Executing bvt148...");
		altID = 148;
		
		zeNavigator.editDashboard("Sample Dashboard", "Dashboard 1", "description to Dashboard 1", "2", null);
		zeNavigator.verifyDashboard("Dashboard 1", "description to Dashboard 1");
		isSuccess = true;
		logger.info("bvt148 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority=204)
	public void bvt149_addAllGadgetsTest(){
		logger.info("Executing bvt149...");
		altID = 149;
		
		zeNavigator.selectDashboard("Dashboard 1");
		zeNavigator.addDailyPulseGadgets("Sample Project", "Release 1.0", null, "Last 7 Days");
		
		List<String> listOfFilterByValues = new ArrayList<String>();
		listOfFilterByValues.add(0, "Test Manager");
		listOfFilterByValues.add(0, "Tester One");
		
		zeNavigator.addExecutionBacklogGadget("Sample Project", "Release 1.0", "User", listOfFilterByValues, "15 Min");
		
		zeNavigator.navigateToManageDashboardPage();
		isSuccess = true;
		logger.info("bvt149 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 205)
	public void bvt154_deleteDashboardWithGadgetTest(){
		logger.info("Executing bvt154...");
		altID = 154;
		
		zeNavigator.createDashboard("Dashboard to Delete", "delete dahboard with gadget", "1", "Any logged in user");
		zeNavigator.verifyDashboard("Dashboard to Delete", "delete dahboard with gadget");
		zeNavigator.selectDashboard("Dashboard to Delete");
		zeNavigator.addDailyPulseGadgets("Sample Project", "Release 1.0", null, "Last 7 Days");
		zeNavigator.navigateToManageDashboardPage();
		zeNavigator.deleteDashbaord("Dashboard to Delete");
		
		isSuccess = true;
		logger.info("bvt150 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 206)
	public void bvt155_loginAsDashboardUserAndCreateDashbaordAndAddGadget(){
		logger.info("Executing bvt155...");
		altID = 155;
		
		zeNavigator.logout();
		zeNavigator.doLogin(Config.getUsersPropValue("USER3_USERNAME"), Config.getUsersPropValue("USER3_PASSWORD"));
		zeNavigator.resetPassword(Config.getUsersPropValue("USER_CHANGEPASSWORD"));
		zeNavigator.launchDashboard();
		zeNavigator.createDashboard("Dashboard created by dashboard user", "dashboard user", "1", "Private");
		zeNavigator.verifyDashboard("Dashboard created by dashboard user", "dashboard user");
		
		isSuccess = true;
		logger.info("bvt155 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 207)
	public void bvt235_createPrivateDashboardTest() {
		logger.info("Executing bvt235...");
		altID = 235;
		
		zeNavigator.launchDashboard();
		zeNavigator.createDashboard("Private Dashboard", "dashboard description", "1", "Private");
		zeNavigator.verifyDashboard("Private Dashboard", "dashboard description");
		
		isSuccess = true;
		logger.info("bvt235 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 208)
	public void bvt236_createProjectTeamDashboardTest() {
		logger.info("Executing bvt236...");
		altID = 236;
		
		zeNavigator.logout();
		HomePage.getInstance().waitForProgressBarToComplete();
		zeNavigator.doLogin(Config.getValue("ZE_LEAD_USERNAME"), Config.getValue("ZE_LEAD_PASSWORD"));
		zeNavigator.launchDashboard();
		zeNavigator.createDashboard("Project Team Dashboard", "dashboard description", "1", "Project Team");
		zeNavigator.verifyDashboard("Project Team Dashboard", "dashboard description");
		
		isSuccess = true;
		logger.info("bvt236 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 209)
	public void bvt237_createDashboardTestWithShareTypeAnyLoggedInUser() {
		logger.info("Executing bvt237...");
		altID = 237;
		
		zeNavigator.logout();
		HomePage.getInstance().waitForProgressBarToComplete();
		zeNavigator.doLogin(Config.getValue("ZE_LEAD_USERNAME"), Config.getValue("ZE_LEAD_PASSWORD"));
		zeNavigator.launchDashboard();
		zeNavigator.createDashboard("Common Dashboard", "dashboard description", "1", "Any logged in user");
		zeNavigator.verifyDashboard("Common Dashboard", "dashboard description");
		
		isSuccess = true;
		logger.info("bvt237 is executed successfully.");
	}
	
	@Test(enabled= testEnabled, priority=210)
	public void bvt233_changeGadgetWithCustomizerefreshrate() {
		
		zeNavigator.logout();
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		zeNavigator.launchAdministration();
		Assert.assertTrue(zeNavigator.launchAdminApps("Customizations"), "Failed to launch Customization App");
	//	zeNavigator.customizwGadgetRefreshRate(Config.getValue("REFRESH_RATE"));
		zeNavigator.launchDashboard();
		zeNavigator.selectDashboard("Dashboard 1");
		zeNavigator.createGadgetwithCustomizeRefreshRate(Config.getProjectPropValue("DEFAULT_PROJECT"), Config.getTCRPropValue("RELEASE_NAME"), Config.getValue("REFRESH_RATE"));
		
	}
	
	@BeforeMethod
	public void beforeMethod() {
		isSuccess = false;
	}

	@AfterMethod
	public void afterMethod() {
		baseAfterMethod();
		if(!isSuccess){
			zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
			zeNavigator.launchDashboard();
		}
	}

	@BeforeClass
	public void beforeClass() {
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
	}
	
	@AfterClass
	public void afterClass() {
		zeNavigator.logout();
	}

}
