package com.thed.zeuihtml.test.bvt;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.thed.zeuihtml.BaseTest;
import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.Constants;
import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;
import com.thed.zeuihtml.ze.ZeNavigator;

public class TestExecutionBvts extends BaseTest {


	public TestExecutionBvts() {
		logger = Logger.getLogger(this.getClass());
	}
	
	@Test(enabled = testEnabled, priority = 111)
	public void bvt111_viewAssingmentsInTCEForClonedCycleWithTestcasesAssignedToAnyoneTest(){
		logger.info("Executing bvt111...");
		altID = 111;
		
		String releaseName = "Release 1.0";
		String appName = "Test Planning";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		zeNavigator.unhideCycle();
		Assert.assertTrue(zeNavigator.editCycle(Config.getEASPropValue("CLONED_CYCLE3_NAME"), 
				null, null, null, null, null, null, null, true, true), "Failed to unhide cycle");
		
		zeNavigator.launchReleaseApp("Test Execution");
		
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_2"));
		nodeList.add(3, Config.getTCRPropValue("NODE_3"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_5"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		
		zeNavigator.verifyAssignedTestcaseInSelectedNodeInTCE(Config.getTCRPropValue("TESTCASE_WITH_ALL_CUSTOM_FIELDS")
				, "Anyone", "Not Executed");
		
		isSuccess = true;
		logger.info("bvt111 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 112)
	public void bvt112_treeWithNewTestCycleShownProperlyTest(){
		logger.info("Executing bvt112...");
		altID = 112;
		
		zeNavigator.logout();
		zeNavigator.doLogin(Config.getUsersPropValue("ZE_TESTER_USERNAME"), Config.getUsersPropValue("ZE_TESTER_PASSWORD"));
		
		String releaseName = Config.getReleasePropValue("DEFAULT_RELEASE_NAME");
		zeNavigator.selectProject(Config.getProjectPropValue("DEFAULT_PROJECT"));
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.launchReleaseApp("Test Execution");
		
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_2"));
		nodeList.add(3, Config.getTCRPropValue("NODE_3"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_5"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		
		zeNavigator.verifyAssignedTestcaseInSelectedNodeInTCE(Config.getTCRPropValue("TESTCASE_WITH_ALL_CUSTOM_FIELDS")
				, "Anyone", "Not Executed");
		
		
		
		isSuccess = true;
		logger.info("bvt112 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 113)
	public void bvt113_verifyAssignedTestcasesTest() {
		logger.info("Executing bvt113...");
		altID = 113;
		String releaseName = Config.getReleasePropValue("DEFAULT_RELEASE_NAME");
		zeNavigator.selectProject(Config.getProjectPropValue("DEFAULT_PROJECT"));
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.launchReleaseApp("Test Execution");
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE4_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		zeNavigator.verifyAssignedTestcaseInSelectedNodeInTCE(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP")
				, "Tester One", "Not Executed");
		
		isSuccess = true;
		logger.info("bvt113 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 114)
	public void bvt114_executeTestToPassFailWIPBlockedTest(){
		logger.info("Executing bvt114...");
		altID = 114;

		Assert.assertTrue(zeNavigator.executeTestcaseInSelectedNodeAndVerify(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), "Pass"), "Failed to execute Test");
		
		zeNavigator.logout();
		zeNavigator.doLogin(Config.getUsersPropValue("ZE_MANAGER_USERNAME"), Config.getUsersPropValue("ZE_MANAGER_PASSWORD"));
		String releaseName = Config.getReleasePropValue("DEFAULT_RELEASE_NAME");
		zeNavigator.selectProject(Config.getProjectPropValue("DEFAULT_PROJECT"));
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.launchReleaseApp("Test Execution");
		
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		//Modifying testcase created with three steps - Cloned Testcase

		Assert.assertTrue(zeNavigator.executeTestcaseInSelectedNodeAndVerify(Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"), "Pass")
				, "Failed to execute Test");
		
		Assert.assertTrue(zeNavigator.executeTestcaseInSelectedNodeAndVerify(Config.getTCRPropValue("TESTCASE_WITH_ATTACHMENT"), "Fail")
				, "Failed to execute Test");
		Assert.assertTrue(zeNavigator.executeTestcaseInSelectedNodeAndVerify(Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"), "WIP")
				, "Failed to execute Test");
		Assert.assertTrue(zeNavigator.executeTestcaseInSelectedNodeAndVerify(Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"), "Blocked")
				, "Failed to execute Test");
		
		isSuccess = true;
		logger.info("bvt114 is executed successfully.");
		
	}
	
	@Test(enabled = testEnabled, priority = 115)
	public void bvt115_executeTestToCustomStatusTest(){
		logger.info("Executing bvt115...");
		altID = 115;
		String releaseName = Config.getReleasePropValue("DEFAULT_RELEASE_NAME");
		zeNavigator.selectProject(Config.getProjectPropValue("DEFAULT_PROJECT"));
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.launchReleaseApp("Test Execution");
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		zeNavigator.executeTestcaseInSelectedNodeAndVerify(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP")
				, Config.getTCEPropValue("CUSTOM_EXECUTION_STATUS_1"));
		
		isSuccess = true;
		logger.info("bvt115 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 117)
	public void bvt117_bulkExecuteTestcasesTest(){
		logger.info("Executing bvt117...");
		altID = 117;
		String releaseName = Config.getReleasePropValue("DEFAULT_RELEASE_NAME");
		zeNavigator.selectProject(Config.getProjectPropValue("DEFAULT_PROJECT"));
		zeNavigator.selectReleaseFromGrid(releaseName);
		
		//zeNavigator.launchReleaseApp("Test Planning");
		zeNavigator.launchReleaseApp("Test Execution");
		
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CYCLE1_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_1"));
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		
		List<String> testcaseNames = new ArrayList<String>();
		testcaseNames.add(0, Config.getTCRPropValue("TESTCASE_WITH_ATTACHMENT"));
		testcaseNames.add(1, Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"));
		testcaseNames.add(2, Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"));
		
		zeNavigator.bulkExecuteTestcaseInSelectedNodeAndVerify(testcaseNames, "Pass");
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		zeNavigator.bulkExecuteTestcaseInSelectedNodeAndVerify(testcaseNames, "Fail");
		
		
		isSuccess = true;
		logger.info("bvt117 is executed successfully.");
	}
	
	
	@Test(enabled = testEnabled, priority = 118)
	public void bvt118_executeTestStepTest(){
		logger.info("Executing bvt118...");
		altID = 118;
		
		String releaseName = Config.getReleasePropValue("DEFAULT_RELEASE_NAME");
		zeNavigator.selectProject(Config.getProjectPropValue("DEFAULT_PROJECT"));
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.launchReleaseApp("Test Execution");
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		
		zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), "1", "Pass", true, false, null);
		zeNavigator.navigateBackToTestcaseList();
		zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), "2", "Fail", true, true, null);
		zeNavigator.navigateBackToTestcaseList();
		zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), "3", "WIP", true, true, null);
		zeNavigator.navigateBackToTestcaseList();
		
		isSuccess = true;
		logger.info("bvt118 is executed successfully.");
	}
	
	
	@Test(enabled = testEnabled, priority = 119)
	public void bvt119_executeStepToCustomStatus(){
		logger.info("Executing bvt119...");
		altID = 119;
		String releaseName = Config.getReleasePropValue("DEFAULT_RELEASE_NAME");
		zeNavigator.selectProject(Config.getProjectPropValue("DEFAULT_PROJECT"));
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.launchReleaseApp("Test Execution");
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP")
				, "1", Config.getTCEPropValue("CUSTOM_STEP_EXECUTION_STATUS_1"), true, true, null);
		zeNavigator.navigateBackToTestcaseList();
		isSuccess = true;
		logger.info("bvt119 is executed successfully.");
	}
	
	
	@Test(enabled = testEnabled, priority = 120)
	public void bvt120_executeAllStepsToSingleStatusAndSetTestcaseStatusToSuggestedValueTest(){
		logger.info("Executing bvt120...");
		altID = 120;
		String releaseName = Config.getReleasePropValue("DEFAULT_RELEASE_NAME");
		zeNavigator.selectProject(Config.getProjectPropValue("DEFAULT_PROJECT"));
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.launchReleaseApp("Test Execution");
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"), "1", "Pass", true, false, null);
		zeNavigator.navigateBackToTestcaseList();
		zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"), "2", "Pass", true, false, null);
		zeNavigator.navigateBackToTestcaseList();
		zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"), "3", "Pass", true, true, "Pass");
		zeNavigator.navigateBackToTestcaseList();
		//zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"), "4", "Pass", false, false, null);
		//zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"), "5", "Pass", false, false, null);
		//zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"), "6", "Pass", false, true, "Pass");
		
		isSuccess = true;
		logger.info("bvt120 is executed successfully.");
	}
	
	//@Test(enabled = testEnabled, priority = 121)
	public void bvt121_executeAllStepsToStatusNotAvailableAtTestcaseLevelAndVerifyPopupTest(){
		logger.info("Executing bvt121...");
		altID = 121;
		String releaseName = Config.getReleasePropValue("DEFAULT_RELEASE_NAME");
		zeNavigator.selectProject(Config.getProjectPropValue("DEFAULT_PROJECT"));
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.launchReleaseApp("Test Execution");
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		
		zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), "1"
				, Config.getTCEPropValue("CUSTOM_STEP_EXECUTION_STATUS_1"), true, false, null);
		zeNavigator.navigateBackToTestcaseList();
		zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), "2"
				, Config.getTCEPropValue("CUSTOM_STEP_EXECUTION_STATUS_1"), false, false, null);
		zeNavigator.navigateBackToTestcaseList();
		zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), "3"
				, Config.getTCEPropValue("CUSTOM_STEP_EXECUTION_STATUS_1"), false, false, null);
		zeNavigator.navigateBackToTestcaseList();
		
		isSuccess = true;
		logger.info("bvt121 is executed successfully.");
	}
	
	
	@Test(enabled = testEnabled, priority = 122)
	public void bvt122_uploadAttachmentToTestExecutionAndStepsTest(){
		logger.info("Executing bvt122...");
		altID = 122;
		String releaseName = Config.getReleasePropValue("DEFAULT_RELEASE_NAME");
		zeNavigator.selectProject(Config.getProjectPropValue("DEFAULT_PROJECT"));
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.launchReleaseApp("Test Execution");
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		
		zeNavigator.addExecutionAttachmentsNotesActualTime(Config.getTCRPropValue("TESTCASE_WITH_ATTACHMENT")
				, Config.getTCRPropValue("TESTCASE_ATTACHMENT"), null, null);
		zeNavigator.navigateBackToTestcaseList();
		
		isSuccess = true;
		logger.info("bvt122 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 123)
	public void bvt123_exportExecutionNodeTest() {
		logger.info("Executing bvt123...");
		altID = 123;
		String releaseName = Config.getReleasePropValue("DEFAULT_RELEASE_NAME");
		zeNavigator.selectProject(Config.getProjectPropValue("DEFAULT_PROJECT"));
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.launchReleaseApp("Test Execution");
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CYCLE1_NAME"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		
		zeNavigator.exportSelectedNodeOfTCE(Config.getEASPropValue("CYCLE1_NAME"),  "Excel", null);
		
		List<String>  fileNames= CommonUtil.returnFileNames(Config.getValue("EXPORT_FILE_PATH"));
		if(fileNames!=null) {
			CommonUtil.renameFile(Config.getValue("EXPORT_FILE_PATH")+"/"+fileNames.get(0), Config.getTCEPropValue("EXCEL_EXPORT_FILENAME"));
			List<Integer> ignoreCells = new ArrayList<Integer>();
			ignoreCells.add(5);
			ignoreCells.add(6);
			ignoreCells.add(10);
			ignoreCells.add(27);

			//isSuccess = CommonUtil.compareExcel(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getTCEPropValue("EXCEL_EXPORT_FILENAME"), Config.getValue("EXPORT_FILE_PATH")+"/backups/"+Config.getTCEPropValue("BACKUP_EXCEL_TO_COMPARE"), ignoreCells);
			
			CommonUtil.moveFile(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getTCEPropValue("EXCEL_EXPORT_FILENAME"), Config.getValue("EXPORT_FILE_PATH")+"/delete");
			
			//Assert.assertTrue(isSuccess, "Exported Excel Data is not correct when compared with expected data");
			
		}
		
		isSuccess = true;
		logger.info("bvt123 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 124)
	public void bvt124_exportExecutionFromGridTest() {
		logger.info("Executing bvt124...");
		altID = 124;
		
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CYCLE1_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_1"));
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		
		zeNavigator.exportGridTestcaseOfTCE("Excel", null);
		
		List<String>  fileNames= CommonUtil.returnFileNames(Config.getValue("EXPORT_FILE_PATH"));
		CommonUtil.renameFile(Config.getValue("EXPORT_FILE_PATH")+"/"+fileNames.get(0), Config.getTCEPropValue("EXCEL_EXPORT_GRID_FILENAME"));
		
		List<Integer> ignoreCells = new ArrayList<Integer>();
		ignoreCells.add(5);
		ignoreCells.add(6);
		ignoreCells.add(10);
		ignoreCells.add(27);
		
		//isSuccess = CommonUtil.compareExcel(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getTCEPropValue("EXCEL_EXPORT_GRID_FILENAME"), Config.getValue("EXPORT_FILE_PATH")+"/backups/"+Config.getTCEPropValue("BACKUP_EXCEL_GRID_TO_COMPARE"),ignoreCells);
		
		CommonUtil.moveFile(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getTCEPropValue("EXCEL_EXPORT_GRID_FILENAME"), Config.getValue("EXPORT_FILE_PATH")+"/delete");
		
		//Assert.assertTrue(isSuccess, "Exported Excel Data is not correct when compared with expected data");
		
		
		isSuccess = true;
		logger.info("bvt124 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 125)
	public void bvt125_switchBetweenSearchAndFolderViewInExecutionTest(){
		logger.info("Executing bvt125...");
		altID = 125;

		zeNavigator.switchExecutionViewAndVerify("Search");
		zeNavigator.switchExecutionViewAndVerify("Folder");
		zeNavigator.switchExecutionViewAndVerify("Search");
		
		isSuccess = true;
		logger.info("bvt125 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 126)
	public void bvt126_quickSearchExecutionByStatusAndSelectSearchedTestcaseAndVerifyDetailsBelowTest(){
		logger.info("Executing bvt126...");
		altID = 126;
		
		List<String> testcaseNamesToVerify = new ArrayList<String>();
		testcaseNamesToVerify.add(0, Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"));
		
		zeNavigator.executionSearchAndVerifyTestcase("Quick", "Pass", testcaseNamesToVerify);
		
		Map<String, String> testcaseDetails = new HashMap<String, String>();
		testcaseDetails.put("Status", "Pass");
		
		zeNavigator.verifyTestExecutionDetailsInSearch(Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"), testcaseDetails);
		
		zeNavigator.switchExecutionViewAndVerify("Folder");
		
		isSuccess = true;
		logger.info("bvt126 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 127)
	public void bvt127_advanceSearchExecutionByAssigneeAndCheckboxCustomFieldAndSelectSearchedTestcaseAndVerifyDetailsBelowTest(){
		logger.info("Executing bvt127...");
		altID = 127;
		
		zeNavigator.switchExecutionViewAndVerify("Search");
		
		List<String> testcaseNamesToVerify = new ArrayList<String>();
		testcaseNamesToVerify.add(0, Config.getTCRPropValue("TESTCASE_WITH_ALL_CUSTOM_FIELDS"));
		
		zeNavigator.executionSearchAndVerifyTestcase("Advanced", "assignee = \"any.one\" and sample-custom-3 = true", testcaseNamesToVerify);
		
		Map<String, String> testcaseDetails = new HashMap<String, String>();
		testcaseDetails.put("Status", "Not Executed");
		
		zeNavigator.verifyTestExecutionDetailsInSearch(Config.getTCRPropValue("TESTCASE_WITH_ALL_CUSTOM_FIELDS"), testcaseDetails);
		
		isSuccess = true;
		logger.info("bvt127 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 128)
	public void bvt128_exportMultiselectedZQLForExecutionTest() {
		logger.info("Executing bvt128...");
		altID = 128;
		
		zeNavigator.exportAllSearchedExecutionInTCE("Excel", null);
		
		List<String>  fileNames= CommonUtil.returnFileNames(Config.getValue("EXPORT_FILE_PATH"));
		CommonUtil.renameFile(Config.getValue("EXPORT_FILE_PATH")+"/"+fileNames.get(0), Config.getTCEPropValue("EXCEL_EXPORT_SEARCH_FILENAME"));
		
		List<Integer> ignoreCells = new ArrayList<Integer>();
		ignoreCells.add(5);
		ignoreCells.add(6);
		ignoreCells.add(24);
		ignoreCells.add(39);
		
		//isSuccess = CommonUtil.compareExcel(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getTCEPropValue("EXCEL_EXPORT_SEARCH_FILENAME"), Config.getValue("EXPORT_FILE_PATH")+"/backups/"+Config.getTCEPropValue("BACKUP_EXCEL_SEARCH_TO_COMPARE"),ignoreCells);
		
		CommonUtil.moveFile(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getTCEPropValue("EXCEL_EXPORT_SEARCH_FILENAME"), Config.getValue("EXPORT_FILE_PATH")+"/delete");
		
		//Assert.assertTrue(isSuccess, "Exported Excel Data is not correct when compared with expected data");
		zeNavigator.switchExecutionViewAndVerify("Folder");
		
		isSuccess = true;
		logger.info("bvt128 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 129)
	public void bvt129_addTestcaseFromAnotherCycleWithDifferentStatusTest(){
		logger.info("Executing bvt129...");
		altID = 129;
		String releaseName = Config.getReleasePropValue("DEFAULT_RELEASE_NAME");
		zeNavigator.selectProject(Config.getProjectPropValue("DEFAULT_PROJECT"));
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.launchReleaseApp("Test Planning");
		
		String startDate = CommonUtil.returnTodaysDate();
		String endDate = CommonUtil.returnFutureDateStartingTodaysDate(0, 2, 0);
		
		Assert.assertTrue(zeNavigator.createCycle(Config.getEASPropValue("CYCLE5_NAME"), null
				, null,startDate,endDate),  "Not created cycle successfully.");
		
		Assert.assertTrue(zeNavigator.addFreeformPhaseToCycle(Config.getEASPropValue("CYCLE5_NAME")
				, Config.getEASPropValue("FREEFORM2_PHASE_NAME"), true)
				, "Failed to add Freeform phase to cycle Successfully");
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE5_NAME"), Config.getEASPropValue("FREEFORM2_PHASE_NAME"), false);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getEASPropValue("FREEFORM2_PHASE_NAME"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		//Modifying testcase created with three steps - Cloned Testcase
		
		List<String> expectedTestcases = new ArrayList<String>();
		expectedTestcases.add(0, Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"));
		
		zeNavigator.addTestcaseToFreeformNodeFromAnotherCycle(Config.getEASPropValue("CLONED_CYCLE3_NAME")
				, Config.getTCRPropValue("PHASE_1"), "Pass", expectedTestcases, false, false);
		
		zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"), "Unassigned", false);
		zeNavigator.verifyTestcaseCountOfSelectedNode(Config.getEASPropValue("FREEFORM2_PHASE_NAME"), 1, false);
		
		expectedTestcases.clear();
		expectedTestcases.add(0, Config.getTCRPropValue("TESTCASE_WITH_ATTACHMENT"));
		zeNavigator.addTestcaseToFreeformNodeFromAnotherCycle(Config.getEASPropValue("CLONED_CYCLE3_NAME")
				, Config.getTCRPropValue("PHASE_1"), "Fail", expectedTestcases, false, false);
		
		zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("TESTCASE_WITH_ATTACHMENT"), "Unassigned", false);
		zeNavigator.verifyTestcaseCountOfSelectedNode(Config.getEASPropValue("FREEFORM2_PHASE_NAME"), 2, false);
		
		expectedTestcases.clear();
		expectedTestcases.add(0, Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"));
		zeNavigator.addTestcaseToFreeformNodeFromAnotherCycle(Config.getEASPropValue("CLONED_CYCLE3_NAME")
				, Config.getTCRPropValue("PHASE_1"), Config.getTCEPropValue("CUSTOM_EXECUTION_STATUS_1"), expectedTestcases, false, false);
		
		zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), "Unassigned", false);
		zeNavigator.verifyTestcaseCountOfSelectedNode(Config.getEASPropValue("FREEFORM2_PHASE_NAME"), 3, true);
		
		isSuccess = true;
		logger.info("bvt129 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 130)
	public void bvt130_searchExistingDefectAndLinkToTestcaseTest(){
		logger.info("Executing bvt130...");
		altID = 130;
		String releaseName = Config.getReleasePropValue("DEFAULT_RELEASE_NAME");
		zeNavigator.selectProject(Config.getProjectPropValue("DEFAULT_PROJECT"));
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.launchReleaseApp("Defect Tracking");
		CommonUtil.normalWait(1000);
		zeNavigator.setJiraUser(Config.getValue("JIRA_USERNAME"), Config.getValue("JIRA_PASSWORD"));
		CommonUtil.normalWait(3000);
		zeNavigator.launchReleaseApp("Test Execution");
		
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		//nodeList.add(4, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		
		zeNavigator.executeTestcaseInSelectedNodeAndVerify("Sample Testcase 1", "Fail");
		
		zeNavigator.searchAndLinkDefect("Sample Testcase 1", "JQL"
				, Config.getTCEPropValue("SEARCH_QUERY1"), Config.getTCEPropValue("DEFECT1_SUMMARY"), Config.getTCEPropValue("DEFECT1_ID"));
		
		
		isSuccess = true;
		logger.info("bvt130 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 131)
	public void bvt131_createNewDefectFromTCEAndViewRemoteLinkInExternalJiraTest(){
		logger.info("Executing bvt131...");
		altID = 131;
		
		zeNavigator.launchReleaseApp("Test Execution");
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		
		Map<String, String> values = new HashMap<String, String>();
		values.put("Project", Config.getProjectPropValue("JIRA_PROJECT_NAME"));
		values.put("Issue Type", Config.getProjectPropValue("ISSUE_TYPE"));
		values.put("Summary", Config.getTCEPropValue("NEW_DEFECT1"));
		values.put("Description", Config.getTCEPropValue("NEW_DEFECT1_DESCRIPTION"));
		values.put("Components", Config.getTCEPropValue("NEW_DEFECT1_COMPONENTS"));
		values.put("Priority", Config.getTCEPropValue("NEW_DEFECT1_PRIORITY"));
		
		Assert.assertTrue(zeNavigator.linkNewDefect(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), values), "Failed to create and link new Defect");
		
		isSuccess = true;
		logger.info("bvt131 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 136)
	public void bvt136_createNewDefectWithTestStepsCopiedToDefectDescriptionAsPlainTextTest(){
		
		logger.info("Executing bvt136...");
		altID = 136;
		
		zeNavigator.launchReleaseApp("Test Execution");
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		
		Map<String, String> values = new HashMap<String, String>();
		values.put("Project", Config.getProjectPropValue("JIRA_PROJECT_NAME"));
		values.put("Issue Type", Config.getProjectPropValue("ISSUE_TYPE"));
		values.put("Summary", Config.getTCEPropValue("NEW_DEFECT2"));
		values.put("Description", Config.getTCEPropValue("NEW_DEFECT2_DESCRIPTION"));
		values.put("Components", Config.getTCEPropValue("NEW_DEFECT2_COMPONENTS"));
		values.put("Priority", Config.getTCEPropValue("NEW_DEFECT2_PRIORITY"));
		
		Assert.assertTrue(zeNavigator.linkNewDefect(Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"), values), "Failed to create new defect with test steps copied to defect desc as plain text");
		
		isSuccess = true;
		logger.info("bvt136 is executed successfully.");
		
	}
	
	@Test(enabled = testEnabled, priority = 137)
	public void bvt137_createNewDefectWithTestStepsCopiedToDefectDescriptionAsWikiMarkupTest(){
		
		logger.info("Executing bvt137...");
		altID = 137;
		
		zeNavigator.launchReleaseApp("Test Execution");
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		
		Map<String, String> values = new HashMap<String, String>();
		values.put("Project", Config.getProjectPropValue("JIRA_PROJECT_NAME"));
		values.put("Issue Type", Config.getProjectPropValue("ISSUE_TYPE"));
		values.put("Summary", Config.getTCEPropValue("NEW_DEFECT3"));
		values.put("Description", Config.getTCEPropValue("NEW_DEFECT3_DESCRIPTION"));
		values.put("Components", Config.getTCEPropValue("NEW_DEFECT3_COMPONENTS"));
		values.put("Priority", Config.getTCEPropValue("NEW_DEFECT3_PRIORITY"));
		
		Assert.assertTrue(zeNavigator.linkNewDefect(Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"), values), "Failed to create new defect with test steps copied to defect desc as wiki-markup text");
		
		isSuccess = true;
		logger.info("bvt137 is executed successfully.");
		
	}
	@Test (enabled = testEnabled, priority=138)
	public void bvt_bulkexecuteStep() {
		logger.info("Executing bvt137...");
		altID = 137;
		
		zeNavigator.launchReleaseApp("Test Execution");
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		zeNavigator.bulkexecuteSteps(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), "Pass", true);
		zeNavigator.navigateBackToTestcaseList();
		isSuccess = true;
		logger.info("bvt118 is executed successfully.");
	}
	
	@Test (enabled = testEnabled, priority=139)
	public void bvt_bulkExecutethestepHotkey() {
		logger.info("Executing bvt137...");
		altID = 137;
		
		zeNavigator.launchReleaseApp("Test Execution");
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		zeNavigator.bulkexecuteStepsUsingHotKey(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), true);
		zeNavigator.navigateBackToTestcaseList();
		isSuccess = true;
		logger.info("bvt118 is executed successfully.");
	}
	

	@Test(enabled= testEnabled, priority=140)
	public void bvt_AutoUpdateStatus() {
		logger.info("Executing bvt137...");
		altID = 137;
		
		String releaseName = "Release 1.0";
		String appName = "Test Execution";
		zeNavigator.launchAdministration();
		CommonUtil.normalWait(1000);
		zeNavigator.launchAdminApps("ProjectSetup");
		zeNavigator.autoUpadteExecution(Config.getProjectPropValue("DEFAULT_PROJECT"));
		CommonUtil.normalWait(1000);
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		zeNavigator.autoUpadteStatusbulkexecuteSteps(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), "Blocked", true);
		zeNavigator.navigateBackToTestcaseList();
		isSuccess = true;
		logger.info("bvt118 is executed successfully.");
	}
	
	@Test(enabled=testEnabled,priority=141)
	public void checkUsageHistorywithLinkDefect()
	{
		
	}
	

	@BeforeMethod
	public void beforeMethod() {
		if(Driver.driver.getTitle().contains("Login")) {
    		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
    	}
    	if(! Driver.driver.getTitle().contains("Test Execution")) {
			String releaseName = "Release 1.0";
			String appName = "Test Execution";
			zeNavigator.selectProject("Sample Project");
			Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
			zeNavigator.launchReleaseApp(appName);
		}
    	if (Driver.driver == null ) {
    		Driver.driver = CommonUtil.getNewWebDriver();
			CommonUtil.launchBrowser(Config.getValue("ZE_URL"));
		}
		isSuccess = false;
	}
	

	

	@AfterMethod
	public void afterMethod() {
		baseAfterMethod();
		if(!isSuccess){
			zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
			String releaseName = "Release 1.0";
			String appName = "Test Planning";
			zeNavigator.selectProject("Sample Project");
			Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
			zeNavigator.launchReleaseApp(appName);
			CommonUtil.normalWait(1000);
		
		}
	}

	@BeforeClass
	public void beforeClass() {
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
	}
	
	@AfterClass
	public void afterClass() {
		zeNavigator.logout();
	}

}
