package com.thed.zeuihtml.ze.impl.zehtmlpages;

import static org.testng.Assert.assertTrue;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;

public class DashboardPage {

	Logger logger;
	
	public DashboardPage(){
		logger = Logger.getLogger(this.getClass());
	}
	
	public static DashboardPage getInstance(){
		return PageFactory.initElements(Driver.driver, DashboardPage.class);
	}
	
	/******************************************************
	 * 	WEBELEMENTS
	 *****************************************************/
	
	@FindBy(xpath="//h1[normalize-space(text())='Dashboards']")
	private WebElement headerDashboards;
	
	@FindBy(xpath="//button[text()='+']")
	private WebElement buttonAddDashboard;
	
	@FindBy(xpath="//input[@id='dashboard-name']")
	private WebElement textBoxDashbaordName;
	
	@FindBy(xpath="//textarea[@id='dashboard-description']")
	private WebElement textareaDashboardDescription;
	
	@FindBy(xpath="//button[text()='Save']")
	private WebElement buttonSaveDashboard;
	
	@FindBy(xpath="//select[@class='select2-hidden-accessible']")
	private WebElement selectAccessType;
	
	@FindBy(xpath="//span[@class='zui-dashboard-layout-1-inner']")
	private WebElement layout1;
	
	@FindBy(xpath="//span[@class='zui-dashboard-layout-2-inner']")
	private WebElement layout2;
	
	@FindBy(xpath="//h5/span[normalize-space(text())='Edit Dashboard']")
	private WebElement headerEditDashboard;
	
	@FindBy(xpath="//button[@id='zui-gadget-trigger-add']")
	private WebElement buttonAddNewGadget;
	
	@FindBy(xpath="//h4[text()='Daily Pulse']/following-sibling::button")
	private WebElement buttonAddDailyPulseGadget;
	
	@FindBy(xpath="//h4[text()='Execution Backlog']/following-sibling::button")
	private WebElement buttonAddExecutionBacklogGadget;
	
	@FindBy(xpath="//h4[text()='Requirement Status']/following-sibling::button")
	private WebElement buttonAddRequirementStatusGAdget;
	
	@FindBy(xpath="//h4[text()='Add Gadget']")
	private WebElement headerAddGadget;
	
	@FindBy(xpath="//h3[normalize-space(text())='Daily Pulse']")
	private WebElement headerDailyPulseInAddedGadget;
	
	@FindBy(xpath="//h3[normalize-space(text())='Execution Backlog']")
	private WebElement headerExecutionBacklogInAddedGadget;
	
	@FindBy(xpath="//label[normalize-space(text())='Project']/following-sibling::div//span[text()='Select Project']")
	private WebElement dropdownSelectProject;
	
	@FindBy(xpath="//label[normalize-space(text())='Refresh Rate']/following-sibling::div//span[text()='Select Refresh Rate']")
	private WebElement dropdownSelectRefreshRate;
	
	@FindBy(xpath="//label[normalize-space(text())='Release']/following-sibling::div//span[text()='Select Release']")
	private WebElement dropdownSelectRelease;
	
	@FindBy(xpath="//label[normalize-space(text())='Timeframe']/following-sibling::div//select")
	private WebElement selectTimeframe;
	
	@FindBy(xpath="//button[text()='Save']")
	private WebElement buttonSave;
	
	@FindBy(xpath="//zui-dashboard//h1/i")
	private WebElement navigateBackToManageDashboardPage;
	
	@FindBy(xpath="//div[@id='zui-dashboard-modal-delete']//h4[text()='Delete Dashboard']")
	private WebElement headerDeleteDashboardInConfirmationPopup;
	
	@FindBy(xpath="//div[@id='zui-dashboard-modal-delete']//button[text()='Delete']")
	private WebElement buttonDeleteDashboardInConfirmationPopup;
	
	@FindBy(xpath="//button[text()='Gadget Refresh Rate']")
	private WebElement buttonGadgetRefreshRate;
	
	@FindBy(xpath=".//*[@id='dashboard-modal']//h4[text()='Gadget Refresh Rate']")
	private WebElement popupGadgetRefreshRate;
	
	
	@FindBy(xpath="//*[@id='dashboard-modal']//h4[text()='Gadget Refresh Rate']/parent::div/parent::div/following-sibling::div//button[text()='Save']")
	private WebElement gadgetRefreshSaveButton;
	
	
	@FindBy(xpath="//button[@value='SAVE_DASHBOARD_SETTINGS']")
	private WebElement gadgetRefreshconfirmation;
	
	
	/******************************************************
	 * 	Methods
	 *****************************************************/
	
	//div[@id='grid-table-dashboard']/div[2]//div[text()='asc']
	
	public boolean createDashboard(String dashboardName, String dashboardDescription, String layout, String accessType){
		try{
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerDashboards), "Dashboard header not found");
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement("//*[@id='ze-main-app']/zui-dashboard//h1[text()='Dashboards']").click();
			CommonUtil.moveToElement(".//*[@id='ze-main-app']/zui-dashboard//h1[text()='Dashboards']");
			buttonAddDashboard.click();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textBoxDashbaordName), "Textbox dashboard name not found");
			textBoxDashbaordName.sendKeys(dashboardName);
			CommonUtil.normalWait(1000);
			textareaDashboardDescription.sendKeys(dashboardDescription);
			CommonUtil.normalWait(1000);
			if(layout!=null){
				if(layout.equals("1")){
					layout1.click();
				}else{
					layout2.click();
				}
			}
			CommonUtil.normalWait(1000);
			//CommonUtil.selectListWithVisibleText(selectAccessType, accessType);
			CommonUtil.returnWebElement("//span[@id='select2--container']").click();
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement("//li[text()='"+accessType+"']").click();
			CommonUtil.normalWait(1000);
			buttonSaveDashboard.click();
			HomePage.getInstance().waitForProgressBarToComplete();
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean editDashboard(String dashboardName, String dashboardNewName, String dashboardDescription, String layout, String accessType){
		try{
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-dashboard']//div[text()='"+dashboardName+"']")
					, "Dashboard name not found by name: "+dashboardName);
			CommonUtil.returnWebElement("//div[@id='grid-table-dashboard']//div[text()='"+dashboardName+"']/parent::div/parent::div/following-sibling::div[3]//span[@data-action='edit']").click();
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerEditDashboard), "Edit Dashboard header not found");
			CommonUtil.normalWait(1000);
			logger.info("Going to clear dashboard name");
			textBoxDashbaordName.clear();
			logger.info("Cleared dashboard name");
			CommonUtil.normalWait(1000);
			logger.info("Going to add new name of dashboard");
			textBoxDashbaordName.sendKeys(dashboardNewName);
			CommonUtil.normalWait(1000);
			textareaDashboardDescription.clear();
			CommonUtil.normalWait(1000);
			textareaDashboardDescription.sendKeys(dashboardDescription);
			CommonUtil.normalWait(1000);
			if(layout!=null){
				if(layout.equals("1")){
					layout1.click();
				}else{
					layout2.click();
				}
			}
			CommonUtil.normalWait(1000);
			if(accessType!=null){
				CommonUtil.selectListWithVisibleText(selectAccessType, accessType);
				CommonUtil.normalWait(1000);
			}
			buttonSaveDashboard.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			
		}catch(Exception e){
			logger.info("Failed to edit dashboard");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean verifyDashboard(String dashboardName, String dashboardDescription){
		try{

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-dashboard']//div[text()='"+dashboardName+"']")
					, "Dashboard name not found by name: "+dashboardName);
				
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-dashboard']//div[text()='"+dashboardName+"']/parent::div/parent::div/following-sibling::div//div[text()='"+dashboardDescription+"']")
					, "Dashboard description not found as: "+dashboardDescription);
			
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean selectDashboard(String dashboardName){
		try{
			CommonUtil.returnWebElement("//div[@id='grid-table-dashboard']//div[text()='"+dashboardName+"']").click();
			HomePage.getInstance().waitForProgressBarToComplete();
		}catch(Exception e){
			logger.info("failed to select dashboard");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean navigateToManageDashboardPage(){
		try{
			HomePage.getInstance().waitForProgressBarToComplete();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(navigateBackToManageDashboardPage), "Navigate back option not found");
			navigateBackToManageDashboardPage.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
		}catch(Exception e){
			logger.info("Failed to navigate to Manage Dashboard page");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean deleteDashbaord(String dashboardName){
		try{
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-dashboard']//div[text()='"+dashboardName+"']")
					, "Dashboard name not found by name: "+dashboardName);
			CommonUtil.returnWebElement("//div[@id='grid-table-dashboard']//div[text()='"+dashboardName+"']/parent::div/parent::div/following-sibling::div[3]//span[@data-action='delete']").click();
			HomePage.getInstance().waitForProgressBarToComplete();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerDeleteDashboardInConfirmationPopup), "Header Delete Dashboard not found in confirmation popup");
			buttonDeleteDashboardInConfirmationPopup.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			Assert.assertFalse(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-dashboard']//div[text()='"+dashboardName+"']")
					, "Dashboard name still visible after delete by name: "+dashboardName);
			
		}catch(Exception e){
			logger.info("Failed to delete Dasboard cleanly");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean addDailyPulseGadgets(String projectName, String releaseName, String trackedBy, String timeFrame){
		try{
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			buttonAddNewGadget.click();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerAddGadget), "Header Add Gadget not found");
			buttonAddDailyPulseGadget.click();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerDailyPulseInAddedGadget), "Header Daily Pulse not found in added gagdet");
			CommonUtil.normalWait(2000);
			dropdownSelectProject.click();
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement("//li[text()='"+projectName+"']").click();
			CommonUtil.normalWait(1000);
			dropdownSelectRelease.click();
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement("//li[text()='"+releaseName+"']").click();
			CommonUtil.normalWait(1000);
			CommonUtil.selectListWithVisibleText(selectTimeframe, timeFrame);
			CommonUtil.normalWait(1000);
			buttonSave.click();
			HomePage.getInstance().waitForProgressBarToComplete();
		
		}catch(Exception e){
			logger.info("Failed to add Daily Pulse Gadget");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean addExecutionBacklogGadget(String projectName, String releaseName, String filterBy, List<String> listOfFilterByValues, String refreshRate){
		try{
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			buttonAddNewGadget.click();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerAddGadget), "Header Add Gadget not found");
			buttonAddExecutionBacklogGadget.click();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerExecutionBacklogInAddedGadget), "Header Execution Backlog not found in added gagdet");
			CommonUtil.normalWait(3000);
			dropdownSelectProject.click();
			CommonUtil.normalWait(2000);
			CommonUtil.returnWebElement("//li[text()='"+projectName+"']").click();
			logger.info("Selected Project");
			CommonUtil.normalWait(2000);
			dropdownSelectRelease.click();
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement("//li[text()='"+releaseName+"']").click();
			CommonUtil.normalWait(1000);
			logger.info("Selected Release");
			CommonUtil.returnWebElement("//label/span[text()='"+filterBy+"']").click();
			CommonUtil.normalWait(1000);
			logger.info("Selected Filter as: " + filterBy);
			CommonUtil.returnWebElement("//label/span[text()='"+filterBy+"']/parent::label/parent::div/following-sibling::zui-inline-options//span[text()='Manage']").click();
			CommonUtil.normalWait(3000);
			logger.info("Clicked on manage");
			if(listOfFilterByValues!=null){	
				for(String values : listOfFilterByValues){
					List<WebElement> val = CommonUtil.returnWebElements("//span[@id='option']/parent::div/span[text()='"+values+"']/parent::div/preceding-sibling::div/input");
					for(WebElement v : val){
						if(v.getAttribute("hidden")!=null){
							
						}else{
							v.click();
						}
					}
					CommonUtil.normalWait(1000);
				}
				
			}else{
				
			}
			logger.info("selected the list of values");
			
			List<WebElement> close = CommonUtil.returnWebElements("//button[@class='close']");
			for(WebElement closeEach : close){
				
				if(CommonUtil.visibilityOfElementLocated(closeEach, 2)){
					closeEach.click();
				}
				
			}
			
			logger.info("Closed manage window");
			CommonUtil.normalWait(1000);
		//	dropdownSelectRefreshRate.click();
			CommonUtil.normalWait(1000);
		//	CommonUtil.returnWebElement("//li[text()='"+refreshRate+"']").click();
			CommonUtil.normalWait(1000);
			
			buttonSave.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			
			
		}catch(Exception e){
			logger.info("Failed to add Execution Backlog Gadget");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean customizwGadgetRefreshRate(String refreshRate ){
			HomePage.getInstance().waitForProgressBarToComplete();
			buttonGadgetRefreshRate.click();
			assertTrue(CommonUtil.visibilityOfElementLocated(popupGadgetRefreshRate), "Popup of GAdget Refresh is not visible");
			CommonUtil.returnWebElement("//*[@id='select2--container']").click();
			CommonUtil.returnWebElement("//*[@id='select2--results']//li[text()='"+refreshRate+"']").click();
			gadgetRefreshSaveButton.click();
			CommonUtil.normalWait(1000);
			gadgetRefreshconfirmation.click();
			CommonUtil.normalWait(2000);
			
		return true;
	
	
	}
	
	public boolean createGadgetwithCustomizeRefreshRate(String projectName, String releaseName, String refreshRate  ) {
		
		try{
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			buttonAddNewGadget.click();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerAddGadget), "Header Add Gadget not found");
			CommonUtil.normalWait(3000);
			CommonUtil.scrollToWebElement(buttonAddRequirementStatusGAdget);
			CommonUtil.normalWait(1000);
			buttonAddRequirementStatusGAdget.click();
			CommonUtil.normalWait(3000);
			dropdownSelectProject.click();
			CommonUtil.normalWait(2000);
			CommonUtil.returnWebElement("//li[text()='"+projectName+"']").click();
			logger.info("Selected Project");
			CommonUtil.normalWait(2000);
			dropdownSelectRelease.click();
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement("//li[text()='"+releaseName+"']").click();
			CommonUtil.normalWait(1000);
			logger.info("Selected Release");
			assertTrue(CommonUtil.visibilityOfElementLocated("//label[normalize-space(text())='Refresh Rate']/following-sibling::div//span[text()='"+refreshRate+"']"), "customizeRefreshrateis not present");
			CommonUtil.normalWait(3000);
			buttonSave.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			
			
		}catch(Exception e){
			logger.info("Failed to add Execution Backlog Gadget");
			e.printStackTrace();
			return false;
		}
			
				
		return true;
	}
	
	
}
