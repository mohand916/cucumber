package com.thed.zeuihtml.ze.impl.zehtmlpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;

public class UserAuthentication {

	Logger logger;

	public UserAuthentication() {
		logger = Logger.getLogger(this.getClass());
	}

	public static UserAuthentication getInstance() {
		return PageFactory.initElements(Driver.driver, UserAuthentication.class);
	}

	/******************************************************
	 * WEBELEMENTS
	 *****************************************************/

	@FindBy(xpath = "//h3/b[text()='Authentication']")
	private WebElement headerUserAuthentication;

	@FindBy(xpath = "//select[@id='authentication-system-select2']")
	private WebElement selectAuthenticationSystem;

	@FindBy(xpath = "//h4[text()='Information']/parent::div/parent::div/following-sibling::div//button[text()='Ok']")
	private WebElement buttonOkInInformationPopup;

	@FindBy(xpath = "//input[@id='ldapHost']")
	private WebElement textboxLdapHost;

	@FindBy(xpath = "//input[@id='baseDN']")
	private WebElement textboxBaseDN;

	@FindBy(xpath = "//input[@id='bindDN']")
	private WebElement textboxBindDN;

	@FindBy(xpath = "//input[@id='bindPWD']")
	private WebElement textboxBindPassword;

	@FindBy(xpath = "//input[@id='searchAttr']")
	private WebElement textboxSearchAttribute;

	@FindBy(xpath = "//input[@id='sampleUsername']")
	private WebElement textboxSampleUsername;

	@FindBy(xpath = "//input[@id='samplePassword']")
	private WebElement textboxSamplePassword;

	@FindBy(xpath = "//button[text()='Test']")
	private WebElement buttonTest;

	@FindBy(xpath = "//input[@id='serverURL']")
	private WebElement textboxServerURLForCrowd;

	@FindBy(xpath = "//input[@id='appName']")
	private WebElement textboxApplicationNameForCrowd;

	@FindBy(xpath = "//input[@id='appPWD']")
	private WebElement textboxApplicationPasswordForCrowd;

	@FindBy(xpath = "//input[@id='webServiceURL']")
	private WebElement textboxWebServiceURL;

	@FindBy(xpath = "//button[text()='Save']")
	private WebElement buttonSave;

	@FindBy(xpath = "//div[@class='main-content']/following-sibling::zui-modal[1]//button[text()='Yes']")
	private WebElement buttonYesInInformationPopup;

	/******************************************************
	 * Methods
	 *****************************************************/

	public boolean setUserAuthenticationToLdap(String ldapHost, String baseDN, String bindDN, String bindPassword,
			String searchAttribute, String userName, String password) {

		try {

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerUserAuthentication),
					"Header User Authentication not found");

			CommonUtil.selectListWithVisibleText(selectAuthenticationSystem, "LDAP");
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			buttonOkInInformationPopup.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			textboxLdapHost.sendKeys(ldapHost);
			CommonUtil.normalWait(1000);
			textboxBaseDN.sendKeys(baseDN);
			CommonUtil.normalWait(1000);
			textboxBindDN.sendKeys(bindDN);
			CommonUtil.normalWait(1000);
			textboxBindPassword.sendKeys(bindPassword);
			CommonUtil.normalWait(1000);
			textboxSearchAttribute.sendKeys(searchAttribute);
			CommonUtil.normalWait(1000);
			textboxSampleUsername.sendKeys(userName);
			CommonUtil.normalWait(1000);
			textboxSamplePassword.sendKeys(password);
			CommonUtil.normalWait(1000);
			buttonTest.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			//
			CommonUtil.normalWait(1000);
			buttonSave.click();
			CommonUtil.normalWait(1000);
			CommonUtil.visibilityOfElementLocated(buttonYesInInformationPopup);
			buttonYesInInformationPopup.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			HomePage.getInstance().closeToastPopup();
		} catch (Exception e) {
			logger.info("Failed to set Authentication to LDAP");
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean setUserAuthenticationToCrowd(String serverURL, String applicationName, String applicationPassword,
			String userName, String password) {
		try {
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerUserAuthentication),
					"Header User Authentication not found");

			CommonUtil.selectListWithVisibleText(selectAuthenticationSystem, "Crowd");
			CommonUtil.normalWait(2000);
			HomePage.getInstance().waitForProgressBarToComplete();
			buttonOkInInformationPopup.click();
			CommonUtil.normalWait(2000);
			HomePage.getInstance().waitForProgressBarToComplete();

			textboxServerURLForCrowd.sendKeys(serverURL);
			CommonUtil.normalWait(2000);
			textboxApplicationNameForCrowd.sendKeys(applicationName);
			CommonUtil.normalWait(2000);
			textboxApplicationPasswordForCrowd.sendKeys(applicationPassword);
			CommonUtil.normalWait(2000);
			textboxSampleUsername.sendKeys(userName);
			CommonUtil.normalWait(2000);
			textboxSamplePassword.sendKeys(password);
			CommonUtil.normalWait(2000);
			buttonTest.click();
			CommonUtil.normalWait(2000);
			HomePage.getInstance().waitForProgressBarToComplete();
			//
			CommonUtil.normalWait(2000);
			buttonSave.click();
			CommonUtil.normalWait(2000);
			CommonUtil.visibilityOfElementLocated(buttonYesInInformationPopup);
			buttonYesInInformationPopup.click();
			CommonUtil.normalWait(2000);
			HomePage.getInstance().waitForProgressBarToComplete();
			HomePage.getInstance().closeToastPopup();
		} catch (Exception e) {
			logger.info("Failed to set Authentication to Crowd");
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean setUserAuthenticationToWebService(String webServiceURL, String userName, String password) {
		try {
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerUserAuthentication),
					"Header User Authentication not found");

			CommonUtil.selectListWithVisibleText(selectAuthenticationSystem, "WebService");
		//	selectAuthenticationSystem.click();
			CommonUtil.normalWait(2000);
			HomePage.getInstance().waitForProgressBarToComplete();
			buttonOkInInformationPopup.click();
			CommonUtil.normalWait(2000);
			HomePage.getInstance().waitForProgressBarToComplete();
			textboxWebServiceURL.sendKeys(webServiceURL);
			CommonUtil.normalWait(2000);
			textboxSampleUsername.sendKeys(userName);
			CommonUtil.normalWait(2000);
			textboxSamplePassword.sendKeys(password);
			CommonUtil.normalWait(2000);
			buttonTest.click();
			CommonUtil.normalWait(2000);
			HomePage.getInstance().waitForProgressBarToComplete();
			//
			CommonUtil.normalWait(2000);
			buttonSave.click();
			CommonUtil.normalWait(2000);
			CommonUtil.visibilityOfElementLocated(buttonYesInInformationPopup);
			buttonYesInInformationPopup.click();
			CommonUtil.normalWait(2000);
			HomePage.getInstance().waitForProgressBarToComplete();
			HomePage.getInstance().closeToastPopup();
		} catch (Exception e) {
			logger.info("Failed to set Authentication to WebService");
			e.printStackTrace();
			return false;
		}
		return true;
	}
}
