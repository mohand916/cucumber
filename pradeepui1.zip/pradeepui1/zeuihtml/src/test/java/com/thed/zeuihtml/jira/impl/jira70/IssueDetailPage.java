package com.thed.zeuihtml.jira.impl.jira70;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;
import com.thed.zeuihtml.ze.impl.zehtmlpages.HomePage;

public class IssueDetailPage {

Logger logger;
	
	public IssueDetailPage(){
		logger = Logger.getLogger(this.getClass());
	}
	
	public static IssueDetailPage getInstance(){
		return PageFactory.initElements(Driver.driver, IssueDetailPage.class);
	}
	
	/******************************************************
	 * 	WEBELEMENTS
	 *****************************************************/
	
	@FindBy(id = "priority-val")
	private WebElement buttonPriority;
	
	@FindBy(id = "priority-field")
	private WebElement textboxPriority;
	
	@FindBy(id = "key-val")
	private WebElement keyValue;
	
	@FindBy(xpath="//div[@class='save-options']//button[@class='aui-button submit']")
	private WebElement buttonTick;
	
	/******************************************************
	 * 	Methods
	 *****************************************************/
	public boolean verifyIssueLink(String testcaseName) {
		try {
			String tcXpath = "//span[contains(@title,'"+testcaseName+"')]//span[text()='"+testcaseName+"']";
			WebElement wbTestcase = CommonUtil.returnWebElement(tcXpath);
			for (int i=0 ; i<3 ; ++i) {
				CommonUtil.normalWait(4000);
				if (CommonUtil.isElementPresent(wbTestcase)) {
					break;
				}
				else {
					CommonUtil.browserRefresh();
				}
			}
			wbTestcase.click();
		}
		catch (Exception e) {
			e.printStackTrace();
			logger.info("Failed to Verify issue link");
			return false;
		}
		return true;
	}
	
	public boolean editIssue (String issueKey, String summary, String priority) {	
		CommonUtil.normalWait(2000);
		try {
			if (keyValue.getText().equals(issueKey)) {
				if ((priority!=null)) {
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonPriority), " Priority Option not found");
					CommonUtil.moveToElement(buttonPriority);
					CommonUtil.normalWait(1500);
					buttonPriority.click();
					CommonUtil.normalWait(1500);
					textboxPriority.clear();
					textboxPriority.sendKeys(priority);
					CommonUtil.normalWait(500);
					CommonUtil.returnWebElement("//em[text()='"+priority+"']").click();
					CommonUtil.normalWait(500);
					buttonTick.click();
					CommonUtil.normalWait(3000);
					CommonUtil.browserRefresh();
					CommonUtil.alertMsg("Reload");
					//JiraHomePage.getInstance().waitForProcessToComplete();
					Assert.assertTrue(CommonUtil.returnWebElement("//span[@id='priority-val']").getText().equals(priority), "Priority value not changed");
				}
				
			}
			else {
				logger.info("Issue key does not match!");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
}
