package com.thed.zeuihtml.ze.impl.zehtmlpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.Constants;
import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;

public class LoginPage {
	
	Logger logger;
	
	public LoginPage(){
		logger = Logger.getLogger(this.getClass());
	}
	
	/******************************************************
	 * 	WEBELEMENTS
	 *****************************************************/
	
	@FindBy(xpath="//div[@class='login-wrapper']//input[@id='zee-login-username-two']")
	private WebElement usernameTextBox;
	
	@FindBy(xpath="//div[@class='login-wrapper']//input[@id='zee-login-password-two']")
	private WebElement passwordTextBox;
	
	@FindBy(xpath="//div[@class='login-wrapper']//form[contains(@class,'ng-dirty')]//button[contains(text(),'Login')]")
	private WebElement loginButton;

	@FindBy(xpath="//div[@class='login-header login-shadow']/img")
	private WebElement zephyrLogoImage;
	
	@FindBy(xpath="//div[@class='login-description']/div[@class='welcome-text']/span")
	private WebElement welcomeText;
	
	@FindBy(xpath="//div[@class='login-description']/div[@class='app-desc']/span")
	private WebElement loginPageDescription;
	
	@FindBy(xpath="//h4[text()='Reset Password']")
	private WebElement headerResetPassword;
	
	@FindBy(xpath="//input[@id='new-password-one']")
	private WebElement textboxNewPassword;
	
	@FindBy(xpath="//input[@id='confirm-password-one']")
	private WebElement textboxConfirmPassword;
	
	@FindBy(xpath="//div[@id='reset-password-modal1']//button[text()='Update']")
	private WebElement buttonUpdate;
	
	/******************************************************
	 * 	Methods
	 *****************************************************/
	
	public static LoginPage getInstance(){
		return PageFactory.initElements(Driver.driver, LoginPage.class);
	}
	
	public boolean resetPassword(String newPassword){
		
		try{
			if(CommonUtil.isElementPresent(headerResetPassword)){
				logger.info("Typing New Passsword : " + newPassword);
				CommonUtil.normalWait(500);
				textboxNewPassword.sendKeys(newPassword);
				CommonUtil.normalWait(500);
				logger.info("Typing Confirm Password : " + newPassword);
				textboxConfirmPassword.sendKeys(newPassword);
				CommonUtil.normalWait(1000);
				buttonUpdate.click();
				logger.info("Clicked Update button successfully");
				HomePage.getInstance().waitForProgressBarToComplete();
			}else{
				logger.info("Reset Password popup not found");
				return false;
			}
		}catch(Exception e){
			logger.info("Reset Password Failed");
			e.printStackTrace();
			return false;
		}
		
		return true;
	}
	
	public boolean doLogin(String username, String pwd){
		
		try{
			logger.info("Login to Zephyr started ...........");
			CommonUtil.browserRefresh();
			HomePage.getInstance().waitForProgressBarToComplete();
			if(CommonUtil.visibilityOfElementLocated(usernameTextBox, 5)){
				logger.info("Typing Username: " + username);
				usernameTextBox.sendKeys(username);
				
				if(CommonUtil.visibilityOfElementLocated(passwordTextBox)){
					logger.info("Typing Password: " + pwd);
					passwordTextBox.sendKeys(pwd);

					if(CommonUtil.visibilityOfElementLocated(loginButton)){
						CommonUtil.normalWait(2000);
						HomePage.getInstance().waitForProgressBarToComplete();
						CommonUtil.isElementClickable(loginButton);
						loginButton.click();
						logger.info("Clicking Login Button");
						CommonUtil.normalWait(5000);
						CommonUtil.implicitWait(Constants.EXPLICIT_WAIT_HIGH);
						HomePage.getInstance().waitForProgressBarToComplete();
						HomePage.getInstance().waitForLoadingToComplete();
						logger.info("Login to Zephyr completed successfully ...........");
					}else{
						logger.info("Login Button not found in login page");
						return false;
					}
					
				}else{
					logger.info("Password Textbox not found in login page");
					return false;
				}
				
			}else{
				logger.info("Username Textbox not found in login page");
				return false;
			}
			
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		
		
	}
	
	public void verifyLoginPage(){
		logger.info("Login Page verification started ...........");
		Assert.assertTrue(CommonUtil.getCurrentURL().contains(Config.getValue("ZE_URL")+"/login"), "Login Page URL not matching, " +
				"Expected: "+Config.getValue("ZE_URL")+"/login " + "Actual URL: " + CommonUtil.getCurrentURL());
		logger.info("Verified Login URL Successfully URL = "+Config.getValue("ZE_URL")+"/login");
		Assert.assertTrue(zephyrLogoImage.getAttribute("src").equals(Config.getValue("ZE_URL")+"/assets/images/logo_rebrand.png")
				, "Zephyr log image src not matched, Expected: "+Config.getValue("ZE_URL")+"/assets/images/logo.png Actulal: "
				+ zephyrLogoImage.getAttribute("src"));
		logger.info("Verified Zephyr logo image src is present successfully");
		
		String welcomeTxt = welcomeText.getText();
		Assert.assertTrue(welcomeTxt.equals("Welcome!"), "Welcome text in login page not matching, Expected: Welcome! Actual: "
				+ welcomeTxt);
		logger.info("Verified Welcome text successully");
		String loginDescription = loginPageDescription.getText();
		Assert.assertTrue(loginDescription.equals("Zephyr Enterprise has a fresh new look! Login, explore and let us know what you think."),
				"Login Description not matching, Expected: 'Zephyr Enterprise has a fresh new look! Login, explore and let us know what you think. ' Actual: "
				+ loginDescription );
		logger.info("Verified login page description successully");
		logger.info("Login Page verification completed successully..........");
	}

}



