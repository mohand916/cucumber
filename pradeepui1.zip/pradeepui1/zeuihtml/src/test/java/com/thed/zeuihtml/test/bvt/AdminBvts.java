package com.thed.zeuihtml.test.bvt;


import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.thed.zeuihtml.BaseTest;
import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.utils.CommonUtil;

public class AdminBvts extends BaseTest {


	public AdminBvts() {
		logger = Logger.getLogger(this.getClass());
	}

	@Test(enabled = testEnabled, priority = 1)
	public void bvt1_launchZephyrTest() {
		CommonUtil.alertMsg("executing bvt1...");
		logger.info("Executing bvt1...");
		altID = 1;
		testcaseId = "218";
		
		zeNavigator.verifyLoginPage();
		isSuccess = true;
		logger.info("bvt1 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 2)
	public void bvt2_loginToZephyrTest() {
		CommonUtil.alertMsg("executing bvt2...");
		logger.info("Executing bvt2...");
		altID = 2;
		testcaseId = "219";

		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		zeNavigator.verifyProjectSummaryPage("Sample Project", "Test Manager", null, null, null, null, null);
		isSuccess = true;
		logger.info("bvt2 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 3)
	public void bvt3_launchAllAppsTest() {
		CommonUtil.alertMsg("executing bvt3...");
		logger.info("Executing bvt3...");
		altID = 3;

		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown("Release 1.0"), "Not selected release.");
		zeNavigator.launchReleaseApp("Requirements");
		zeNavigator.launchReleaseApp("Test Repository");
		zeNavigator.launchReleaseApp("Test Planning");
		zeNavigator.launchReleaseApp("Test Execution");

		isSuccess = true;
		logger.info("bvt3 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 4)
	public void bvt4_setMailComapanyAndSystemNameTest() {
		CommonUtil.alertMsg("executing bvt4...");
		logger.info("Executing bvt4...");
		altID = 4;
		zeNavigator.launchAdministration();
		zeNavigator.changeSystemConfigurations("Zephyr", "QA", Config.getValue("MAILSERVER_IP"),
				Config.getValue("MAILSERVER_PORT"), Config.getValue("MAILSERVER_USERNAME"),
				Config.getValue("MAILSERVER_PASSWORD"));
		zeNavigator.verifySystemConfigPage("Zephyr", "QA", Config.getValue("ZE_DESKTOP_URL"),
				Config.getValue("ZE_DASHBOARD_URL"), Config.getValue("MAILSERVER_IP"),
				Config.getValue("MAILSERVER_PORT"), Config.getValue("MAILSERVER_USERNAME"));
		isSuccess = true;
		logger.info("bvt4 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 5)
	public void bvt5_setDTJiraTest() {
		CommonUtil.alertMsg("executing bvt5...");
		logger.info("Executing bvt5...");
		altID = 5;
		Assert.assertTrue(zeNavigator.launchAdministration(), "Failed to navigate Administration Page");
		
		isSuccess = zeNavigator.setDefectTracking();
		Assert.assertTrue(isSuccess, "Failed to set Defect Tracking");
		logger.info("bvt5 is executed successfully.");
	}

	@Test(enabled = false, priority = 6)
	public void bvt6_setDefectUserInDefectAdminTest() {
		CommonUtil.alertMsg("executing bvt6...");
		logger.info("Executing bvt6...");
		altID = 6;
		
		isSuccess = zeNavigator.setUserJiraCredentialsinExternalPopup();
		Assert.assertTrue(isSuccess, "Failed to set User Credentials in External popup");
		//zeNavigator.launchAdminApps("ManageProjects");
		logger.info("bvt6 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 7)
	public void bvt7_addTestcaseCustomFieldsTest() {
		CommonUtil.alertMsg("executing bvt7...");
		logger.info("Executing bvt7...");
		altID = 7;

		List<String> pickListValues = new ArrayList<String>();
		pickListValues.add(0, Config.getTCRPropValue("TC_PICKLIST_VALUE_1"));
		pickListValues.add(1, Config.getTCRPropValue("TC_PICKLIST_VALUE_2"));
		pickListValues.add(2, Config.getTCRPropValue("TC_PICKLIST_VALUE_3"));
		pickListValues.add(3, Config.getTCRPropValue("TC_PICKLIST_VALUE_4"));
		
//		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		Assert.assertTrue(zeNavigator.launchAdminApps("Customizations"), "Failed to launch Customization App");
		Assert.assertTrue(zeNavigator.launchCustomizationOptions("TestcaseCustomField"),
				"Failed to launch Testcase Custom Field Window");
//		Assert.assertTrue(zeNavigator.lockZephyrAccess(true), "Failed to lock Zephyr");

		Assert.assertTrue(
				zeNavigator.addCustomField(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_1"),
						Config.getTCRPropValue("TEXT_CUSTOM_FIELD_TYPE"),
						Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_1"), true, false, null, true),
				"Failed to Add custom field");
		Assert.assertTrue(
				zeNavigator.addCustomField(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_2"),
						Config.getTCRPropValue("LONGTEXT_CUSTOM_FIELD_TYPE"),
						Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_2"), true, false, null, true),
				"Failed to Add custom field");
		Assert.assertTrue(
				zeNavigator.addCustomField(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_3"),
						Config.getTCRPropValue("CHECKBOX_CUSTOM_FIELD_TYPE"),
						Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_3"), true, false, null, true),
				"Failed to Add custom field");
		Assert.assertTrue(
				zeNavigator.addCustomField(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_4"),
						Config.getTCRPropValue("DATE_CUSTOM_FIELD_TYPE"),
						Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_4"), false, false, null, true),
				"Failed to Add custom field");
		Assert.assertTrue(
				zeNavigator.addCustomField(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_5"),
						Config.getTCRPropValue("NUMBER_CUSTOM_FIELD_TYPE"),
						Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_5"), true, false, null, true),
				"Failed to Add custom field");
		Assert.assertTrue(
				zeNavigator.addCustomFieldPicklist(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_6"),
						Config.getTCRPropValue("PICKLIST_CUSTOM_FIELD_TYPE"),
						Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_6"), true, false, pickListValues, null, true),
				"Failed to Add custom field");

		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_1"),
						Config.getTCRPropValue("TEXT_CUSTOM_FIELD_TYPE"),
						Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_1"), true, false),
				"Custom Field verification failed");
		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_2"),
						Config.getTCRPropValue("LONGTEXT_CUSTOM_FIELD_TYPE"),
						Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_2"), true, false),
				"Custom Field verification failed");
		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_3"),
						Config.getTCRPropValue("CHECKBOX_CUSTOM_FIELD_TYPE"),
						Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_3"), true, false),
				"Custom Field verification failed");
		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_4"),
						Config.getTCRPropValue("DATE_CUSTOM_FIELD_TYPE"),
						Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_4"), true, false),
				"Custom Field verification failed");
		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_5"),
						Config.getTCRPropValue("NUMBER_CUSTOM_FIELD_TYPE"),
						Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_5"), true, false),
				"Custom Field verification failed");
		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_6"),
						Config.getTCRPropValue("PICKLIST_CUSTOM_FIELD_TYPE"),
						Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_6"), true, false),
				"Custom Field verification failed");

		//Assert.assertTrue(zeNavigator.lockZephyrAccess(false), "Failed to unlock Zephyr Access");
		zeNavigator.closeCustomfield();
		isSuccess = true;
		logger.info("bvt7 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 8)
	public void bvt8_addRequirementCustomFieldsTest() {
		CommonUtil.alertMsg("executing bvt8...");
		logger.info("Executing bvt8...");
		altID = 8;

		List<String> pickListValues = new ArrayList<String>();
		pickListValues.add(0, Config.getReqPropValue("RQ_PICKLIST_VALUE_1"));
		pickListValues.add(1, Config.getReqPropValue("RQ_PICKLIST_VALUE_2"));
		pickListValues.add(2, Config.getReqPropValue("RQ_PICKLIST_VALUE_3"));
		pickListValues.add(3, Config.getReqPropValue("RQ_PICKLIST_VALUE_4"));

//		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		Assert.assertTrue(zeNavigator.launchAdminApps("Customizations"), "Failed to launch Customization App");
		Assert.assertTrue(zeNavigator.launchCustomizationOptions("RequirementCustomField"),
				"Failed to launch Requirement Custom Field Window");
		//Assert.assertTrue(zeNavigator.lockZephyrAccess(true), "Failed to lock Zephyr");

		Assert.assertTrue(
				zeNavigator.addCustomField(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_1"),
						Config.getReqPropValue("TEXT_CUSTOM_FIELD_TYPE"),
						Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_1"), true, false, null, true),
				"Failed to Add custom field");
		Assert.assertTrue(
				zeNavigator.addCustomField(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_2"),
						Config.getReqPropValue("LONGTEXT_CUSTOM_FIELD_TYPE"),
						Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_2"), true, false, null, true),
				"Failed to Add custom field");
		Assert.assertTrue(
				zeNavigator.addCustomField(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_3"),
						Config.getReqPropValue("CHECKBOX_CUSTOM_FIELD_TYPE"),
						Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_3"), true, false, null, true),
				"Failed to Add custom field");
		Assert.assertTrue(
				zeNavigator.addCustomField(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_4"),
						Config.getReqPropValue("DATE_CUSTOM_FIELD_TYPE"),
						Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_4"), false, false, null, true),
				"Failed to Add custom field");
		Assert.assertTrue(
				zeNavigator.addCustomField(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_5"),
						Config.getReqPropValue("NUMBER_CUSTOM_FIELD_TYPE"),
						Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_5"), true, false, null, true),
				"Failed to Add custom field");
		Assert.assertTrue(
				zeNavigator.addCustomFieldPicklist(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_6"),
						Config.getReqPropValue("PICKLIST_CUSTOM_FIELD_TYPE"),
						Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_6"), true, false, pickListValues, null, true),
				"Failed to Add custom field");

		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_1"),
						Config.getReqPropValue("TEXT_CUSTOM_FIELD_TYPE"),
						Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_1"), true, false),
				"Custom Field verification failed");
		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_2"),
						Config.getReqPropValue("LONGTEXT_CUSTOM_FIELD_TYPE"),
						Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_2"), true, false),
				"Custom Field verification failed");
		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_3"),
						Config.getReqPropValue("CHECKBOX_CUSTOM_FIELD_TYPE"),
						Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_3"), true, false),
				"Custom Field verification failed");
		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_4"),
						Config.getReqPropValue("DATE_CUSTOM_FIELD_TYPE"),
						Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_4"), true, false),
				"Custom Field verification failed");
		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_5"),
						Config.getReqPropValue("NUMBER_CUSTOM_FIELD_TYPE"),
						Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_5"), true, false),
				"Custom Field verification failed");
		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_6"),
						Config.getReqPropValue("PICKLIST_CUSTOM_FIELD_TYPE"),
						Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_6"), true, false),
				"Custom Field verification failed");

//		Assert.assertTrue(zeNavigator.lockZephyrAccess(false), "Failed to unlock Zephyr Access");
		zeNavigator.closeCustomfield();
		isSuccess = true;
		logger.info("bvt8 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 9)
	public void bvt9_addProjectCustomFieldsTest() {
		CommonUtil.alertMsg("executing bvt9...");
		logger.info("Executing bvt9...");
		altID = 9;

		List<String> pickListValues = new ArrayList<String>();
		pickListValues.add(0, Config.getProjectPropValue("PR_PICKLIST_VALUE_1"));
		pickListValues.add(1, Config.getProjectPropValue("PR_PICKLIST_VALUE_2"));
		pickListValues.add(2, Config.getProjectPropValue("PR_PICKLIST_VALUE_3"));
		pickListValues.add(3, Config.getProjectPropValue("PR_PICKLIST_VALUE_4"));

	//	zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		Assert.assertTrue(zeNavigator.launchAdminApps("Customizations"), "Failed to launch Customization App");
		Assert.assertTrue(zeNavigator.launchCustomizationOptions("ProjectCustomFiled"),
				"Failed to launch Project Custom Field Window");

		Assert.assertTrue(
				zeNavigator.addCustomField(Config.getProjectPropValue("PR_CUSTOM_FIELD_NAME_1"),
						Config.getProjectPropValue("TEXT_CUSTOM_FIELD_TYPE"),
						Config.getProjectPropValue("PR_CUSTOM_FIELD_DESCRIPTION_1"), false, false, null, true),
				"Failed to Add custom field");
		
		
		Assert.assertTrue(
				zeNavigator.addCustomField(Config.getProjectPropValue("PR_CUSTOM_FIELD_NAME_2"),
						Config.getProjectPropValue("NUMBER_CUSTOM_FIELD_TYPE"),
						Config.getProjectPropValue("PR_CUSTOM_FIELD_DESCRIPTION_2"), false, false, null, true),
				"Failed to Add custom field");
		Assert.assertTrue(
				zeNavigator.addCustomFieldPicklist(Config.getProjectPropValue("PR_CUSTOM_FIELD_NAME_3"),
						Config.getProjectPropValue("PICKLIST_CUSTOM_FIELD_TYPE"),
						Config.getProjectPropValue("PR_CUSTOM_FIELD_DESCRIPTION_3"), false, false, pickListValues, null, true),
				"Failed to Add custom field");

		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getProjectPropValue("PR_CUSTOM_FIELD_NAME_1"),
						Config.getProjectPropValue("TEXT_CUSTOM_FIELD_TYPE"),
						Config.getProjectPropValue("PR_CUSTOM_FIELD_DESCRIPTION_1"), false, false),
				"Custom Field verification failed");
		
		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getProjectPropValue("PR_CUSTOM_FIELD_NAME_2"),
						Config.getProjectPropValue("NUMBER_CUSTOM_FIELD_TYPE"),
						Config.getProjectPropValue("PR_CUSTOM_FIELD_DESCRIPTION_2"), false, false),
				"Custom Field verification failed");
		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getProjectPropValue("PR_CUSTOM_FIELD_NAME_3"),
						Config.getProjectPropValue("PICKLIST_CUSTOM_FIELD_TYPE"),
						Config.getProjectPropValue("PR_CUSTOM_FIELD_DESCRIPTION_3"), false, false),
				"Custom Field verification failed");

//		Assert.assertTrue(zeNavigator.lockZephyrAccess(false), "Failed to unlock Zephyr Access");
		zeNavigator.closeCustomfield();
		isSuccess = true;
		logger.info("bvt9 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority=10 )
	public void bvt10_updateCutomField(){
		CommonUtil.alertMsg("executing bvt10...");
		logger.info("Executing bvt10...");
		altID =10;
		
		Assert.assertTrue(zeNavigator.launchAdminApps("Customizations"), "Failed to launch Customization App");
		Assert.assertTrue(zeNavigator.launchCustomizationOptions("ProjectCustomFiled"),
				"Failed to launch Project Custom Field Window");
		Assert.assertTrue(
				zeNavigator.addCustomField(Config.getProjectPropValue("PR_CUSTOM_FIELD_NAME_UPDATE"),
						Config.getProjectPropValue("TEXT_CUSTOM_FIELD_TYPE"),
						Config.getProjectPropValue("PR_CUSTOM_FIELD_DESCRIPTION_UPDATE"), false, false, null, true),
				"Failed to Add custom field");
		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getProjectPropValue("PR_CUSTOM_FIELD_NAME_UPDATE"),
						Config.getProjectPropValue("TEXT_CUSTOM_FIELD_TYPE"),
						Config.getProjectPropValue("PR_CUSTOM_FIELD_DESCRIPTION_UPDATE"), false, false),
				"Custom Field verification failed");
		Assert.assertTrue(zeNavigator.editCustomfield(Config.getProjectPropValue("PR_CUSTOM_FIELD_NAME_UPDATE"), Config.getProjectPropValue("PR_CUSTOM_FIELD_NAME_DELETE")), "Customfield Update fail");
		zeNavigator.closeCustomfield();
		isSuccess = true;
		logger.info("bvt10 is executed successfully");
		
	}
	
	@Test(enabled = testEnabled, priority=11)
	public void bvt11_deleteCustomfield(){
		CommonUtil.alertMsg("executing bvt11...");
		logger.info("Executing bvt11...");
		altID = 11;
		
		Assert.assertTrue(zeNavigator.launchAdminApps("Customizations"), "Failed to launch Customization App");
		Assert.assertTrue(zeNavigator.launchCustomizationOptions("ProjectCustomFiled"),
				"Failed to launch Project Custom Field Window");
		Assert.assertTrue(zeNavigator.deleteCustomfield(Config.getProjectPropValue("PR_CUSTOM_FIELD_NAME_DELETE")), "Customfield Deleted Successfully");
		zeNavigator.closeCustomfield();
		isSuccess = true;
		logger.info("bvt11 is executed successfully...");
	}

	@Test(enabled = testEnabled, priority = 12)
	public void bvt12_addExecutionCustomStatusTest() {
		CommonUtil.alertMsg("executing bvt12...");
		logger.info("Executing bvt12...");
		altID = 12;
		
		Assert.assertTrue(zeNavigator.launchAdministration(), "Failed to navigate Administration Page");
		Assert.assertTrue(zeNavigator.launchAdminApps("Customizations"), "Failed to launch Customization App");
		Assert.assertTrue(zeNavigator.launchCustomizationOptions("ExecutionStatus"),
				"Failed to launch Manage Execution Status Window");
		System.out.println(Config.getTCEPropValue("CUSTOM_EXECUTION_STATUS_1"));
		String customExecutionStatus = Config.getTCEPropValue("CUSTOM_EXECUTION_STATUS_1");
		Assert.assertTrue(zeNavigator.addExecutionStatus(customExecutionStatus),
				"Failed to Add Custom Status by name: " + customExecutionStatus);
		zeNavigator.verifyExecutionStatus(customExecutionStatus, true);
		isSuccess = true;
		logger.info("bvt12 is completed successfully...");
	}

	@Test(enabled = testEnabled, priority = 13)
	public void bvt13_addStepExecutionCustomStatusTest() {
		CommonUtil.alertMsg("executing bvt13...");
		logger.info("Executing bvt13...");
		altID = 13;
		Assert.assertTrue(zeNavigator.launchAdministration(), "Failed to navigate Administration Page");
		Assert.assertTrue(zeNavigator.launchAdminApps("Customizations"), "Failed to launch Customization App");
		Assert.assertTrue(zeNavigator.launchCustomizationOptions("StepExecutionStatus"),
				"Failed to launch Manage Execution Status Window");
		String customExecutionStatus = Config.getTCEPropValue("CUSTOM_STEP_EXECUTION_STATUS_1");
		Assert.assertTrue(zeNavigator.addExecutionStatus(customExecutionStatus),
				"Failed to Add Custom Status by name: " + customExecutionStatus);
		zeNavigator.verifyExecutionStatus(customExecutionStatus, true);
		isSuccess = true;
		logger.info("bvt13 is completed successfully...");
	}

	@Test(enabled = testEnabled, priority = 14)
	public void bvt14_updateEstimatedTimeTest() {
		CommonUtil.alertMsg("executing bvt14...");
		logger.info("Executing bvt14...");
		altID = 14;

		Assert.assertTrue(zeNavigator.launchAdministration(), "Failed to navigate Administration Page");
		
		Assert.assertTrue(zeNavigator.launchAdminApps("Customizations"), "Failed to launch Customization App");
		Assert.assertTrue(zeNavigator.launchCustomizationOptions("EstimatedTime"),
				"Failed to launch Manage Execution Status Window");
		Assert.assertTrue(zeNavigator.updateDefaultEstimatedTime(Config.getTCRPropValue("NEW_ESTIMATED_TIME")),
				"Failed to update estimation time");
		Assert.assertTrue(zeNavigator.launchCustomizationOptions("EstimatedTime"),
				"Failed to launch Manage Execution Status Window");
		zeNavigator.verifyEstimatedTime(Config.getTCRPropValue("NEW_ESTIMATED_TIME"));
		isSuccess = true;
		logger.info("bvt14 is completed successfully...");
	}

	@Test(enabled = testEnabled, priority = 15)
	public void bvt15_updateEstimatedTimeToDefaultTest() {
		CommonUtil.alertMsg("executing bvt15...");
		logger.info("Executing bvt15...");
		altID = 15;

		Assert.assertTrue(zeNavigator.launchAdministration(), "Failed to navigate Administration Page");
		
		Assert.assertTrue(zeNavigator.launchAdminApps("Customizations"), "Failed to launch Customization App");
		Assert.assertTrue(zeNavigator.launchCustomizationOptions("EstimatedTime"),
				"Failed to launch Manage Execution Status Window");
		Assert.assertTrue(zeNavigator.updateDefaultEstimatedTime(Config.getTCRPropValue("DEFAULT_ESTIMATED_TIME")),
				"Failed to update estimation time");
		Assert.assertTrue(zeNavigator.launchCustomizationOptions("EstimatedTime"),
				"Failed to launch Manage Execution Status Window");
		zeNavigator.verifyEstimatedTime(Config.getTCRPropValue("DEFAULT_ESTIMATED_TIME"));
		isSuccess = true;
		logger.info("bvt15 is completed successfully...");
	}

	@Test(enabled = testEnabled, priority = 16)
	public void bvt16_addNewLeadWithMandatoryFieldsTest() {
		CommonUtil.alertMsg("executing bvt16...");
		logger.info("Executing bvt16...");
		altID = 16;

		Assert.assertTrue(zeNavigator.launchAdminApps("UserSetup"), "Failed to launch User setup App");
		Assert.assertTrue(
				zeNavigator.addNewUser(Config.getUsersPropValue("USER1_FIST_LAST_NAME"),
						Config.getUsersPropValue("USER1_ROLE"), Config.getUsersPropValue("USER1_EMAIL"),
						Config.getUsersPropValue("USER1_LOCATION")),
				"Failed to add new user, please check logs for details");
		zeNavigator.verifyUser(Config.getUsersPropValue("USER1_FIST_LAST_NAME"),
				Config.getUsersPropValue("USER1_ROLE"), Config.getUsersPropValue("USER1_EMAIL"),
				Config.getUsersPropValue("USER1_LOCATION"));
		isSuccess = true;

		logger.info("bvt16 is completed successfully...");
	}

	@Test(enabled = testEnabled, priority = 17)
	public void bvt17_addNewTesterWithMandatoryFieldsTest() {
		CommonUtil.alertMsg("executing bvt17...");
		logger.info("Executing bvt17...");
		altID = 17;
		Assert.assertTrue(zeNavigator.launchAdminApps("UserSetup"), "Failed to launch User setup App");
		Assert.assertTrue(
				zeNavigator.addNewUser(Config.getUsersPropValue("USER2_FIST_LAST_NAME"),
						Config.getUsersPropValue("USER2_ROLE"), Config.getUsersPropValue("USER2_EMAIL"),
						Config.getUsersPropValue("USER2_LOCATION")),
				"Failed to add new user, please check logs for details");
		zeNavigator.verifyUser(Config.getUsersPropValue("USER2_FIST_LAST_NAME"),
				Config.getUsersPropValue("USER2_ROLE"), Config.getUsersPropValue("USER2_EMAIL"),
				Config.getUsersPropValue("USER2_LOCATION"));
		isSuccess = true;
		logger.info("bvt17 is completed successfully...");
	}

	@Test(enabled = testEnabled, priority = 18)
	public void bvt18_addNewDashboardUserWithMandatoryFieldsTest() {
		CommonUtil.alertMsg("executing bvt18...");
		logger.info("Executing bvt18...");
		altID = 18;

		Assert.assertTrue(
				zeNavigator.addNewUser(Config.getUsersPropValue("USER3_FIST_LAST_NAME"),
						Config.getUsersPropValue("USER3_ROLE"), Config.getUsersPropValue("USER3_EMAIL"),
						Config.getUsersPropValue("USER3_LOCATION")),
				"Failed to add new user, please check logs for details");
		zeNavigator.verifyUser(Config.getUsersPropValue("USER3_FIST_LAST_NAME"),
				Config.getUsersPropValue("USER3_ROLE"), Config.getUsersPropValue("USER3_EMAIL"),
				Config.getUsersPropValue("USER3_LOCATION"));
		CommonUtil.normalWait(1000);
		isSuccess = true;
		logger.info("bvt18 is completed successfully...");
	}

	@Test(enabled = testEnabled, priority = 19)
	public void bvt19_addNormalProjectTest() {
		CommonUtil.alertMsg("executing bvt19...");
		logger.info("Executing bvt19...");
		altID = 19;

		Assert.assertTrue(zeNavigator.launchAdminApps("ProjectSetup"), "Failed to launch Project setup App");
		zeNavigator.addNewProject(Config.getProjectPropValue("PROJECT1_NAME"),
				Config.getProjectPropValue("PROJECT1_TYPE"), Config.getProjectPropValue("PROJECT1_DESCRIPTION"),
				Config.getProjectPropValue("PROJECT1_STARTDATE"), null, null, null);
		zeNavigator.verifyProject(Config.getProjectPropValue("PROJECT1_NAME"),
				Config.getProjectPropValue("PROJECT1_TYPE"), Config.getProjectPropValue("PROJECT1_DESCRIPTION"),
				Config.getProjectPropValue("PROJECT1_STARTDATE"), null, null, null, null, null);
		isSuccess = true;
		logger.info("bvt19 is completed successfully...");
	}

	@Test(enabled = testEnabled, priority = 20)
	public void bvt20_addRestrictedProjectTest() {
		CommonUtil.alertMsg("executing bvt20...");
		logger.info("Executing bvt20...");
		altID = 20;

		Assert.assertTrue(zeNavigator.launchAdminApps("ProjectSetup"), "Failed to launch Project setup App");
		zeNavigator.addNewProject(Config.getProjectPropValue("PROJECT2_NAME"),
				Config.getProjectPropValue("PROJECT2_TYPE"), Config.getProjectPropValue("PROJECT2_DESCRIPTION"),
				Config.getProjectPropValue("PROJECT2_STARTDATE"), null, null, null);
		zeNavigator.verifyProject(Config.getProjectPropValue("PROJECT2_NAME"),
				Config.getProjectPropValue("PROJECT2_TYPE"), Config.getProjectPropValue("PROJECT2_DESCRIPTION"),
				Config.getProjectPropValue("PROJECT2_STARTDATE"), null, null, null,null, null);
		isSuccess = true;
		logger.info("bvt20 is completed successfully...");

	}

	@Test(enabled = testEnabled, priority = 21)
	public void bvt21_addIsolatedProjectTest() {
		CommonUtil.alertMsg("executing bvt21...");
		logger.info("Executing bvt21...");
		altID = 21;

		Assert.assertTrue(zeNavigator.launchAdminApps("ProjectSetup"), "Failed to launch Project setup App");
		zeNavigator.addNewProject(Config.getProjectPropValue("PROJECT3_NAME"),
				Config.getProjectPropValue("PROJECT3_TYPE"), Config.getProjectPropValue("PROJECT3_DESCRIPTION"),
				Config.getProjectPropValue("PROJECT3_STARTDATE"), null, null, null);
		zeNavigator.verifyProject(Config.getProjectPropValue("PROJECT3_NAME"),
				Config.getProjectPropValue("PROJECT3_TYPE"), Config.getProjectPropValue("PROJECT3_DESCRIPTION"),
				Config.getProjectPropValue("PROJECT3_STARTDATE"), null, null, null,null,null);
		isSuccess = true;
		logger.info("bvt21 is completed successfully...");

	}
	
	@Test(enabled = testEnabled, priority = 22)
	public void bvt22_addLeadTwoTesterAndDashboardUserInProjectTest() {
		CommonUtil.alertMsg("executing bvt22...");
		logger.info("Executing bvt22...");
		altID = 22;
	//	zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		Assert.assertTrue(zeNavigator.launchAdministration(), "Failed to navigate Administration Page");
		Assert.assertTrue(zeNavigator.launchAdminApps("ProjectSetup"), "Failed to launch Project setup App");
		String leadName = Config.getUsersPropValue("USER1_FIST_LAST_NAME");
		List<String> resourceNamesToAdd = new ArrayList<String>();
		resourceNamesToAdd.add(0,Config.getUsersPropValue("TESTER"));
		resourceNamesToAdd.add(1,Config.getUsersPropValue("USER2_FIST_LAST_NAME"));
		resourceNamesToAdd.add(2,Config.getUsersPropValue("USER3_FIST_LAST_NAME"));

		zeNavigator.editProject(Config.getProjectPropValue("PROJECT1_NAME"), null, null, null, null, null, leadName, 
				null, null, null, resourceNamesToAdd, null, null);
		
		zeNavigator.verifyProject(Config.getProjectPropValue("PROJECT1_NAME"), null, null, null, null, 
				leadName, null, resourceNamesToAdd, "4");
		
		isSuccess = true;
		logger.info("bvt22 is completed successfully...");

	}
	
	@Test(enabled = testEnabled, priority = 23)
	public void bvt23_addLeadAndTesterInRestrictedProjectTest() {
		CommonUtil.alertMsg("executing bvt23...");
		logger.info("Executing bvt23...");
		altID = 23;
		
		Assert.assertTrue(zeNavigator.launchAdminApps("ProjectSetup"), "Failed to launch Project setup App");
		String leadName = Config.getUsersPropValue("LEAD");
		List<String> resourceNamesToAdd = new ArrayList<String>();
		resourceNamesToAdd.add(0,Config.getUsersPropValue("TESTER"));

		zeNavigator.editProject(Config.getProjectPropValue("PROJECT2_NAME"), null, null, null, null, null, leadName, 
				null, null, null, resourceNamesToAdd, null, null);
		
		zeNavigator.verifyProject(Config.getProjectPropValue("PROJECT2_NAME"), null, null, null, null, 
				leadName, null, resourceNamesToAdd, "2");
		
		isSuccess = true;
		logger.info("bvt23 is completed successfully...");

	}
	
	@Test(enabled = testEnabled, priority = 24)
	public void bvt24_addLeadAndDashboardUserInIsolatedProjectTest() {
		CommonUtil.alertMsg("executing bvt24...");
		logger.info("Executing bvt24...");
		altID = 24;
		
		Assert.assertTrue(zeNavigator.launchAdminApps("ProjectSetup"), "Failed to launch Project setup App");
		String leadName = Config.getUsersPropValue("LEAD");
		List<String> resourceNamesToAdd = new ArrayList<String>();
		resourceNamesToAdd.add(0,Config.getUsersPropValue("USER3_FIST_LAST_NAME"));

		zeNavigator.editProject(Config.getProjectPropValue("PROJECT3_NAME"), null, null, null, null, null, leadName, 
				null, null, null, resourceNamesToAdd, null, null);
		
		zeNavigator.verifyProject(Config.getProjectPropValue("PROJECT3_NAME"), null, null, null, null, 
				leadName, null, resourceNamesToAdd, "2");
		
		isSuccess = true;
		logger.info("bvt21 is completed successfully...");

	}
	
	@Test(enabled = testEnabled, priority = 25)
	public void bvt25_mapZephyrProjectToJiraProjectAndCheckActivityStreamTest() {
		CommonUtil.alertMsg("executing bvt25...");
		logger.info("Executing bvt25...");
		altID = 25;
		
		Assert.assertTrue(zeNavigator.launchAdminApps("ProjectSetup"), "Failed to launch Project setup App");
		zeNavigator.editProject(Config.getProjectPropValue("DEFAULT_PROJECT"), null, null, null, null, null, null, 
				Config.getProjectPropValue("JIRA_PROJECT_NAME"), null, null, null, null, null);	
		CommonUtil.normalWait(5000);
		String parentWindowId = CommonUtil.launchNewBrowserWindow(Config.getValue("JIRA_URL"));
		CommonUtil.normalWait(5000);
		isSuccess = jiraNavigator.doJiraLogin(Config.getValue("JIRA_USERNAME"), Config.getValue("JIRA_PASSWORD"));
		CommonUtil.normalWait(5000);
		CommonUtil.browserRefresh();
		CommonUtil.normalWait(5000);
		if(isSuccess) {
			isSuccess = jiraNavigator.verifyNewMappedProject(Config.getProjectPropValue("DEFAULT_PROJECT"), Config.getProjectPropValue("JIRA_PROJECT_NAME"));
		}

		CommonUtil.closeCurrentBrowserWindow();
		CommonUtil.returnToParentWindow(parentWindowId);
		Assert.assertTrue(isSuccess, "Activity Stream not found in Jira");
		
		logger.info("bvt25 is completed successfully...");

	}
	
	@Test(enabled = testEnabled, priority = 26)
	public void bvt26_updateProjCustomfieldvalue(){
		CommonUtil.alertMsg("Executing bvt26...");
		logger.info("Executing bvt26...");
		altID = 26;
		
		Assert.assertTrue(zeNavigator.launchAdminApps("ProjectSetup"), "Failed to launch Project setup App");
		zeNavigator.editProject(Config.getProjectPropValue("PROJECT1_NAME"), null, null, null, null, null, null, null, null, Config.getProjectPropValue("PR_CUSTOM_FILED_NAME1_VALUE"), null, null, null);
		isSuccess = true;
		logger.info("bvt26 is completed successfully...");
	}
	
	@Test(enabled = testEnabled, priority = 27)
	public void bvt27_createCustomRoleTest() {
		CommonUtil.alertMsg("executing bvt27...");
		logger.info("Executing bvt27...");
		altID = 27;
		Assert.assertTrue(zeNavigator.launchAdministration(), "Failed to navigate Administration Page");
		Assert.assertTrue(zeNavigator.launchAdminApps("Customizations"), "Failed to launch Customization App");
		Assert.assertTrue(zeNavigator.launchCustomizationOptions("Roles"),
				"Failed to launch Customize Roles Window");
	
		Assert.assertTrue(zeNavigator.addNewRole(Config.getUsersPropValue("ROLE_NAME"), Config.getUsersPropValue("ROLE_DESCRIPTION"), false, true, true, false, 
				true, true, true, true, true, true, true), "Failed to create new Role");
		
		Assert.assertTrue(zeNavigator.launchCustomizationOptions("Roles"),
				"Failed to launch Customize Roles Window");
		zeNavigator.verifyRole(Config.getUsersPropValue("ROLE_NAME"), Config.getUsersPropValue("ROLE_DESCRIPTION"), true);
		isSuccess = true;
		logger.info("bvt27 is completed successfully...");

	}
	
	@Test(enabled = testEnabled, priority = 28)
	public void bvt28_addNewCustomRoleUserTest() {
		CommonUtil.alertMsg("executing bvt28...");
		logger.info("Executing bvt28...");
		altID = 28;

		Assert.assertTrue(zeNavigator.launchAdminApps("UserSetup"), "Failed to launch User setup App");
		Assert.assertTrue(
				zeNavigator.addNewUser(Config.getUsersPropValue("USER4_FIST_LAST_NAME"),
						Config.getUsersPropValue("USER4_ROLE"), Config.getUsersPropValue("USER4_EMAIL"),
						Config.getUsersPropValue("USER4_LOCATION")),
				"Failed to add new custom role user, please check logs for details");
		zeNavigator.verifyUser(Config.getUsersPropValue("USER4_FIST_LAST_NAME"),
				Config.getUsersPropValue("USER4_ROLE"), Config.getUsersPropValue("USER4_EMAIL"),
				Config.getUsersPropValue("USER4_LOCATION"));
		isSuccess = true;
		logger.info("bvt28 is completed successfully...");
	}
	
	
	@Test(enabled = testEnabled, priority = 29)
	public void bvt29_assingMultipleProjectsToCustomRoleUserTest(){
		CommonUtil.alertMsg("executing bvt29...");
		logger.info("Executing bvt29...");
		altID = 29;
		
		List<String> projectNamesToAdd = new ArrayList<String>();
		projectNamesToAdd.add(0,Config.getProjectPropValue("PROJECT1_NAME"));
		projectNamesToAdd.add(1,Config.getProjectPropValue("PROJECT2_NAME"));
		projectNamesToAdd.add(2,Config.getProjectPropValue("PROJECT3_NAME"));
		
		
		Assert.assertTrue(zeNavigator.assignProjectsToUser(Config.getUsersPropValue("USER4_FIST_LAST_NAME"), projectNamesToAdd)
				, "Failed to assing project to user : " + Config.getUsersPropValue("USER4_FIST_LAST_NAME"));
		
		zeNavigator.verifyProjectsAssignedToUser(Config.getUsersPropValue("USER4_FIST_LAST_NAME"), projectNamesToAdd);
		
		isSuccess = true;
		logger.info("bvt29 is completed successfully...");
	}
	
	@Test(enabled = testEnabled, priority = 30)
	public void bvt30_loginAsCustomRoleAndVerifyAppsTest(){
		CommonUtil.alertMsg("executing bvt30...");
		logger.info("Executing bvt30...");
		altID = 30;
		
//		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		zeNavigator.logout();
		zeNavigator.doLogin(Config.getUsersPropValue("USER4_USERNAME"), Config.getUsersPropValue("USER4_USERNAME"));
		zeNavigator.resetPassword(Config.getUsersPropValue("USER4_PASSWORD"));
		
		zeNavigator.launchAdministration();
		zeNavigator.verifyAdminAppsToBePresent(false, true, true, false);
		zeNavigator.selectProject("Success Meet");
		String releaseName = "Release 1.0";
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.verifyReleaseAppsToBePresent(true, true, true, true, true, true);
		
		isSuccess = true;
		logger.info("bvt30 is completed successfully...");
		
	}
	
	@Test(enabled = testEnabled, priority = 31)
	public void bvt31_allAppsCanBeLaunchedTest(){
		CommonUtil.alertMsg("executing bvt31...");
		logger.info("Executing bvt31...");
		altID = 31;
		//zeNavigator.logout();
		//zeNavigator.doLogin(Config.getUsersPropValue("USER4_USERNAME"), Config.getUsersPropValue("USER4_PASSWORD"));
		zeNavigator.selectProject("Success Meet");
		String releaseName = "Release 1.0";
		zeNavigator.selectReleaseFromGrid(releaseName);
//		zeNavigator.doLogin(Config.getUsersPropValue("USER4_USERNAME"), Config.getUsersPropValue("USER4_PASSWORD"));
//		zeNavigator.selectReleaseFromGrid("Release 1.0");
		zeNavigator.launchReleaseApp("Requirements");
		zeNavigator.verifyRequirementApp(Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
		zeNavigator.launchReleaseApp("Test Repository");
		zeNavigator.verifyTestRepositorySummaryPage(Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
		zeNavigator.launchReleaseApp("Test Planning");
		zeNavigator.verifyTestPlanningPage(Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
		isSuccess = true;
		logger.info("bvt31 is completed successfully...");
	}
	

	@Test(enabled = testEnabled, priority = 32)
	public void bvt32_selectOtherProjectFromDropdownAndViewProjectSummaryPageTest(){
		CommonUtil.alertMsg("executing bvt32...");
		logger.info("Executing bvt32...");
		altID = 32;
		
		zeNavigator.logout();
		zeNavigator.doLogin(Config.getUsersPropValue("ZE_MANAGER_USERNAME"), Config.getUsersPropValue("ZE_MANAGER_PASSWORD"));
		
		Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"))
				, "Failed to select Project : " + Config.getProjectPropValue("PROJECT1_NAME"));
		
		zeNavigator.verifyProjectSummaryPage(Config.getProjectPropValue("PROJECT1_NAME"), Config.getUsersPropValue("MANAGER")
				, 1, 1, 00, 00, 05);
		
		Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("DEFAULT_PROJECT"))
				, "Failed to select Project : " + Config.getProjectPropValue("DEFAULT_PROJECT"));
		
		isSuccess = true;
		logger.info("bvt32 is completed successfully...");
		
	}
	
	@Test(enabled = testEnabled, priority = 33)
	public void bvt33_selectReleaseFromDropdownAndNavigateToReleaseSummayPageTest(){
		CommonUtil.alertMsg("executing bvt33...");
		logger.info("Executing bvt33...");
		altID = 33;
		
		Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("DEFAULT_PROJECT"))
				, "Failed to select Project : " + Config.getProjectPropValue("DEFAULT_PROJECT"));
		
		String releaseName = "Release 1.0";
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.verifyReleaseSummaryPage(releaseName);
		isSuccess = true;
		logger.info("bvt33 is completed successfully...");
		
	}
	
	@Test(enabled = testEnabled, priority = 34)
	public void bvt34_clickManageButtonInReleaseSummaryAndLaunchReleaseSetupTest(){
		CommonUtil.alertMsg("executing bvt34...");
		logger.info("Executing bvt34...");
		altID = 34;
		
		Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("DEFAULT_PROJECT"))
				, "Failed to select Project : " + Config.getProjectPropValue("DEFAULT_PROJECT"));
		Assert.assertTrue(zeNavigator.selectReleaseDropDown("Release 1.0"), "Not selected release.");
		
		Assert.assertTrue(zeNavigator.launchReleaseSetupPage(), "Failed to launch Release Setup , View Logs for details");
		zeNavigator.verifyReleaseSetupPage();
		
		isSuccess = true;
		logger.info("bvt34 is completed successfully...");
		
	}
	
	@Test(enabled = testEnabled, priority = 35)
	public void bvt35_createNewReleaseTest(){
		CommonUtil.alertMsg("executing bvt35...");
		logger.info("Executing bvt35...");
		altID = 35;
		
		Assert.assertTrue(zeNavigator.createNewRelease(Config.getReleasePropValue("RELEASE_NAME_1"), Config.getReleasePropValue("RELEASE_DESCRIPTION_1"), 
				false, Config.getReleasePropValue("RELEASE_STARTDATE_1"), Config.getReleasePropValue("RELEASE_ENDDATE_1")), "failed to create new release");
		
		zeNavigator.verifyReleaseInReleaseSetup(Config.getReleasePropValue("RELEASE_NAME_1"), Config.getReleasePropValue("RELEASE_DESCRIPTION_1"), 
				false, Config.getReleasePropValue("RELEASE_STARTDATE_1"), Config.getReleasePropValue("RELEASE_ENDDATE_1"));
		
		isSuccess = true;
		logger.info("bvt35 is completed successfully...");
		
	}
	
	@Test(enabled = testEnabled, priority = 36)
	public void bvt36_viewNewlyCreatedReleaseInReleaseDropdownTest(){
		CommonUtil.alertMsg("executing bvt36...");
		logger.info("Executing bvt36...");
		altID = 36;
		
		Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("DEFAULT_PROJECT"))
				, "Failed to select Project : " + Config.getProjectPropValue("DEFAULT_PROJECT"));
		
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("RELEASE_NAME_1")), "Release not found by name: " +Config.getReleasePropValue("RELEASE_NAME_1"));
		zeNavigator.verifyReleaseSummaryPage(Config.getReleasePropValue("RELEASE_NAME_1"));
		isSuccess = true;
		logger.info("bvt36 is completed successfully...");
		
	}
	
	@Test(enabled = testEnabled, priority = 37)
	public void bvt37_navigateBetweenReleaseFromLeftDropdownTest(){
		CommonUtil.alertMsg("executing bvt37...");
		logger.info("Executing bvt37...");
		altID = 37;
		
		String releaseOne = Config.getReleasePropValue("DEFAULT_RELEASE_NAME");
		String releaseTwo = Config.getReleasePropValue("RELEASE_NAME_1");
		
		zeNavigator.navigateReleaseFromTopDropdown(releaseOne);
		zeNavigator.navigateReleaseFromTopDropdown(releaseTwo);
		
		isSuccess = true;
		
		logger.info("bvt37 is completed successfully...");
		
	}
	
	@Test(enabled = testEnabled, priority = 38)
	public void bvt38_createHiddenReleaseTest(){
		CommonUtil.alertMsg("executing bvt38...");
		logger.info("Executing bvt38...");
		altID = 38;
		
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.launchReleaseSetupPage(), "Failed to launch Release Setup , View Logs for details");
		zeNavigator.verifyReleaseSetupPage();
		
		Assert.assertTrue(zeNavigator.createNewRelease(Config.getReleasePropValue("HIDDEN_RELEASE_NAME"), Config.getReleasePropValue("HIDDEN_RELEASE_dESCRIPTION"), 
				true, Config.getReleasePropValue("HIDDEN_RELEASE_STARTdATE_1"), Config.getReleasePropValue("HIDDEN_RELEASE_ENDdATE_1") ), "failed to create new release");
		
		isSuccess = true;
		
		logger.info("bvt38 is completed successfully...");
	}
	
	@Test(enabled = testEnabled, priority = 39)
	public void bvt39_attemptToCreateProjectWithSameNameAsExistingProject() {
		CommonUtil.alertMsg("executing bvt39...");
		logger.info("Executing bvt39...");
		altID = 39;

		zeNavigator.launchAdministration();
		Assert.assertTrue(zeNavigator.launchAdminApps("ProjectSetup"), "Failed to launch Project setup App");
		zeNavigator.attemptToaddNewProjectWithDuplicateName(Config.getProjectPropValue("DEFAULT_PROJECT"),
				Config.getProjectPropValue("PROJECT1_TYPE"), Config.getProjectPropValue("PROJECT1_DESCRIPTION"),
				Config.getProjectPropValue("PROJECT1_STARTDATE"), null, null, null);
		isSuccess = true;
		logger.info("bvt39 is completed successfully...");
	}

	@BeforeMethod
	public void beforeMethod() {
		isSuccess = false;
	}

	@AfterMethod
	public void afterMethod() {
		baseAfterMethod();
		if(!isSuccess){
			zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
			zeNavigator.launchAdministration();
		}
	}
	
	@AfterClass
	public void afterClass() {
		zeNavigator.logout();
	}

}
