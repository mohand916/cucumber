package com.thed.zeuihtml.ze;

import java.util.List;
import java.util.Map;



public interface ZeNavigator {
	
	

	public boolean doLogin(String username, String password);
	
	public void verifyLoginPage();
	
	public boolean logout();
	
	public boolean resetPassword(String newPassword);
	
	/**
	 * No Return Type, Test fails with Error msg printing Expected conditions
	 * This method is used to verify 'Project Summary' Page after login 
	 * @param expectedDefaultSelectedProjectName contains Project Name expected to be present
	 * @param expectedUserTitle This parameter contains User Title displayed after login at right top
	 * @param totalReleaseCount This parameter contains Total Release count expected in selected project
	 * @return void
	 */
	public void verifyProjectSummaryPage(String expectedDefaultSelectedProjectName, String expectedUserTitle, Integer expectedTotalReleaseCount
			, Integer totalInprogressRelease, Integer totalTestcases, Integer totalExecutions, Integer totalmembers);
	
	
	public boolean selectReleaseFromGrid(String ReleaseName);
	
	public void verifyReleaseSummaryPage(String releaseName);
	
	public void verifyReleaseSetupPage();

	
	/**
	 * @param ReleaseName
	 * @return
	 * @author Created by manoj.behera on 05-Apr-2017.
	 */
	
	
	
	boolean DeleteRelease(String ReleaseName);
	
	/**
	 * @param releaseName
	 * @param appName
	 * @return
	 * @author Created by shruthi on 02-AUG-2017.
	 */
	
	boolean CloneRelease(String ReleaseName);
	/**
	 * @param releaseName
	 * @param appName
	 * @return
	 * @author Created by shruthi on 02-AUG-2017.
	 */
	boolean CloneRelease(String Projectname, String ReleaseName, String User );
	
	public void verifyReleaseSummaryPage( String expectedReleaseName, String expecteRrequirementCount
			, String expectetestcaseCount, String expectedexecutionProgress, String expectedtotalLinkedDefects);
	
	public Map<String, String> getReleaseSummaryCountDetails(String releaseName);
	
	boolean renameRelease(String ReleaseName, String newReleaseName, String releaseDescription,String releaseEndDate );
	
	/**
	 * @param releaseName
	 * @param appName
	 * @return
	 * @author Created by shruthi on 03-AUG-2017.
	 */
	
	
	boolean selectReleaseDropDown(String ReleaseName);


	/**
	 * @param releaseName
	 * @param appName
	 * @return
	 * @author Created by manoj.behera on 05-Apr-2017.
	 */
	boolean navigateToReleaseApps(String releaseName, String appName);



	/**
	 * @return
	 * @author Created by manoj.behera on 05-Apr-2017.
	 */
	boolean launchAdministration();


	/**
	 * @param companyName
	 * @param systemName
	 * @param desktopURL
	 * @param dashboardURL
	 * @param mailServerHostName
	 * @param mailServerPort
	 * @param mailServerUsername
	 * @author Created by manoj.behera on 05-Apr-2017.
	 */
	void verifySystemConfigPage(String companyName, String systemName, String desktopURL, String dashboardURL,
			String mailServerHostName, String mailServerPort, String mailServerUsername);


	/**
	 * @param companyName
	 * @param systemName
	 * @param hostName
	 * @param port
	 * @param mailServerUsername
	 * @param mailServerPassword
	 * @return
	 * @author Created by manoj.behera on 05-Apr-2017.
	 */
	boolean changeSystemConfigurations(String companyName, String systemName, String hostName, String port,
			String mailServerUsername, String mailServerPassword);


	/**
	 * @return
	 * @author Created by manoj.behera on 05-Apr-2017.
	 */
	boolean setDefectTracking();


	/**
	 * @return
	 * @author Created by manoj.behera on 05-Apr-2017.
	 */
	boolean setUserJiraCredentialsinExternalPopup();


	/**
	 * To run this method user should be present in Custom Field window.
	 * Before executing this method make sure to run method - lockZephyrAccess(boolean lock)
	 * @param customFieldName
	 * @param customFieldType - values should be any one of these : "Text (1024)", Long Text (32000), Checkbox, Date, Number
	 * @param customFieldDescriptio
	 * @param searchable
	 * @param mandatory
	 * @return
	 * @author Created by manoj.behera on 05-Apr-2017.
	 */
	boolean addCustomField(String customFieldName, String customFieldType, String customFieldDescription,
			boolean searchable, boolean mandatory, String projectName, boolean all);
	
	
	/**
	 * To run this method user should be present in Custom Field window.
	 * Before executing this method make sure to run - launchCustomizationOptions(String fieldName), </br>
	 * Releasing Zephyr Lock by passing false value will also close CustomField Window.
	 * @param lock Takes boolean value and locks/unlocks Zephyr Access from Custom Field Window 
	 * @return boolean value true or false
	 */
	public boolean lockZephyrAccess(boolean lock);
	
	/**
	 * To run this method user should be present in Administration, 
	 * Before executing this method make sure to run -
	 * @param appNameToBeLaunched Takes String value to Launch App - Expected values: <b>DefectTracking, Customization, 
	 * DefectAdmin, ManageUsers, ManageProjects <b>
	 * @return boolean value true or false
	 */
	public boolean launchAdminApps(String appNameToBeLaunched);
	
	/**
	 * To run this method user should be present in Customization App, 
	 * Before executing this method make sure to run - launchAdminApps(String appNameToBeLaunched)
	 * @param fieldName Takes String value to Launch all available Customization Options - Expected values: <b>TestcaseCustomField, 
	 * RequirementCustomField, ExecutionStatus, StepExecutionStatus, EstimatedTime<b>
	 * 
	 * @return boolean value true or false
	 */
	public boolean launchCustomizationOptions(String fieldName);
	
	/**
	 * To run this method user should be present in Logged In to Zephyr
	 * If not logged in to Zephyr then before executing this method make sure to run - doLogin(String username, String password)
	 * @param projectName Takes String value to Select prject by name
	 * @return boolean value true or false
	 */
	public boolean selectProject(String projectName);
	
	
	/**
	 * To run this method user should be present in Custom Field window.
	 * Before executing this method make sure to run - launchCustomizationOptions(String fieldName), </br>
	 * @param customFieldName
	 * @param customFieldType
	 * @param customFieldDescriptio
	 * @param searchable
	 * @param mandatory
	 * @return boolean value true or false
	 */
	public boolean verifyCustomFields(String customFieldName, String customFieldType, String customFieldDescription, 
			boolean searchable, boolean mandatory);

	/**
	 * To run this method user should be present in Custom Field window.
	 * Before executing this method make sure to run method - lockZephyrAccess(boolean lock)
	 * @param customFieldName
	 * @param customFieldType
	 * @param customFieldDescriptio
	 * @param searchable
	 * @param mandatory
	 * @param picklistValues list of values to be added
	 * @return boolean value true or false
	 */
	public boolean addCustomFieldPicklist(String customFieldName, String customFieldType, String customFieldDescription, 
			boolean searchable, boolean mandatory, List<String> picklistValues, String projectName, boolean all);
	
	
	/**
	 * To run this method user should be present in Manage Test Execution Status window
	 * Before executing this method make sure to run - launchCustomizationOptions(String fieldName)
	 * @param executionStatusName Takes String value to create execution status by given name
	 * @return boolean value true or false
	 */
	public boolean addExecutionStatus(String executionStatusName);
	
	/**
	 * To run this method user should be present in Manage Test Execution Status window
	 * Before executing this method make sure to run - launchCustomizationOptions(String fieldName)
	 * @param executionStatusName Takes String value to create execution status by given name
	 */
	public void verifyExecutionStatus(String executionStatusName, boolean closeWindowAfterVerifying);
	
	/**
	 * To run this method user should be present in Default Estimated Time Editor window
	 * Before executing this method make sure to run - launchCustomizationOptions(String fieldName)
	 * @param estimatedTime Takes String value between - 00 to 99 : 00 to 23 : 01 to 59 (e.g estimatedTime = 11:12:13)
	 * @return boolean value true or false
	 */
	public boolean updateDefaultEstimatedTime(String estimatedTime);
	/**
	 * To run this method user should be present in Default Estimated Time Editor window
	 * Before executing this method make sure to run - launchCustomizationOptions(String fieldName)
	 * @param estimatedTime Takes String value between - 00 to 99 : 00 to 23 : 01 to 59 (e.g estimatedTime = 11:12:13)
	 */
	public void verifyEstimatedTime(String estimatedTime);
	
	
	/**
	 * To run this method user should be present in Manage Users window
	 * Before executing this method make sure to run - launchAdminApps(String appNameToBeLaunched)
	 * @param userFistAndLastName Takes String value with space between FirstName and LastName - e.g. "John Doe"
	 * @param userRole Takes only one of following string - <b>lead, tester, dashboard <b>, or custom role if created
	 * @param email Takes String value with valid emailID format e.g. "john.doe@gmail.com"
	 * @param location Takes String value
	 * @return boolean value true or false
	 */
	public boolean addNewUser(String userFistAndLastName, String userRole, String email, String location);
	
	/**
	 * To run this method user should be present in Manage Users window
	 * Before executing this method make sure to run - launchAdminApps(String appNameToBeLaunched)
	 * @param userFistAndLastName Takes String value with space between FirstName and LastName - e.g. "John Doe"
	 * @param userRole Takes only one of following string - <b>lead, tester, dashboard <b>, or custom role if created
	 * @param email Takes String value with valid emailID format e.g. "john.doe@gmail.com"
	 * @param location Takes String value
	 */
	public void verifyUser(String userFistAndLastName, String userRole, String email, String location);
	

	/**
	 * To run this method user should be present in Manage Projects window
	 * Before executing this method make sure to run - launchAdminApps(String appNameToBeLaunched)
	 * @param projectName Takes String value
	 * @param projectType Takes only one of following string - <b>Normal, Restricted, Isolated <b>
	 * @param projectDescription Takes String value
	 * @param startDate Takes String value wih format as - <b> mm/dd/yyyy <b> e.g. 04/10/2017
	 * @param endDate Takes String value wih format as - <b> mm/dd/yyyy <b> e.g. 04/10/2017
	 * @param leadName - Takes Lead Name - e.g. "Test Lead"
	 * @param jiraProjectName - - Takes Jira Project name - e.g. "Demo Project b"
	 * @return boolean value true or false
	 */
	public boolean addNewProject(String projectName, String projectType, String projectDescription, String startDate, String endDate, 
			String leadName, String jiraProjectName);
	
	/**
	 * To run this method user should be present in Manage Projects window
	 * Before executing this method make sure to run - launchAdminApps(String appNameToBeLaunched)
	 * @param projectName Takes String value
	 * @param projectType Takes only one of following string - <b>Normal, Restricted, Isolated <b>
	 * @param projectDescription Takes String value
	 * @param startDate Takes String value wih format as - <b> mm/dd/yyyy <b> e.g. 04/10/2017
	 * @param endDate Takes String value wih format as - <b> mm/dd/yyyy <b> e.g. 04/10/2017
	 * @param leadName - Takes Lead Name - e.g. "Test Lead"
	 * @param jiraProjectName - Not implemented yet, Inprogress
	 */
	public void verifyProject(String projectName, String projectType, String projectDescription, String startDate, String endDate, 
			String leadName, String jiraProjectName, List<String> resourceNames, String membersInProject);
	
	public boolean editProject(String projectName, String newProjectName, String projectType, String projectDescription, String startDate, String endDate, 
			String leadName, String jiraProjectName, String Jiraconnection, String CustomfieldText, List<String> resourceNameToAdd, List<String> resourceNameToRemove, List<String> ProjectNameToAdd);
	
	public boolean addNewRole(String roleName, String roleDescription, boolean systemSetup, boolean userSetup, boolean projectSetup
			, boolean defectsAdmin, boolean releaseSetup, boolean requirements, boolean testPlanning, boolean testRepository
			, boolean testExecution, boolean defectTracking, boolean closeWindowAfterCreation);
	
	public void verifyRole(String roleName, String RoleDescription, boolean closeWindowAferVerifying);
	
	public boolean assignProjectsToUser(String userFistAndLastName, List<String> projectNames);
	
	public void verifyProjectsAssignedToUser(String userFistAndLastName, List<String> projectNames);
	
	public void verifyAdminAppsToBePresent(boolean systemSetupApp, boolean userSetupApp, boolean projectSetupApp,
			boolean defectsAdminApp);
	
	public void verifyReleaseAppsToBePresent(boolean requirementApp, boolean testRepository, boolean testPlanningApp,
			boolean testExecutionApp, boolean defectTrackingApp, boolean zAutomationApp);
	
	public boolean launchReleaseSetupPage();
	
	public boolean createNewRelease(String releaseName, String releaseDescription, boolean hideRelease
			, String releaseStartDate, String releaseEndDate);
	
	public void verifyReleaseInReleaseSetup(String releaseName, String releaseDescription, boolean hideRelease
			, String releaseStartDate, String releaseEndDate);
	
	public boolean navigateReleaseFromTopDropdown(String releaseName);
	
	boolean createNode(List<String> parentTree, String phaseName, String nodeName, String nodeDescription);
	boolean createNode(String phaseName, String nodeName, String nodeDescription);
	boolean renameNode(String renameNodeName, String newNodeName, String newNodeDescription);


	boolean deleteNode(String deleteNodeName);
	boolean filterNodes(String filterText);
	boolean navigateToNodes(List<String> phases);
	String addDefaultTestcase(String nodeName);
	boolean modifyTestcase(Map<String, String> values);
	public boolean modifyTeststep(Map<String, String> values);

	public boolean addCustomfieldToTestcase(String customfieldName, String customfieldValue, String customfieldType);
	public boolean verifyCustomfieldToTestcase(String customfieldName, String customfieldValue, String customfieldType);
	
	public String getTestcase(String nodeName);
	
	public String getTestcase(String nodeName, String testcaseName);
	
	public boolean cloneTestcase(String nodeName, String testcaseName,String stepstatus);
	
	public boolean navigateBetweenTestcases(String nodeName, String testcaseName);
	
	public boolean findAndAddTestcase(String nodeName,String searchQuery);
	
	public boolean dockUndockGlobalTree(String nodeName);
	
	public boolean searchTescases(String searchType, String searchQuery, List<String> expectedTestcases, boolean navigateBackToFolder);
	
	public boolean switchBetweenSearchFolderListDetailView(String nodeName);



	/**
	 * @param releaseName
	 * @param phaseName
	 * @param phaseDescription
	 * @return
	 * @author Created by manoj.behera on 12-Apr-2017.
	 */
	boolean createPhase(String releaseName, String phaseName, String phaseDescription);


	/**
	 * @param nodeName
	 * @param testcaseId
	 * @return
	 * @author Created by manoj.behera on 19-Apr-2017.
	 */
	boolean deleteTestcase(String nodeName, String testcaseId);


	/**
	 * @param cycleName
	 * @param buildName
	 * @param environment
	 * @param startDate 
	 * @param endDate
	 * @return
	 * @author Created by manoj.behera on 21-Apr-2017.
	 */
	boolean createCycle(String cycleName, String buildName, String environment, String startDate, String endDate);


	/**
	 * @param cycleName - Name of cycle to be edited
	 * @param newCycleName - Provide New name for cycle, send 'null' if value not required to change
	 * @param buildName - Provide New Build name value for cycle, send 'null' if value not required to change
	 * @param environment - Provide Environment value for cycle, send 'null' if value not required to change
	 * @param cycleStartDate - Format: mm/dd/yyyy, send 'null' if value not required to change
	 * @param cycleEndDate - Format: mm/dd/yyyy, send 'null' if value not required to change
	 * @param phaseNameWithStartDates - Format: "PhaseName>mm/dd/yyyy", send 'null' if value not required to change
	 * @param phaseNameWithEndDates - Format: "PhaseName>mm/dd/yyyy", send 'null' if value not required to change
	 * @param hideCycle - expected value true or false
	 * @return
	 */
	public boolean editCycle(String cycleName, String newCycleName, String buildName, String environment
			,String cycleStartDate, String cycleEndDate, List<String> phaseNameWithStartDates, List<String> phaseNameWithEndDates, boolean hideCycle,boolean viewhideCycle);


	/**
	 * @param deleteCycleName
	 * @return
	 * @author Created by manoj.behera on 21-Apr-2017.
	 */
	boolean deleteCycle(String deleteCycleName);
	
	/**
	 * @param cycleName
	 * @param phaseName
	 * @param bulkAssingTo -  <b>Expected value are only: creator, anyone</b>
	 * @return
	 */
	public boolean addPhaseToCycle(String cycleName, String phaseName, String bulkAssingTo, boolean navigatebackToCycle);

	public boolean navigateToAssignTestcaseToExecuteWindow(String cycleName, String phaseName, boolean initialBulkAssignmentPopupExpected);
	
	public boolean navigateToNodeInAssignTestcaseToExecuteWindow(List<String> nodeList);
	
	public void verifyAssigneeOfTestcase(String testcaseName, String assignee, boolean navigateBackToCycles);
	
	public boolean cloneCycle(String cycleName, String clonedCycleNewName, boolean copyTestcaseAssignments);
	
	public void verifyPhaseNotVisiblieInCyclePage(String cycleName, String phaseNameNotToBeVisible);
	
	public boolean assignTestIndividually(String testcaseName, String assignee, boolean navigateBackToCycles);
	
	public boolean bulkAssignNotExecutedTest(String assignee, boolean applySubFolders, boolean navigateBackToCycles);
	public boolean bulkAssignUnassignedTest(String assignee, boolean applySubFolders, boolean navigateBackToCycles);
	public boolean bulkAssignAllAssignedButNotExecutedTest(String fromAssignee, String toAssignee, boolean applySubFolders, boolean navigateBackToCycles);
	
	public boolean addFreeformPhaseToCycle(String cycleName, String freeformPhaseName, boolean navigateBackToCycles);
	
	public boolean addFreeformChildNode(String freeformNodeNameToAddChildNodes, List<String> freeformChildNodeNames, boolean navigateBackToCycles);
	
	public boolean editFreeformChildNode(String freeformNodeNameToEdit, String newNodeName, String newNodeDescription, boolean navigateBackToCycles);

	public boolean addTestcaseToFreeformNodeBrowse(String freeFormName, String phaseName, String nodeName
			,String subNodeName,boolean bringHierarchy);
		
	public void launchReleaseApp(String appName);
	
	public boolean deleteFreeformChildNodeAndVerify(String freeformNodeNameToDelete, boolean navigateBackToCycles);
	
	public boolean addTestcaseToFreeformNode(String searchType, String searchQuery
			, List<String> expectedTestcases, boolean addAllFetchedTestcases, boolean selectAllCheckboxInGrid
			,boolean bringHierarchy);
	
	public boolean syncSelectedNode(List<String> nodesNameWithTestCountAdded, List<String> nodesNameWithTestCountDeleted, boolean removeDeleted, boolean navigateBackToCycles);
	public boolean verifyTestExecutionDetailInGrid(String testcaseName,String version);
	public void verifyAbsenceOfTestcaseInCycleAssignmentWindow(String testcaseName, boolean navigateBackToCycles);
	
	public boolean deleteTestcaseFromSelectedNodeInAssingTestcaseToExecuteWindow(List<String> testcaseNamesInSelectedNode, boolean navigateBackToCycles);
	
	public boolean deleteCyclePhase(String cycleName, String phaseName);
	
	public boolean verifyTestcaseCountOfSelectedNode(String nodeName, int testCaseCount, boolean navigateBackToCycles);
	
	public boolean verifyRequirementApp(String releaseName);
	public boolean verifyTestRepositorySummaryPage(String releaseName);
	public boolean verifyTestPlanningPage(String releaseName);
	
	boolean createReqPhase(String releaseName, String phaseName, String phaseDescription);


	boolean renameRequirementsNode(String renameNodeName, String newNodeName, String newNodeDescription);

	boolean navigateToNodesInRequirements(List<String> phases);

	String addDefaultRequirement(String nodeName);
	

	public boolean navigateToNodesInTestExecution(List<String> nodeList);
	
	public boolean verifyAssignedTestcaseInSelectedNodeInTCE(String testcaseName, String assingedTo, String status);
	public boolean createRequirementNode(String phaseName, String nodeName, String nodeDescription);
	
	public boolean executeTestcaseInSelectedNodeAndVerify(String testcaseName, String status);

	public boolean bulkExecuteTestcaseInSelectedNodeAndVerify(List<String> testNames, String status);
	
	public boolean executeTestStepAndVerify(String testcaseName, String stepId, String status, boolean expandStepsSection
			,boolean expectedExecuteTestcasePopup, String executeTestcaseStatus);
	
	public boolean addExecutionAttachmentsNotesActualTime(String testcaseName, String attachmentFileWithPath,
			String notes, String actualTime);
	
	public boolean switchExecutionViewAndVerify(String folderOrSearch);
	public boolean cloneRequirement(String nodeName, String requirementId);
	
	public boolean executionSearchAndVerifyTestcase(String searchTypeQuickOrAdvanced, String searchQuery, List<String> testcaseNamesToVerify);
	
	public boolean verifyTestExecutionDetailsInSearch(String testcaseName, Map<String, String> values);

	public boolean bulkEditTestCase(Map<String, String> values);


	boolean deleteRequirement(String nodeName, String requirementId);

	
	public boolean addTestcaseToFreeformNodeFromAnotherCycle(String fromCycle, String fromPhase, String withStatus
			, List<String> expectedTestcases, boolean selectAllCheckboxInGrid
			,boolean bringHierarchy);
	
	public boolean searchAndLinkDefect(String testcaseName, String searchChoice, String searchValue, String defectSummary
			, String defectID);
	
	public boolean linkNewDefect(String testcaseName, Map<String, String> values);
	
	public boolean launchDashboard();
	
	public boolean createDashboard(String dashboardName, String dashboardDescription, String layout, String accessType);
	
	public boolean editDashboard(String dashboardName, String dashboardNewName, String dashboardDescription, String layout, String accessType);
	
	public boolean verifyDashboard(String dashboardName, String dashboardDescription);
	
	public boolean selectDashboard(String dashboardName);
	
	public boolean addDailyPulseGadgets(String projectName, String releaseName, String trackedBy, String timeFrame);
	
	public boolean addExecutionBacklogGadget(String projectName, String releaseName, String filterBy, List<String> listOfFilterByValues, String refreshRate);
	
	public boolean navigateToManageDashboardPage();
	
	public boolean deleteDashbaord(String dashboardName);
	
	public boolean deallocateRequirement(String reqName);
	
	public boolean verifyRequirement(String reqName, Map<String, String> reqFieldsValues);
	
	public boolean allocateRequirement(String reqName);
	
	public boolean mapTestcaseToRequirement(String reqName, List<String> navigateToTCCTreeNodes, String testcaseName);
	
	public boolean modifyRequirement(String reqName, Map<String, String> values, String nodeName);
	
	public boolean switchRequirementSearchFolderView(String view);
	
	public boolean searchRequirements(String type, String query, List<String> reqNames);
	
	public boolean updateRequirementCustomFieldValue(String reqName, Map<String, String> typeNameAndValue);
	
	public boolean checkOrUncheckRequirementFieldsInGrid(List<String> fieldNames, boolean check);
	
	public boolean changePassword(String newPassword, String oldPassword);
	
	public boolean setUserAuthenticationToLdap(String ldapHost, String baseDN, String bindDN, String bindPassword, String searchAttribute, String userName, String password);

	public boolean setUserAuthenticationToCrowd(String serverURL, String applicationName, String applicationPassword, String userName, String password);
	
	public boolean setUserAuthenticationToWebService(String webServiceURL, String userName, String password);
	
	public boolean enableDisableSecondaryAuthentication();
	
	public boolean doFullReindex();
	
	public boolean runETLJobForTrendForToday(boolean testcase, boolean execution);
	
	public boolean createNewDefectFromDefectTrackingApp(Map<String, String> values);
	
	public boolean verifySearchedDefect(Map<String, String> valuesToVerify);
	
	public boolean searchByIdOrJqlOrFilter(String searchType, String searchValue, boolean launchAdvanced, Map<String, String> valuesToVerify);
	
	public boolean navigateToTestcaseLinkedWithDefectFromDefectTrackingApp(String defectSummay, String linkedTestcaseName);
	
	public boolean exportSelectedNodeOfTCC(String nodeName, String reportType, String outputAs);
	
	public boolean exportGridTestcaseOfTCC(String reportType, String outputAs);
	
	public boolean moveNode(String moveNodeName, String oldParentNodeName, String newParentNodeName, List<String> nodeList);
	public boolean copyNode(String copyNodeName, String oldParentNodeName, String newParentNodeName, List<String> nodeList);

	public boolean exportCycle(String cycleName, String reportType, String outputAs);
	
	public boolean exportSelectedNodeOfTCE(String nodeName, String reportType, String outputAs);
	
	public boolean exportGridTestcaseOfTCE(String reportType, String outputAs);
	
	public boolean exportSearchedDefectResults();
	
	public boolean exportAllSearchedExecutionInTCE(String reportType, String outputAs);
	
	public boolean exportSelectedRequirementTreeNode(String treeNodeName, String reportType, String outputAs);
	
	public boolean exportAllRequirementFromGridOfSelectedTreeNode(String reportType, String outputAs);

	public boolean importJiraRequirements(String jql, List<String> issueSummay, String renameNode);
	
	public boolean moveImportedNode(String importedNodeContent, String nodeName);
	
	public boolean copyImportedNode(String importedNodeContent, String nodeName);
	
	public boolean pasteCopiedImportedNode(String parentNodeName);

	public boolean exportEntireTraceabilityOfSelectedRequirementTreeNode(String treeNodeName, String reportType, String outputAs);
	
	public boolean exportEntireTraceablilityOfAllRequirementFromGridOfSelectedTreeNode(String reportType, String outputAs);
	
	public boolean exportAllRequirementSearchedResults(String reportType, String outputAs);
	
	public boolean exportAllSearchedTestcaseInTCC(String reportType, String outputAs, boolean navigateBackToFolder);
	
	public boolean exportNodeFromTestPlanningAssignmentWindow(String nodeName, String reportType, String outputAs, boolean navigateBackToCycle);

	public boolean copyImportedNodeByDragNDrop(String nodeName);
	
	public boolean setDefectAdminProperties(String category, String name, String value);
	
	public boolean setPaginationPageSizeInTestRepository(String size);
	
	public boolean verifyTestcasesInSelectedNodeOfTestRepository(List<String> testcasesNames);
	
	public boolean navigateToNextOrPrevPageInTestRepositoryGrid(String nextOrPrev);
	
	public boolean setPaginationPageSizeInRequirement(String size);
	
	public boolean verifyRequirementInSelectedNodeOfRequirementApp(List<String> requirementNames);
	
	public boolean navigateToNextOrPrevPageInRequirementGrid(String nextOrPrev);

	public boolean mapRequirementToTestcase(String testcaseName, List<String> navigateToReqTreeNodes, String requirementName);
	
	public boolean changeTestcaseFromManualToAutomated(String tcName, String scriptName, String id, String path);
	
	public boolean performSearchInEASAddTestcaseToFreeformWindow(String searchType, String searchQuery, String setPageSize, int expectedNoOfPages
			,Map<Integer, List<String>>  pageAndexpectedTestcases);
	
	public boolean setPageSizeInTCEGrid(String size);
	
	public boolean navigateToNextOrPrevPageInTCEGrid(String nextOrPrev);
	
	public void doProjectLevelReindex(String projectName);

	public boolean addCustomField(String customFieldName, String customFieldType, String customFieldDescription, 
			boolean searchable, boolean mandatory, String projectName, boolean unique, boolean all);
	
	public boolean attemptToUpdateRequirementUniqueCustomFieldWithDuplicateValue(String reqName,
			Map<String, String> typeNameAndValue);
	
	public String getRequirementCustomFieldValue(String ReqId, Map<String, String> typeNameAndValue);
	
	public boolean uncheckUniqueReqCustomField(String customFieldName);
	
	public boolean attemptToAddDuplicateValueToTestcaseHavingUniqueCustomField(String customfieldName, String customfieldValue, String customfieldType);
	
	public String getTestcaseCustomFieldValue(String customfieldName,String customfieldType, String TcId);
	
	public boolean uncheckUniqueTestcaseCustomField(String customFieldName);
	//rasagna
	public String createAutomationJob(String automationTool, String scriptPath, String resultPath
			, boolean packageStructure, String zbot, String startDate, String endDate, String jobName, String cycleName, String phaseName);
	
	/*public String createAutomationJob(String automationTool, String scriptPath, String resultPath
			, boolean packageStructure, String zbot, String startDate, String endDate, String jobName);*/
	//rasagna
	public boolean verifyAutomationJobCreated(String jobId, String automationTool, String scriptPath, String resultPath
			, String status, String zbot, String startDate, String endDate);
	
	public boolean executeAutomationJob(String jobId, String cycleName, String phaseName, boolean setPostFixTimeStamp, String user, String expectedNotificationCount);
	
	public boolean applyNotification(String expectedNotificationCount);
	
	public boolean verifyPhase(String phaseName, String phaseDescription);
	
	public boolean verifyNode(String parentNodename, String nodeName, String nodeDescription);
	
	public String verifyDefaultTestcase(int testcaseNum);
	
	public boolean createNodeinReqGlobal(String parentNodeName, String nodeName, String nodeDescription);
	
	public boolean verifyNodeinReqGlobal(String parentNodename, String nodeName, String nodeDescription);

	public boolean verifyCycleAndPhaseDetailsInTestPlanning(String cycleName, String cycleStartDateExpected
			, String cycleEndDateExpected, String phaseName, String phaseStartDateExpected, String phaseEndDateExpected);
	
	public boolean verifyMapTestcaseToRequirement(String reqName, String mapCount);
	
	public boolean verifyTestcaseExecutionStatus(String testcaseName, String status);
	
	public boolean SelectTestcase(String tcName);
	
	public boolean verifyTeststepExecutionStatus(String testcaseName, String stepId, String status, boolean expandStepsSection,
			boolean expectedExecuteTestcasePopup, String executeTestcaseStatus);
	
	public boolean addTestcaseMap(String mapName, String rowNumber, String selectDiscriminator
			, String mapDescription, String testcaseNameColumn, String testStepColumn,
			String expectedResultColumn, String externalIdColumn, String testDataColumn, List<String> otherFieldsMappingIfAny);
	
	public boolean importTestcase(String jobName, String mapName, String importFileNameWithPath);
	
	public boolean navigateToTCCNodeUnderImportedNode(String nodeNameContains);
	
	public boolean renameSelectedTCCImportedNodeAndDragToRelease(String nodeNameContains,String renameImportedNode, String releaseNodeNameToDrop, boolean dragWithControl);

	public boolean addRequirementMap(String mapName, String rowNumber, String selectDiscriminator
			, String mapDescription, String requirementNameColumn, List<String> otherFieldsMappingIfAny);
	
	public boolean importRequirement(String jobName, String mapName, String importFileNameWithPath);
	
	public boolean navigateToRequirementNodeUnderImportedNode(String nodeNameContains);
	
	public boolean attemptToaddNewProjectWithDuplicateName(String projectName, String projectType, String projectDescription, String startDate, String endDate, 
			String leadName, String jiraProjectName);

	public boolean verifyForceLogoutPopupAndClickOk();
	
	public boolean launchGlobalTCCWindow(String releaseName);
	
	public boolean navigateToNodeInGlobalTCC(List<String> nodeList);
	
	public boolean DnDGlobalTestcaseToLocalRelease(String  localReleaseNodeName,String globalSelectedNodeNameOrNull, List<String> elseTestcaseNamesToDraged);
	
	public boolean navigateToLocalReleaseNodeInGlobalTCC(List<String> nodeList);
	
	public boolean checkOrUncheckTestcaseFieldsInGridAndVerify(List<String> fieldNames, boolean check);
	
	public boolean resetTestcaseGridToDefaultAndVerifyAbsenceOfCustomizedFields(List<String> fieldNamesNotToBePresent);
	
	public boolean resetRequirementGridToDefaultAndVerifyAbsenceOfCustomizedFields(List<String> fieldNamesNotToBePresent);
	public boolean attemptToAddDuplicateProject(String projectName, String projectType, String projectDescription, String startDate, String endDate, 
			String leadName, String jiraProjectName);

	public boolean performNodeSync(String parentNodeName);
	
	public boolean closeCustomfield();
	
	public boolean verifyTestcaseVersion(int testcaseId, String versionNo);
	
	public boolean verifyTestcaseVersion(String testcaseName, String versionNo);
	
	public boolean clickOnTestcase (String testcaseId);
	
	public boolean navigateBackToTestcaseList();
	
	public boolean navigateBackToReqList();
	
	public boolean navigateBackToCycles();

	boolean setMultiJira();

	boolean createNewDefectwithCustomfield(Map<String, String> values);

	boolean setJiraUser(String username, String password);

	boolean editCustomfield(String customFieldName, String customfieldUpdate);

	boolean deleteCustomfield(String customFieldName);
	
	public boolean deleteTestcase(String nodeName, int testcaseId);
	
	public boolean verifyTraceability(Map<String, Map<String, Map<String, String>>> reqTraceability);

	public boolean exportSelectedRequirementTraceabilityInFolderView (List <String> reqName);

	public boolean exportAllSearchedRequirementTraceability ();

	boolean clickonTestcaseCoverageLink(String reqName1);
	
	boolean clickonReqCoverageLink(String TcName);

	public boolean verifyTestcasesInGridOfSelectedPageInAddTestcaseToFreeformScreen(List<String> testcasesNames);

	public void verifyPhaseNotVisiblieInHiddenCyclePage(String hiddenCycleName, String phaseName);
	
	public boolean unhideCycle();
	
	public boolean sort(boolean TestcaseID);
	
	public boolean createProjectRepoPhase(String releaseName, String phaseName, String phaseDescription);
	
	public boolean createProjectRepoNode(List<String> parentTee, String parentNodeName, String nodeName, String nodeDescription);

	public String verifyDefaultTestcaseProjectRepo(int testcaseNum);
	
	public String addDefaultTestcaseProjectRepo(String nodeName);
	
	public boolean modifyTestcaseProjectRepo(Map<String, String> values);
	
	public boolean verifyTestcaseVersionProjectRepo(String testcaseName, String versionNo);
	
	public boolean cloneTestcaseProjectRepo(String nodeName,String testcaseName,String stepstatus);
	
	public String getTestcaseProjectRepo(String nodeName);
	
	public String getTestcaseProjectRepo(String nodeName, String testcaseName);
	
	public boolean deleteTestcaseProjectRepo(String nodeName, int testcaseId);
	
	public boolean deleteTestcaseProjectRepo(String nodeName, List<String> testcaseId);
	
	public boolean deleteNodeProjectRepo(String deleteNodeName);
	
	public boolean exportSelectedNodeOfTCCProjectRepo(String nodeName, String reportType, String outputAs);
	
	public boolean verifyTestcasesInSelectedNodeOfTestRepositoryProjectRepo(List<String> testcasesNames);
	
	public boolean dndsharenodeToRelease(String sourceNodeSelection, String destinationNode, boolean dragWithControl);
	public boolean navigateToNodesProjectRepo(List<String> nodeList);
	public boolean dndsharenodeToProjectRepo(String sourceNodeSelection, String destinationNode, boolean dragWithControl);
	public boolean launchShareTCCWindowProjectRepo(String releaseName);
	
	//Global Repository
	
	public boolean launchGlobalRepository();
	public void verifyAppTopHeader(boolean globalRepos, boolean dashboard, boolean Administration);
	
	public boolean editRole(String roleName, String roleDescription, boolean systemSetup, boolean userSetup, boolean projectSetup
			, boolean defectsAdmin, boolean releaseSetup, boolean requirements, boolean testPlanning, boolean testRepository
			, boolean testExecution, boolean defectTracking, boolean closeWindowAfterCreation, boolean globalTestRepository, boolean globalRepoConfig);
	
	public boolean launchGlobalApps(String appNameToBeLaunched);
	public boolean globalRepoProjectAssignment(List<String> projectNames);
	
	public boolean VerifyToReleaseOptionsNotpresent(String optionsName, String nodeName);
	public boolean verifyclonetestcasecoverage(String testcaseId, String coverage);
	public boolean customizwGadgetRefreshRate(String refreshRate );
	public boolean createGadgetwithCustomizeRefreshRate(String projectName, String releaseName, String refreshRate  );
	public boolean bulkexecuteSteps(String testcaseName, 
			String status, boolean expandStepsSection);
	public boolean bulkexecuteStepsUsingHotKey(String testcaseName, boolean expandStepsSection);
	public boolean autoUpadteExecution(String projectName);
	public boolean autoUpadteStatusbulkexecuteSteps(String testcaseName, 
			String status, boolean expandStepsSection);
	public boolean cloneRequirement(String reqName);
	public boolean dupicateRequiremnetNode(String releaseName, String phaseName, String phaseDescription);
	public boolean copyPasteSteps(Map<String, String> values);
	public boolean testcaseReorder(String testcaseName);
	public String getDefectIDLinkDefect(String testcaseName);
	public String getStatusInExecution(String testcaseName);
	public boolean checkUsageHistory(Map<String, String> values);
	
}
