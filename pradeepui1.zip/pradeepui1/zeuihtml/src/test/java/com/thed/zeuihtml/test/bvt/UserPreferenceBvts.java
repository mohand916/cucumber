package com.thed.zeuihtml.test.bvt;

import com.thed.zeuihtml.BaseTest;
import com.thed.zeuihtml.Config;
import org.apache.log4j.Logger;
import org.testng.annotations.*;

public class UserPreferenceBvts extends BaseTest {
    public UserPreferenceBvts() {
        logger = Logger.getLogger(this.getClass());
    }

    //Add BVTs here

    @BeforeMethod
    public void beforeMethod() {
        isSuccess = false;
    }

    @AfterMethod
    public void afterMethod() {
        baseAfterMethod();
        if(!isSuccess){
            zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
        }
    }

    @BeforeClass
    public void beforeClass() {
        zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
    }

    @AfterClass
    public void afterClass() {
        zeNavigator.logout();
    }
}
