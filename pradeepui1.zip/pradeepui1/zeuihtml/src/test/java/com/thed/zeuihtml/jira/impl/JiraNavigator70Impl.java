package com.thed.zeuihtml.jira.impl;

import com.thed.zeuihtml.jira.JiraNavigator;
import com.thed.zeuihtml.jira.impl.jira70.IssueDetailPage;
import com.thed.zeuihtml.jira.impl.jira70.JiraHomePage;
import com.thed.zeuihtml.jira.impl.jira70.JiraLogin;
import com.thed.zeuihtml.jira.impl.jira70.JiraLoginCloud;

public class JiraNavigator70Impl implements JiraNavigator{
	
	
	
	@Override
	public boolean doJiraLogin(String username, String password) {
		
		return JiraLogin.getInstance().jiraLogin(username, password);
	}

	@Override
	public boolean verifyNewMappedProject(String zephyrProjectName,
			String jiraProjectName) {
		return JiraHomePage.getInstance().verifyNewMappedProject(zephyrProjectName, jiraProjectName);
	}

	@Override
	public boolean verifyIssueLink(String testcaseName) {
		return IssueDetailPage.getInstance().verifyIssueLink(testcaseName);
	}

	@Override
	public boolean editIssue(String issueKey, String summary, String priority) {
		return IssueDetailPage.getInstance().editIssue(issueKey, summary, priority);
	}

	@Override
	public boolean jiraLoginCloud(String username, String password) {
		
		return JiraLoginCloud.getInstance().jiraLoginCloud(username, password);
	}
	

	}

