package com.thed.zeuihtml.test.bvt;
import org.openqa.selenium.support.ui.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.thed.zeuihtml.BaseTest;
import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.utils.CommonUtil;

public class ZAutomationBvts extends BaseTest {

	short jobID;

	public ZAutomationBvts() {
		logger = Logger.getLogger(this.getClass());
	}

	@Test(enabled = testEnabled, priority = 1)
	public void bvt215_attemptToViewZAutomationAppIfLicenseIsNotInstalledTest() {
		logger.info("Executing bvt215...");
		altID = 215;

		zeNavigator.selectProject("Sample Project");
		String releaseName = "Release 1.0";
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.verifyReleaseAppsToBePresent(true, true, true, true, true, false);
		
		isSuccess = true;
		logger.info("bvt215 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 2)
	public void bvt216_setupZAutomationLicneseAndVerifyAfterServerRestartTest() {
		logger.info("Executing bvt216...");
		altID = 216;
		
		zeNavigator.logout();
		
		CommonUtil.copyFile(CommonUtil.getCompleteFilePath(Config.getValue("ZA_AUTOMATION_LICENSE_SRC_PATH"))
				, Config.getValue("ZA_AUTOMATION_LICENSE_DST_PATH"));
		
		List<String> lines = new ArrayList<String>();
		lines.add("licenseFile="+Config.getValue("ZE_LICENSE_PATH"));
		lines.add("automationLicenseFile="+Config.getValue("ZA_AUTOMATION_LICENSE_DST_PATH"));
		
		CommonUtil.remveAllAndAddNewLinesInFile(Config.getValue("LICENSE_PROPERTIES")
				, lines);
		
	//	CommonUtil.stopWindowsService("ZephyrServer");
	//	CommonUtil.startWindowsService("ZephyrServer");
		CommonUtil.browserRefresh();
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		
		zeNavigator.selectProject("Sample Project");
		String releaseName = "Release 1.0";
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.verifyReleaseAppsToBePresent(true, true, true, true, true, true);
		
		isSuccess = true;
		logger.info("bvt216 is executed successfully.");
	}

	//TODO ALT.IDS

	@Test(enabled = testEnabled, priority = 3)
	public void bvt217_configureAndRunZEAutomationJobTestSelenium() {
		logger.info("Executing bvt217...");
		altID = 217;
		
		zeNavigator.selectProject("Sample Project");
		String releaseName = "Release 1.0";
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.verifyReleaseAppsToBePresent(true, true, true, true, true, true);

		zeNavigator.launchReleaseApp("Vortex");
		
		
		String startDate = CommonUtil.returnTodaysDate();
		String endDate = CommonUtil.returnFutureDateStartingTodaysDate(0, 0, 0);
	
		/*String jobId = zeNavigator.createAutomationJob(Config.getVortexPropValue("SELENIUM"),CommonUtil.getCompleteFilePath(Config.getVortexPropValue("SELENIUM_SCRIPT"))
				, CommonUtil.getCompleteFilePath(Config.getVortexPropValue("SELENIUM_RESULT")), true
				, Config.getValue("ZBOT"), startDate, endDate);*/

		String jobId = zeNavigator.createAutomationJob(Config.getVortexPropValue("SELENIUM"),CommonUtil.getCompleteFilePath(Config.getVortexPropValue("SELENIUM_SCRIPT"))
				, CommonUtil.getCompleteFilePath(Config.getVortexPropValue("SELENIUM_RESULT")), true
				, Config.getValue("ZBOT"), startDate, endDate, Config.getVortexPropValue("SELENIUM_CycleName"),Config.getVortexPropValue("SELENIUM_JobName"),Config.getVortexPropValue("SELENIUM_PhaseName"));
	
	
		Assert.assertNotNull(jobId, "Automation Job not created");
		
		zeNavigator.verifyAutomationJobCreated(jobId, Config.getVortexPropValue("SELENIUM"), null
				, CommonUtil.getCompleteFilePath(Config.getVortexPropValue("SELENIUM_RESULT")), null, Config.getValue("ZBOT"), startDate, endDate);

        DateFormat df = new SimpleDateFormat("hh:mm:a:EEE:MMM:dd:yyyy");
        String date = df.format(new Date());
        String dateDetails[] = date.split(":");
        zeNavigator.executeAutomationJob(jobId, Config.getEASPropValue("CYCLE_NAME_SELENIUM"), Config.getEASPropValue("PHASE_NAME_SELENIUM"), false,"Anyone", "3");

	//	String cycleName = "Selenium_" + dateDetails[3] + "_" + dateDetails[5] + " " + dateDetails[4] + " " + dateDetails[6] + "_" + dateDetails[0] + ":" + dateDetails[1] + " " + dateDetails[2];
	//	String phaseName = "Selenium_Automation_" + dateDetails[3] + " " + dateDetails[5] + ", " + dateDetails[6] + " " + dateDetails[0] + ":" + dateDetails[1] + " " + dateDetails[2];
	//	System.out.println("Cycle Name : "+cycleName);

	//	zeNavigator.launchReleaseApp("Test Planning");
 //    zeNavigator.verifyCycleAndPhaseDetailsInTestPlanning(Config.getEASPropValue("CYCLE_NAME_SELENIUM"), dateDetails[5], dateDetails[5], Config.getEASPropValue("PHASE_NAME_SELENIUM"), dateDetails[5], dateDetails[5]);
		
		isSuccess = true;
		logger.info("bvt217 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 4)
	public void bvt217_configureAndRunZEAutomationJobTestCucumber() {
		logger.info("Executing bvt217...");
		altID = 217;
		
		zeNavigator.selectProject("Sample Project");
		String releaseName = "Release 1.0";
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.launchReleaseApp("Vortex");
				
		String startDate = CommonUtil.returnTodaysDate();
		String endDate = CommonUtil.returnFutureDateStartingTodaysDate(0, 0, 0);

		String jobId = zeNavigator.createAutomationJob(Config.getVortexPropValue("CUCUMBER"),null
				, CommonUtil.getCompleteFilePath(Config.getVortexPropValue("CUCUMBER_RESULT")), false
				, Config.getValue("ZBOT"), startDate, endDate,Config.getVortexPropValue("CUCUMBER_CycleName"),Config.getVortexPropValue("CUCUMBER_JobName"),Config.getVortexPropValue("CUCUMBER_PhaseName"));
		/*zeNavigator.createAutomationJob(Config.getVortexPropValue("SELENIUM"),CommonUtil.getCompleteFilePath(Config.getVortexPropValue("SELENIUM_SCRIPT"))
				, CommonUtil.getCompleteFilePath(Config.getVortexPropValue("SELENIUM_RESULT")), true
				, Config.getValue("ZBOT"), startDate, endDate, Config.getVortexPropValue("SELENIUM_CycleName"),Config.getVortexPropValue("SELENIUM_JobName"),Config.getVortexPropValue("SELENIUM_PhaseName"));
	*/
		System.out.println("CERATED CUCUMBER");
		Assert.assertNotNull(jobId, "Automation Job not created");

		/*zeNavigator.verifyAutomationJobCreated(jobId,Config.getVortexPropValue("CUCUMBER"),null
				, CommonUtil.getCompleteFilePath(Config.getVortexPropValue("CUCUMBER_RESULT")), Config.getValue("ZBOT"), startDate, endDate,Config.getVortexPropValue("CUCUMBER_CycleName"));
System.out.println("VERIFIED CUCUMBER");*/
		DateFormat df = new SimpleDateFormat("hh:mm:a:EEE:MMM:dd:yyyy");
		String date = df.format(new Date());
		String dateDetails[] = date.split(":");
		CommonUtil.normalWait(3000);
		System.out.println("GOING TO EXECUTE CUCUMBER");
		zeNavigator.executeAutomationJob(jobId, Config.getEASPropValue("CYCLE_NAME_CUCUMBER"), Config.getEASPropValue("PHASE_NAME_CUCUMBER"), false,"Anyone", "3");
		System.out.println("DONE EXECUTE CUCUMBER");
/*public boolean executeAutomationJob(String jobId, String cycleName, String phaseName, boolean setPostFixTimeStamp, String user, String expectedNotificationCount) {
		try {
			
			CommonUtil.normalWait(2000);
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-zauto']//div[text()='"+jobId+"']")
					, "Job ID not found as:" + jobId);
			
			CommonUtil.returnWebElement("//div[@id='grid-table-zauto']//div[text()='"+jobId+"']/parent::div/parent::div/parent::div//span[text()='E']").click();
			*/
		//String cycleName = "Selenium_" + dateDetails[3] + " " + dateDetails[5] + ", " + dateDetails[6] + " " + dateDetails[0] + ":" + dateDetails[1] + " " + dateDetails[2];
		//String phaseName = "Selenium_Automation_" + dateDetails[3] + " " + dateDetails[5] + ", " + dateDetails[6] + " " + dateDetails[0] + ":" + dateDetails[1] + " " + dateDetails[2];
		//System.out.println("Cycle Name : "+cycleName);

		// rasagna zeNavigator.launchReleaseApp("Test Planning");
		//rasagna zeNavigator.verifyCycleAndPhaseDetailsInTestPlanning(Config.getEASPropValue("CYCLE_NAME_CUCUMBER"), dateDetails[5], dateDetails[5], Config.getEASPropValue("PHASE_NAME_CUCUMBER"), dateDetails[5], dateDetails[5]);

		isSuccess = true;
		logger.info("bvt217 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 5)
	public void bvt217_configureAndRunZEAutomationJobTestTosca() {
		logger.info("Executing bvt217...");
		altID = 217;
		zeNavigator.selectProject("Sample Project");
		String releaseName = "Release 1.0";
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.launchReleaseApp("Vortex");
		String startDate = CommonUtil.returnTodaysDate();
		String endDate = CommonUtil.returnFutureDateStartingTodaysDate(0, 0, 0);

		String jobId = zeNavigator.createAutomationJob(Config.getVortexPropValue("TOSCA"), null, CommonUtil.getCompleteFilePath(Config.getVortexPropValue("TOSCA_RESULT")), false, Config.getValue("ZBOT"), startDate, endDate, Config.getVortexPropValue("TOSCA_JobName"), Config.getVortexPropValue("TOSCA_CycleName"),Config.getVortexPropValue("TOSCA_PhaseName"));
				

		Assert.assertNotNull(jobId, "Automation Job not created");

		zeNavigator.verifyAutomationJobCreated(jobId, "tosca", null
				, CommonUtil.getCompleteFilePath(Config.getVortexPropValue("TOSCA_RESULT")), null, Config.getValue("ZBOT"), startDate, endDate);

		DateFormat df = new SimpleDateFormat("hh:mm:a:EEE:MMM:dd:yyyy");
		String date = df.format(new Date());
		String dateDetails[] = date.split(":");
		zeNavigator.executeAutomationJob(jobId, Config.getEASPropValue("CYCLE_NAME_TOSCA"), Config.getEASPropValue("PHASE_NAME_TOSCA"), false,"Anyone", "3");

		//String cycleName = "Selenium_" + dateDetails[3] + " " + dateDetails[5] + ", " + dateDetails[6] + " " + dateDetails[0] + ":" + dateDetails[1] + " " + dateDetails[2];
		//String phaseName = "Selenium_Automation_" + dateDetails[3] + " " + dateDetails[5] + ", " + dateDetails[6] + " " + dateDetails[0] + ":" + dateDetails[1] + " " + dateDetails[2];
		//System.out.println("Cycle Name : "+cycleName);

	//	zeNavigator.launchReleaseApp("Test Planning");
	//	zeNavigator.verifyCycleAndPhaseDetailsInTestPlanning(Config.getEASPropValue("CYCLE_NAME_TOSCA"), dateDetails[5], dateDetails[5], Config.getEASPropValue("PHASE_NAME_TOSCA"), dateDetails[5], dateDetails[5]);

		isSuccess = true;
		logger.info("bvt217 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 6)
	public void bvt217_configureAndRunZEAutomationJobTestJunit() {
		logger.info("Executing bvt217...");
		altID = 217;
		
		zeNavigator.selectProject("Sample Project");
		String releaseName = "Release 1.0";
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.launchReleaseApp("Vortex");
		String startDate = CommonUtil.returnTodaysDate();
		String endDate = CommonUtil.returnFutureDateStartingTodaysDate(0, 0, 0);

		String jobId = zeNavigator.createAutomationJob(Config.getVortexPropValue("JUNIT"),null
				, CommonUtil.getCompleteFilePath(Config.getVortexPropValue("JUNIT_RESULT")), false
				, Config.getValue("ZBOT"), startDate, endDate,Config.getVortexPropValue("JUNIT_JobName"), Config.getVortexPropValue("JUNIT_CycleName"),Config.getVortexPropValue("JUNIT_PhaseName"));

		Assert.assertNotNull(jobId, "Automation Job not created");

		zeNavigator.verifyAutomationJobCreated(jobId, "Junit", null
				, CommonUtil.getCompleteFilePath(Config.getVortexPropValue("JUNIT_RESULT")), null, Config.getValue("ZBOT"), startDate, endDate);

		DateFormat df = new SimpleDateFormat("hh:mm:a:EEE:MMM:dd:yyyy");
		String date = df.format(new Date());
		String dateDetails[] = date.split(":");
		zeNavigator.executeAutomationJob(jobId, Config.getEASPropValue("CYCLE_NAME_JUNIT"), Config.getEASPropValue("PHASE_NAME_JUNIT"), false,"Anyone", "3");

		//String cycleName = "Selenium_" + dateDetails[3] + " " + dateDetails[5] + ", " + dateDetails[6] + " " + dateDetails[0] + ":" + dateDetails[1] + " " + dateDetails[2];
		//String phaseName = "Selenium_Automation_" + dateDetails[3] + " " + dateDetails[5] + ", " + dateDetails[6] + " " + dateDetails[0] + ":" + dateDetails[1] + " " + dateDetails[2];
		//System.out.println("Cycle Name : "+cycleName);

		//zeNavigator.launchReleaseApp("Test Planning");
		//zeNavigator.verifyCycleAndPhaseDetailsInTestPlanning(Config.getEASPropValue("CYCLE_NAME_JUNIT"), dateDetails[5], dateDetails[5], Config.getEASPropValue("PHASE_NAME_JUNIT"), dateDetails[5], dateDetails[5]);

		isSuccess = true;
		logger.info("bvt217 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 7)
	public void bvt217_configureAndRunZEAutomationJobTestTestNg() {
		logger.info("Executing bvt217...");
		altID = 217;
		zeNavigator.selectProject("Sample Project");
		String releaseName = "Release 1.0";
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.launchReleaseApp("Vortex");
		String startDate = CommonUtil.returnTodaysDate();
		String endDate = CommonUtil.returnFutureDateStartingTodaysDate(0, 0, 0);

		String jobId = zeNavigator.createAutomationJob(Config.getVortexPropValue("TESTNG"),null
				, CommonUtil.getCompleteFilePath(Config.getVortexPropValue("TESTNG_RESULT")), false
				, Config.getValue("ZBOT"), startDate, endDate,Config.getVortexPropValue("TESTNG_JobName"), Config.getVortexPropValue("TESTNG_CycleName"),Config.getVortexPropValue("TESTNG_PhaseName"));

		Assert.assertNotNull(jobId, "Automation Job not created");

		zeNavigator.verifyAutomationJobCreated(jobId, "TestNg", null
				, CommonUtil.getCompleteFilePath(Config.getVortexPropValue("TESTNG_RESULT")), null, Config.getValue("ZBOT"), startDate, endDate);

		DateFormat df = new SimpleDateFormat("hh:mm:a:EEE:MMM:dd:yyyy");
		String date = df.format(new Date());
		String dateDetails[] = date.split(":");
		zeNavigator.executeAutomationJob(jobId, Config.getEASPropValue("CYCLE_NAME_TESTNG"), Config.getEASPropValue("PHASE_NAME_TESTNG"), false,"Anyone", "3");

		//String cycleName = "Selenium_" + dateDetails[3] + " " + dateDetails[5] + ", " + dateDetails[6] + " " + dateDetails[0] + ":" + dateDetails[1] + " " + dateDetails[2];
		//String phaseName = "Selenium_Automation_" + dateDetails[3] + " " + dateDetails[5] + ", " + dateDetails[6] + " " + dateDetails[0] + ":" + dateDetails[1] + " " + dateDetails[2];
		//System.out.println("Cycle Name : "+cycleName);

		//zeNavigator.launchReleaseApp("Test Planning");
		//zeNavigator.verifyCycleAndPhaseDetailsInTestPlanning(Config.getEASPropValue("CYCLE_NAME_TESTNG"), dateDetails[5], dateDetails[5], Config.getEASPropValue("PHASE_NAME_TESTNG"), dateDetails[5], dateDetails[5]);

		isSuccess = true;
		logger.info("bvt217 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 8)
	public void bvt217_configureAndRunZEAutomationJobTestUFT() {
		logger.info("Executing bvt217...");
		altID = 217;
		zeNavigator.selectProject("Sample Project");
		String releaseName = "Release 1.0";
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.launchReleaseApp("Vortex");
		String startDate = CommonUtil.returnTodaysDate();
		String endDate = CommonUtil.returnFutureDateStartingTodaysDate(0, 0, 0);

		String jobId = zeNavigator.createAutomationJob(Config.getVortexPropValue("UFT"),null
				, CommonUtil.getCompleteFilePath(Config.getVortexPropValue("UFT_RESULT")), false
				, Config.getValue("ZBOT"), startDate, endDate,Config.getVortexPropValue("UFT_JobName"), Config.getVortexPropValue("UFT_CycleName"),Config.getVortexPropValue("UFT_PhaseName"));

		Assert.assertNotNull(jobId, "Automation Job not created");

		zeNavigator.verifyAutomationJobCreated(jobId,"uft", null
				, CommonUtil.getCompleteFilePath(Config.getVortexPropValue("UFT_RESULT")), null, Config.getValue("ZBOT"), startDate, endDate);

		DateFormat df = new SimpleDateFormat("hh:mm:a:EEE:MMM:dd:yyyy");
		String date = df.format(new Date());
		String dateDetails[] = date.split(":");
		zeNavigator.executeAutomationJob(jobId, Config.getEASPropValue("CYCLE_NAME_UFT"), Config.getEASPropValue("PHASE_NAME_UFT"), false,"Anyone", "3");

		//String cycleName = "Selenium_" + dateDetails[3] + " " + dateDetails[5] + ", " + dateDetails[6] + " " + dateDetails[0] + ":" + dateDetails[1] + " " + dateDetails[2];
		//String phaseName = "Selenium_Automation_" + dateDetails[3] + " " + dateDetails[5] + ", " + dateDetails[6] + " " + dateDetails[0] + ":" + dateDetails[1] + " " + dateDetails[2];
		//System.out.println("Cycle Name : "+cycleName);

		//zeNavigator.launchReleaseApp("Test Planning");
		//zeNavigator.verifyCycleAndPhaseDetailsInTestPlanning(Config.getEASPropValue("CYCLE_NAME_UFT"), dateDetails[5], dateDetails[5], Config.getEASPropValue("PHASE_NAME_UFT"), dateDetails[5], dateDetails[5]);

		isSuccess = true;
		logger.info("bvt217 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 9)
	public void bvt217_configureAndRunZEAutomationJobTestEggPlant() {
		logger.info("Executing bvt217...");
		altID = 217;
		zeNavigator.selectProject("Sample Project");
		String releaseName = "Release 1.0";
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.launchReleaseApp("Vortex");
		String startDate = CommonUtil.returnTodaysDate();
		String endDate = CommonUtil.returnFutureDateStartingTodaysDate(0, 0, 0);

		String jobId = zeNavigator.createAutomationJob(Config.getVortexPropValue("EGGPLANT"),null
				, CommonUtil.getCompleteFilePath(Config.getVortexPropValue("EGGPLANT_RESULT")), false
				, Config.getValue("ZBOT"), startDate, endDate, Config.getVortexPropValue("EGGPLANT_JobName"), Config.getVortexPropValue("EGGPLANT_CycleName"),Config.getVortexPropValue("EGGPLANT_PhaseName"));

		Assert.assertNotNull(jobId, "Automation Job not created");

		zeNavigator.verifyAutomationJobCreated(jobId,"EggPlant", null
				, CommonUtil.getCompleteFilePath(Config.getVortexPropValue("EGGPLANT_RESULT")), null, Config.getValue("ZBOT"), startDate, endDate);

		DateFormat df = new SimpleDateFormat("hh:mm:a:EEE:MMM:dd:yyyy");
		String date = df.format(new Date());
		String dateDetails[] = date.split(":");
		zeNavigator.executeAutomationJob(jobId, Config.getEASPropValue("CYCLE_NAME_EGGPLANT"), Config.getEASPropValue("PHASE_NAME_EGGPLANT"), false,"Anyone", "3");

		//String cycleName = "Selenium_" + dateDetails[3] + " " + dateDetails[5] + ", " + dateDetails[6] + " " + dateDetails[0] + ":" + dateDetails[1] + " " + dateDetails[2];
		//String phaseName = "Selenium_Automation_" + dateDetails[3] + " " + dateDetails[5] + ", " + dateDetails[6] + " " + dateDetails[0] + ":" + dateDetails[1] + " " + dateDetails[2];
		//System.out.println("Cycle Name : "+cycleName);

		//zeNavigator.launchReleaseApp("Test Planning");
	//	zeNavigator.verifyCycleAndPhaseDetailsInTestPlanning(Config.getEASPropValue("CYCLE_NAME_EGGPLANT"), dateDetails[5], dateDetails[5], Config.getEASPropValue("PHASE_NAME_EGGPLANT"), dateDetails[5], dateDetails[5]);

		isSuccess = true;
		logger.info("bvt217 is executed successfully.");
	}

	/*@Test(enabled = true, priority = 10)
	public void bvt231_runZEAutomationJobWithCyclePrefixTest() {
		logger.info("Executing bvt231...");
		altID = 231;
		zeNavigator.selectProject("Sample Project");
		String releaseName = "Release 1.0";
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.launchReleaseApp("Vortex");
		jobID = Short.parseShort(Config.getValue("EXPECTED_FIRST_JOBID"));
		jobID++;

		String startDate = CommonUtil.returnTodaysDate();
		String endDate = CommonUtil.returnFutureDateStartingTodaysDate(0, 6, 0);
		//zeNavigator.launchReleaseApp("ZAutomation");
		zeNavigator.createAutomationJob("Selenium",CommonUtil.getCompleteFilePath(Config.getValue("SELENIUM_SCRIPT"))
				, Config.getValue("SELENIUM_RESULT"), true
				, Config.getValue("ZBOT"), startDate, endDate,Config.getVortexPropValue("SELENIUM_CycleName"),Config.getVortexPropValue("SELENIUM_JobName"),Config.getVortexPropValue("SELENIUM_PhaseName"));
		
		zeNavigator.verifyAutomationJobCreated(jobID+"", "Selenium", null
				, Config.getValue("SELENIUM_RESULT"), null, Config.getValue("ZBOT"), startDate, endDate);
		
		//zeNavigator.executeAutomationJob(jobID+"", "cycle7days", "2");
		
		DateFormat df = new SimpleDateFormat("hh:mm:a:EEE:MMM:dd:yyyy");
		String date = df.format(new Date());
		String dateDetails[] = date.split(":");
		
		String cycleName = "cycle7days_" + "SELENIUM_" + dateDetails[3] + " " + dateDetails[5] + ", " + dateDetails[6] + " " + dateDetails[0] + ":" + dateDetails[1] + " " + dateDetails[2];
		
	//	zeNavigator.launchReleaseApp("Test Planning");
		
	//	int endDate1 = CommonUtil.addNumberOfDaysInTodaysDateAndGetNewDate(Integer.parseInt(endDate)) - 1;
		
	//	System.out.println("Cycle End date :" + endDate1);
	//	zeNavigator.verifyCycleAndPhaseDetailsInTestPlanning(cycleName, dateDetails[5], endDate1+"", "SELENIUM_Automation", dateDetails[5], endDate1+"");
		
		isSuccess = true;
		logger.info("bvt231 is executed successfully.");
	}
	
	@Test(enabled = true, priority = 5)
	public void bvt232_runZEAutomationWithDifferentCycleDurationTest() {
		logger.info("Executing bvt232...");
		altID = 232;
		
		zeNavigator.launchReleaseApp("ZAutomation");
		jobID++;
		System.out.println("JOB ID :" + jobID);
		String startDate = CommonUtil.returnTodaysDate();
		String endDate = CommonUtil.returnFutureDateStartingTodaysDate(0, 14, 0);
		zeNavigator.createAutomationJob("Selenium",CommonUtil.getCompleteFilePath(Config.getValue("SELENIUM_SCRIPT"))
				, Config.getValue("SELENIUM_RESULT"), true
				, Config.getValue("ZBOT"), startDate, endDate);
		
		zeNavigator.verifyAutomationJobCreated(jobID+"", "Selenium", null
				, Config.getValue("SELENIUM_RESULT"), null, Config.getValue("ZBOT"), startDate, endDate);
		
		//zeNavigator.executeAutomationJob(jobID+"", "cycle15days", "2");
		
		DateFormat df = new SimpleDateFormat("hh:mm:a:EEE:MMM:dd:yyyy");
		String date = df.format(new Date());
		String dateDetails[] = date.split(":");
		
		String cycleName = "cycle15days_" + "SELENIUM_" + dateDetails[3] + " " + dateDetails[5] + ", " + dateDetails[6] + " " + dateDetails[0] + ":" + dateDetails[1] + " " + dateDetails[2];
		
		zeNavigator.launchReleaseApp("Test Planning");
		int endDate1 = CommonUtil.addNumberOfDaysInTodaysDateAndGetNewDate(Integer.parseInt(endDate)-1);
		System.out.println("Cycle End date :" + endDate1);
		zeNavigator.verifyCycleAndPhaseDetailsInTestPlanning(cycleName, dateDetails[5], endDate1+"", "SELENIUM_Automation", dateDetails[5], endDate1+"");
		
		
		
		isSuccess = true;
		logger.info("bvt232 is executed successfully.");
	}*/
	
	@BeforeMethod
	public void beforeMethod() {
		isSuccess = false;
	}

	@AfterMethod
	public void afterMethod() {
		baseAfterMethod();
		if(!isSuccess){
			zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
			String releaseName = "Release 1.0";
			zeNavigator.selectProject("Sample Project");
			Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		}
	}

	@BeforeClass
	public void beforeClass() {
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
	}
	
	@AfterClass
	public void afterClass() {
		zeNavigator.logout();
	}

}
