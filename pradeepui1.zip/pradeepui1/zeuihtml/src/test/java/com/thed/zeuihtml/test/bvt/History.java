package com.thed.zeuihtml.test.bvt;




import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.thed.zeuihtml.BaseTest;
import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.Constants;
import com.thed.zeuihtml.utils.CommonUtil;

public class History extends BaseTest {


	public History () {
	logger = Logger.getLogger(this.getClass());
	}
	
	@Test(enabled = testEnabled, priority=145)
	public void linkDefectCheckUsageHistory() {
		
		logger.info("Executing Bvt282...");
		altID = 282;
	zeNavigator.logout();
	zeNavigator.doLogin(Config.getValue("ZE_TESTER_USERNAME"), Config.getValue("ZE_TESTER_PASSWORD"));
		
		
		Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"))
				, "Failed to select Project : " + Config.getProjectPropValue("PROJECT1_NAME"));
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME")), "Release not found by name: " +Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
		zeNavigator.verifyReleaseSummaryPage(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
		zeNavigator.launchReleaseApp("Test Execution");
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		
		String	defectID = zeNavigator.getDefectIDLinkDefect(Config.getTCRPropValue("TESTCASE_FOR_PHASE_FIND_AND_ADD_"));
		
		String appName = "Test Repository";
		Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"))
				, "Failed to select Project : " + Config.getProjectPropValue("PROJECT1_NAME"));
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME")), "Release not found by name: " +Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
		zeNavigator.verifyReleaseSummaryPage(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
		zeNavigator.launchReleaseApp(appName);
		
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		
		Map<String, String> values = new HashMap<String, String>();
		values.put("DEFECT", defectID);
		values.put("TESTCASE_NAME",Config.getTCRPropValue("TESTCASE_FOR_PHASE_FIND_AND_ADD_") );
		values.put("NODE_NAME", Config.getTCRPropValue("NODE_1"));
		
		zeNavigator.checkUsageHistory(values);
		
		isSuccess = true;
		logger.info("bvt279 is completed successfully...");
		
	}
	
	@Test(enabled=testEnabled,priority=146)
	public void checkUsageHistoryExecutionStatus()
	{
		logger.info("Executing Bvt282...");
		altID = 282;
	zeNavigator.logout();
	zeNavigator.doLogin(Config.getValue("ZE_TESTER_USERNAME"), Config.getValue("ZE_TESTER_PASSWORD"));
	Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"))
			, "Failed to select Project : " + Config.getProjectPropValue("PROJECT1_NAME"));
	Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME")), "Release not found by name: " +Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
	zeNavigator.verifyReleaseSummaryPage(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
	zeNavigator.launchReleaseApp("Test Execution");
	List<String> nodeList = new ArrayList<String>();
	nodeList.add(0, Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
	nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
	nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
	nodeList.add(3, Config.getTCRPropValue("NODE_1"));
	zeNavigator.navigateToNodesInTestExecution(nodeList);
	zeNavigator.executeTestcaseInSelectedNodeAndVerify(Config.getTCRPropValue("TESTCASE_USAGE_HISTORY_3"), "Fail");
	String status = zeNavigator.getStatusInExecution(Config.getTCRPropValue("TESTCASE_USAGE_HISTORY_3"));
	
	String appName = "Test Repository";
	Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"))
			, "Failed to select Project : " + Config.getProjectPropValue("PROJECT1_NAME"));
	Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME")), "Release not found by name: " +Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
	zeNavigator.verifyReleaseSummaryPage(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
	zeNavigator.launchReleaseApp(appName);
	
	List<String> phases = new ArrayList<String>();
	phases.add(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
	phases.add(Config.getTCRPropValue("PHASE_1"));
	phases.add(Config.getTCRPropValue("NODE_1"));
	Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
	
	Map<String, String> values = new HashMap<String, String>();
	values.put("STATUS", status);
	values.put("TESTCASE_NAME",Config.getTCRPropValue("TESTCASE_USAGE_HISTORY_3") );
	values.put("NODE_NAME", Config.getTCRPropValue("NODE_1"));
	
	zeNavigator.checkUsageHistory(values);
	
	isSuccess = true;
	logger.info("bvt279 is completed successfully...");
		
	}
	
	@Test(enabled=testEnabled,priority=147)
	public void AttemptToviewHistoryTestcaseDeletedfromPlanning()
	{
		logger.info("Executing Bvt282...");
		altID = 282;
		String appName = "Test Repository";
	//zeNavigator.logout();
//	zeNavigator.doLogin(Config.getValue("ZE_TESTER_USERNAME"), Config.getValue("ZE_TESTER_PASSWORD"));
	Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"))
				, "Failed to select Project : " + Config.getProjectPropValue("PROJECT1_NAME"));
	Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME")), "Release not found by name: " +Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
	zeNavigator.launchReleaseApp(appName);
	List<String> phases = new ArrayList<String>();
	phases.add(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
	phases.add(Config.getTCRPropValue("SUB_NODE_9"));
	Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
	String nodeName = Config.getTCRPropValue("SUB_NODE_9");
	String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
	Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");
	System.out.println("Testcase IDs : " + testcaseId);
	Map<String, String> values = new HashMap<String, String>();
	values.put("NODE_NAME", nodeName);
	values.put("TESTCASE_ID", testcaseId);
	values.put("TESTCASE_SUMMARY", Config.getTCRPropValue("TESTCASE_USAGE_HISTORY_1"));
	Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
	
	//Test Planning
	Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"))
			, "Failed to select Project : " + Config.getProjectPropValue("PROJECT1_NAME"));
	Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME")), "Release not found by name: " +Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
	String appName1 = "Test Planning";
	zeNavigator.launchReleaseApp(appName1);
	zeNavigator.addPhaseToCycle(Config.getEASPropValue("CYCLE5_NAME"), Config.getTCRPropValue("SUB_NODE_9")
			, "anyone", true);
	zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE5_NAME"), Config.getTCRPropValue("SUB_NODE_9"), false);
	List<String> nodeList = new ArrayList<String>();
	nodeList.add(0, Config.getTCRPropValue("SUB_NODE_9"));
	zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
	zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("TESTCASE_USAGE_HISTORY_1"), "Anyone", true);
	
	//Test Repository
	Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"))
			, "Failed to select Project : " + Config.getProjectPropValue("PROJECT1_NAME"));
	Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME")), "Release not found by name: " +Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
	zeNavigator.launchReleaseApp(appName);
	//List<String> phases1 = new ArrayList<String>();
	phases.add(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
	phases.add(Config.getTCRPropValue("SUB_NODE_9"));
	Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
//	Map<String, String> values1 = new HashMap<String, String>();
	values.put("STATUS", "Not Executed");
	values.put("TESTCASE_NAME",Config.getTCRPropValue("TESTCASE_USAGE_HISTORY_1"));
	values.put("NODE_NAME", Config.getTCRPropValue("SUB_NODE_9"));
	zeNavigator.checkUsageHistory(values);
	
	
	
	//Test Planning
	Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"))
			, "Failed to select Project : " + Config.getProjectPropValue("PROJECT1_NAME"));
	Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME")), "Release not found by name: " +Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
	//zeNavigator.launchReleaseApp(appName);
	//String appName = "Test Planning";
	zeNavigator.launchReleaseApp(appName1);
	zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE5_NAME"), Config.getTCRPropValue("SUB_NODE_9"), false);
	zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
	List<String> testcasNameToDelete = new ArrayList<String>();
	testcasNameToDelete.add(0, Config.getTCRPropValue("TESTCASE_USAGE_HISTORY_1"));
	zeNavigator.deleteTestcaseFromSelectedNodeInAssingTestcaseToExecuteWindow(testcasNameToDelete, true);
	
	//Test Repository
	Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"))
			, "Failed to select Project : " + Config.getProjectPropValue("PROJECT1_NAME"));
	Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME")), "Release not found by name: " +Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
	zeNavigator.launchReleaseApp(appName);
	
	//List<String> phases1 = new ArrayList<String>();
	phases.add(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
	phases.add(Config.getTCRPropValue("SUB_NODE_9"));
	Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
	//Map<String, String> values1 = new HashMap<String, String>();
	values.put("STATUS", "Not Executed");
	values.put("TESTCASE_NAME",Config.getTCRPropValue("TESTCASE_USAGE_HISTORY_1"));
	values.put("NODE_NAME", Config.getTCRPropValue("SUB_NODE_9"));
	Assert.assertFalse(zeNavigator.checkUsageHistory(values));
	
	
	}
	@BeforeMethod
	public void beforeMethod() {
		isSuccess = false;
	}

	@AfterMethod
	public void afterMethod() {
		baseAfterMethod();
		if(!isSuccess){
			zeNavigator.doLogin(Config.getValue("ZE_TESTER_USERNAME"), Config.getValue("ZE_TESTER_PASSWORD"));
		}
	}

	@BeforeClass
	public void beforeClass() {
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
	}
	
	@AfterClass
	public void afterClass() {
		zeNavigator.logout();
	}

	
	
}