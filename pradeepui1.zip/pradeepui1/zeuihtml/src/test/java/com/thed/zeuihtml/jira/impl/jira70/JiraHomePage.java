package com.thed.zeuihtml.jira.impl.jira70;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;

public class JiraHomePage {

	Logger logger;
	int counter = 1;
	
	public JiraHomePage(){
		logger = Logger.getLogger(this.getClass());
	}
	
	public static JiraHomePage getInstance(){
		return PageFactory.initElements(Driver.driver, JiraHomePage.class);
	}
	
	/******************************************************
	 * 	WEBELEMENTS
	 *****************************************************/
	
	@FindBy(xpath="//a[@id='home_link']")
	private WebElement menuDashboard;
	
	@FindBy(xpath="//a[text()='System Dashboard']")
	private WebElement linkSystemDashboard;
	
	@FindBy(xpath="//h3[text()='Activity Stream']")
	private WebElement headerActivityStream;
	
	@FindBy(xpath="//a[text()='Moments ago']")
	private WebElement linkMomentsAgo;
	
	@FindBy(xpath="//input[@class='text aui-ss-field ajs-dirty-warning-exempt']")
	private WebElement process;
	
	/******************************************************
	 * 	Methods
	 *****************************************************/
	
	public boolean verifyNewMappedProject(String zephyrProjectName, String jiraProjectName){
		CommonUtil.browserRefresh();
		CommonUtil.normalWait(5000);
		try {
			//a[text()='Moments ago']/parent::div//preceding-sibling::div[text()='New testing project mapped in Zephyr']
			Driver.driver.switchTo().frame("gadget-10003");
			//do your stuff
			
			
			if(CommonUtil.visibilityOfElementLocated
					("//a[text()='Moments ago']/parent::div//preceding-sibling::div[text()='New testing project mapped in Zephyr']")){
				logger.info("Project Mapped Information Found as : New testing project mapped in Zephyr , Now going to verify project names");
				
				String text = CommonUtil.returnWebElement
				("//a[text()='Moments ago']/parent::div//preceding-sibling::div[text()='New testing project mapped in Zephyr']/div").
				getText();
				
				if(text.contains(zephyrProjectName)){
					logger.info("Zephyr Project Name found in Activity as : "+zephyrProjectName);
				}else{
					logger.info("Zephyr Project Name not found in Activity as : "+zephyrProjectName);
					Driver.driver.switchTo().defaultContent();
					return false;
				}
				if(text.contains(jiraProjectName)){
					logger.info("Zephyr Project Name found in Activity as : "+jiraProjectName);
				}else{
					logger.info("Zephyr Project Name not found in Activity as : "+jiraProjectName);
					Driver.driver.switchTo().defaultContent();
					return false;
				}
				
			}else{
				logger.info("Activity not found as : New testing project mapped in Zephyr");
				Driver.driver.switchTo().defaultContent();
				return false;
			}
			Driver.driver.switchTo().defaultContent();
			
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	
	public boolean waitForProcessToComplete(){
		
		try{
			logger.info("Checking progress bar to complete");
			CommonUtil.normalWait(1000);
			System.out.println("Progress Bar status: " + process.isDisplayed());
			if(counter>60){
				logger.info("Progress bar is not completed after 1 min, so failing test");
				return false;
			}
			if(process.isDisplayed()){
				counter++;
				logger.info("progress bar still inprogress after "+counter+" sec");
				waitForProcessToComplete();
			}
			logger.info("Progress bar completed within " + counter + "seconds");
			return true;
		}catch(Exception e){
			return false;
		}
		
		
	}
	
}
