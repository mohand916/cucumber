package com.thed.zeuihtml.utils;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.testautomationguru.utility.CompareMode;
import com.testautomationguru.utility.PDFUtil;
import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.Constants;


public class CommonUtil {

	public static Properties loadProperties(String path) {
		Properties properties = new Properties();
		FileInputStream fis = null ;
		try {
			File file = getPropertyFilePath(path); 
			fis = new FileInputStream(file);
			properties.load(fis);
			fis.close();
		} catch (Exception e) {
			return null ;
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return properties ;
	}
	
	public static File getPropertyFilePath(String path) throws URISyntaxException {
        URL url = path.getClass().getResource(path);
	    File inputFile = new File(url.toURI());
	    return inputFile ;
	}
	
	public static boolean launchBrowser(String url){
		try{
			
			Driver.driver.get(url);
			Driver.driver.manage().window().maximize();
			implicitWait(Constants.EXPLICIT_WAIT_HIGH);
		}catch(Exception e){
			System.out.println(e);
			return false;
		}
		return true;
	}
	
	public static WebDriver getNewWebDriver() {
		return Driver.browserFactory();
	}
	
	public static void moveToElement(WebElement wb){
		Actions action = new Actions(Driver.driver);
		 
        action.moveToElement(wb).build().perform();
	}
	
	public static boolean moveToElement(String xpath){
		 try {
		        Driver.driver.findElement(By.xpath(xpath));
		        return true;
		    } catch (Exception e) {
		        return false;
		    }
		}
	
	public static boolean isElementPresent(String xpath) {
	    try {
	        Driver.driver.findElement(By.xpath(xpath));
	        return true;
	    } catch (Exception e) {
	        return false;
	    }
	}
	
	public static void implicitWait(int timetowaitInSec){
		Driver.driver.manage().timeouts().implicitlyWait(timetowaitInSec, TimeUnit.SECONDS);
	}
	
	public static void ExplicitWaitForElement(WebElement element){
		try{
			implicitWait(0);
			WebDriverWait wb=new WebDriverWait(Driver.driver, Constants.EXPLICIT_WAIT_HIGH);
			wb.until(ExpectedConditions.visibilityOf(element));
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void isElementClickable(WebElement element){
		try{
			implicitWait(0);
			WebDriverWait wb=new WebDriverWait(Driver.driver, Constants.EXPLICIT_WAIT_HIGH);
			wb.until(ExpectedConditions.elementToBeClickable(element));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static boolean isElementClickable(WebElement element, int timetowaitInSec){
		try{
			WebDriverWait wb=new WebDriverWait(Driver.driver, timetowaitInSec);
			wb.until(ExpectedConditions.elementToBeClickable(element));
			return true;
		}catch(Exception e){
			return false;
		}
	}
	
	public static void closeTheDriver(){
		Driver.driver.quit();
	}
	
	public static String getTitle(){
		return Driver.driver.getTitle();
	}
	
	public static String getCurrentURL(){
		return Driver.driver.getCurrentUrl();
	}
	
	public static void normalWait(int timeInMilli){
		try{
			Thread.sleep(timeInMilli);
			
		}catch(InterruptedException e){
			e.printStackTrace();
		}
		
	}
	
	public static void selectListWithVisibleText(WebElement wb, String textToSelect){
		Select select=new Select(wb);
		select.selectByVisibleText(textToSelect);
		normalWait(1000);
	}
	
	public static void selectListWithIndex(WebElement wb, int indexToSelect){
		Select select=new Select(wb);
		select.selectByIndex(indexToSelect);
	}
	
	public static void selectListWithValue(WebElement wb, String valueToSelect){
		Select select=new Select(wb);
		select.selectByValue(valueToSelect);
	}
	
	public static WebElement returnWebElement(String xpath){
		return Driver.driver.findElement(By.xpath(xpath));
	}
	public static List<WebElement> returnWebElements(String xpath){
		return Driver.driver.findElements(By.xpath(xpath));
	}
	public static int returnSizeOfElements(String xpath){
		int count = 0;
		try{
			List<WebElement> list = Driver.driver.findElements(By.xpath(xpath));
			count = list.size();
		}catch(Exception e){
			return count;
		}
		return count;
	}
	
	public static boolean visibilityOfElementLocated(String xpath){
		try{
			implicitWait(0);
			WebDriverWait wb=new WebDriverWait(Driver.driver, Constants.EXPLICIT_WAIT_HIGH);
			wb.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
		}catch(Exception e){
			return false;
		}
		return true;
	}
	public static boolean visibilityOfElementLocated(String xpath,int waitTimeInSeconds){
		try{
			implicitWait(0);
			WebDriverWait wb=new WebDriverWait(Driver.driver, waitTimeInSeconds);
			wb.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
		}catch(Exception e){
			return false;
		}
		return true;
	}
	public static boolean visibilityOfElementLocated(WebElement element){
		try{
			implicitWait(0);
			WebDriverWait wb=new WebDriverWait(Driver.driver, Constants.EXPLICIT_WAIT_HIGH);
			wb.until(ExpectedConditions.visibilityOf(element));
		}catch(Exception e){
			return false;
		}
		return true;
	}
	
	public static boolean visibilityOfElementLocated(WebElement element, int waitTimeInSeconds){
		try{
			implicitWait(0);
			WebDriverWait wb=new WebDriverWait(Driver.driver, waitTimeInSeconds);
			wb.until(ExpectedConditions.visibilityOf(element));
		}catch(Exception e){
			return false;
		}
		return true;
	}
	
	public static boolean textToBePresentInElement(WebElement element, String text){
		try{
			WebDriverWait wb=new WebDriverWait(Driver.driver, Constants.EXPLICIT_WAIT_HIGH);
			wb.until(ExpectedConditions.textToBePresentInElement(element, text));
		}catch(Exception e){
			return false;
		}
		return true;
	}
	
	public static String captureScreenshot(String destPath){
		try{
			EventFiringWebDriver edriver=new EventFiringWebDriver(Driver.driver);
			File src=edriver.getScreenshotAs(OutputType.FILE);
			System.out.println("output: " + src.getAbsolutePath());
			File dest=new File(destPath);
			FileUtils.copyFile(src, new File(destPath));
			return destPath;
		}catch(Exception e){
			e.printStackTrace();
		}
		return null ;
	}
	public static Actions actionClass(){
		Actions act=new Actions(Driver.driver);
		return act;
	}
	public static Alert switchToAlert(){
		try{
			return Driver.driver.switchTo().alert();
		}catch(Exception e){
			return null;
		}
	}
	
	public static void switchiframe( String element,String text) {
		try {
		Driver.driver.switchTo().frame(element);
		WebElement wb = Driver.driver.findElement(By.id("tinymce"));
		System.out.println("Entering something in text input");
	    wb.sendKeys(Keys.CONTROL + "a");
		wb.sendKeys(text);
		Driver.driver.switchTo().defaultContent();
	}
		catch(Exception e){
			e.printStackTrace();
		}	
		
	}
	
	public static boolean isElementPresent(WebElement element) {
		boolean flag = false;
		try {
			if (element.isDisplayed()
					|| element.isEnabled())
				flag = true;
		} catch (NoSuchElementException e) {
			flag = false;
		} catch (StaleElementReferenceException e) {
			flag = false;
		}
		return flag;
	}
	public static void pressEnter(){
		Robot r;
		try {
			r = new Robot();
			r.keyPress(KeyEvent.VK_ENTER);
			r.keyRelease(KeyEvent.VK_ENTER);
		} catch (AWTException e) {
			e.printStackTrace();
		}
		
	}
	public static void browserRefresh(){
		Driver.driver.navigate().refresh();
		implicitWait(120);
	}
	public static void doubleClick(WebElement element) {
		try {
			Actions action = new Actions(Driver.driver).doubleClick(element);
			action.build().perform();

			System.out.println("Double clicked the element");
		} catch (StaleElementReferenceException e) {
			System.out.println("Element is not attached to the page document "
					+ e.getStackTrace());
		} catch (NoSuchElementException e) {
			System.out.println("Element " + element + " was not found in DOM "
					+ e.getStackTrace());
		} catch (Exception e) {
			System.out.println("Element " + element + " was not clickable "
					+ e.getStackTrace());
		}
	}
	public static void javaWait(int time) {
		try{
			if(time==1){
				Thread.sleep(1000);
			}else if (time==2) {
				Thread.sleep(2000);
			}else if (time==3) {
				Thread.sleep(3000);
			}else if (time==4) {
				Thread.sleep(4000);
			}else if (time==5){
				Thread.sleep(5000);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public static String getText(String xpath){
		String text = null;
		try{
			text = Driver.driver.findElement(By.xpath(xpath)).getText();
		}catch(Exception e){
			e.printStackTrace();
			return text;
		}
		return text;
	}
	public static String getFoundElementSize(String xpath){
		Integer elementSize = null;
		try{
			elementSize = Driver.driver.findElements(By.xpath(xpath)).size();
		}catch(Exception e){
			e.printStackTrace();
			return elementSize.toString();
		}
		return elementSize.toString();
	}
	public static boolean scrollPage(){
		try{
			((JavascriptExecutor)Driver.driver).executeScript("javascript:window.scrollBy(0,400)"); 
		    
		}catch(Exception e){
			return false;
		}
		return true;
	}
	public static boolean scrollToWebElement(WebElement wb){
		try{    
		    ((JavascriptExecutor)Driver.driver).executeScript("arguments[0].scrollIntoView();", wb);
		}catch(Exception e){
			return false;
		}
		return true;
	}
	public static boolean scrollToWebElementAndView(WebElement wb){
		try{    
		    ((JavascriptExecutor)Driver.driver).executeScript("arguments[0].scrollIntoView(true);", wb);
		}catch(Exception e){
			return false;
		}
		return true;
	}
	public static boolean ClickOnElementUsingJS(WebElement wb){
		try{    
		    ((JavascriptExecutor)Driver.driver).executeScript("arguments[0].click();", wb);
		}catch(Exception e){
			return false;
		}
		return true;
	}
	
	
	public static String launchNewBrowserWindow(String url){
		try{
			//String selectLinkOpeninNewTab = Keys.chord(Keys.CONTROL,"t");
			//Driver.driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"n");
			//Actions newTab = new Actions(Driver.driver);
		    //newTab.sendKeys(Keys.CONTROL + "t").perform();
			((JavascriptExecutor)Driver.driver).executeScript("window.open();");
			
			Set<String> windowID = Driver.driver.getWindowHandles();
			
			Iterator<String> it1 = windowID.iterator();
			String parentWin = it1.next();
			String childWin = it1.next();
			Driver.driver.switchTo().window(childWin);
			Driver.driver.navigate().to(url);
			implicitWait(60);
			return parentWin;
			}catch(Exception e){
				return null;
			}
			
	}
	
	public static boolean returnToParentWindow(String parentWindowId){
		
		try{
			Driver.driver.switchTo().window(parentWindowId);
			normalWait(500);
			return true;
		}catch(Exception e){
			return false;
		}
	}
	
	public static boolean closeCurrentBrowserTab(){
		try{
		Driver.driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"w");
		}catch(Exception e){
			return false;
		}
		return true;
	}
	
	public static boolean closeCurrentBrowserWindow(){
		try{
		Driver.driver.close();
		}catch(Exception e){
			return false;
		}
		return true;
	}
	
	public static String returnTodaysDate(){
		DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
		return df.format(new Date());
	}
	
	public static int addNumberOfDaysInTodaysDateAndGetNewDate(int numberOfDaysToAdd) {
		
		  DateFormat df = new SimpleDateFormat("dd:MM:yyyy");
	      String d = df.format(new Date());
	      String date[] = d.split(":");
	      
	      int tdate = Integer.parseInt(date[0]) ;
	      int tmonth = Integer.parseInt(date[1]) ;
	      int year = Integer.parseInt(date[2]);
	      System.out.println("Date to add : " + numberOfDaysToAdd);
	      System.out.println("Todays Date : " + tdate);
	      
	      if(tdate+numberOfDaysToAdd <31) {
	    	  return tdate+numberOfDaysToAdd;
	      }else {
	    	  if((date[1]=="1")||(date[1]=="3")||(date[1]=="5")||(date[1]=="7")||(date[1]=="8")||(date[1]=="10")||(date[1]=="12")) {
	    		  return (tdate+numberOfDaysToAdd - 31);
	    	  }else {
	    		  if(date[1]=="2") {
	    			  
	    			  if(year%4 == 0) {
	    				  return (tdate+numberOfDaysToAdd - 29);
	    			  }else {
	    				  return (tdate+numberOfDaysToAdd - 28);
	    			  }	  
	    		  }else {
	    			  return (tdate+numberOfDaysToAdd - 30);
	    		  }
	    	  }
	    	  
	      }

	}
	
	public static String returnFutureDateStartingTodaysDate(int noOfMonthsToAdd, int noOfDaysToAdd, int noOfYearsToAdd){
		String todaysDate = returnTodaysDate();
		String splitDays[] = todaysDate.split("/");
		int newMM = Integer.parseInt(splitDays[0]) + noOfMonthsToAdd;
		int newDD = Integer.parseInt(splitDays[1]) + noOfDaysToAdd;
		int newYYYY = Integer.parseInt(splitDays[2]) + noOfYearsToAdd;
		String newDate;
		String newMonth;
		if(newDD<10){
			newDate = "0"+newDD;
		}else{
			if(newDD>30){
				newMM++;
				
				if((newDD - 30)<10){
					newDate = "0" + (newDD - 30) +"";
				}else{
					newDate = (newDD - 30) +"";
				}	
			}else{
				newDate = ""+newDD;
			}	
		}
		
		if(newMM<10){
			newMonth = "0"+newMM;
		}else{
			if(newMM>12){
				newYYYY++;
				
				if((newMM - 12)<10){
					newMonth = "0" + (newMM - 12) +"";
				}else{
					newMonth = (newMM - 12) +"";
				}	
			}else{
				newMonth = ""+newMM;
			}
			
		}
		
		return newMonth+"/"+newDate+"/"+newYYYY;
	}
	
	public static String getStringCellValueFromExcelSheet(String fileNameWithPath, int row, int cell, String sheetName){
		String data="";
		try {
			FileInputStream fis = new FileInputStream(new File(fileNameWithPath));
			Workbook wb = WorkbookFactory.create(fis);
			Sheet sheet = wb.getSheet(sheetName);
			Row r = sheet.getRow(row);
			data = r.getCell(cell).getStringCellValue();
			fis.close();
			}catch (Exception e) {
				e.printStackTrace();
				}
		return data;
		}
	
	public static boolean verifyExcelCellData(String fileNameWithPath, int row, int cell, String sheetName, String expectedCellValue) {
		try {
			String actualValue = getStringCellValueFromExcelSheet(fileNameWithPath, row, cell, sheetName);
			return actualValue.equals(expectedCellValue);
		} catch (Exception e) {
			return false;
		}
	}
	
	
	
	
	/**
     * List all the files under a directory
     * @param directoryName to be listed
     */
    public static List<String> returnFileNames(String directoryName){
        File directory = new File(directoryName);
        List<String> fileNames = new ArrayList<String>();
        File[] fList = directory.listFiles();
        for (File file : fList){
            if (file.isFile()){
            	fileNames.add(file.getName());
            }
        }
        return fileNames;
    }
    
    public static double getFileSize(String fileNameWithPath){
		File file=new File(fileNameWithPath);
	
		if(file.exists()){
			return file.length();
		}
		else{
			return -1;
			}
	}
    
    public static void moveFile(String fileNameWithPath, String newPath){

    	File file=new File(fileNameWithPath);
    	file.renameTo(new File(newPath + "\\" + file.getName()));
    }

    
    public static void copyFile(String fileNameWithPath, String fileNameWithnewPath){

    	try {
    		File src=new File(fileNameWithPath);
    		File dest=new File(fileNameWithnewPath);
    		System.out.println(dest.canWrite());
        	if(dest.exists()) {
        		dest.delete();
        	}
        	Files.copy(src.toPath(), dest.toPath());
		} catch (Exception e) {
			e.printStackTrace();
		}	
    	
    }
    
    
    public static void remveAllAndAddNewLinesInFile(String fileNameWithPath, List<String> lines) {
    	File file = new File(fileNameWithPath);
    	PrintWriter pw = null;
    	try {
			pw = new PrintWriter(file);
			
			for(String line:lines) {
				pw.println(line); 
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			pw.close();
		}
    	
    }
    
    public static boolean renameFile(String fileNameWithPath, String newName) {
    	try {
    		Path source = Paths.get(fileNameWithPath);
        	Files.move(source, source.resolveSibling(newName));
    	}catch (Exception e) {
			return false;
		}
    	return true;
    }
    
    public static void cleanDirectory(String directoryPath) {
    	File file=new File(directoryPath);
    	try {
			FileUtils.cleanDirectory(file);
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
    
    
    public static boolean compareExcel(String file1NameWithPath, String file2NameWithPath, List<Integer> ignoreCells) {
    	boolean success = false;
    	FileInputStream excellFile1 = null;
    	FileInputStream excellFile2 = null;
    	try {
    		
            // get input excel files
            excellFile1 = new FileInputStream(new File(
                    file1NameWithPath));
            excellFile2 = new FileInputStream(new File(
            		file2NameWithPath));

            // Create Workbook instance holding reference to .xlsx file
            XSSFWorkbook workbook1 = new XSSFWorkbook(excellFile1);
            XSSFWorkbook workbook2 = new XSSFWorkbook(excellFile2);

            // Get first/desired sheet from the workbook
            XSSFSheet sheet1 = workbook1.getSheetAt(0);
            XSSFSheet sheet2 = workbook2.getSheetAt(0);

            // Compare sheets
            if(compareTwoSheets(sheet1, sheet2,ignoreCells)) {
            	success = true;
                System.out.println("\n\nThe two excel sheets are Equal");
            } else {
                System.out.println("\n\nThe two excel sheets are Not Equal");
            }
            
            return success;

        } catch (Exception e) {
            e.printStackTrace();
            return success;
        }finally {
        	//close files
            try {
				excellFile1.close();
				excellFile2.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            
		}
    }
    
 // Compare Two Sheets
    public static boolean compareTwoSheets(XSSFSheet sheet1, XSSFSheet sheet2,  List<Integer> ignoreCells) {
        int firstRow1 = sheet1.getFirstRowNum();
        int lastRow1 = sheet1.getLastRowNum();
        boolean equalSheets = true;
        for(int i=firstRow1; i <= lastRow1; i++) {
            
            System.out.println("\n\nComparing Row "+i);
            
            XSSFRow row1 = sheet1.getRow(i);
            XSSFRow row2 = sheet2.getRow(i);
            if(!compareTwoRows(row1, row2,ignoreCells)) {
                equalSheets = false;
                System.out.println("Row "+i+" - Not Equal");
                break;
            } else {
                System.out.println("Row "+i+" - Equal");
            }
        }
        return equalSheets;
    }

    
 // Compare Two Rows
    public static boolean compareTwoRows(XSSFRow row1, XSSFRow row2,  List<Integer> ignoreCells) {
        if((row1 == null) && (row2 == null)) {
            return true;
        } else if((row1 == null) || (row2 == null)) {
            return false;
        }
        
        int firstCell1 = row1.getFirstCellNum();
        int lastCell1 = row1.getLastCellNum();
        boolean equalRows = true;
        
        // Compare all cells in a row
        for(int i=firstCell1; i <= lastCell1; i++) {
        	XSSFCell cell1 = row1.getCell(i);
        	XSSFCell cell2 = row2.getCell(i);
            
            if(!ignoreCells.contains(i)) {
            	if(!compareTwoCells(cell1, cell2)) {
                    equalRows = false;
                    System.err.println("       Cell "+i+" - NOt Equal");
                    break;
                } else {
                    System.out.println("       Cell "+i+" - Equal");
                }
            }else {
            	System.out.println("Ignored cell " + i);
            }
          
        }
        return equalRows;
    }
    
    
 // Compare Two Cells
    public static boolean compareTwoCells(XSSFCell cell1, XSSFCell cell2) {
        if((cell1 == null) && (cell2 == null)) {
            return true;
        } else if((cell1 == null) || (cell2 == null)) {
            return false;
        }
        
        boolean equalCells = false;
        int type1 = cell1.getCellType();
        int type2 = cell2.getCellType();
        if (type1 == type2) {
            if (cell1.getCellStyle().equals(cell2.getCellStyle())) {
                // Compare cells based on its type
                switch (cell1.getCellType()) {
                case XSSFCell.CELL_TYPE_FORMULA:
                    if (cell1.getCellFormula().equals(cell2.getCellFormula())) {
                        equalCells = true;
                    }
                    break;
                case XSSFCell.CELL_TYPE_NUMERIC:
                    if (cell1.getNumericCellValue() == cell2
                            .getNumericCellValue()) {
                        equalCells = true;
                    }
                    break;
                case XSSFCell.CELL_TYPE_STRING:
                    if (cell1.getStringCellValue().equals(cell2
                            .getStringCellValue())) {
                        equalCells = true;
                    }
                    break;
                case XSSFCell.CELL_TYPE_BLANK:
                    if (cell2.getCellType() == XSSFCell.CELL_TYPE_BLANK) {
                        equalCells = true;
                    }
                    break;
                case XSSFCell.CELL_TYPE_BOOLEAN:
                    if (cell1.getBooleanCellValue() == cell2
                            .getBooleanCellValue()) {
                        equalCells = true;
                    }
                    break;
                case XSSFCell.CELL_TYPE_ERROR:
                    if (cell1.getErrorCellValue() == cell2.getErrorCellValue()) {
                        equalCells = true;
                    }
                    break;
                default:
                    if (cell1.getStringCellValue().equals(
                            cell2.getStringCellValue())) {
                        equalCells = true;
                    }
                    break;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
        return equalCells;
    }
    
    
    public static boolean compareTwoPDFFilesData(String file1WithPath, String file2WithPath) {
    	try {
    		
    		PDFUtil pdfUtil = new PDFUtil();
    		pdfUtil.excludeText("\\d+", "AM", "PM");
    		
    		return pdfUtil.compare(file1WithPath, file2WithPath);
    		
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
    }
    
    public static boolean compareTwoPDFFilesInVisualMode(String file1WithPath, String file2WithPath) {
    	try {
    		
    		PDFUtil pdfUtil = new PDFUtil();
    		pdfUtil.setCompareMode(CompareMode.VISUAL_MODE);
    		pdfUtil.excludeText("\\d+", "AM", "PM");
    		pdfUtil.highlightPdfDifference(true);
    		pdfUtil.setImageDestinationPath(Config.getValue("EXPORT_FILE_PATH")+"/delete");
    		return pdfUtil.compare(file1WithPath, file2WithPath);
    		
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
    }
    
    public static String getCompleteFilePath(String filePath) {
    	return System.getProperty("user.dir") + "\\" + filePath;
    }
    
    public static boolean alertMsg(String msg){
		try{
			//((JavascriptExecutor) Driver.driver).executeScript("setTimeout(function(){alert('"+msg+"');},0)");
			Thread.sleep(2000);
			Driver.driver.switchTo().alert().accept();
		} catch (Exception e) {
			return false;
		}
		return true;
	}
    public static void stopWindowsService(String serviceName) {
    	 String[] command = {"cmd.exe", "/c", "net", "stop", serviceName};
    	 InputStream inputStream = null;
       	 InputStreamReader inputStreamReader = null;
       	 BufferedReader bufferedReader = null;
         try {
             Process process = new ProcessBuilder(command).start();
             inputStream = process.getInputStream(); 
             inputStreamReader = new InputStreamReader(inputStream);
             bufferedReader = new BufferedReader(inputStreamReader);
             String line;
             while ((line = bufferedReader.readLine()) != null) {
                 System.out.println(line);
             }
         } catch(Exception ex) {
             System.out.println("Exception : "+ex);
         }finally {
         	try {
 				inputStream.close();
 				inputStreamReader.close();
 	            bufferedReader.close();
 			} catch (IOException e) {
 				e.printStackTrace();
 			}
             
 		}
    }
    
    public static void startWindowsService(String serviceName) {
   	 
    	String[] command = {"cmd.exe", "/c", "net", "start", serviceName};
   	 	InputStream inputStream = null;
   	 	InputStreamReader inputStreamReader = null;
   	 	BufferedReader bufferedReader = null;
   	
        try {
            Process process = new ProcessBuilder(command).start();
            inputStream = process.getInputStream(); 
            inputStreamReader = new InputStreamReader(inputStream);
            bufferedReader = new BufferedReader(inputStreamReader);
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                System.out.println(line);
            }
            
        } catch(Exception ex) {
            System.out.println("Exception : "+ex);
        }finally {
        	try {
				inputStream.close();
				inputStreamReader.close();
	            bufferedReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
            
		}
   }
    

}
