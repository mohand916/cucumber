package com.thed.zeuihtml.utils;

import java.io.File;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;

import com.thed.zeuihtml.Config;

public class Driver {

	public static WebDriver driver = browserFactory();
	//public static WebDriver driver = new ChromeDriver();
	
	public static WebDriver browserFactory(){
		//System.setProperty("webdriver.gecko.driver","G:\\eclipse-workspace\\zeeui\\driver\\geckodriver.exe");
		String browserType=Config.getValue("BROWSER_TYPE");
		if(browserType.equals("firefox")){
			System.setProperty("webdriver.gecko.driver",Config.getValue("GEKO_DRIVER"));
			FirefoxProfile profile = new FirefoxProfile();
			profile.setPreference("browser.download.folderList",2);
			profile.setPreference("browser.download.manager.showWhenStarting",false);
			profile.setPreference("browser.download.dir",Config.getValue("EXPORT_FILE_PATH"));
			profile.setPreference("browser.helperApps.neverAsk.saveToDisk","image/jpg, text/csv,text/xml,application/xml,application/vnd.ms-excel,application/x-excel,application/x-msexcel,application/excel,application/pdf,application/octet-stream");
			driver= new FirefoxDriver();////rasagna//////
		}else if(browserType.equals("chrome")){
			
			System.setProperty("webdriver.chrome.driver", Config.getValue("CHROME_DRIVER"));
			/*Map<String, Object> prefs = new Hashtable<String, Object>();
			prefs.put("download.prompt_for_download", "false");
			prefs.put("profile.default_content_settings.popups", 0);
			prefs.put("download.default_directory", Config.getValue("EXPORT_FILE_PATH"));
			//prefs.put("download.extensions_to_open", "image/jpg, text/csv,text/xml,application/xml,application/vnd.ms-excel,application/x-excel,application/x-msexcel,application/excel,application/pdf");
			prefs.put("download.extensions_to_open", "image/jpg, text/csv,text/xml,application/xml,application/vnd.ms-excel,application/x-excel,application/x-msexcel,application/excel,application/pdf,application/octet-stream");
			
			ChromeOptions options= new ChromeOptions();
			options.setExperimentalOption("prefs", prefs);
			driver= new ChromeDriver(options);*/
			String downloadFilepath = Config.getValue("EXPORT_FILE_PATH");
			File file = new File(downloadFilepath);
			HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
		    chromePrefs.put("download.default_directory", file.getAbsolutePath());
		    chromePrefs.put("download.prompt_for_download", false);
		    chromePrefs.put("profile.default_content_settings.popups", 0);
		    chromePrefs.put("credentials_enable_service", false);
		    chromePrefs.put("profile.password_manager_enabled", false);
		    ChromeOptions options = new ChromeOptions();
		    HashMap<String, Object> chromeOptionsMap = new HashMap<String, Object>();
		    options.setExperimentalOption("prefs", chromePrefs);
		    options.addArguments("disable-infobars");
		    options.addArguments("--test-type");
		  
		    DesiredCapabilities cap = DesiredCapabilities.chrome();
		    cap.setCapability(ChromeOptions.CAPABILITY, chromeOptionsMap);
		    cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		    cap.setCapability(ChromeOptions.CAPABILITY, options);
		    driver = new ChromeDriver(cap);  
		}
		else if(browserType.equals("ie")){
//			System.setProperty("webdriver.ie.driver", Config.getFilePath("", "IEDriverServer.exe"));
//			driver= new InternetExplorerDriver();
			
		}else if(browserType.equals("safari")){
			driver= new SafariDriver();
		} else if (browserType.equals("htmlUnit")) {
			driver = new HtmlUnitDriver();
		}
		
		return driver;
		
	}
}
