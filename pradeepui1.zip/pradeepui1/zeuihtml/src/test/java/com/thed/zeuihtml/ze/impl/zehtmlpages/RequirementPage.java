package com.thed.zeuihtml.ze.impl.zehtmlpages;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.DoubleClickAction;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.Constants;
import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;

public class RequirementPage {

	Logger logger;

	public RequirementPage() {
		logger = Logger.getLogger(this.getClass());
	}

	public static RequirementPage getInstance() {
		return PageFactory.initElements(Driver.driver, RequirementPage.class);
	}

	/******************************************************
	 * WEBELEMENTS
	 *****************************************************/

	@FindBy(xpath = "//*[@id='ze-main-app']//zee-test-requirements/test-requirements-component//div[@class='zui-tcr-folder-view']//span/i[contains(@class,'zui-search-icon')]")
	private WebElement searchView;

	@FindBy(xpath = "//*[@id='ze-main-app']//zee-test-requirements/test-requirements-component//*[@class='zui-tcr-folder-view']//span/i[contains(@class,'fa-folder-open')]")
	private WebElement folderView;

	@FindBy(xpath = "//button[@id='zui-modal-trigger-import-requirements']")
	private WebElement buttonImport;

	@FindBy(xpath = "//*[@id='ze-main-app']/zee-test-repository/test-repository-component//*[@class='left-navs']//h3")
	private WebElement testRepositoryPageHeader;

	@FindBy(xpath = "//*[@data-parenttype='release' and @data-name='Release 1.0']")
	private WebElement releasesInRequirement;

	@FindBy(xpath = "//*[@id='zephyr-tree-tcr']//li[@data-parenttype='release']/a")
	private WebElement releasesInTestRepository1;

	@FindBy(xpath = "//*[@id='zephyr-tree-requirement']//*[@data-parenttype='release']/div")
	private WebElement releaseOptionsBtn;

	@FindBy(xpath = "//ul[@class='vakata-context jstree-contextmenu jstree-default-contextmenu']")
	private WebElement nodeOptionsMenu;

	@FindBy(xpath = "//ul[@class='vakata-context jstree-contextmenu jstree-default-contextmenu']//a")
	private List<WebElement> releaseOptionsLink;

	@FindBy(id = "addNodeName")
	private WebElement createRequirementsPhaseDialogBox;

	@FindBy(xpath = "//*[@id='reqAddNodeModal']//*[@class='modal-title']")
	private WebElement createReqPhaseDialogBoxHeader;

	@FindBy(id = "addNodeName")
	private WebElement addNodeNameTextBox;

	@FindBy(id = "addNodeDescription")
	private WebElement addNodeDescriptionTextArea;

	@FindBy(id = "reqAddNodeModalSave")
	private WebElement reqAddNodeModalSaveBtn;

	@FindBy(xpath = "//a[@data-parenttype='release']/following-sibling::ul//a[@data-type='req']")
	private List<WebElement> listOfPhases;
	
	@FindBy(xpath = "//a[@data-parenttype='global']/following-sibling::ul//a[@data-type='req']")
	private List<WebElement> listOfPhasesinReqGlobal;
	
	@FindBy(xpath="//h4[text()='Duplicate Custom field value']")
	private WebElement popUpDuplicateValue;
	
	@FindBy(xpath="//*[@id='custom-field-error-modal']//button[text()='Ok']")
	private WebElement buttonOk;

	// Node details
	@FindBy(xpath = "//*[@id='zephyr-tree-tcr']//li[@data-parenttype='release']/a/div[contains(@class,'contextMenuIcon')]")
	private WebElement nodeOptionsBtn;

	@FindBy(id = "reqRenameNodeModal")
	private WebElement renameNodeDialogBox;

	@FindBy(id = "reqRenameNodeModalSave")
	private WebElement buttonRename;
	
	@FindBy(id = "renameNodeName")
	private WebElement renameNodeNameTextBox;

	@FindBy(id = "nodeDescription")
	private WebElement renameNodeDescriptionTextArea;

	@FindBy(id = "reqRenameNodeModalSave")
	private WebElement requirementRenameNodeModalSaveBtn;

	@FindBy(xpath = "//*[@id='reqRenameNodeModal']//*[@class='modal-title capitalize']")
	private WebElement renamePhaseDialogBoxHeader;
	
	@FindBy(xpath = "//*[@id='zephyr-tree-requirement']//ul//li//a[@data-parenttype='global']/div")
	private WebElement optionButtonGlobal;

	@FindBy(xpath =".//*[@id='zephyr-testcase-panel']/div/div[1]/div/div/zee-panel-content1/div/div/div[1]/div/zephyr-inline-edit/div/div/span[1]" )
	private WebElement TcName;
	
	
	// Delete Node details
	@FindBy(id = "tcrDeleteNodeModal")
	private WebElement deleteNodeDialogBox;

	@FindBy(id = "tcrDeleteNodeModalSave")
	private WebElement tcrDeleteNodeModalSaveBtn;

	@FindBy(xpath = "//*[@id='tcrDeleteNodeModal']//*[@class='modal-title']")
	private WebElement deleteNodeDialogBoxHeader;

	@FindBy(xpath = "//*[@id='toast-container']")
	private WebElement successContainer;

	@FindBy(xpath = "//*[@id='toast-container']//div[@class='toast-title']")
	private WebElement deleteSuccessToastTitle;

	@FindBy(xpath = "//*[@id='toast-container']//div[@class='toast-message']")
	private WebElement deleteSuccessToastMsg;
	
	@FindBy (xpath = "//*[@id='requirement-details']//div[@title='Back to list']/i")
	private WebElement backToReqList;
	
	@FindBy (xpath = "//*[@id='traceability-details']//div[@title='Back to list']/i")
	private WebElement backFromTraceability;

	// Filter elements
	@FindBy(id = "tree-view-filter-tcr")
	private WebElement tcrFilterSearchBox;

	@FindBy(xpath = "//a[contains(@class,'jstree-search')]")
	private List<WebElement> tcrSearchText;

	@FindBy(id = "zui-modal-trigger-requirement_1")
	private WebElement addRequirementBtn;

	@FindBy(xpath="//zee-test-requirements/test-requirements-component//b[text()='Requirements']")
	private WebElement headerRequirement;
	
	@FindBy(xpath="//head/title[contains(text(),'Requirements')]")
	private WebElement reqPageHeader;
	
	@FindBy(xpath="//input[@id='tree-view-filter-requirement']")
	private WebElement textboxFilter;

	@FindBy(xpath="//*[@id='zui-modal-trigger-requirement_2' and text()='Clone']")
	private WebElement reqCloneBtn;
	
	@FindBy(xpath="//*[@id='zui-modal-trigger-requirement_4' and text()='Delete']")
	private WebElement reqDeleteBtn;
	
	@FindBy(xpath=".//*[@id='zee-delete-modal-requirement_4']//button[text()='Delete']")
	private WebElement reqDeleteBtnPopup;
	
	@FindBy(xpath="//*[@id='zee-delete-modal-requirement_4']//button[text()='Deallocate']")
	private WebElement buttonDeallocate;

	@FindBy(xpath="//button[text()='Allocate']")
	private WebElement buttonAllocate;
	
	@FindBy(xpath="//*[@id='requirement-details']//a[text()='Mapped Testcases']")
	private WebElement headerMappedTestcasesModule;
	
	@FindBy(xpath="//button[@id='mapTest']")
	private WebElement buttonMapTestcase;
	
	@FindBy(xpath="//*[@id='zee-requirement-map-module']/div[2]/div/div/ul/li/div/a")
	private WebElement MapTc;
	
	@FindBy(xpath="//button//strong[text()='Back to requirements']")
	private WebElement BackToRequirement;
	
	@FindBy(xpath="//h4[text()='Map TestCases To Requirements']")
	private WebElement headerMapTestcasesToRequirements;
	
	@FindBy(xpath="//div[@id='zee-map-modal']//button[text()='Save']")
	private WebElement buttonSaveInMapWindow;
	
	@FindBy(xpath="(//*[@id='zee-map-modal-grid']//button[@class='close'])[1]")
	private WebElement buttonCloseMapWindow;
	
	@FindBy(xpath="//*[@id='requirement-details']//a[text()='Attachment']")
	private WebElement reqAttachmentTitle;
	
	@FindBy(xpath="//*[@id='requirement-details']//a[text()='Requirement Detail']")
	private WebElement buttonReqDetail;
	
	@FindBy(xpath="//input[@id='uploadFilerequirement']")
	private WebElement reqUploadLink;
	
	@FindBy(xpath="//i[contains(@class,'zui-search-icon')]/parent::span/parent::a")
	private WebElement buttonSearchView;
	
	@FindBy(xpath="//i[contains(@class,'fa-folder-open')]/parent::span/parent::a")
	private WebElement buttonFolderView;
	
	@FindBy(xpath="//h3[normalize-space(text())='Search']")
	private WebElement headerSearch;
	
	@FindBy(xpath="//span[text()='Quick']")
	private WebElement radioButtonQuick;
	
	@FindBy(xpath="//span[text()='Advanced']")
	private WebElement radioButtonAdvanced;
	
	@FindBy(xpath="//input[@id='zui-search-textarea']")
	private WebElement textAreaQuickSearch;
	
	@FindBy(xpath="//zui-zephyr-search//button[text()='Go']")
	private WebElement buttonGo;
	
	@FindBy(xpath="//div[@id='grid-table-req']")
	private WebElement reqGridTable;
	
	@FindBy(xpath="//div[@id='zephyr-tree-requirement']")
	private WebElement reqTreePannel;
	
	@FindBy(xpath="//a[@data-name='Project Requirements']")
	private WebElement globalNode;
	
	@FindBy(xpath="//input[@id='zql-search-input-req-search']")
	private WebElement inputZQLReqSearch;
	
	@FindBy(xpath="//h5[text()='Custom Fields']")
	private WebElement headerCustomFields;
	
	@FindBy(xpath="//*[@id='tcr-grid']//a[@class='inline-dialog-trigger']")
	private WebElement linkContextMenuToAddRequirementFieldsInGrid;
	
	@FindBy(id="zui-modal-trigger-traceability")
	private WebElement buttonTraceability;
	
	//Export
	
	@FindBy(xpath="//button[text()='Requirement Only']")
	private WebElement buttonRequiremnetOnly;
	
	@FindBy(xpath="//button[text()='Entire Traceability']")
	private WebElement buttonEntireTraceability;
	
	@FindBy(xpath="//span[text()='Data (Excel only)']")
	private WebElement radioButtonDataExcel;
	
	@FindBy(xpath="//span[text()='Detailed']")
	private WebElement radioButtonDetailed;
	
	@FindBy(xpath="//span[text()='HTML']")
	private WebElement radioButtonHtml;
	
	@FindBy(xpath="//span[text()='PDF']")
	private WebElement radioButtonPdf;
	
	@FindBy(xpath="//span[text()='Word']")
	private WebElement radioButtonWord;
	
	@FindBy(xpath="//span[text()='Summary']")
	private WebElement radioButtonSummary;
	
	@FindBy(xpath="//div[@id='zui-export-modal-requirement_3']//button[text()='Save']")
	private WebElement buttonSaveExport;
	
	@FindBy(xpath="//div[@id='zui-export-modal-requirement_3-download']//h4[text()='Download File']")
	private WebElement headerDownloadFileInPopup;
	
	@FindBy(xpath="//div[@id='zui-export-modal-requirement_3-download']//button[text()='Download']")
	private WebElement buttonDownload;
	
	@FindBy(xpath="//input[@id='req_select_all']")
	private WebElement checkboxSelectallRequirementFromGrid;
	
	@FindBy(xpath="//button[text()='Export']")
	private WebElement buttonExportInGrid;
	
	@FindBy(xpath="//div[@id='zui-import-modal-choice']//button[text()='JIRA']")
	private WebElement buttonJiraImport;
	
	@FindBy(xpath="//div[@id='reqSyncNodeModal']//div[@class='modal-footer']//button[text()='Sync']")
	private WebElement buttonSync;
	
	@FindBy(xpath="//input[@id='searchDefectsJQL']")
	private WebElement searchDefectJQL;
	
	@FindBy(xpath="//div[@id='rwalgn{']//button[text()='Search']")
	private WebElement buttonImportJQLSearch;
	
	@FindBy(xpath="//div[@id='zee-import-modal-requirement-jira']//button[text()='Import All']")
	private WebElement buttonImportAll;
	
	@FindBy(xpath="//div[@id='zephyr-tree-requirement']//ul//li[3]/i")
	private WebElement importedNodeArrow;
	
	@FindBy(xpath="//div[contains(@class,'contextMenuIcon')]")
	private WebElement importOptionMenu;
	
	@FindBy(xpath="//a[text()='Copy']")
	private WebElement copyFromOption;
	
	@FindBy(xpath="//a[text()='Move']")
	private WebElement moveFromOption;
	
	@FindBy(xpath="//a[text()='Rename']")
	private WebElement renameFromOption;
	
	@FindBy(xpath="//input[@id='req_select_all']")
	private WebElement checkboxSelectAllFromSearch;
	
	@FindBy(xpath="//button[text()='Export']")
	private WebElement buttonExportInSearch;

	@FindBy(xpath="//*[@id='button-Export']")
	private WebElement btnExportTraceability;

	@FindBy(xpath="//section[@id='content']//zephyr-inline-edit[@class='zephyr-testcase-name']//input")
	private WebElement textBoxRequirementName;
	
	@FindBy(xpath="//section[@id='content']//span[@placeholder='Enter name']")
	private WebElement editRequirementName;
	
	@FindBy(xpath="//section[@id='content']//span[@placeholder='Enter alt ID']")
	private WebElement editAltId;
	
	@FindBy(xpath="//section[@id='content']//zephyr-inline-edit//input")
	private WebElement textBoxReq;
	
	@FindBy(xpath="//section[@id='content']//button[@type='submit']")
	private WebElement buttonSubmit;
	
	//Pagination
	
	@FindBy(xpath="//select[@id='pagination-page-size-req']")
	private WebElement selectPaginationPageSize;
	
	@FindBy(xpath="//div[@id='tcr-grid']//span[text()='Next']/parent::a")
	private WebElement linkNextPage;
	
	@FindBy(xpath="//div[@id='tcr-grid']//span[text()='Prev']/parent::a")
	private WebElement linkPrevPage;
	
	
	//Import
	
		@FindBy(xpath="//button[text()='Excel']")
		private WebElement buttonExcel;
		
		@FindBy(xpath="//h4[text()='Import Requirements']")
		private WebElement headerImportRequirements;
		
		@FindBy(xpath="//div[@id='zee-import-modal-requirement']//button[text()='Next']")
		private WebElement buttonNext;
		
		@FindBy(xpath="//div[@id='zee-import-modal-requirement']//p[text()='Saved Maps']")
		private WebElement textSavedMaps;
		
		@FindBy(xpath="//div[@id='zee-import-modal-requirement']//button[text()='Add New Map']")
		private WebElement buttonAddMap;
		
		@FindBy(xpath="//input[@name='mapName']")
		private WebElement textboxMapName;
		
		@FindBy(xpath="//input[@name='rowNumber']")
		private WebElement textboxRowNumber;
		
		@FindBy(xpath="//select[@name='selectedMapDiscriminator']")
		private WebElement selectMapDiscriminator;
		
		@FindBy(xpath="//textarea[@name='mapDescription']")
		private WebElement textareaMapDescription;
		
		@FindBy(xpath="//input[@name='savedMaps.fields.101']")
		private WebElement textboxZephyrFieldName;
		
		@FindBy(xpath="//div[@id='update-savedMaps']//button[text()='Save']")
		private WebElement buttonSaveMap;
		
		@FindBy(xpath="//p[text()='Saved Maps']/parent::b/parent::div/following-sibling::div//button[@class='close']")
		private WebElement buttonCloseImportMapWindow;
		
		@FindBy(xpath="//div[@id='zee-import-modal-requirement']//p[text()='Import Jobs']")
		private WebElement textImportJobs;
		
		@FindBy(xpath="//p[text()='Import Jobs']/parent::b/parent::div/following-sibling::div//button[@class='close']")
		private WebElement buttonCloseImportJobWindow;
		
		@FindBy(xpath="//div[@id='zee-import-modal-requirement']//button[text()='Add New Job']")
		private WebElement buttonAddJob;
		
		@FindBy(xpath="//input[@id='job-name']")
		private WebElement textboxJobName;
		
		@FindBy(xpath="//span[@id='importJobs-fields']//span[@class='selection']")
		private WebElement selectMap;
		
		@FindBy(xpath="//input[@id='uploadFileimport']")
		private WebElement inputUploadFile;
		
		@FindBy(xpath="//div[@id='update-importJobs']//button[text()='Save']")
		private WebElement buttonSaveImportJob;
		
		@FindBy(xpath="//div[@id='job-status-modal-importJob']//h4[text()='Import Job Progress']")
		private WebElement headerImportJobProgress;
		
		@FindBy(xpath="//div[@id='job-status-modal-importJob']//span[normalize-space(text())='Status :']/following-sibling::span[text()='Success']")
		private WebElement textStatusSuccess;
		
		@FindBy(xpath="//div[@id='job-status-modal-importJob']//button[text()='Ok']")
		private WebElement buttonOkInImportJobProgress;
		
		@FindBy(xpath="//div[@id='tcr-grid']//span[@title='Reset to Default View']")
		private WebElement iconResetToDefault;
		
		@FindBy(xpath="//div[@id='reset-warning-popup-req']//button[text()='Yes']")
		private WebElement buttonYesInResetWarningPopup;
		
		@FindBy(xpath="//span[contains(text(),'Detail')]")
		private WebElement detail_Tab;
	
		
		
		
		@FindBy(xpath=".//*[@id='toast-container']//div[text()='Duplicated requirement tree name, please choose a different name']")
		private WebElement duplicateToasterMsgNode;
	/******************************************************
	 * Methods
	 * 
	 * @return
	 *****************************************************/

		public boolean expandImportedNode() {
			try {
				String expandStatus = CommonUtil.returnWebElement("//a[@data-name='Imported']/parent::li").getAttribute("aria-expanded");
				if(expandStatus!=null) {
					if(expandStatus.equals("false")) {
						CommonUtil.returnWebElement("//a[@data-name='Imported']/parent::li/i").click();
						HomePage.getInstance().waitForProgressBarToComplete();
						CommonUtil.normalWait(1000);
					}else {
						logger.info("Imported node is already expanded");
					}
				}
			}
			catch (Exception e) {
				logger.info("Failed to expand Imported Node");
				e.printStackTrace();
				return false;
			}
			return true;
		}
		
		public boolean navigateToRequirementNodeUnderImportedNode(String nodeNameContains) {
			try {
				
				String expandStatus = CommonUtil.returnWebElement("//a[@data-name='Imported']/parent::li").getAttribute("aria-expanded");
				if(expandStatus!=null) {
					if(expandStatus.equals("false")) {
						CommonUtil.returnWebElement("//a[@data-name='Imported']/parent::li/i")
						.click();
						HomePage.getInstance().waitForProgressBarToComplete();
						CommonUtil.normalWait(1000);
					}else {
						logger.info("Imported node is already expanded");
					}
				
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//a[@data-parenttype='import']/following-sibling::ul//a[contains(@data-name,'"+nodeNameContains+"')]")
							, "Node not found under imported node which contians text in name as: "+ nodeNameContains);
					CommonUtil.returnWebElement("//a[@data-parenttype='import']/following-sibling::ul//a[contains(@data-name,'"+nodeNameContains+"')]")
					.click();
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.normalWait(1000);
				}
				
				
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
			return true;
		}
		
		public boolean importRequirement(String jobName, String mapName, String importFileNameWithPath) {
			try {
				
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonImport)
						, "Import button not found in the Grid");
				buttonImport.click();
				CommonUtil.normalWait(1000);
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonExcel)
						, "Excel button not found in the Grid");
				buttonExcel.click();
				CommonUtil.normalWait(1000);
				
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerImportRequirements)
						, "Import window failed to launch");
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonNext)
						, "Button Next not found to navigate to map screen");
				CommonUtil.normalWait(1000);
				buttonNext.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textSavedMaps)
						, "Text 'Saved Maps' not found after clicking on Next button to navigate to Map Window");
				CommonUtil.normalWait(1000);
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonNext)
						, "Button Next not found to navigate to map screen");
				CommonUtil.normalWait(1000);
				buttonNext.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textImportJobs)
						, "Text 'Import Job' not found after clicking on Next button to navigate to Job Window");
				CommonUtil.normalWait(1000);
				buttonAddJob.click();
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textboxJobName)
						, "Textbox Job Name not found after clicking on Add Job button");	
				CommonUtil.normalWait(1000);
				textboxJobName.sendKeys(jobName);
				CommonUtil.normalWait(1000);
				//CommonUtil.selectListWithVisibleText(selectMap, mapName);
				selectMap.click();
				CommonUtil.normalWait(1000);
				CommonUtil.returnWebElement("//li[text()='"+mapName+"']").click();
				CommonUtil.normalWait(1000);
				inputUploadFile.sendKeys(importFileNameWithPath);
				CommonUtil.normalWait(1000);
				buttonSaveImportJob.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-import_jobs']//div[text()='"+jobName+"']"), "Job not found after saving in grid by name: "+ jobName);
				
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-import_jobs']//div[text()='"+jobName+"']/parent::div/parent::div/following-sibling::div//i[contains(@class,'runJobs')]"), "Run Job Icon not found for Job: " + jobName);
				
				CommonUtil.returnWebElement("//div[@id='grid-table-import_jobs']//div[text()='"+jobName+"']/parent::div/parent::div/following-sibling::div//i[contains(@class,'runJobs')]")
				.click();

				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerImportJobProgress), "Job Progress Popup not found after running the job");
				
				
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textStatusSuccess), "Status as success not found in import progress job popup");
				HomePage.getInstance().waitForProgressBarToComplete();
				
				
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}finally {
				
				if(CommonUtil.visibilityOfElementLocated(buttonOkInImportJobProgress)) {
					buttonOkInImportJobProgress.click();
					CommonUtil.normalWait(1000);
				}
				if(CommonUtil.visibilityOfElementLocated(buttonCloseImportJobWindow)) {
					buttonCloseImportJobWindow.click();
					CommonUtil.normalWait(1000);
				}else {
					if(CommonUtil.visibilityOfElementLocated(buttonCloseImportMapWindow)) {
						buttonCloseImportMapWindow.click();
						CommonUtil.normalWait(1000);
						HomePage.getInstance().waitForProgressBarToComplete();
					}
				}
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
				CommonUtil.browserRefresh();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(2000);
			}
			return true;
		}
		
		public boolean addRequirementMap(String mapName, String rowNumber, String selectDiscriminator
				, String mapDescription, String requirementNameColumn, List<String> otherFieldsMappingIfAny) {
			try {

				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonImport)
						, "Import button not found in the Grid");
				buttonImport.click();
				CommonUtil.normalWait(1000);
				
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonExcel)
						, "Excel button not found in the Grid");
				buttonExcel.click();
				CommonUtil.normalWait(1000);
				
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerImportRequirements)
						, "Import window failed to launch");
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonNext)
						, "Button Next not found to navigate to map screen");
				CommonUtil.normalWait(1000);
				buttonNext.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textSavedMaps)
						, "Text 'Saved Maps' not found after clicking on Next button to navigate to Map Window");
				CommonUtil.normalWait(1000);
				buttonAddMap.click();
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textboxMapName)
						, "Textbox Map Name not found after clicking on Add button");
				CommonUtil.normalWait(1000);
				textboxMapName.sendKeys(mapName);
				CommonUtil.normalWait(1000);
				textboxRowNumber.sendKeys(rowNumber);
				CommonUtil.normalWait(1000);
				CommonUtil.selectListWithVisibleText(selectMapDiscriminator, selectDiscriminator);
				CommonUtil.normalWait(1000);
				textareaMapDescription.sendKeys(mapDescription);
				CommonUtil.normalWait(1000);
				textboxZephyrFieldName.sendKeys(requirementNameColumn);
				CommonUtil.normalWait(1000);

				buttonSaveMap.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}finally {
				CommonUtil.normalWait(1000);
				buttonCloseImportMapWindow.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
			}
			return true;
		}
		
		
	public boolean createPhase(String releaseName, String phaseName, String phaseDescription) {
		try {
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(2000);
			//String xpathForRelease = "//li[@data-parenttype='release']/a[@data-name='"+releaseName+"']";
			String xpathForRelease = "//a[@data-parenttype='release'and @data-name='"+releaseName+"']";
			CommonUtil.returnWebElement(xpathForRelease).click();
			CommonUtil.normalWait(2000);
		    logger.info("Hovered on Release successfully.");

			releaseOptionsBtn.click();
			logger.info("Clicked on Node Options on the Release successfully.");
			CommonUtil.normalWait(2000);

			Assert.assertTrue(navigateToReleaseOptions("Add Folder"), "Not clicked on Add Button.");
			logger.info("Clicked on Add Btn to create Folder");

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(createRequirementsPhaseDialogBox),
					"Create phase Dialog box not visible.");
			logger.info("Create phase Dialog box visible to create phase.");

			Assert.assertTrue(createReqPhaseDialogBoxHeader.getText().trim().equals("Add Folder"),
					"Create  Folder dialog box header not validated.");
			logger.info("Create  Folder dialog box header validated successsfully.");

			addNodeNameTextBox.sendKeys(phaseName);
			logger.info("Phase name : " + phaseName + " given successfully to the text box successfully.");

			if (phaseDescription != null) {
				CommonUtil.normalWait(2000);
				addNodeDescriptionTextArea.sendKeys(phaseDescription);
				logger.info("Phase name : " + phaseDescription + " given successfully to the text area successfully.");
			}
			CommonUtil.normalWait(2000);
			reqAddNodeModalSaveBtn.click();
			logger.info("Clicked on the save button successfully.");
			CommonUtil.normalWait(5000);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return verifyPhase(releaseName, phaseName, phaseDescription);

	}

	public boolean navigateToNodes(List<String> nodeList) {
		boolean flag = false;
		try {
			CommonUtil.normalWait(5000);

			String topNode = nodeList.get(0);
			String x;
			for (int i = 0; i < nodeList.size(); i++) {
				if(i==0){
					x = CommonUtil.returnWebElement("//*[*[@data-name='"+nodeList.get(i)+"']]").getAttribute("aria-expanded");
				}else {
					x = CommonUtil.returnWebElement("//a[@data-name='"+topNode+"']/following-sibling::ul//*[*[@data-name='"+nodeList.get(i)+"']]").getAttribute("aria-expanded");
				}
				
				
				if(x!=null){
					if(x.equals("true")){
						logger.info("Node is already in Open state.");
						if(i==nodeList.size()-1){
							CommonUtil.normalWait(1000);
							if(i==0){
								WebElement we = CommonUtil.returnWebElement("//a[@data-name='"+topNode+"']");
								we.click();
							}else{
								WebElement we = CommonUtil.returnWebElement("//a[@data-name='"+topNode+"']/following-sibling::ul//*[@data-name='" + nodeList.get(i) + "']");
								we.click();
							}
						}
					}else{
						CommonUtil.normalWait(1000);
						if(i==0){
							
							WebElement we = CommonUtil.returnWebElement("//*[@data-name='" + nodeList.get(i) + "']");
							CommonUtil.doubleClick(we);
							
						}else{
							WebElement we = CommonUtil.returnWebElement("//a[@data-name='"+topNode+"']/following-sibling::ul//*[@data-name='" + nodeList.get(i) + "']");
							CommonUtil.doubleClick(we);
						}
						logger.info("Expanded the release successfully and Child nodes are visible now.");
						CommonUtil.normalWait(3000);
					}
				}else{
					CommonUtil.normalWait(1000);
					WebElement we = CommonUtil.returnWebElement("//a[@data-name='"+topNode+"']/following-sibling::ul//*[@data-name='" + nodeList.get(i) + "']");
					CommonUtil.doubleClick(we);
				}
				
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return flag;
		}
		return flag;
	}
	public boolean createNode(String parentNodeName, String nodeName, String nodeDescription) {
		try {
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(3000);
			String xpath = "//*[@data-name = '" + parentNodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			CommonUtil.normalWait(2000);
			CommonUtil.actionClass().moveToElement(we).build().perform();
			CommonUtil.normalWait(2000);
			logger.info("Hovered on Phase successfully.");

			releaseOptionsBtn.click();
			logger.info("Clicked on Node Options on the Phase successfully.");

			Assert.assertTrue(navigateToReleaseOptions("Add Folder"), "Not clicked on Add Button.");
			logger.info("Clicked on Add Btn to create Phase");

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(createRequirementsPhaseDialogBox),
					"Create Node Dialog box not visible.");
			logger.info("Create Node Dialog box visible to create phase.");

			Assert.assertTrue(createReqPhaseDialogBoxHeader.getText().trim().equals("Add Folder"),
					"Create  phase dialog box header not validated.");
			logger.info("Create  phase dialog box header validated successsfully.");
			CommonUtil.normalWait(2000);
			addNodeNameTextBox.sendKeys(nodeName);
			logger.info("Phase name : " + nodeName + " given successfully to the text box successfully.");

			if (nodeDescription != null) {
				CommonUtil.normalWait(2000);
				addNodeDescriptionTextArea.sendKeys(nodeDescription);
				logger.info("Node name : " + nodeDescription + " given successfully to the text area successfully.");
			}

			reqAddNodeModalSaveBtn.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(5000);
			logger.info("Clicked on the save button successfully.");

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return verifyNode(parentNodeName, nodeName, nodeDescription);
	}
	
	public boolean createNodeinReqGlobal(String parentNodeName, String nodeName, String nodeDescription) {
		try {
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(2000);
			String xpath = "//*[@data-name = '" + parentNodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			CommonUtil.normalWait(2000);
			CommonUtil.actionClass().moveToElement(we).build().perform();
			CommonUtil.normalWait(2000);
			logger.info("Hovered on Phase successfully.");

			optionButtonGlobal.click();
			logger.info("Clicked on Node Options on the Phase successfully.");

			Assert.assertTrue(navigateToReleaseOptions("Add Folder"), "Not clicked on Add Button.");
			logger.info("Clicked on Add Btn to create Phase");

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(createRequirementsPhaseDialogBox),
					"Create Node Dialog box not visible.");
			logger.info("Create Node Dialog box visible to create phase.");

			Assert.assertTrue(createReqPhaseDialogBoxHeader.getText().trim().equals("Add Folder"),
					"Create  phase dialog box header not validated.");
			logger.info("Create  phase dialog box header validated successsfully.");
			CommonUtil.normalWait(2000);
			addNodeNameTextBox.sendKeys(nodeName);
			logger.info("Phase name : " + nodeName + " given successfully to the text box successfully.");

			if (nodeDescription != null) {
				CommonUtil.normalWait(2000);
				addNodeDescriptionTextArea.sendKeys(nodeDescription);
				logger.info("Node name : " + nodeDescription + " given successfully to the text area successfully.");
			}

			reqAddNodeModalSaveBtn.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(5000);
			logger.info("Clicked on the save button successfully.");

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return verifyNodeinReqGlobal(parentNodeName, nodeName, nodeDescription);
	}

	

	public boolean filterNodes(String filterText) {
		boolean flag = false;
		int count = 0;
		try {

			CommonUtil.normalWait(1000);
			logger.info("Searching filter text.");
			tcrFilterSearchBox.clear();
			logger.info("Cleared the filter text box.");
			tcrFilterSearchBox.sendKeys(filterText);
			logger.info("Givin value to the filter text box.");
			tcrFilterSearchBox.sendKeys(Keys.RETURN);
			logger.info("Searching filter text.");
			CommonUtil.normalWait(1000);
			for (Iterator iterator = tcrSearchText.iterator(); iterator.hasNext();) {
				WebElement webElement = (WebElement) iterator.next();
				logger.info(webElement.getText());
				if (tcrSearchText.size() > 0) {
					logger.info(webElement.getText().trim() + ":" + filterText);
					Assert.assertTrue(webElement.getText().trim().contains(filterText)
							|| webElement.getText().trim().equals(filterText), "Not searched filtered text.");

					flag = true;
					count++;
				}
				// if(webElement.getText().trim().contains(filterText)){
				//
				// logger.info(filterText+" verified successfully.");
				// flag = true;
				// count ++;
				// }
			}

			logger.info("Searched Text found : " + count + " times .");
		} catch (Exception e) {
			e.printStackTrace();
			return flag;
		}
		return flag;

	}
	
	public boolean navigateBackToReqList() {
		try {
			logger.info("Going to click back button");
			backToReqList.click();
			CommonUtil.normalWait(2000);
		}
		catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}

	public String addDefaultRequirement(String nodeName) {
		String requirementId = null;
		try {
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + nodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			
			CommonUtil.normalWait(3000);
			logger.info("Node selected successfully.");

			int sizeOfRequirementBefore=0;
			WebElement we2;
			try {
				we2 = CommonUtil.returnWebElement("//*[@id='grid-table-req']/div[@class='grid-content']/div");
				if(we2!=null){
					if(we2.isDisplayed()) {
						sizeOfRequirementBefore = CommonUtil
								.returnSizeOfElements("//*[@id='grid-table-req']/div[@class='grid-content']/div");
						logger.info("Size of elements before : " + sizeOfRequirementBefore);
					}
				}
			} catch (Exception e) {
			}
			
			logger.info("Creating default Requirement.");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(addRequirementBtn), "Add Requirement button not visible");
			CommonUtil.moveToElement(addRequirementBtn);
			addRequirementBtn.click();
			CommonUtil.normalWait(5000);
			logger.info("Clicked on Add Requirement btn.");
			if (sizeOfRequirementBefore==0) {
				
				//navigateToNodes(nodeList)
					CommonUtil.normalWait(4000);
					String xpath1 = "//a[@data-parenttype='release'][@data-name = '" + nodeName + "']";
					WebElement we1 = CommonUtil.returnWebElement(xpath1);
					we1.click();
					CommonUtil.normalWait(5000);
					logger.info("Node selected successfully.");
			}
			
			
		//	Assert.assertTrue(verifySuccessPopup("add"), "Not verified success popup.");

			logger.info("Added default requirement successfully.");

//			Driver.driver.navigate().refresh();
			CommonUtil.normalWait(4000);
           int sizeOfRequirementAfter = CommonUtil
				.returnSizeOfElements("//*[@id='grid-table-req']/div[@class='grid-content']/div");
			logger.info("Size of elements after : " + sizeOfRequirementAfter);
			CommonUtil.normalWait(3000);
			Assert.assertTrue(sizeOfRequirementBefore + 1 == sizeOfRequirementAfter, "Requirement size not increased.");
			logger.info("Requirement size verified Successfully.");

			requirementId = verifyDefaultRequirement(sizeOfRequirementAfter);
			logger.info("Requirement Id : " + requirementId);
			Assert.assertTrue(requirementId != null, "Requirement not created.");
			logger.info("Requirement created and verified Successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			return requirementId;
		}
		return requirementId;

	}

	public boolean verifyPhase(String releaseName, String phaseName, String phaseDescription) {
		try {
			CommonUtil.normalWait(2000);
			String xpath = "//*[@data-name='"+releaseName+"']";
			//CommonUtil.doubleClick(CommonUtil.returnWebElement(xpath));
			// CommonUtil.actionClass().moveToElement(releasesInTestRepository).doubleClick().build().perform();
			logger.info("Waiting for the phasees.");
			CommonUtil.visibilityOfElementLocated("//*[@data-parenttype='release']/following-sibling::ul//a[@data-type='req']");
			logger.info("Expanded the release successfully and verifing the phases.");

			for (Iterator iterator = listOfPhases.iterator(); iterator.hasNext();) {
				WebElement webElement = (WebElement) iterator.next();
				// logger.info(webElement.getText());
				if (webElement.getText().trim().equals(phaseName)) {

					logger.info(phaseName + " verified successfully.");
					// webElement.click();
					if (phaseDescription != null) {
						String desc = webElement.getAttribute("data-desc");
						Assert.assertEquals(desc, phaseDescription, "Phase Description not verified.");
						logger.info("Phase description verified successfully.");
					}
					break;
				}
			}

//			CommonUtil.normalWait(1000);
//			CommonUtil.doubleClick(releasesInTestRepository);
			logger.info("Phase verified successfully.");

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;

	}

	public boolean verifyNode(String parentNodename, String nodeName, String nodeDescription) {
		try {
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + parentNodename + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);

			
			CommonUtil.normalWait(1000);
			// CommonUtil.actionClass().moveToElement(releasesInTestRepository).doubleClick().build().perform();
			logger.info("Waiting for the phasees.");
			boolean flag = CommonUtil.visibilityOfElementLocated("//a[@data-name='" + parentNodename + "']/following-sibling::ul/li", 5);
			if(flag){
				logger.info("Expanded the release successfully and verifing the nodes.");
			}else{
				CommonUtil.doubleClick(we);
				CommonUtil.normalWait(2000);
			}
			

			for (Iterator iterator = listOfPhases.iterator(); iterator.hasNext();) {
				WebElement webElement = (WebElement) iterator.next();
				// logger.info(webElement.getText());
				if (webElement.getText().trim().equals(nodeName)) {

					logger.info(nodeName + " verified successfully.");
					CommonUtil.normalWait(500);
					// webElement.click();
					if (nodeDescription != null) {
						String desc = webElement.getAttribute("data-desc");
						Assert.assertEquals(desc, nodeDescription, "Node Description not verified.");
						logger.info("Node description verified successfully.");
					}
					break;
				}
			}

//			CommonUtil.normalWait(1000);
//			CommonUtil.doubleClick(we);
			CommonUtil.normalWait(500);
			logger.info("Node verified successfully.");

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;

	}

	public boolean verifyNodeinReqGlobal(String parentNodename, String nodeName, String nodeDescription) {
		try {
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + parentNodename + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);

			
			CommonUtil.normalWait(1000);
			// CommonUtil.actionClass().moveToElement(releasesInTestRepository).doubleClick().build().perform();
			logger.info("Waiting for the phasees.");
			boolean flag = CommonUtil.visibilityOfElementLocated("//a[@data-name='" + parentNodename + "']/following-sibling::ul/li", 5);
			if(flag){
				logger.info("Expanded the release successfully and verifing the nodes.");
			}else{
				CommonUtil.doubleClick(we);
				CommonUtil.normalWait(2000);
			}
			

			for (Iterator iterator = listOfPhasesinReqGlobal.iterator(); iterator.hasNext();) {
				WebElement webElement = (WebElement) iterator.next();
				// logger.info(webElement.getText());
				if (webElement.getText().trim().equals(nodeName)) {

					logger.info(nodeName + " verified successfully.");
					CommonUtil.normalWait(500);
					// webElement.click();
					if (nodeDescription != null) {
						String desc = webElement.getAttribute("data-desc");
						Assert.assertEquals(desc, nodeDescription, "Node Description not verified.");
						logger.info("Node description verified successfully.");
					}
					break;
				}
			}

			CommonUtil.normalWait(500);
			logger.info("Node verified successfully.");

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;

	}
	
	private boolean navigateToReleaseOptions(String optionsName) {
		Assert.assertTrue(CommonUtil.visibilityOfElementLocated(nodeOptionsMenu),
				"Release node options menu's are not visible.");
		logger.info("Release node options menu's are visible.");

		for (Iterator iterator = releaseOptionsLink.iterator(); iterator.hasNext();) {
			WebElement webElement = (WebElement) iterator.next();
			logger.info(webElement.getText());
			if (webElement.getText().trim().equals(optionsName)) {
				webElement.click();
				CommonUtil.normalWait(2000);
				logger.info(optionsName + " selected successfully.");
				break;
			}
		}

		return true;
	}

	public boolean verifySuccessPopup(String type) {
		try {
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(successContainer));
			logger.info("Success Message verified Successfully.");

			Assert.assertTrue(deleteSuccessToastTitle.getText().equals("Success"), "Not found Success message");
			logger.info("Success message popup text not verified.");

			String successMessage = deleteSuccessToastMsg.getText();
			if (type.equals("delete")) {
				Assert.assertTrue(successMessage.contains("Deleted node with id(s)"), "Not found Success message");
			} else if (type.equals("add")) {
				Assert.assertTrue(successMessage.contains("Created requirement with id(s)"), "Not found Success message");
			} else if (type.equals("testcase_update")) {
				Assert.assertTrue(successMessage.contains("Requirement with id"), "Not found Success message");
				Assert.assertTrue(successMessage.contains("updated successfully"), "Not found Success message");
			}
			logger.info("Success message popup message verified, Message : " + successMessage);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public String verifyDefaultRequirement(int requirementNum) {
		String requirementId = null;
		try {
			String xpathForRequirementId = "//*[@id='grid-table-req']/div[@class='grid-content']/div[" + requirementNum
					+ "]/div[@data-col-index='2']";
			requirementId = CommonUtil.getText(xpathForRequirementId);

			Assert.assertNotNull(requirementId, "Requirement id is null.");
			logger.info("Requirement Id is : " + requirementId);

			String xpathForRequirementName = "//*[@id='grid-table-req']/div[@class='grid-content']/div[" + requirementNum
					+ "]/div[@data-col-index='3']";
			String requirementName = CommonUtil.getText(xpathForRequirementName);

			Assert.assertTrue(requirementName.equals("Untitled requirement"), "Requirement default name not verified.");
			logger.info("Requirement default name verified successfully, Name is : " + requirementNum);

			//String xpathForRequirementCoverageStatus = "//*[@id='grid-table-req']/div[@class='grid-content']/div[" + requirementNum + "]/div[@data-col-index='4']"	+ "]/div[@data-col-index='4']";
			//String coverageStatus = CommonUtil.getText(xpathForRequirementCoverageStatus);

			//Assert.assertTrue(coverageStatus.equals("Not covered"), "Requirement Covarage status not verified.");
			//logger.info("Requirement default coverage status verified successfully, Status is : " + coverageStatus);

//			String xpathForRequirementPriority = "//*[@id='grid-table-req']/div[@class='grid-content']/div["
//					+ requirementNum + "]/div[@data-col-index='5']";
//		String requirementPriority = CommonUtil.getText(xpathForRequirementPriority);
//
//			Assert.assertNull(xpathForRequirementPriority,
//					"Requirement Priority not verified.");
//		logger.info("Requirement Priority verified successfully, Priority : "
//					+ requirementPriority);

			
			logger.info("Requirement Default data verified successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			return requirementId;
			
		}
		return requirementId;
	}
	
	public boolean renameRequirementNode(String renameNodeName, String newNodeName, String newNodeDescription) {
		try {
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + renameNodeName + "']";
			System.out.println(xpath);
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			CommonUtil.normalWait(1000);
			CommonUtil.actionClass().moveToElement(we).build().perform();

			logger.info("Hovered on Node successfully.");

			releaseOptionsBtn.click();
			CommonUtil.normalWait(1000);
			logger.info("Clicked on Node Options on the Phase successfully.");

			Assert.assertTrue(navigateToReleaseOptions("Rename"), "Not clicked on Add Button.");
			logger.info("Clicked on Rename Btn to create Phase");

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(renameNodeDialogBox),
					"Rename Node Dialog box not visible.");
			logger.info("Rename Node Dialog box visible to rename phase.");

			Assert.assertTrue(renamePhaseDialogBoxHeader.getText().trim().equals("Rename Folder"),
					"Rename  phase dialog box header not validated.");
			logger.info("Rename  phase dialog box header validated successsfully.");

			renameNodeNameTextBox.clear();
			CommonUtil.normalWait(1000);
			renameNodeNameTextBox.sendKeys(newNodeName);
			renameNodeNameTextBox.clear();
			CommonUtil.normalWait(2000);
			System.out.println("Rename value in method: "+ newNodeName);
			renameNodeNameTextBox.sendKeys(newNodeName);
			logger.info("Phase name : " + newNodeName + " given successfully to the text box successfully.");

			if (newNodeDescription != null) {
				renameNodeDescriptionTextArea.clear();
				renameNodeDescriptionTextArea.sendKeys(newNodeDescription);
				logger.info("Node Description : " + newNodeDescription
						+ " given successfully to the text area successfully.");
			}

			requirementRenameNodeModalSaveBtn.click();
			logger.info("Clicked on the save button successfully.");
			CommonUtil.normalWait(5000);

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return verifyRenamedRequirementNode(renameNodeName, newNodeName, newNodeDescription);
		

	}
	public boolean verifyRenamedRequirementNode(String parentNodename, String nodeName, String nodeDescription) {
		boolean flag = false;
		try {
//			CommonUtil.normalWait(1000);
//			
//			String xpath = "//a[@data-name='" + parentNodename + "']/following-sibling::ul/li/a";
//			List<WebElement> listOfNodes = CommonUtil.returnWebElements(xpath);
//			for (Iterator iterator = listOfNodes.iterator(); iterator.hasNext();) {
//				WebElement webElement = (WebElement) iterator.next();
//				logger.info(webElement.getText());
//				if (webElement.getText().trim().equals(nodeName)) {
//
//					logger.info(nodeName + " verified successfully.");
//					// webElement.click();
//					if (nodeDescription != null) {
//						String desc = webElement.getAttribute("data-desc");
//						logger.info(desc);
//						Assert.assertEquals(desc, nodeDescription, "Phase Description not verified.");
//						logger.info("Phase description verified successfully.");
//					}
//					flag = true;
//					break;
//				}
//			}
//
//			logger.info("Phase verified successfully.");
			
			
			CommonUtil.normalWait(1000);
			parentNodename = nodeName;
			String xpath = "//a[@data-name='" + parentNodename + "']";
			List<WebElement> listOfNodes = CommonUtil.returnWebElements(xpath);
			for (Iterator iterator = listOfNodes.iterator(); iterator.hasNext();) 
			{
		 WebElement webElement = (WebElement) iterator.next();
		 logger.info(webElement.getText());
		 if (webElement.getText().trim().equals(nodeName)) 
		 {
			 logger.info(nodeName + " verified successfully.");
			 if (nodeDescription != null) {
				 String desc = webElement.getAttribute("data-desc");
				 logger.info(desc);
				 Assert.assertEquals(desc, nodeDescription, "Phase Description not verified.");
				 logger.info("Phase description verified successfully.");
			 }
			 flag = true;
			 break;
		 }
			}
	     logger.info("Phase verified successfully.");
	
         } catch (Exception e) {
			e.printStackTrace();
			return flag;
		  }
              return flag;

	}
	private Map<String, String> getRequirementsData(String requirementId){
		Map<String, String> data =  new HashMap<String, String>();
		String reqName = CommonUtil.getText("//*[@id='grid-table-req']/div[@class='grid-content']/div[@data-id='"+requirementId+"']/div[@data-col-index=2]");
		data.put("REQ_NAME", reqName);
		String reqCoverage = CommonUtil.getText("//*[@id='grid-table-req']/div[@class='grid-content']/div[@data-id='"+requirementId+"']/div[@data-col-index=4]");
		data.put("REQ_COVERAGE", reqCoverage);
		String reqPriority = CommonUtil.getText("//*[@id='grid-table-req']/div[@class='grid-content']/div[@data-id='"+requirementId+"']/div[@data-col-index=5]");
		if(reqPriority.length() != 0 || reqPriority != null ){
			data.put("REQ_PRIORITY", reqPriority);
		}
		return data;
	}
	public boolean cloneRequirement(String nodeName,String requirementId) {
		boolean cloneStatus = false;
		try {
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + nodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			logger.info("Node selected successfully.");

			int sizeOfRequirementsBefore = CommonUtil
					.returnSizeOfElements("//*[@id='grid-table-req']/div[@class='grid-content']/div");
			logger.info("Size of elements before : " + sizeOfRequirementsBefore);

			if(sizeOfRequirementsBefore>0){
				logger.info("Test case count::"+sizeOfRequirementsBefore);
				
				Map<String, String> beforeData = getRequirementsData(requirementId);
				String clonetestcaseString = "//*[@id='grid-table-req']/div[@class='grid-content']//div[@data-col-index='2']//div[@title='"+requirementId+"']/parent::div/parent::div/preceding-sibling::div//input[@name='req_select']";

				CommonUtil.normalWait(2000);
				WebElement web = CommonUtil.returnWebElement(clonetestcaseString);
				CommonUtil.moveToElement(web);
				web.click();
				logger.info("Selected the requirement successfully.");
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(2000);
				reqCloneBtn.click();
				logger.info("Clicked on Clone Btn successfully.");
				HomePage.getInstance().closeToastPopup();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(4000);
//				web.click();
//				HomePage.getInstance().waitForProgressBarToComplete();
//				CommonUtil.normalWait(1000);
//				int sizeOfRequirementsAfter = CommonUtil
//						.returnSizeOfElements("//*[@id='grid-table-tcr']/div[@class='grid-content']/div");
				String requirementsSizeAfter = CommonUtil.getText(".//*[@id='tcr-grid']//div[@class='pagination-details']//div[@class='page-track']/b[position() = (last())]");
				int sizeOfRequirementsAfter = Integer.parseInt(requirementsSizeAfter);
				logger.info("Size of Requirements after : " + sizeOfRequirementsAfter);

				Assert.assertTrue(sizeOfRequirementsBefore + 1 == sizeOfRequirementsAfter, "Testcase size not increased (clone).");
				logger.info("Requirements size verified Successfully (clone).");
				Map<String, String> afterData = getRequirementsData(requirementId);
				Assert.assertTrue(beforeData.equals(afterData), "Requirement not validated after cloning");
				logger.info("Requirement validated successfully after cloning.");
				cloneStatus = true;
				
			}else{
				logger.error("No Requirements found while cloning : Requirements count::"+sizeOfRequirementsBefore);
				cloneStatus = false;
			}
			logger.info("Clicked on the save button successfully.");

		} catch (Exception e) {
			e.printStackTrace();
			return cloneStatus;
		}
		return cloneStatus;
	}
	
	public boolean cloneRequirement(String reqName) {
		
		HomePage.getInstance().waitForProgressBarToComplete();
		Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-req']//div[text()='"+reqName+"']")
				, "Requirement not found by name: "+ reqName);
		CommonUtil.normalWait(1000);
		CommonUtil.returnWebElement("//div[@id='grid-table-req']//div[text()='"+reqName+"']/parent::div/parent::div/preceding-sibling::div//input[@type='checkbox']").click();
		CommonUtil.normalWait(1000);
		reqCloneBtn.click();
		CommonUtil.normalWait(5000);
		HomePage.getInstance().waitForProgressBarToComplete();
		
		return true;
	}
	public boolean deleteRequirement(String nodeName,String requirementId) {
		boolean cloneStatus = false;
		try {
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + nodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			logger.info("Node selected successfully.");

			int sizeOfRequirementsBefore = CommonUtil
					.returnSizeOfElements("//*[@id='grid-table-req']/div[@class='grid-content']/div");
			logger.info("Size of elements before : " + sizeOfRequirementsBefore);

			if(sizeOfRequirementsBefore>0){
				logger.info("Test case count::"+sizeOfRequirementsBefore);
				
				String clonetestcaseString = "//*[@id='grid-table-req']//div[@title='"+requirementId+"']/parent::div/parent::div/preceding-sibling::div//input[@name='req_select']";
				
				CommonUtil.normalWait(2000);
				WebElement web = CommonUtil.returnWebElement(clonetestcaseString);
				web.click();
				logger.info("Selected the requirement successfully.");
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(2000);
				reqDeleteBtn.click();
				logger.info("Clicked on Delete Btn successfully.");
				
				CommonUtil.visibilityOfElementLocated(reqDeleteBtnPopup);
				reqDeleteBtnPopup.click();
				logger.info("Clicked on Delete Confirmation popup.");
				//HomePage.getInstance().closeToastPopup();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(4000);
				logger.info("Requirement deleted successfully.");
				String requirementsSizeAfter = CommonUtil.getText(".//*[@id='tcr-grid']//div[@class='pagination-details']//div[@class='page-track']/b[position() = (last())]");
				int sizeOfRequirementsAfter = Integer.parseInt(requirementsSizeAfter);
				logger.info("Size of Requirements after : " + sizeOfRequirementsAfter);

				Assert.assertTrue(sizeOfRequirementsBefore - 1 == sizeOfRequirementsAfter, "Testcase size not decreased (delete).");
				logger.info("Requirements size verified Successfully (Delete).");
				cloneStatus = true;
				
			}else{
				logger.error("No Requirements found while deleting : Requirements count::"+sizeOfRequirementsBefore);
				cloneStatus = false;
			}

		} catch (Exception e) {
			e.printStackTrace();
			return cloneStatus;
		}
		return cloneStatus;
	}
	public boolean verifyRequirementApp(String releaseName){
		
		try{

			HomePage.getInstance().waitForProgressBarToComplete();

			Assert.assertEquals(CommonUtil.getTitle(), "Requirements - Zephyr Enterprise 6.2");

			//Assert.assertTrue(CommonUtil.visibilityOfElementLocated(globalNode),"Global node Requirement page not found");


			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(searchView), "Search View not found");

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(folderView), "Folder View not found");

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textboxFilter), "Filter textbox not found");

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='zephyr-tree-requirement']//a[@data-name='"+releaseName+"']")
					, "Release Name not found by name: " + releaseName);
			
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	
	public boolean deallocateRequirement(String reqName){
		
		try{
			HomePage.getInstance().waitForProgressBarToComplete();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-req']//div[text()='"+reqName+"']")
					, "Requirement not found by name: "+ reqName);
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement("//div[@id='grid-table-req']//div[text()='"+reqName+"']/parent::div/parent::div/preceding-sibling::div//input[@type='checkbox']").click();
			CommonUtil.normalWait(1000);
			reqDeleteBtn.click();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonDeallocate), "Deallocate button not found");
			buttonDeallocate.click();
			CommonUtil.normalWait(5000);
			HomePage.getInstance().waitForProgressBarToComplete();
			logger.info("verifying absence of deallocated requirement by name: "+ reqName);
			Assert.assertFalse(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-req']//div[text()='"+reqName+"']", 5)
					, "Requirement should not be there after deallocating: "+ reqName);
			logger.info("Absence of requirement verified successfully");
			
		}catch(Exception e){
			logger.info("failed to deallocate requirement");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean allocateRequirement(String reqName){
		
		try{
			HomePage.getInstance().waitForProgressBarToComplete();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-req']//div[text()='"+reqName+"']")
					, "Requirement not found by name: "+ reqName);
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement("//div[@id='grid-table-req']//div[text()='"+reqName+"']/parent::div/parent::div/preceding-sibling::div//input[@type='checkbox']").click();
			CommonUtil.normalWait(1000);
			buttonAllocate.click();
			CommonUtil.normalWait(2000);
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.browserRefresh();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			
		}catch(Exception e){
			logger.info("Failed to allocate Requirement");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean verifyRequirement(String reqName, Map<String, String> reqFieldsValues){
		
		try{
			HomePage.getInstance().waitForProgressBarToComplete();
			logger.info("Going to verify requirement in grid");
			String xpathReqName = "//div[@id='grid-table-req']//div[text()='"+reqName+"']";
			WebElement wbReqName = CommonUtil.returnWebElement(xpathReqName);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(wbReqName), "Requirement not found by name: "+ reqName);
			logger.info("Verified requirement in grid");
			CommonUtil.normalWait(1000);
			CommonUtil.moveToElement(wbReqName);
			wbReqName.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			
			if (reqFieldsValues!=null) {
				if(reqFieldsValues.containsKey("CUSTOMFIELDS")){
					String customFieldDetails = reqFieldsValues.get("CUSTOMFIELDS");
					String customFieldNameAndValue[] = customFieldDetails.split(Constants.CHAR_TO_SPLIT_STRING);
						
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[text()='"+customFieldNameAndValue[0]+"']/parent::div/parent::div")
							, "Requirement Feild not found in header grid so value can not be verified, Add Feild in grid");
					
					String columnIdex = CommonUtil.returnWebElement("//div[text()='"+customFieldNameAndValue[0]+"']/parent::div/parent::div").getAttribute("tabindex");
					System.out.println("Column Index: " + columnIdex);
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[text()='"+reqName+"']/parent::div/parent::div/following-sibling::div[@data-col-index='"+columnIdex+"']//div[text()='"+customFieldNameAndValue[1]+"']")
							, "Requirement Custom Field value not matching for custom field name: "+ customFieldNameAndValue[0] + " Expected value: "+ customFieldNameAndValue[1]);
					
				}
				
				if(reqFieldsValues.containsKey("Priority")){
					String priorityValue = reqFieldsValues.get("Priority");
					Assert.assertTrue(CommonUtil.returnWebElement("//*[@id='zee-requirement-details-module']//strong[text()='Priority']/parent::span/following-sibling::span/span").getText().equals(priorityValue), "Priority not changed");
				}
				
				//Inprogress for other fields
			}
			
		}catch(Exception e){
			logger.info("Failed to verify Requirement");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean modifyRequirement(String reqName, Map<String, String> values, String nodeName){
		try{
			
			if (nodeName!=null)
			{
				CommonUtil.normalWait(1000);
				String xpath = "//*[@data-name = '" + nodeName + "']";
				WebElement we = CommonUtil.returnWebElement(xpath);
				we.click();
				CommonUtil.normalWait(1000);
				logger.info("Node selected successfully.");

				int sizeOfRequirementBefore=0;
				
				WebElement we2;
				try {
					we2 = CommonUtil.returnWebElement("//*[@id='grid-table-req']/div[@class='grid-content']/div");
					if(we2!=null){
						if(we2.isDisplayed()) {
							sizeOfRequirementBefore = CommonUtil
									.returnSizeOfElements("//*[@id='grid-table-req']/div[@class='grid-content']/div");
							logger.info("Size of elements before : " + sizeOfRequirementBefore);
						}
					}
					
				}catch(Exception e){
					e.printStackTrace();
					return false;
				}
			}
				
			HomePage.getInstance().waitForProgressBarToComplete();
			logger.info("Going to verify requirement in grid");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-req']//div[text()='"+reqName+"']")
					, "Requirement not found by name: "+ reqName);
			logger.info("Verified requirement in grid");
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement("//div[@id='grid-table-req']//div[text()='"+reqName+"']").click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(2000);
			
			if (values!=null) {
				if(values.containsKey("NAME")) {
					logger.info("Editing Requiremnt Name");
					editRequirementName.click();
					CommonUtil.normalWait(2000);
					textBoxRequirementName.clear();
					CommonUtil.normalWait(1000);
					textBoxRequirementName.sendKeys(values.get("NAME"));
					CommonUtil.normalWait(1000);
					buttonSubmit.click();
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.normalWait(3000);
				}
				if (values.containsKey("ATTACHMENT")) {
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.scrollToWebElement(reqAttachmentTitle);
					CommonUtil.normalWait(1000);
					CommonUtil.moveToElement(reqAttachmentTitle);
					reqAttachmentTitle.click();
					logger.info("Uploading Attachment To Requirement, Attachment : "+values.get("ATTACHMENT"));
					CommonUtil.normalWait(1000);
					File file = new File(values.get("ATTACHMENT"));
					System.out.println(file.getAbsolutePath());
					reqUploadLink.sendKeys(file.getAbsolutePath());
					logger.info("Attachment Uploaded successfully, Attachment is : "
							+ values.get("TESTCASE_ATTACHMENT"));
					reqAttachmentTitle.click();
//					Assert.assertTrue(verifyAttachments(values.get("TESTCASE_ATTACHMENT")), "Testcase Attachment not verified.");
//					logger.info("Attachments verified successfully.");
				}
				if (values.containsKey("ALTID")) {
					HomePage.getInstance().waitForProgressBarToComplete();
					logger.info("Going to edit Requiremnt altId");
					buttonReqDetail.click();
					CommonUtil.normalWait(1000);
					editAltId.click();
					CommonUtil.normalWait(1000);
					textBoxReq.click();
					textBoxReq.clear();
					textBoxReq.sendKeys(values.get("ALTID"));
					CommonUtil.normalWait(1000);
					buttonSubmit.click();
					HomePage.getInstance().waitForProgressBarToComplete();
					logger.info("Edited Requiremnt altId");
				}
			}
			
		}catch(Exception e){
			logger.info("Failed to modify Requirement");
			e.printStackTrace();
			return false;
		}
		finally {
			backToReqList.click();
			CommonUtil.normalWait(1000);
		}
		
		return true;
	
	}
	
	public boolean updateRequirementCustomFieldValue(String reqName, Map<String, String> typeNameAndValue){
		try{
			HomePage.getInstance().waitForProgressBarToComplete();
			logger.info("Going to verify requirement in grid");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-req']/div[2]//div[text()='"+reqName+"']")
				, "Requirement not found by name: "+ reqName);
			
			
					logger.info("Verified requirement in grid");
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement("//div[@id='grid-table-req']/div[2]//div[text()='"+reqName+"']").click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			
			if(typeNameAndValue.containsKey("Text")){
				String value = typeNameAndValue.get("Text");
				String nameAndValue[] = value.split(Constants.CHAR_TO_SPLIT_STRING);
				String customFieldName = nameAndValue[0];
				String customFieldValue = nameAndValue[1];
	
				logger.info("Going to verify custom field name is available or not");
				//Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//span[contains(@class,'custom-field-name')]/span[text()='"+customFieldName+"']")
					//	, "Custom field not found by name: "+ customFieldName);
				
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']")
					, "Custom field not found by name: "+ customFieldName);	
				
				
				logger.info("Going to click on textbox and type values");
				
				WebElement textbox = CommonUtil.returnWebElement("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']//parent::strong//parent::span//following-sibling::span//span[@class='zephyr-inline-field-name fourth']");
				System.out.println("Text custom field value :" + textbox.getText());
				textbox.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.returnWebElement("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']//parent::strong//parent::span//following-sibling::span//input")
				.sendKeys(customFieldValue);
				logger.info("Going to save typed value");
				CommonUtil.returnWebElement("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']//parent::strong//parent::span//following-sibling::span//button[@type='submit']")
				.click();
				logger.info("Clicked submit button");
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(3000);
				//Assert.assertTrue(textbox.getText().equals(customFieldValue), "Saved custom field value not matching, Expected: "+customFieldValue+", Actual: "+textbox.getText());
				
			}
				
			if(typeNameAndValue.containsKey("LongText")){
				String value = typeNameAndValue.get("LongText");
				String nameAndValue[] = value.split(Constants.CHAR_TO_SPLIT_STRING);
				String customFieldName = nameAndValue[0];
				String customFieldValue = nameAndValue[1];
				logger.info("Going to verify custom field name is available or not");
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']")
						, "Custom field not found by name: "+ customFieldName);
				logger.info("Going to click on textarea and type values");
				WebElement textbox = CommonUtil.returnWebElement("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']//parent::strong//parent::span//following-sibling::span//field-textarea");
				textbox.click();
				HomePage.getInstance().waitForProgressBarToComplete();
						
				CommonUtil.returnWebElement("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']//parent::strong//parent::span//following-sibling::span//textarea")
				.sendKeys(customFieldValue);
				logger.info("Going to save typed value");
				CommonUtil.returnWebElement("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']//parent::strong//parent::span//following-sibling::span//button[@type='submit']")
				.click();
				logger.info("Clicked submit button");
				CommonUtil.normalWait(1000);
				
			//	Assert.assertTrue(textbox.getText().equals(customFieldValue), "Saved custom field value not matching, Expected: "+customFieldValue+", Actual: "+textbox.getText());
				
			}
				
			if(typeNameAndValue.containsKey("Checkbox")){
				String value = typeNameAndValue.get("Checkbox");
				
				logger.info("Going to verify custom field name is available or not");
				//Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//span[contains(@class,'custom-field-name')]/span[text()='"+value+"']")
					//	, "Custom field not found by name: "+ value);
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//strong[@class='custom-field-name']/span[text()='"+value+"']")
						, "Custom field not found by name: "+ value);
				
				logger.info("Going to click on checkbox");
				CommonUtil.returnWebElement("//strong[@class='custom-field-name']/span[text()='"+value+"']//parent::strong//parent::span//following-sibling::span//input")
				.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
			}
				
				
			if(typeNameAndValue.containsKey("Date")){
				String value = typeNameAndValue.get("Date");
				String nameAndValue[] = value.split(Constants.CHAR_TO_SPLIT_STRING);
				String customFieldName = nameAndValue[0];
				String customFieldValue = nameAndValue[1];
				
				logger.info("Going to verify custom field name is available or not");
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']")
						, "Custom field not found by name: "+ customFieldName);
				logger.info("Going to click and select date");
				WebElement editIcon = CommonUtil.returnWebElement("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']//parent::strong//parent::span//following-sibling::span//span[contains(@class,'zui-fa-pencil')]");
				CommonUtil.moveToElement(editIcon);
				CommonUtil.returnWebElement("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']//parent::strong//parent::span//following-sibling::span//span[contains(@class,'zui-fa-pencil')]")
				.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.returnWebElement("//button[contains(@class,'active btn-default')]")
				.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
			}
			
			
			if(typeNameAndValue.containsKey("Number")){
				String value = typeNameAndValue.get("Number");
				String nameAndValue[] = value.split(Constants.CHAR_TO_SPLIT_STRING);
				String customFieldName = nameAndValue[0];
				String customFieldValue = nameAndValue[1];
	
				logger.info("Going to verify custom field name is available or not");
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']")
						, "Custom field not found by name: "+ customFieldName);
				logger.info("Going to click on textbox and type values");
				
				WebElement textbox = CommonUtil.returnWebElement("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']//parent::strong//parent::span//following-sibling::span//field-input");
				textbox.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.returnWebElement("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']//parent::strong//parent::span//following-sibling::span//input")
				.sendKeys(customFieldValue);
				logger.info("Going to save typed value");
				CommonUtil.returnWebElement("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']//parent::strong//parent::span//following-sibling::span//button[@type='submit']")
				.click();
				logger.info("Clicked submit button");
				CommonUtil.normalWait(1000);
				
				//Assert.assertTrue(textbox.getText().equals(customFieldValue), "Saved custom field value not matching, Expected: "+customFieldValue+", Actual: "+textbox.getText());
			}
			
			if(typeNameAndValue.containsKey("Picklist")){
				String value = typeNameAndValue.get("Picklist");
				String nameAndValue[] = value.split(Constants.CHAR_TO_SPLIT_STRING);
				String customFieldName = nameAndValue[0];
				String customFieldValue = nameAndValue[1];
	
				logger.info("Going to verify custom field name is available or not");
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']")
						, "Custom field not found by name: "+ customFieldName);
				logger.info("Going to click on textbox and and select picklist value");
				WebElement textbox = CommonUtil.returnWebElement("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']//parent::strong//parent::span//following-sibling::span//span");
				textbox.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
				System.out.println("picklist value: "+ customFieldValue);
				CommonUtil.returnWebElement("//li[text()='"+customFieldValue+"']").click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
				
				//Assert.assertTrue(textbox.getText().equals(customFieldValue), "Saved custom field value not matching, Expected: "+customFieldValue+", Actual: "+textbox.getText());
			}

		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		finally {
			backToReqList.click();
			CommonUtil.normalWait(1000);
		}
		return true;
	}
	
	public boolean updateRequirementUniqueCustomFieldWithDuplicateValue(String reqName, Map<String, String> typeNameAndValue){
		try{
			HomePage.getInstance().waitForProgressBarToComplete();
			logger.info("Going to verify requirement in grid");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-req']//div[text()='"+reqName+"']")
					, "Requirement not found by name: "+ reqName);
			logger.info("Verified requirement in grid");
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement("//div[@id='grid-table-req']//div[text()='"+reqName+"']").click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			
			if(typeNameAndValue.containsKey("Text")){
				String value = typeNameAndValue.get("Text");
				String nameAndValue[] = value.split(Constants.CHAR_TO_SPLIT_STRING);
				String customFieldName = nameAndValue[0];
				String customFieldValue = nameAndValue[1];
	
				logger.info("Going to verify custom field name is available or not");
				//Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//span[contains(@class,'custom-field-name')]/span[text()='"+customFieldName+"']")
					//	, "Custom field not found by name: "+ customFieldName);
				
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']")
					, "Custom field not found by name: "+ customFieldName);	
				
				
				logger.info("Going to click on textbox and type values");
				
				WebElement textbox = CommonUtil.returnWebElement("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']//parent::strong//parent::span//following-sibling::span//span[@class='zephyr-inline-field-name fourth']");
				System.out.println("Text custom field value :" + textbox.getText());
				textbox.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.returnWebElement("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']//parent::strong//parent::span//following-sibling::span//input")
				.sendKeys(customFieldValue);
				logger.info("Going to save typed value");
				CommonUtil.returnWebElement("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']//parent::strong//parent::span//following-sibling::span//button[@type='submit']")
				.click();
				logger.info("Clicked submit button");
				CommonUtil.normalWait(3000);
				
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(popUpDuplicateValue), "Error message for duplicate value is not shown");
				buttonOk.click();
				CommonUtil.normalWait(2000);
				
			}
				
			if(typeNameAndValue.containsKey("Number")){
				String value = typeNameAndValue.get("Number");
				String nameAndValue[] = value.split(Constants.CHAR_TO_SPLIT_STRING);
				String customFieldName = nameAndValue[0];
				String customFieldValue = nameAndValue[1];
	
				logger.info("Going to verify custom field name is available or not");
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']")
						, "Custom field not found by name: "+ customFieldName);
				logger.info("Going to click on textbox and type values");
				
				WebElement textbox = CommonUtil.returnWebElement("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']//parent::strong//parent::span//following-sibling::span//field-input");
				textbox.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.returnWebElement("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']//parent::strong//parent::span//following-sibling::span//input")
				.sendKeys(customFieldValue);
				logger.info("Going to save typed value");
				CommonUtil.returnWebElement("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']//parent::strong//parent::span//following-sibling::span//button[@type='submit']")
				.click();
				logger.info("Clicked submit button");
				CommonUtil.normalWait(3000);
				
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(popUpDuplicateValue), "Error message for duplicate value is not shown");
				buttonOk.click();
				CommonUtil.normalWait(2000);
			}
			
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		finally {
			CommonUtil.normalWait(1000);
			backToReqList.click();
			CommonUtil.normalWait(1000);
		}
		return true;
	}
	
	public String getRequirementCustomFieldValue(String ReqId, Map<String, String> typeNameAndValue){
		String fieldValue = null;
		try{
			HomePage.getInstance().waitForProgressBarToComplete();
			logger.info("Going to verify requirement in grid");
			String  reqXpath= "//*[@id='grid-table-req']/div[@class='grid-content']//div[@title='"+ReqId+"']/parent::div/parent::div/following-sibling::div[1]/div/div";
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(reqXpath), "Requirement not found : "+ reqXpath);
			logger.info("Verified requirement in grid");
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement(reqXpath).click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			
			if(typeNameAndValue.containsKey("Text")){
				String value = typeNameAndValue.get("Text");
				String nameAndValue[] = value.split(Constants.CHAR_TO_SPLIT_STRING);
				String customFieldName = nameAndValue[0];
				String customFieldValue = nameAndValue[1];
	
				logger.info("Going to verify custom field name is available or not");
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']"), "Custom field not found by name: "+ customFieldName);	
				logger.info("Going to click on textbox and type values");
				WebElement textbox = CommonUtil.returnWebElement("//strong[@class='custom-field-name']/span[text()='"+customFieldName+"']//parent::strong//parent::span//following-sibling::span//span[@class='zephyr-inline-field-name fourth']");
				System.out.println("Text custom field value :" + textbox.getText());
				fieldValue = textbox.getText();
				
			}
				
			if(typeNameAndValue.containsKey("LongText")){
				String value = typeNameAndValue.get("LongText");
				String nameAndValue[] = value.split(Constants.CHAR_TO_SPLIT_STRING);
				String customFieldName = nameAndValue[0];
				String customFieldValue = nameAndValue[1];
				
				logger.info("Going to verify custom field name is available or not");
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//strong[contains(@class,'custom-field-name']/span[text()='"+customFieldName+"']")
						, "Custom field not found by name: "+ customFieldName);
				WebElement textbox = CommonUtil.returnWebElement("//strong[@class,'custom-field-name']/span[text()='"+customFieldName+"']/parent::span/parent::strong/following-sibling::span");
				System.out.println("Long Text custom field value :" + textbox.getText());
				fieldValue = textbox.getText();
			}
				
			
			if(typeNameAndValue.containsKey("Number")){
				String value = typeNameAndValue.get("Number");
				String nameAndValue[] = value.split(Constants.CHAR_TO_SPLIT_STRING);
				String customFieldName = nameAndValue[0];
				String customFieldValue = nameAndValue[1];
	
				logger.info("Going to verify custom field name is available or not");
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//strong[@class,'custom-field-name']/span[text()='"+customFieldName+"']")
						, "Custom field not found by name: "+ customFieldName);
				
				WebElement textbox = CommonUtil.returnWebElement("//strong[@class,'custom-field-name']/span[text()='"+customFieldName+"']/parent::span/parent::strong/following-sibling::span");
				System.out.println("Number custom field value :" + textbox.getText());
				fieldValue = textbox.getText();
			}
			
			if(typeNameAndValue.containsKey("Picklist")){
				String value = typeNameAndValue.get("Picklist");
				String nameAndValue[] = value.split(Constants.CHAR_TO_SPLIT_STRING);
				String customFieldName = nameAndValue[0];
				String customFieldValue = nameAndValue[1];
	
				logger.info("Going to verify custom field name is available or not");
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//strong[@class,'custom-field-name']/span[text()='"+customFieldName+"']")
						, "Custom field not found by name: "+ customFieldName);
				WebElement textbox = CommonUtil.returnWebElement("//strong[@class,'custom-field-name']/span[text()='"+customFieldName+"']/parent::span/parent::strong/following-sibling::span");
				System.out.println("Picklist custom field value :" + textbox.getText());
				fieldValue = textbox.getText();
			}

		}catch(Exception e){
			e.printStackTrace();
		}
		finally {
			CommonUtil.normalWait(2000);
			backToReqList.click();
			CommonUtil.normalWait(1000);
		}
		return fieldValue;
	}
	
	public boolean mapTestcaseToRequirement(String reqName, List<String> navigateToTCCTreeNodes, String testcaseName){
		
		try{
			HomePage.getInstance().waitForProgressBarToComplete();
			logger.info("Going to verify requirement in grid");
			CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-req']//div[text()='"+reqName+"']");
			logger.info("Verified requirement in grid");
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement("//div[@id='grid-table-req']//div[text()='"+reqName+"']").click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			//headerMappedTestcasesModule.click();
			CommonUtil.normalWait(1000);
			buttonMapTestcase.click();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerMapTestcasesToRequirements)
					, "Header Map testcases To Requirements not found");
			CommonUtil.normalWait(1000);
			
			expandTreeNodeInMapWindow(navigateToTCCTreeNodes);
	
			CommonUtil.visibilityOfElementLocated("//div[@id='map-grid']//div[text()='"+testcaseName+"']");
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement("//div[@id='map-grid']//div[text()='"+testcaseName+"']/parent::div/parent::div/preceding-sibling::div//input").click();
			CommonUtil.normalWait(1000);
			buttonSaveInMapWindow.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//a[text()='Maps to 1 testcase']"));
		}catch(Exception e){
			logger.info("Failed to map testcase to requirement");
			e.printStackTrace();
			CommonUtil.browserRefresh();
			HomePage.getInstance().waitForProgressBarToComplete();
			return false;
		}
		return true;
	}
	
	public boolean verifyMapTestcaseToRequirement(String reqName, String mapCount) {
		
		try{
			CommonUtil.normalWait(1000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[text()='"+reqName+"']"), "Requirement not found");
			CommonUtil.returnWebElement("//div[text()='"+reqName+"']").click();
			CommonUtil.normalWait(1000);
			headerMappedTestcasesModule.click();
			CommonUtil.normalWait(1000);
			logger.info("Checking for Map Count...");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//a[text()='Maps to "+mapCount+" testcase']"), "Map Count not found as 1 after mapping");
		}catch(Exception e){
			logger.info("Failed to map testcase to requirement");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	private boolean expandTreeNodeInMapWindow(List<String> treeNodes){
		
		try{
			
			for(int nodeLevel=0; nodeLevel<treeNodes.size();nodeLevel++){
				if(nodeLevel==treeNodes.size()-1){
					CommonUtil.returnWebElement("//div[@id='zee-map-modal']//a[@data-name='"+treeNodes.get(nodeLevel)+"']").click();
					CommonUtil.normalWait(1000);
					HomePage.getInstance().waitForProgressBarToComplete();
				}else{
					CommonUtil.returnWebElement("//div[@id='zee-map-modal']//a[@data-name='"+treeNodes.get(nodeLevel)+"']/preceding-sibling::i").click();
					CommonUtil.normalWait(1000);
				}
			}
			
		}catch(Exception e){
			logger.info("Failed to expand tree node in map window");
			e.printStackTrace();
			return false;
		}
		return true;
		
	}
	
	public boolean switchRequirementSearchFolderView(String view){
		try{
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			if(view.equalsIgnoreCase("Search")){
				
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonSearchView), "Button Search View not found");
				buttonSearchView.click();
				CommonUtil.normalWait(1000);
				HomePage.getInstance().waitForProgressBarToComplete();
				
				logger.info("Going to verify Search Requirement Page");
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonQuick), "Radio button Quick Search not found");
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonAdvanced), "Radio button Advance Search not found");
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textAreaQuickSearch), "Text Box Quick Search not found");
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonGo), "Button Go not found");
			}else{
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonFolderView), "Button Folder View not found");
				buttonFolderView.click();
				CommonUtil.normalWait(1000);
				HomePage.getInstance().waitForProgressBarToComplete();
				
				logger.info("Going to verify Folder Requirement Page");
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(reqTreePannel), "Requirement Tree Pannel not found");
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(globalNode), "Global node not found");
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(addRequirementBtn), "Add button not found");
			}
		}catch(Exception e){
			logger.info("Failed to switch between views");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean searchRequirements(String type, String query, List<String> reqNames){
		try{
			if(type.equalsIgnoreCase("Quick")){
				radioButtonQuick.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
				textAreaQuickSearch.sendKeys(query);
				
			}else{
				radioButtonAdvanced.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
				inputZQLReqSearch.sendKeys(query);
				
			}
			
			buttonGo.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			
			if(reqNames!=null) {
				for(String reqName : reqNames){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[text()='"+reqName+"']")
							, "Requirement not found after search by name: " + reqName);
					CommonUtil.returnWebElement("//div[text()='Untitled requirement']").click();
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.normalWait(2000);
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//span[text()='"+reqName+"']")
							, "Requirement name not found in details in search view after selecting requirement in search grid");
					navigateBackToReqList();
				}
			}
			
		}catch(Exception e){
			logger.info("Failed to search requirements");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean resetRequirementGridToDefaultAndVerifyAbsenceOfCustomizedFields(List<String> fieldNamesNotToBePresent) {
		try {
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			
			iconResetToDefault.click();
			CommonUtil.normalWait(1000);
			
			CommonUtil.visibilityOfElementLocated(buttonYesInResetWarningPopup);
			buttonYesInResetWarningPopup.click();
			
			for(String fieldName : fieldNamesNotToBePresent) {	
				Assert.assertFalse(CommonUtil.visibilityOfElementLocated("//div[@class='grid-header']//div[text()='"+fieldName+"']",5)
						, "field name still visible in grid header after reset by Name: " + fieldName);
			}
			
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean checkOrUncheckRequirementFieldsInGrid(List<String> fieldNames, boolean check){
		try{
			HomePage.getInstance().waitForProgressBarToComplete();
			linkContextMenuToAddRequirementFieldsInGrid.click();
			CommonUtil.normalWait(1000);
			
			for(String fielName : fieldNames) {
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//label[text()='"+fielName+"']")
						, "Custom Field not found in context menu to add by name: " +fielName);
				CommonUtil.returnWebElement("//label[text()='"+fielName+"']").click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
			}
			
			CommonUtil.returnWebElement("//div[@class='inline-dialog-body top-right-arrow']").click();
			
			if(check) {
				for(String fielName : fieldNames) {
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@class='grid-header']//div[text()='"+fielName+"']")
							, "field name not found in grid header after adding by Name: " + fielName);
				}
			}else {
				for(String fielName : fieldNames) {
					Assert.assertFalse(CommonUtil.visibilityOfElementLocated("//div[@class='grid-header']//div[text()='"+fielName+"']",5)
							, "field name still visible in grid header after unchecking by Name: " + fielName);
				}
			}
				
		}catch(Exception e){
			logger.info("Unable to add Requirement Field in the grid, field name: " +fieldNames);
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean exportSelectedRequirementTreeNode(String treeNodeName, String reportType, String outputAs) {
		
		try {
			
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-parenttype='release'][@data-name = '" + treeNodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			CommonUtil.normalWait(1000);
			CommonUtil.actionClass().moveToElement(we).build().perform();
			CommonUtil.normalWait(1000);
			logger.info("Hovered on Node successfully.");

			releaseOptionsBtn.click();
			logger.info("Clicked on Node Options on the Node successfully.");

			Assert.assertTrue(navigateToReleaseOptions("Export Requirements"), "Not clicked on Add Button.");
			logger.info("Clicked on Export Requirements");
			CommonUtil.normalWait(1000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonRequiremnetOnly), "Button Requiremnet Only not found");
			buttonRequiremnetOnly.click();
			CommonUtil.normalWait(5000);
			
			if(reportType.equalsIgnoreCase("Excel")){
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDataExcel), "Excel export not found in Export window");
				CommonUtil.scrollToWebElement(radioButtonDataExcel);
				radioButtonDataExcel.click();
					
			}else{
				if(reportType.equalsIgnoreCase("Summary")){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonSummary), "Summary export not found in Export window");
					CommonUtil.scrollToWebElement(radioButtonSummary);
					radioButtonSummary.click();
					
				}else{
					if(reportType.equalsIgnoreCase("Detailed")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDetailed), "Detailed export not found in Export window");
						CommonUtil.scrollToWebElement(radioButtonDetailed);
						radioButtonDetailed.click();
					}
				}
				CommonUtil.normalWait(1000);
				if(outputAs.equalsIgnoreCase("HTML")){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonHtml), "HTML type not found in Export window");
					radioButtonHtml.click();
				}else{
					if(outputAs.equalsIgnoreCase("PDF")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonPdf), "PDF type not found in Export window");
						radioButtonPdf.click();
					}else{
						if(outputAs.equalsIgnoreCase("Word")){
							Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonWord), "Word type not found in Export window");
							radioButtonWord.click();
						}
					}
				}
				
			}
			CommonUtil.normalWait(1000);
			buttonSaveExport.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerDownloadFileInPopup), "Header Download File not found");
			buttonDownload.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(10000);
			
		}catch(Exception e){
			logger.info("Failed to export node successfully");
			e.printStackTrace();
			return false;
		}
		return true;
		
	}
	
	public boolean exportAllRequirementFromGridOfSelectedTreeNode(String reportType, String outputAs) {
		
		try {
			
			HomePage.getInstance().waitForProgressBarToComplete();
			checkboxSelectallRequirementFromGrid.click();
			CommonUtil.normalWait(2000);
			
			buttonExportInGrid.click();
			CommonUtil.normalWait(1000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonRequiremnetOnly), "Button Requiremnet Only not found");
			buttonRequiremnetOnly.click();
			CommonUtil.normalWait(5000);
			
			if(reportType.equalsIgnoreCase("Excel")){
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDataExcel), "Excel export not found in Export window");
				CommonUtil.scrollToWebElement(radioButtonDataExcel);
				radioButtonDataExcel.click();
					
			}else{
				if(reportType.equalsIgnoreCase("Summary")){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonSummary), "Summary export not found in Export window");
					CommonUtil.scrollToWebElement(radioButtonSummary);
					radioButtonSummary.click();
					
				}else{
					if(reportType.equalsIgnoreCase("Detailed")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDetailed), "Detailed export not found in Export window");
						CommonUtil.scrollToWebElement(radioButtonDetailed);
						radioButtonDetailed.click();
					}
				}
				CommonUtil.normalWait(1000);
				if(outputAs.equalsIgnoreCase("HTML")){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonHtml), "HTML type not found in Export window");
					radioButtonHtml.click();
				}else{
					if(outputAs.equalsIgnoreCase("PDF")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonPdf), "PDF type not found in Export window");
						radioButtonPdf.click();
					}else{
						if(outputAs.equalsIgnoreCase("Word")){
							Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonWord), "Word type not found in Export window");
							radioButtonWord.click();
						}
					}
				}
				
			}
			CommonUtil.normalWait(1000);
			buttonSaveExport.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerDownloadFileInPopup), "Header Download File not found");
			buttonDownload.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(10000);
			
		}catch(Exception e){
			logger.info("Failed to export grid data successfully");
			e.printStackTrace();
			return false;
		}
		return true;
		
	}
	
	public boolean exportEntireTraceabilityOfSelectedRequirementTreeNode(String treeNodeName, String reportType, String outputAs) {
		
		try {
			
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-parenttype='release'][@data-name = '" + treeNodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			CommonUtil.normalWait(1000);
			CommonUtil.actionClass().moveToElement(we).build().perform();
			CommonUtil.normalWait(500);
			logger.info("Hovered on Node successfully.");

			releaseOptionsBtn.click();
			logger.info("Clicked on Node Options on the Node successfully.");

			Assert.assertTrue(navigateToReleaseOptions("Export Requirements"), "Not clicked on Add Button.");
			logger.info("Clicked on Export Requirements");
			
			CommonUtil.normalWait(1000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonEntireTraceability), "Button Entire Traceability not found");
			buttonEntireTraceability.click();
			CommonUtil.normalWait(5000);
			if(reportType.equalsIgnoreCase("Excel")){
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDataExcel), "Excel export not found in Export window");
				CommonUtil.scrollToWebElement(radioButtonDataExcel);
				radioButtonDataExcel.click();
					
			}else{
				if(reportType.equalsIgnoreCase("Summary")){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonSummary), "Summary export not found in Export window");
					CommonUtil.scrollToWebElement(radioButtonSummary);
					radioButtonSummary.click();
					
				}else{
					if(reportType.equalsIgnoreCase("Detailed")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDetailed), "Detailed export not found in Export window");
						CommonUtil.scrollToWebElement(radioButtonDetailed);
						radioButtonDetailed.click();
					}
				}
				CommonUtil.normalWait(1000);
				if(outputAs.equalsIgnoreCase("HTML")){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonHtml), "HTML type not found in Export window");
					radioButtonHtml.click();
				}else{
					if(outputAs.equalsIgnoreCase("PDF")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonPdf), "PDF type not found in Export window");
						radioButtonPdf.click();
					}else{
						if(outputAs.equalsIgnoreCase("Word")){
							Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonWord), "Word type not found in Export window");
							radioButtonWord.click();
						}
					}
				}
				
			}
			CommonUtil.normalWait(1000);
			buttonSaveExport.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerDownloadFileInPopup), "Header Download File not found");
			buttonDownload.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(10000);
			
		}catch(Exception e){
			logger.info("Failed to export node successfully");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean importJiraRequirements(String jql, List<String> issueSummay, String renameNode) {
		
		try {
			
			HomePage.getInstance().waitForProgressBarToComplete();
			buttonImport.click();
			CommonUtil.normalWait(2000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonJiraImport), "Jira Import button not found");
			buttonJiraImport.click();
			CommonUtil.normalWait(4000);
			HomePage.getInstance().waitForProgressBarToComplete();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(searchDefectJQL), "JQL Search box not found");
			CommonUtil.normalWait(2000);
			searchDefectJQL.sendKeys(jql);
			CommonUtil.moveToElement(buttonImportJQLSearch);
			CommonUtil.normalWait(2000);
			buttonImportJQLSearch.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			
			for(String issue:issueSummay) {
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(CommonUtil.returnWebElement
						("//div[@id='grid-table-IMPORT_JIRA']//div[text()='"+issue+"']")), "JIRA Issue not found");
			}

			buttonImportAll.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.browserRefresh();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			Assert.assertTrue(expandImportedNode());
			String xpathImpNode = "//a[@data-name='Imported']//following-sibling::ul//li[1]";
			WebElement impNode = CommonUtil.returnWebElement(xpathImpNode);
			CommonUtil.normalWait(2000);
			CommonUtil.moveToElement(impNode);
			importOptionMenu.click();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(renameFromOption), "Rename option not found");
			renameFromOption.click();
			CommonUtil.normalWait(2000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(renameNodeNameTextBox), "Rename window not found");
			renameNodeNameTextBox.click();
			renameNodeNameTextBox.clear();
			renameNodeNameTextBox.sendKeys(renameNode);
			CommonUtil.normalWait(1000);
			buttonRename.click();
		}
		catch (Exception e) {
			logger.info("Failed to import JIRA requirements");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean copyImportedNode(String importedNodeContent, String nodeName) {
		try {			
			HomePage.getInstance().waitForProgressBarToComplete();
			importedNodeArrow.click();
			String xpathImpNode = "//a[@data-name='Imported']//following-sibling::ul//li//a[@data-name='"+nodeName+"']";
			WebElement impNode = CommonUtil.returnWebElement(xpathImpNode);
			CommonUtil.normalWait(3000);
			impNode.click();
			CommonUtil.normalWait(2000);
			CommonUtil.moveToElement(impNode);
			CommonUtil.normalWait(2000);
			importOptionMenu.click();
			CommonUtil.normalWait(1000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(copyFromOption), "Copy option not found");
			copyFromOption.click();
			CommonUtil.normalWait(1000);
		}
		catch (Exception e) {
			logger.info("Failed to copy imported node");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean copyImportedNodeByDragNDrop(String nodeName) {
		try {
			HomePage.getInstance().waitForProgressBarToComplete();
			//importedNodeArrow.click();
			String xpathImpNode = "//a[@data-name='Imported']//following-sibling::ul//li//a[@data-name='"+nodeName+"']";
			WebElement impNode = CommonUtil.returnWebElement(xpathImpNode);
			CommonUtil.normalWait(1000);
			Actions builder = CommonUtil.actionClass();
			Action dragAndDrop = builder.keyDown(Keys.CONTROL).clickAndHold(impNode)
					.moveToElement(releasesInRequirement)
	                .release().keyUp(Keys.CONTROL).build();
	        dragAndDrop.perform();   
		}
		catch (Exception e) {
			logger.info("Failed to copy imported node by drag & drop");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean moveImportedNode(String importedNodeContent, String nodeName) {
		try {
			HomePage.getInstance().waitForProgressBarToComplete();
			importedNodeArrow.click();
			String xpathImpNode = "//a[@data-name='Imported']//following-sibling::ul//li//a[@data-name='"+nodeName+"']";
			WebElement impNode = CommonUtil.returnWebElement(xpathImpNode);
			CommonUtil.normalWait(2000);
			CommonUtil.moveToElement(impNode);
			importOptionMenu.click();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(moveFromOption), "Move option not found");
			moveFromOption.click();
		}
		catch (Exception e) {
			logger.info("Failed to move imported node");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean pasteCopiedImportedNode(String parentNodeName) {
		try {
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-name = '" + parentNodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			we.click();
			CommonUtil.normalWait(1000);
			CommonUtil.actionClass().moveToElement(we).build().perform();
			CommonUtil.normalWait(500);
			logger.info("Hovered on Phase successfully.");

			releaseOptionsBtn.click();
			logger.info("Clicked on Node Options on the Phase successfully.");

			Assert.assertTrue(navigateToReleaseOptions("Paste"), "Not clicked on Paste Button.");
			
		}
		catch (Exception e) {
			logger.info("Failed to Paste copied imported node");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean performNodeSync(String parentNodeName) {
		try {
			CommonUtil.normalWait(1000);
			String xpath = "//*[@data-parenttype='release'][@data-name = '" + parentNodeName + "']";
			WebElement we = CommonUtil.returnWebElement(xpath);
			/*we.click();
			CommonUtil.normalWait(2000);*/
			CommonUtil.actionClass().moveToElement(we).build().perform();
			CommonUtil.normalWait(1000);
			logger.info("Hovered on Phase successfully.");
			CommonUtil.normalWait(1000);
			releaseOptionsBtn.click();
			logger.info("Clicked on Node Options on the Phase successfully.");

			Assert.assertTrue(navigateToReleaseOptions("Manual JIRA Update"), "Not clicked on Sync Option");
			CommonUtil.normalWait(1500);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonSync), "Not able to find Sync Pop-up");
			buttonSync.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@class='progress-bar']//following-sibling::p[contains(text(),'Requirement details update is complete. . Completed 100 %')]"), "Progress not complete");
			HomePage.getInstance().waitForProgressBarToComplete();
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='job-status-modal-requirement']//zui-modal-footer//button[text()='Ok']"), "Ok button not found");
			CommonUtil.returnWebElement("//div[@id='job-status-modal-requirement']//zui-modal-footer//button[text()='Ok']").click();
			logger.info("Node Sync Success");
			
		}
		catch (Exception e) {
			logger.info("Failed to Paste copied imported node");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean exportEntireTraceablilityOfAllRequirementFromGridOfSelectedTreeNode(String reportType, String outputAs) {
		
		try {
			
			HomePage.getInstance().waitForProgressBarToComplete();
			checkboxSelectallRequirementFromGrid.click();
			CommonUtil.normalWait(1000);
			
			buttonExportInGrid.click();
			CommonUtil.normalWait(1000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonEntireTraceability), "Button Entire Traceability not found");
			buttonEntireTraceability.click();
			CommonUtil.normalWait(5000);
			if(reportType.equalsIgnoreCase("Excel")){
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDataExcel), "Excel export not found in Export window");
				CommonUtil.scrollToWebElement(radioButtonDataExcel);
				radioButtonDataExcel.click();
					
			}else{
				if(reportType.equalsIgnoreCase("Summary")){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonSummary), "Summary export not found in Export window");
					CommonUtil.scrollToWebElement(radioButtonSummary);
					radioButtonSummary.click();
					
				}else{
					if(reportType.equalsIgnoreCase("Detailed")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDetailed), "Detailed export not found in Export window");
						CommonUtil.scrollToWebElement(radioButtonDetailed);
						radioButtonDetailed.click();
					}
				}
				CommonUtil.normalWait(1000);
				if(outputAs.equalsIgnoreCase("HTML")){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonHtml), "HTML type not found in Export window");
					radioButtonHtml.click();
				}else{
					if(outputAs.equalsIgnoreCase("PDF")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonPdf), "PDF type not found in Export window");
						radioButtonPdf.click();
					}else{
						if(outputAs.equalsIgnoreCase("Word")){
							Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonWord), "Word type not found in Export window");
							radioButtonWord.click();
						}
					}
				}
				
			}
			CommonUtil.normalWait(1000);
			buttonSaveExport.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerDownloadFileInPopup), "Header Download File not found");
			buttonDownload.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(10000);
			
		}catch(Exception e){
			logger.info("Failed to export grid data successfully");
			e.printStackTrace();
			return false;
		}
		return true;
		
	}
	
	public boolean exportAllRequirementSearchedResults(String reportType, String outputAs) {
		
		try {
			HomePage.getInstance().waitForProgressBarToComplete();
			checkboxSelectAllFromSearch.click();
			CommonUtil.normalWait(1000);
			buttonExportInSearch.click();
			CommonUtil.normalWait(5000);
			
			if(reportType.equalsIgnoreCase("Excel")){
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDataExcel), "Excel export not found in Export window");
				radioButtonDataExcel.click();
					
			}else{
				if(reportType.equalsIgnoreCase("Summary")){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonSummary), "Summary export not found in Export window");
					radioButtonSummary.click();
					
				}else{
					if(reportType.equalsIgnoreCase("Detailed")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDetailed), "Detailed export not found in Export window");
						radioButtonDetailed.click();
					}
				}
				CommonUtil.normalWait(1000);
				if(outputAs.equalsIgnoreCase("HTML")){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonHtml), "HTML type not found in Export window");
					radioButtonHtml.click();
				}else{
					if(outputAs.equalsIgnoreCase("PDF")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonPdf), "PDF type not found in Export window");
						radioButtonPdf.click();
					}else{
						if(outputAs.equalsIgnoreCase("Word")){
							Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonWord), "Word type not found in Export window");
							radioButtonWord.click();
						}
					}
				}
				
			}
			CommonUtil.normalWait(1000);
			buttonSaveExport.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerDownloadFileInPopup), "Header Download File not found");
			buttonDownload.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(10000);
			
			
		}catch (Exception e) {
			logger.info("Failed to export all searched result");
			e.printStackTrace();
			return false;
		}
		return true;
	}

		
	public boolean setPaginationPageSizeInRequirement(String size) {
		try {
			
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			CommonUtil.selectListWithVisibleText(selectPaginationPageSize, size);
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			
		}catch (Exception e) {
			logger.info("Failed to change page size to: "+ size);
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean verifyRequirementInSelectedNodeOfRequirementApp(List<String> requirementNames) {
		try {
			
			for(String requirementName: requirementNames) {
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-req']//div[text()='"+requirementName+"']"), "Requirement not found by name: "+ requirementName);
			}
			
		}catch (Exception e) {
			logger.info("Failed to verify requirement successfully");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean navigateToNextOrPrevPageInRequirementGrid(String nextOrPrev) {
		try {
			if(nextOrPrev.equalsIgnoreCase("Next")) {
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkNextPage), "Link Next page not found");
				linkNextPage.click();
			}else {
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkPrevPage), "Link Prev page not found");
				linkPrevPage.click();
			}
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
		}catch (Exception e) {
			logger.info("Failed to navigate ot "+nextOrPrev+" Page.");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean verifyTraceability(Map<String, Map<String, Map<String, String>>> reqTraceability) {
		try {
			
			if(reqTraceability != null) {
				for (Entry<String, Map<String, Map<String, String>>> entry1 : reqTraceability.entrySet()) {
					String reqString = "//*[@id='grid-table-req']/div[@class='grid-content']//div[@data-col-index='3']//div[text()='"+entry1.getKey()+"']/parent::div/parent::div/preceding-sibling::div//input[@name='req_select']";
					CommonUtil.normalWait(1000);
					CommonUtil.returnWebElement(reqString).click();
				}
				logger.info("Selected the requirement successfully.");
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
				buttonTraceability.click();
				logger.info("Clicked on Traceability Btn successfully.");
				
				for (Map.Entry<String, Map<String, Map<String, String>>> entry1 : reqTraceability.entrySet()) {
					String xpathReq = "//div[@class='requirement-container']//div[text()='"+entry1.getKey()+"']";
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(xpathReq));
				    System.out.println("Requirement Name : " +entry1.getKey());
				    Map<String, Map<String, String>> tempTed = entry1.getValue();
				    if (tempTed != null) {
				    	for (Map.Entry<String, Map<String, String>> entry2 : tempTed.entrySet()) {
					    	System.out.println("Testcase Name : "+entry2.getKey());
					    	String xpathTestcase = xpathReq+"/parent::div/parent::div//following-sibling::div[@class='test-container']//strong[text()='"+entry2.getKey()+"']";
					    	Assert.assertTrue(CommonUtil.visibilityOfElementLocated(xpathTestcase));
					    	logger.info("Verified Testcase");
					    	Map<String, String> tempEd = entry2.getValue();
					    	if (tempEd!=null) {
					    		if (tempEd.containsKey("ExeCount")) {
						    		System.out.println("Count : "+tempEd.get("ExeCount"));
						    		String xpathExeCount = xpathTestcase+"/parent::div/parent::div/parent::div/following-sibling::div//strong[text()='Total : "+tempEd.get("ExeCount")+"']";
						    		Assert.assertTrue(CommonUtil.visibilityOfElementLocated(xpathExeCount));
						    		logger.info("Verified Execution Count");
						    	}		
						    	if (tempEd.containsKey("DefectCount")) {
						    		System.out.println("Defect : "+tempEd.get("DefectCount"));
							    	String xpathDefect = xpathTestcase+"/parent::div/parent::div/parent::div/following-sibling::div//span[@class='traceability-links']";
							    	String LinkedDefectCount = CommonUtil.getFoundElementSize(xpathDefect);
							    	Assert.assertTrue(tempEd.get("DefectCount").equals(LinkedDefectCount));
							    	logger.info("Verified Defect");
					    		}
					    	}
					    }
				    }
				}
			}
			
		}catch (Exception e) {
			logger.info("Failed to verify Traceability");
			e.printStackTrace();
			return false;
		}
		finally {
			CommonUtil.normalWait(1000);
			backFromTraceability.click();
		}
		return true;
	}

	public boolean exportRequirementTraceability() {

		try {
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			btnExportTraceability.click();
			CommonUtil.normalWait(10000);
			HomePage.getInstance().waitForProgressBarToComplete();
		}catch (Exception e) {
			logger.info("Failed to export all searched result");
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean exportSelectedRequirementTraceabilityInFolderView (List <String> reqName) {
		try {
			if(reqName != null) {
				for (String req : reqName) {
					String reqString = "//*[@id='grid-table-req']/div[@class='grid-content']//div[@data-col-index='3']//div[text()='"+req+"']/parent::div/parent::div/preceding-sibling::div//input[@name='req_select']";
					CommonUtil.normalWait(1000);
					CommonUtil.returnWebElement(reqString).click();
				}
			}
			logger.info("Selected the requirement successfully.");
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			buttonTraceability.click();
			logger.info("Clicked on Traceability Btn successfully.");
			Assert.assertTrue(exportRequirementTraceability());
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			CommonUtil.normalWait(1000);
			backFromTraceability.click();
		}
		return true;
	}

	public boolean exportAllSearchedRequirementTraceability () {
		try {
			HomePage.getInstance().waitForProgressBarToComplete();
			checkboxSelectAllFromSearch.click();
			logger.info("Selected the requirement successfully.");
			HomePage.getInstance().waitForProgressBarToComplete();
			buttonTraceability.click();
			logger.info("Clicked on Traceability Btn successfully.");
			Assert.assertTrue(exportRequirementTraceability());
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			CommonUtil.normalWait(1000);
			backFromTraceability.click();
		}
		return true;
	}

	
	public boolean clickonTestcaseCoverageLink(String reqName1 ) {
		{
			HomePage.getInstance().waitForProgressBarToComplete();
			MapTc.click();
			logger.info("Clicked on Testcase coverage link.");
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//span[text()='"+reqName1+"']"),"Not searching for mapped testcase");
			logger.info("Searched for mapped requirement");
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			BackToRequirement.click();
			logger.info("Navigating back to requirements");
			}
		return true;
		
	}
	
	public boolean dupicateRequiremnetNode(String releaseName, String phaseName, String phaseDescription)
	{
	
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(2000);
			//String xpathForRelease = "//li[@data-parenttype='release']/a[@data-name='"+releaseName+"']";
			String xpathForRelease = "//a[@data-parenttype='release'and @data-name='"+releaseName+"']";
			CommonUtil.returnWebElement(xpathForRelease).click();
			CommonUtil.normalWait(2000);
		    logger.info("Hovered on Release successfully.");

			releaseOptionsBtn.click();
			logger.info("Clicked on Node Options on the Release successfully.");
			CommonUtil.normalWait(2000);

			Assert.assertTrue(navigateToReleaseOptions("Add Folder"), "Not clicked on Add Button.");
			logger.info("Clicked on Add Btn to create Folder");

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(createRequirementsPhaseDialogBox),
					"Create phase Dialog box not visible.");
			logger.info("Create phase Dialog box visible to create phase.");

			Assert.assertTrue(createReqPhaseDialogBoxHeader.getText().trim().equals("Add Folder"),
					"Create  Folder dialog box header not validated.");
			logger.info("Create  Folder dialog box header validated successsfully.");

			addNodeNameTextBox.sendKeys(phaseName);
			logger.info("Phase name : " + phaseName + " given successfully to the text box successfully.");

			if (phaseDescription != null) {
				CommonUtil.normalWait(2000);
				addNodeDescriptionTextArea.sendKeys(phaseDescription);
				logger.info("Phase name : " + phaseDescription + " given successfully to the text area successfully.");
			}
			CommonUtil.normalWait(2000);
			reqAddNodeModalSaveBtn.click();
			logger.info("Clicked on the save button successfully.");
			CommonUtil.actionClass().moveToElement(duplicateToasterMsgNode).build().perform();
			assertEquals(CommonUtil.getText(".//*[@id='toast-container']//div[text()='Duplicated requirement tree name, please choose a different name']"), "Duplicated requirement tree name, please choose a different name");
			
			
			//CommonUtil
			CommonUtil.normalWait(5000);
		return true;
	}



}

