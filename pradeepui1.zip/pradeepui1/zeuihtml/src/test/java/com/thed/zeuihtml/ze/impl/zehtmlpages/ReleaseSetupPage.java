package com.thed.zeuihtml.ze.impl.zehtmlpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;

public class ReleaseSetupPage {

	Logger logger;
	public ReleaseSetupPage(){
		logger = Logger.getLogger(this.getClass());
	}
	
	public static ReleaseSetupPage getInstance(){
		return PageFactory.initElements(Driver.driver, ReleaseSetupPage.class);
	}
	
	/******************************************************
	 * 	WEBELEMENTS
	 *****************************************************/
	
	@FindBy(xpath="//span[@title='Add New Release']")
	private WebElement iconAddRelease;
	
	@FindBy(xpath="//div[@title='ID']")
	private WebElement idColumnHeader;
	
	@FindBy(xpath="//div[@title='Release Name']")
	private WebElement releaseNameColumnHeader;
	
	@FindBy(xpath="//div[@title='Start Date']")
	private WebElement startDateColumnHeader;
	
	@FindBy(xpath="//div[@title='End Date']")
	private WebElement endDateColumnHeader;
	
	@FindBy(xpath="//div[@title='Visible']")
	private WebElement visibleColumnHeader;
	
	@FindBy(xpath="//div[@title='Action']")
	private WebElement actionColumnHeader;
	
	@FindBy(xpath="//h2[normalize-space(text())='Add or Clone Release']")
	private WebElement headerAddOrCloneReleasePopup;
	
	@FindBy(xpath="//h2[normalize-space(text())='Add or Clone Release']/parent::div/following-sibling::div[2]/button[text()='Continue']")
	private WebElement buttonContinueToAddOrCloneReleasePopup;
	
	@FindBy(xpath="//span[normalize-space(text())='Add Release']")
	private WebElement headerAddRelease;
	
	@FindBy(xpath="//input[@id='release-name']")
	private WebElement textBoxReleaseName;
	
	@FindBy(xpath="//textarea[@id='release-description']")
	private WebElement textAreaReleaseDescription;
	
	@FindBy(xpath="//input[@id='release-status']")
	private WebElement checkboxHideRelease;
	
	@FindBy(xpath="//div[@id='release-startdate']//input")
	private WebElement inputReleaseStartDate;
	
	@FindBy(xpath="//*[@id='release-enddate']/calendar/div/input")
	private WebElement inputReleaseEndDate;
	
	@FindBy(xpath="//button[normalize-space(text())='Add']")
	private WebElement buttonAddRelease;
	/*shruthi/
	 * 
	 */
	@FindBy(className ="grid-action-icon cursor-pointer clone")
	private WebElement cloneIcon;
	
	@FindBy(xpath="//*[@class='modal fade in']//button[@value='DELETE_DOUBLE_CONFIRMATION']")
	private WebElement FirstCanfirmaOk;
	@FindBy(xpath="//*[@class='modal-dialog']//button[@value='DELETE']")
	private WebElement SecondCanfirmaOk;
	
	@FindBy(xpath="//button[@value='CLONE_RELEASE']")
	private WebElement buttonYesCloneConfirmationPopup;
	
	@FindBy(xpath="//div[@class='clearfix form-footer']//button[text()='Clone']")
	private WebElement MainCloneButton;
	
	@FindBy(xpath="//button[@value='CLONE_RELEASE_CONFIRMED']")
	private WebElement FinalCloneConfirmPopup;
	
	@FindBy(xpath="//label[text()='Test Case Attachments']")
	private WebElement TestAttachmentCheck;
	
	@FindBy(xpath="//label[contains(.,'Clone Cycles')]")
	private WebElement CloneycleCheck;
	
	@FindBy(xpath="//label[contains(.,'Apply 7 day offset to cycles to')]")
	private WebElement ApplyDayOffsetCheck;
	
	@FindBy(xpath="//label[contains(.,'Apply 0 day offset to cycles to')]")
	private WebElement ApplyZeroOFFsetCheck;
	
	@FindBy(xpath="//label[contains(.,'Cycle Phase Assignments')]")
	private WebElement CyclePhaseAssignmentsCheck;
	
	@FindBy(xpath="//label[contains(.,'Clone Execution Results')]")
	private WebElement CloneExecutionResultsCheck;
	
	@FindBy(xpath="//label[contains(.,'Execution-Defect Mappings')]")
	private WebElement ExecutionDefectMappingsCheck;
	
	@FindBy(xpath=".//*[@id='executionComment']")
	private WebElement ExecutionCommentsCheck;
	
    @FindBy(xpath="//label[.//text()='Execution Attachments']")
	private WebElement ExecutionAttachmentsCheck;

    @FindBy(xpath="//label[.//text()='Clone Step Execution Results']")
	private WebElement CloneStepExecutionResultsCheck;
	
	@FindBy(xpath="//label[.//text()='Step Execution Comments']")
	private WebElement StepExecutionCommentCheck;

	@FindBy(xpath="//label[.//text()='Step Execution Attachments']")
	private WebElement StepExecutionAttachmentsCheck;
	
	@FindBy(xpath="//label[contains(text(),'Requirement Test Case Mapping')]")
	private WebElement RequirmentTestcaseMappingCheck;
	
	@FindBy(xpath="//label[.//text()='Requirment Attachments']")
	private WebElement RequirmentAttachmentsCheck;
	
	@FindBy(xpath="//div[@id='job-status-modal-cloneRelease']//button[normalize-space(text())='Ok']")
	private WebElement buttonSucessCloneOk;
	
	
	@FindBy(xpath="//button[normalize-space(text())='Save']")
	private WebElement buttonReleaseRenameSave;
	
	@FindBy(xpath=".//*[@id='add-release-modal']//span[text()='Clone existing release']")
	private WebElement cloneExistingRelease;
	
	@FindBy(xpath=".//select[@id='project']")
	private WebElement cloneSelectProject;
	
	
	
	
	
	
	
	
	/******************************************************
	 * 	Methods
	 *****************************************************/
	
	public void verifyReleaseSetupPage(){
		logger.info("ReleaseSetPage verification started");
		Assert.assertTrue(iconAddRelease!=null, "Add New Release link");
		logger.info("Verified 'Add New Release' link successfully");
		CommonUtil.normalWait(1000);
		Assert.assertTrue(idColumnHeader.getText().equals("ID"), "ID header column");
	}
	
	
	public boolean createNewRelease(String releaseName, String releaseDescription, boolean hideRelease
			, String releaseStartDate, String releaseEndDate){
		
		try{
			CommonUtil.visibilityOfElementLocated(iconAddRelease);
			iconAddRelease.click();
			
			if(CommonUtil.visibilityOfElementLocated(headerAddOrCloneReleasePopup)){
				buttonContinueToAddOrCloneReleasePopup.click();
				if(CommonUtil.visibilityOfElementLocated(headerAddRelease)){
					logger.info("Going to type Release Name as: " + releaseName);
					textBoxReleaseName.sendKeys(releaseName);
					CommonUtil.normalWait(1000);
					
					if(releaseDescription!=null){
						logger.info("Going to type Release description as: " + releaseDescription);
						textAreaReleaseDescription.sendKeys(releaseDescription);
						logger.info("Release Description Added Successfully");
						CommonUtil.normalWait(1000);
					}
					if(hideRelease){
						logger.info("Going to hide release");
						checkboxHideRelease.click();
						logger.info("Release is made hidden successfully");
					}
					
					CommonUtil.normalWait(500);
					inputReleaseStartDate.sendKeys(releaseStartDate);
					
					if(releaseEndDate!=null){
						CommonUtil.normalWait(500);
						inputReleaseEndDate.sendKeys(releaseEndDate);
					}
					CommonUtil.normalWait(1000);
					CommonUtil.scrollToWebElement(buttonAddRelease);
					buttonAddRelease.click();
					HomePage.getInstance().closeToastPopup();
					HomePage.getInstance().waitForProgressBarToComplete();
					
					
					
				}else{
					logger.info("Add Release Header not found");
					return false;
				}
			}else{
				logger.info("Add Or Clone popup not found");
				return false;
			}
			
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		
		return true;
	}
	
	public void verifyReleaseInReleaseSetup(String releaseName, String releaseDescription, boolean hideRelease
			, String releaseStartDate, String releaseEndDate){
		
		logger.info("Going to verify Release Name as: " + releaseName);
		Assert.assertTrue(CommonUtil.visibilityOfElementLocated
				("//div[@id='grid-table-release_setup']//div[@title='"+ releaseName +"']")
				, "Release Name not found, Expected: " + releaseName);
		logger.info("Release name verified successfully as: " + releaseName);
		
		
		if(releaseStartDate!=null){
			logger.info("Going to verify Release Start Date as: " + releaseStartDate);
			String startDate[] = releaseStartDate.split("/");
			String year[] = startDate[2].split("0");
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-release_setup']//div[@title='"+ releaseName 
					+"']/parent::div/parent::div/following-sibling::div[1]//div[@title='"+startDate[0]+"/"+startDate[1]+"/"+year[1]+"']")
					, "Release Start Date verified successfully as: "+releaseStartDate);
			logger.info("Release Start Date verified successfully as: " + releaseStartDate);
		}
		
		if(releaseEndDate!=null){
			logger.info("Going to verify Release End Date as: " + releaseEndDate);
			String endDate[] = releaseEndDate.split("/");
			String year[] = endDate[2].split("0");
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-release_setup']//div[@title='"+ releaseName 
					+"']/parent::div/parent::div/following-sibling::div[2]//div[@title='"+endDate[0]+"/"+endDate[1]+"/"+year[1]+"']")
					, "Release End Date verified successfully as: "+releaseEndDate);
			
			logger.info("Release End Date verified successfully as: " + releaseEndDate);
		}
		
		
		if(hideRelease){
			logger.info("Going to verify Release as hidden");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-release_setup']//div[@title='"+ releaseName +"']/parent::div/parent::div/following-sibling::div[3]//div[@title='No']")
					, "Release found visible, expected hidden");
			logger.info("Release verified as hidden successfully");
			
		}else{
			logger.info("Going to verify Release as Visible");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-release_setup']//div[@title='"+ releaseName +"']/parent::div/parent::div/following-sibling::div[3]//div[@title='Yes']")
					, "Release found hidden, expected visible");
			logger.info("Release verified as visible successfully");
		}
		
		if(releaseDescription!=null){
			CommonUtil.returnWebElement
			("//div[@id='grid-table-release_setup']//div[@title='"+ releaseName +"']").click();
			CommonUtil.normalWait(4000);
			String actualDescription = textAreaReleaseDescription.getAttribute("value");
					
			Assert.assertTrue(actualDescription.equals(releaseDescription), "Release Description not matched, Expected: " + releaseDescription + 
					" Actual: " +actualDescription);
			System.out.println("Actual: " +actualDescription);
			System.out.println("Expected: " + releaseDescription);
			
		}
		
	
		
		
	}
	
	public boolean DeleteRelease(String ReleaseName)
	{
		logger.info("Delete the Release" + ReleaseName );
		Assert.assertTrue(CommonUtil.visibilityOfElementLocated
				("//*[@id='grid-table-release_setup']//div[@title='"+ ReleaseName +"']/parent::div/parent::div/following-sibling::div//span[@title='Delete']"));
		String releaseDelete = "//*[@id='grid-table-release_setup']//div[@title='"+ ReleaseName +"']/parent::div/parent::div/following-sibling::div//span[@title='Delete']";
		WebElement reDelete = CommonUtil.returnWebElement(releaseDelete);
		reDelete.click();
		CommonUtil.normalWait(3000);
		logger.info("clicked on delete icon");
		CommonUtil.normalWait(1000);
		Assert.assertTrue(CommonUtil.visibilityOfElementLocated(FirstCanfirmaOk)," 1st Ok button not found");
		FirstCanfirmaOk.click();
		CommonUtil.normalWait(1000);
		//Defect is there for ZEPHYR-20688
		
		Assert.assertTrue(CommonUtil.visibilityOfElementLocated(SecondCanfirmaOk),"Ok button not found");
		SecondCanfirmaOk.click();
		return true;
		
	}
	public boolean CloneRelease(String ReleaseName)
	{
		logger.info("Clone a release" + ReleaseName );
		HomePage.getInstance().waitForProgressBarToComplete();
		String cloneRel = "//*[@id='grid-table-release_setup']//div[@title='"+ ReleaseName +"']/parent::div/parent::div/following-sibling::div//span[@title='Clone']";
		Assert.assertTrue(CommonUtil.visibilityOfElementLocated(cloneRel));
		WebElement cloneRelease = CommonUtil.returnWebElement(cloneRel);
		cloneRelease.click();
		logger.info("clone icon is clicked");
		Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonYesCloneConfirmationPopup), "Yes button not found in clone confirmation popup");
		buttonYesCloneConfirmationPopup.click();
		logger.info("confirm popup is clicked");
		CommonUtil.normalWait(1000);
		logger.info("waiting");
		CommonUtil.scrollPage();
		CommonUtil.scrollToWebElement(MainCloneButton);
		logger.info("scroll");
		CommonUtil.normalWait(4000);
		Assert.assertTrue(CommonUtil.visibilityOfElementLocated(TestAttachmentCheck),"Yes button not found");
		TestAttachmentCheck.click();
		logger.info("testcase attachment checked");
		CommonUtil.normalWait(1000);
		CloneycleCheck.click();
		ApplyDayOffsetCheck.click();
		CommonUtil.normalWait(1000);
		CyclePhaseAssignmentsCheck.click();
		CommonUtil.normalWait(1000);
		CloneExecutionResultsCheck.click();
		CommonUtil.normalWait(1000);
		ExecutionDefectMappingsCheck.click();
		CommonUtil.normalWait(1000);
		ExecutionCommentsCheck.click();
		CommonUtil.normalWait(1000);
		logger.info("ExecutionComments");
		CommonUtil.normalWait(1000);
		ExecutionAttachmentsCheck.click();
		CommonUtil.normalWait(1000);
		CloneStepExecutionResultsCheck.click();
		StepExecutionCommentCheck.click();
		CommonUtil.normalWait(1000);
		StepExecutionAttachmentsCheck.click();
		RequirmentTestcaseMappingCheck.click();
		/*	if (RequirmentAttachmentsCheck.isEnabled()==true)
		{
		RequirmentAttachmentsCheck.click();
		}
		else {
		CommonUtil.normalWait(1000);
		logger.info("release cloned within same project");	
		} */
		logger.info("Allchecked");
		logger.info("Selection is done");
		
		MainCloneButton.click();
		logger.info("Final popup will showed up");
		CommonUtil.ExplicitWaitForElement(FinalCloneConfirmPopup);
		FinalCloneConfirmPopup.click();
		logger.info("Clone in progress");
		Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//p[contains(text(),'Completed 100 %')]", 240));
		logger.info("Completed release 100%");
		CommonUtil.normalWait(1000);
		CommonUtil.isElementClickable(buttonSucessCloneOk);
		logger.info("button is clicked");
		CommonUtil.normalWait(1000);
		buttonSucessCloneOk.click();
		
		
		return true;
		
		
	}
	
	public boolean CloneRelease(String Projectname, String ReleaseName, String User) {
		
		logger.info("Clone a release" + ReleaseName );
		try{
			CommonUtil.visibilityOfElementLocated(iconAddRelease);
			iconAddRelease.click();
			if(CommonUtil.visibilityOfElementLocated(headerAddOrCloneReleasePopup)){
				cloneExistingRelease.click();
				CommonUtil.normalWait(1000);
				buttonContinueToAddOrCloneReleasePopup.click();
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonYesCloneConfirmationPopup), "Yes button not found in clone confirmation popup");
				buttonYesCloneConfirmationPopup.click();
				logger.info("confirm popup is clicked");
				
			}
			
			else {
				logger.info("ADD Icon not found");
			}
				CommonUtil.normalWait(1000);
				logger.info("waiting");
				CommonUtil.scrollPage();
				CommonUtil.scrollToWebElement(MainCloneButton);
				logger.info("scroll");
				CommonUtil.normalWait(4000);
				cloneSelectProject.click();
				CommonUtil.returnWebElement("//*[@id='project']/option[text()='"+Projectname+"']").click();
				CommonUtil.normalWait(1000);
				CommonUtil.returnWebElement("//*[@id='release']/option[text()='"+ReleaseName+"']").click();
				CommonUtil.normalWait(1000);
				CommonUtil.returnWebElement("//*[@id='user']/option[text()='"+User+"']").click();
				CommonUtil.normalWait(1000);
				CommonUtil.normalWait(1000);
				CloneycleCheck.click();
				ApplyZeroOFFsetCheck.click();
				CommonUtil.normalWait(1000);
				CyclePhaseAssignmentsCheck.click();
				CommonUtil.normalWait(1000);
				logger.info("Selection is done");
				MainCloneButton.click();
				logger.info("Final popup will showed up");
				CommonUtil.ExplicitWaitForElement(FinalCloneConfirmPopup);
				FinalCloneConfirmPopup.click();
				logger.info("Clone in progress");
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//p[contains(text(),'Completed 100 %')]", 240));
				logger.info("Completed release 100%");
				CommonUtil.normalWait(1000);
				CommonUtil.isElementClickable(buttonSucessCloneOk);
				logger.info("button is clicked");
				CommonUtil.normalWait(1000);
				buttonSucessCloneOk.click();
			
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		
		return true;
		
	}
	
	public boolean renameRelease(String ReleaseName, String newReleaseName, String releaseDescription,String releaseEndDate)
	{
		
		Assert.assertTrue(CommonUtil.visibilityOfElementLocated
				("//div[@title='"+ ReleaseName+"']"));
		
		String clonedRelName = ("//div[@title='"+ ReleaseName+"']");
		WebElement clonedReleaseName = CommonUtil.returnWebElement(clonedRelName);
		clonedReleaseName.click();
		
		
		CommonUtil.visibilityOfElementLocated(textBoxReleaseName);
		
			logger.info("Going to type Release Name as: " + newReleaseName);
			textBoxReleaseName.clear();
			textBoxReleaseName.sendKeys(newReleaseName);
			
			
			logger.info("Going to type Release description as: " + releaseDescription);
			textAreaReleaseDescription.clear();
				textAreaReleaseDescription.sendKeys(releaseDescription);
				
				logger.info("Release Description Added Successfully");
				
				if(releaseEndDate!=null){
					CommonUtil.normalWait(500);
					inputReleaseEndDate.sendKeys(releaseEndDate);
				}
				else
				{
				logger.info(";release have end date");
				}
				
				buttonReleaseRenameSave.click();
				logger.info("Release renamed");
	
		return true;
	}
	
		  
	
}
