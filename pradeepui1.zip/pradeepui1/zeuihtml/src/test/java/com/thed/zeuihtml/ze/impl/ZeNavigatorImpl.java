package com.thed.zeuihtml.ze.impl;

import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;

import com.thed.zeuihtml.ze.ZeNavigator;
import com.thed.zeuihtml.ze.impl.zehtmlpages.CustomizationPage;
import com.thed.zeuihtml.ze.impl.zehtmlpages.DashboardPage;
import com.thed.zeuihtml.ze.impl.zehtmlpages.DefectAdminPage;
import com.thed.zeuihtml.ze.impl.zehtmlpages.DefectTrackingConfigurationPage;
import com.thed.zeuihtml.ze.impl.zehtmlpages.DefectTrackingPage;
import com.thed.zeuihtml.ze.impl.zehtmlpages.HomePage;
import com.thed.zeuihtml.ze.impl.zehtmlpages.LoginPage;
import com.thed.zeuihtml.ze.impl.zehtmlpages.ManageProjects;
import com.thed.zeuihtml.ze.impl.zehtmlpages.ManageUsers;
import com.thed.zeuihtml.ze.impl.zehtmlpages.ProjectSummaryPage;
import com.thed.zeuihtml.ze.impl.zehtmlpages.ReleaseSetupPage;
import com.thed.zeuihtml.ze.impl.zehtmlpages.ReleaseSummaryPage;
import com.thed.zeuihtml.ze.impl.zehtmlpages.RequirementPage;
import com.thed.zeuihtml.ze.impl.zehtmlpages.SystemConfigurationPage;
import com.thed.zeuihtml.ze.impl.zehtmlpages.TestExecutionPage;
import com.thed.zeuihtml.ze.impl.zehtmlpages.TestPlanningPage;
import com.thed.zeuihtml.ze.impl.zehtmlpages.TestRepositoryPage;
import com.thed.zeuihtml.ze.impl.zehtmlpages.UserAuthentication;
import com.thed.zeuihtml.ze.impl.zehtmlpages.ZAutomationPage;



public class ZeNavigatorImpl implements ZeNavigator{

	@Override
	public boolean doLogin(String username, String password) {
		return LoginPage.getInstance().doLogin(username, password);
	}

	@Override
	public boolean logout(){
		return HomePage.getInstance().logout();
	}
	
	@Override
	public boolean resetPassword(String newPassword){
		return LoginPage.getInstance().resetPassword(newPassword);
	}
	
	@Override
	public void verifyProjectSummaryPage(String expectedDefaultSelectedProjectName,String expectedUserTitle, Integer totalReleaseCount,
			Integer totalInprogressRelease, Integer totalTestcases, Integer totalExecutions, Integer totalmembers) {
		
		ProjectSummaryPage.getInstance().verifyProjectSummaryPage(expectedDefaultSelectedProjectName, expectedUserTitle, 
				totalReleaseCount, totalInprogressRelease, totalTestcases, totalExecutions, totalmembers);
	}
	
	@Override
	public boolean launchReleaseSetupPage(){
		return ReleaseSummaryPage.getInstance().launchReleaseSetupPage();
	}

	public boolean createNewRelease(String releaseName, String releaseDescription, boolean hideRelease
			, String releaseStartDate, String releaseEndDate){
		return ReleaseSetupPage.getInstance().createNewRelease(releaseName, releaseDescription, 
				hideRelease, releaseStartDate, releaseEndDate);
	}
	
	public void verifyReleaseInReleaseSetup(String releaseName, String releaseDescription, boolean hideRelease
			, String releaseStartDate, String releaseEndDate){
		ReleaseSetupPage.getInstance().verifyReleaseInReleaseSetup(releaseName, 
				releaseDescription, hideRelease, releaseStartDate, releaseEndDate);
	}
	
	public boolean navigateReleaseFromTopDropdown(String releaseName){
		return ReleaseSummaryPage.getInstance().navigateReleaseFromTopDropdown(releaseName);
	}
	
	public void verifyReleaseSetupPage(){
		ReleaseSetupPage.getInstance().verifyReleaseSetupPage();
	}
	
	@Override
	public void verifyLoginPage() {
		LoginPage.getInstance().verifyLoginPage();
	}

	@Override
	public boolean selectReleaseFromGrid(String ReleaseName) {
		return ProjectSummaryPage.getInstance().selectReleaseFromGrid(ReleaseName);
	}

	@Override
	public void verifyReleaseSummaryPage(String releaseName) {
		ReleaseSummaryPage.getInstance().verifyReleaseSummaryPage(releaseName);
		
	}
	@Override
	public boolean selectReleaseDropDown(String ReleaseName) {
		return ProjectSummaryPage.getInstance().selectRelease(ReleaseName);
	}
	
	@Override
	public boolean launchAdministration() {
		return HomePage.getInstance().launchAdministration();
	}

	@Override
	public boolean navigateToReleaseApps(String releaseName, String appName) {
		return ReleaseSummaryPage.getInstance().navigateToReleaseApps(releaseName, appName);
	}
	@Override
	public void verifySystemConfigPage(String companyName, String systemName, String desktopURL, String dashboardURL,
			String mailServerHostName, String mailServerPort, String mailServerUsername) {
	
		SystemConfigurationPage.getInstance().verifySystemConfigPage(companyName, systemName, desktopURL, dashboardURL,
				mailServerHostName, mailServerPort, mailServerUsername);
	}

	@Override
	public boolean createPhase(String releaseName, String phaseName, String phaseDescription) {
		return TestRepositoryPage.getInstance().createPhase(releaseName, phaseName, phaseDescription);
	}
	
	@Override
	public boolean createReqPhase(String releaseName, String phaseName, String phaseDescription) {
		return RequirementPage.getInstance().createPhase(releaseName, phaseName, phaseDescription);
	}
		
	@Override
	public boolean changeSystemConfigurations(String companyName,
			String systemName, String hostName, String port,
			String mailServerUsername, String mailServerPassword) {
	return	SystemConfigurationPage.getInstance().changeSystemConfigurations(companyName, systemName, hostName, port,
				mailServerUsername, mailServerPassword);
	}

	@Override
	public boolean setDefectTracking() {
		//HomePage.getInstance().launchAdministration();
		HomePage.getInstance().launchAdminApps("DefectTracking");
		//HomePage.getInstance().launchAdminApps("DefectTracking");
		return DefectTrackingConfigurationPage.getInstance().setDefectTracking();
	}

	@Override
	public boolean setUserJiraCredentialsinExternalPopup() {
		HomePage.getInstance().launchAdminApps("DefectAdmin");
		return DefectAdminPage.getInstance().setUserJiraCredentialsinExternalPopup();
	}

	@Override
	public boolean addCustomField(String customFieldName,
			String customFieldType, String customFieldDescriptio,
			boolean searchable, boolean mandatory , String projectName, boolean all) {
		return CustomizationPage.getInstance().addCustomField(customFieldName, customFieldType, customFieldDescriptio, searchable, mandatory, projectName, all);
	}

	@Override
	public boolean lockZephyrAccess(boolean lock) {
		return CustomizationPage.getInstance().lockZephyrAccess(lock);
	}

	@Override
	public boolean launchAdminApps(String appNameToBeLaunched) {
		return HomePage.getInstance().launchAdminApps(appNameToBeLaunched);
	}

	@Override
	public boolean launchCustomizationOptions(String fieldName) {
		return CustomizationPage.getInstance().launchCustomizationOptions(fieldName);
	}

	@Override
	public boolean selectProject(String projectName) {
		return HomePage.getInstance().selectProject(projectName);
	}

	@Override
	public boolean verifyCustomFields(String customFieldName,
			String customFieldType, String customFieldDescriptio,
			boolean searchable, boolean mandatory) {
		return CustomizationPage.getInstance().verifyCustomFields(customFieldName, customFieldType, customFieldDescriptio, searchable, mandatory);
	}

	@Override
	public boolean addCustomFieldPicklist(String customFieldName,
			String customFieldType, String customFieldDescription,
			boolean searchable, boolean mandatory, List<String> picklistValues, String projectName, boolean all) {
		return CustomizationPage.getInstance().addCustomFieldPicklist(customFieldName, customFieldType, customFieldDescription, 
				searchable, mandatory, picklistValues, projectName, all);
	}
	
	@Override
	public boolean editCustomfield(String customFieldName, String customfieldUpdate){
		return CustomizationPage.getInstance().editCustomfield(customFieldName,customfieldUpdate);
	}
	
	
	@Override
	public boolean deleteCustomfield(String customFieldName){
	return CustomizationPage.getInstance().deleteCustomfield(customFieldName);
	}
	
	
	@Override
	public boolean addExecutionStatus(String executionStatusName) {
		return CustomizationPage.getInstance().addExecutionStatus(executionStatusName);
	}

	@Override
	public void verifyExecutionStatus(String executionStatusName, boolean closeWindowAfterVerifying) {
		CustomizationPage.getInstance().verifyExecutionStatus(executionStatusName, closeWindowAfterVerifying);
	}

	@Override
	public boolean updateDefaultEstimatedTime(String estimatedTime) {
		return CustomizationPage.getInstance().updateDefaultEstimatedTime(estimatedTime);
	}

	@Override
	public void verifyEstimatedTime(String estimatedTime) {
		CustomizationPage.getInstance().verifyEstimatedTime(estimatedTime);
		
	}

	@Override
	public boolean addNewUser(String userFistAndLastName, String userRole,
			String email, String location) {
		return ManageUsers.getInstance().addNewUser(userFistAndLastName, userRole, email, location);
	}

	@Override
	public void verifyUser(String userFistAndLastName, String userRole,
			String email, String location) {
		ManageUsers.getInstance().verifyUser(userFistAndLastName, userRole, email, location);
	}

	@Override
	public boolean addNewProject(String projectName, String projectType,
			String projectDescription, String startDate, String endDate,
			String leadName, String jiraProjectName) {
		return ManageProjects.getInstance().addNewProject(projectName, projectType, projectDescription, startDate, 
				endDate, leadName, jiraProjectName);
	}

	@Override
	public void verifyProject(String projectName, String projectType,
			String projectDescription, String startDate, String endDate,
			String leadName, String jiraProjectName, List<String> resourceNames, String membersInProject) {
		ManageProjects.getInstance().verifyProject(projectName, projectType, projectDescription, startDate, 
				endDate, leadName, jiraProjectName, resourceNames, membersInProject);
	}
	
	@Override
	public boolean editProject(String projectName, String newProjectName, String projectType, String projectDescription, String startDate, String endDate, 
			String leadName, String jiraProjectName, String Jiraconnection, String CustomfieldText, List<String> resourceNameToAdd, List<String> resourceNameToRemove, List<String> ProjectNameToAdd){
		return ManageProjects.getInstance().editProject(projectName, newProjectName, projectType, projectDescription, 
				startDate, endDate, leadName, jiraProjectName, Jiraconnection, CustomfieldText, resourceNameToAdd, resourceNameToRemove, ProjectNameToAdd);
	}
	
	@Override
	public boolean addNewRole(String roleName, String roleDescription, boolean systemSetup, boolean userSetup, boolean projectSetup
			, boolean defectsAdmin, boolean releaseSetup, boolean requirements, boolean testPlanning, boolean testRepository
			, boolean testExecution, boolean defectTracking, boolean closeWindowAfterCreation){
		return CustomizationPage.getInstance().addNewRole(roleName, roleDescription, systemSetup, userSetup, 
				projectSetup, defectsAdmin, releaseSetup, requirements, testPlanning, testRepository, testExecution, 
				defectTracking, closeWindowAfterCreation);
	}
	
	@Override
	public void verifyRole(String roleName, String RoleDescription, boolean closeWindowAferVerifying){
		CustomizationPage.getInstance().verifyRole(roleName, RoleDescription, closeWindowAferVerifying);
	}
	
	@Override
	public boolean assignProjectsToUser(String userFistAndLastName, List<String> projectNames){
		return ManageUsers.getInstance().assignProjectsToUser(userFistAndLastName, projectNames);
	}
	
	@Override
	public void verifyProjectsAssignedToUser(String userFistAndLastName, List<String> projectNames){
		ManageUsers.getInstance().verifyProjectsAssignedToUser(userFistAndLastName, projectNames);
	}
	
	@Override
	public void verifyAdminAppsToBePresent(boolean systemSetupApp, boolean userSetupApp, boolean projectSetupApp,
			boolean defectsAdminApp){
		HomePage.getInstance().verifyAdminAppsToBePresent(systemSetupApp, userSetupApp, projectSetupApp, defectsAdminApp);
	}
	
	@Override
	public void verifyReleaseAppsToBePresent(boolean requirementApp, boolean testRepository, boolean testPlanningApp,
			boolean testExecutionApp, boolean defectTrackingApp, boolean zAutomationApp){
		ReleaseSummaryPage.getInstance().verifyReleaseAppsToBePresent(requirementApp, testRepository, 
				testPlanningApp, testExecutionApp, defectTrackingApp, zAutomationApp);
	}
	
	@Override
	public boolean createNode(List<String> parentTree, String phaseName, String nodeName, String nodeDescription) {
		return TestRepositoryPage.getInstance().createNode(parentTree, phaseName, nodeName, nodeDescription);
	}
	
	@Override
	public boolean createNode(String phaseName, String nodeName, String nodeDescription) {
		return TestRepositoryPage.getInstance().createNode(phaseName, nodeName, nodeDescription);
	}
	@Override
	public boolean renameNode(String renameNodeName, String newNodeName, String newNodeDescription) {
		return TestRepositoryPage.getInstance().renameNode(renameNodeName, newNodeName, newNodeDescription);
	}
	@Override
	public boolean renameRequirementsNode(String renameNodeName, String newNodeName, String newNodeDescription) {
		return RequirementPage.getInstance().renameRequirementNode(renameNodeName, newNodeName, newNodeDescription);
	}
	@Override
	public boolean deleteNode(String deleteNodeName) {
		return TestRepositoryPage.getInstance().deleteNode(deleteNodeName);
	}
	@Override
	public boolean navigateToNodes(List<String> phases) {
		return TestRepositoryPage.getInstance().navigateToNodes(phases);
	}	
	@Override
	public boolean navigateToNodesInRequirements(List<String> phases) {
		return RequirementPage.getInstance().navigateToNodes(phases);
	}
	@Override
	public boolean filterNodes(String filterText) {
		return TestRepositoryPage.getInstance().filterNodes(filterText);
	}
	@Override
	public String addDefaultTestcase(String nodeName) {
		return TestRepositoryPage.getInstance().addDefaultTestcase(nodeName);
	}
	@Override
	public boolean modifyTestcase(Map<String, String> values) {
		return TestRepositoryPage.getInstance().modifyTestcase(values);
	}
	
	@Override
	public boolean modifyTeststep(Map<String, String> values){
		return TestRepositoryPage.getInstance().modifyTeststep(values);
	}
	
	@Override
	public boolean cloneTestcase(String nodeName, String testcaseName,String stepstatus){
		return TestRepositoryPage.getInstance().cloneTestcase(nodeName,testcaseName,stepstatus);
	}
	
	@Override
	public String getTestcase(String nodeName){
		return TestRepositoryPage.getInstance().getTestcase(nodeName);
	}
	
	@Override
	public String getTestcase(String nodeName, String testcaseName){
		return TestRepositoryPage.getInstance().getTestcase(nodeName, testcaseName);
	}
	
	@Override
	public boolean navigateBetweenTestcases(String nodeName, String testcaseName){
		return TestRepositoryPage.getInstance().navigateBetweenTestcases(nodeName, testcaseName);
	}
	
	@Override
	public boolean findAndAddTestcase(String nodeName,String searchQuery){
		return TestRepositoryPage.getInstance().findAndAddTestcase(nodeName, searchQuery);
	}
	
	@Override
	public boolean dockUndockGlobalTree(String nodeName){
		return TestRepositoryPage.getInstance().dockUndockGlobalTree(nodeName);
	}
	
	@Override
	public boolean searchTescases(String searchType, String searchQuery, List<String> expectedTestcases, boolean navigateBackToFolder){
		return TestRepositoryPage.getInstance().searchTescases(searchType, searchQuery, expectedTestcases, navigateBackToFolder);
	}
	
	@Override
	public boolean switchBetweenSearchFolderListDetailView(String nodeName){
		return TestRepositoryPage.getInstance().switchBetweenSearchFolderListDetailView(nodeName);
	}
	
	@Override
	public boolean deleteTestcase(String nodeName, String testcaseId) {
		return TestRepositoryPage.getInstance().deleteTestcase(nodeName, testcaseId);
	}
	@Override
	public boolean createCycle(String cycleName, String buildName, String environment, String startDate, String endDate) {
		return TestPlanningPage.getInstance().createCycle(cycleName, buildName, environment, startDate, endDate);
	}
	@Override
	public boolean editCycle(String cycleName, String newCycleName, String buildName, String environment
			,String cycleStartDate, String cycleEndDate, List<String> phaseNameWithStartDates, List<String> phaseNameWithEndDates, boolean hideCycle, boolean viewhideCycle) {
		return TestPlanningPage.getInstance().editCycle(cycleName, newCycleName, 
				buildName, environment, cycleStartDate, cycleEndDate, phaseNameWithStartDates, phaseNameWithEndDates, hideCycle,viewhideCycle);
	}
	
	@Override
	public boolean deleteCycle(String deleteCycleName) {
		return TestPlanningPage.getInstance().deleteCycle(deleteCycleName);
	}
	
	@Override
	public boolean addPhaseToCycle(String cycleName, String phaseName, String bulkAssingTo, boolean navigatebackToCycle){
		return TestPlanningPage.getInstance().addPhaseToCycle(cycleName, phaseName, bulkAssingTo, navigatebackToCycle);
	}
	
	@Override
    public String addDefaultRequirement(String nodeName) {
		return RequirementPage.getInstance().addDefaultRequirement(nodeName);
	}

	@Override

	public boolean addCustomfieldToTestcase(String customfieldName, String customfieldValue, String customfieldType) {
		return TestRepositoryPage.getInstance().addCustomfieldToTestcase(customfieldName, customfieldValue, customfieldType);
	}

	@Override
	public boolean verifyCustomfieldToTestcase(String customfieldName, String customfieldValue,
			String customfieldType) {
		
		return TestRepositoryPage.getInstance().verifyCustomfieldToTestcase(customfieldName, customfieldValue, customfieldType);
	}

	@Override	
	public boolean navigateToAssignTestcaseToExecuteWindow(String cycleName,
			String phaseName, boolean initialBulkAssignmentPopupExpected) {
		return TestPlanningPage.getInstance().navigateToAssignTestcaseToExecuteWindow(cycleName, phaseName, initialBulkAssignmentPopupExpected);
	}

	@Override
	public boolean navigateToNodeInAssignTestcaseToExecuteWindow(
			List<String> nodeList) {
		return TestPlanningPage.getInstance().navigateToNodeInAssingTestcaseToExecuteWindow(nodeList);
	}

	@Override
	public void verifyAssigneeOfTestcase(String testcaseName, String assignee,
			boolean navigateBackToCycles) {
		TestPlanningPage.getInstance().verifyAssigneeOfTestcase(testcaseName, assignee, navigateBackToCycles);
		
	}

	@Override
	public boolean cloneCycle(String cycleName, String clonedCycleNewName,
			boolean copyTestcaseAssignments) {
		return TestPlanningPage.getInstance().cloneCycle(cycleName, clonedCycleNewName, copyTestcaseAssignments);
	}

	@Override
	public void verifyPhaseNotVisiblieInCyclePage(
			String hiddenCycleName, String phaseName) {
		TestPlanningPage.getInstance().verifyPhaseNotVisiblieInCyclePage(hiddenCycleName, phaseName);
		
	}
	
	@Override
	public void verifyPhaseNotVisiblieInHiddenCyclePage(
			String hiddenCycleName, String phaseName) {
		TestPlanningPage.getInstance().verifyPhaseNotVisiblieInHiddenCyclePage(hiddenCycleName, phaseName);
		
	}

	@Override
	public boolean assignTestIndividually(String testcaseName, String assignee,
			boolean navigateBackToCycles) {
		return TestPlanningPage.getInstance().assignTestIndividually(testcaseName, assignee, navigateBackToCycles);
	}

	@Override
	public boolean bulkAssignNotExecutedTest(String assignee,
			boolean applySubFolders, boolean navigateBackToCycles) {
		return TestPlanningPage.getInstance().bulkAssignNotExecutedTest(assignee, applySubFolders, navigateBackToCycles);
	}

	@Override
	public boolean bulkAssignUnassignedTest(String assignee,
			boolean applySubFolders, boolean navigateBackToCycles) {
		return TestPlanningPage.getInstance().bulkAssignUnassignedTest(assignee, applySubFolders, navigateBackToCycles);
	}

	@Override
	public boolean bulkAssignAllAssignedButNotExecutedTest(String fromAssignee,
			String toAssignee, boolean applySubFolders, boolean navigateBackToCycles) {
		return TestPlanningPage.getInstance().bulkAssignAllAssignedButNotExecutedTest(fromAssignee, toAssignee, applySubFolders, navigateBackToCycles);
	}

	@Override
	public boolean addFreeformPhaseToCycle(String cycleName,
			String freeformPhaseName,
			boolean navigateBackToCycles) {
		return TestPlanningPage.getInstance().addFreeformPhaseToCycle(cycleName, freeformPhaseName
				, navigateBackToCycles);
	}

	@Override
	public boolean addFreeformChildNode(String freeformNodeNameToAddChildNodes,
			List<String> freeformChildNodeNames, boolean navigateBackToCycles) {
		return TestPlanningPage.getInstance().addFreeformChildNode(freeformNodeNameToAddChildNodes
				, freeformChildNodeNames, navigateBackToCycles);
	}

	@Override
	public boolean editFreeformChildNode(String freeformNodeNameToEdit,
			String newNodeName, String newNodeDescription,
			boolean navigateBackToCycles) {
		return TestPlanningPage.getInstance().editFreeformChildNode(freeformNodeNameToEdit
				, newNodeName, newNodeDescription, navigateBackToCycles);
	}

	@Override
	public void launchReleaseApp(String appName) {
		ReleaseSummaryPage.getInstance().launchReleaseApp(appName);
	}

	@Override
	public boolean deleteFreeformChildNodeAndVerify(
			String freeformNodeNameToDelete, boolean navigateBackToCycles) {
		return TestPlanningPage.getInstance().deleteFreeformChildNodeAndVerify(freeformNodeNameToDelete
				, navigateBackToCycles);
	}

	@Override
	public boolean addTestcaseToFreeformNode(String searchType,
			String searchQuery, List<String> expectedTestcases,
			boolean addAllFetchedTestcases, boolean selectAllCheckboxInGrid,
			boolean bringHierarchy) {
	
		return TestPlanningPage.getInstance().addTestcaseToFreeformNode(searchType, searchQuery
				, expectedTestcases, addAllFetchedTestcases, selectAllCheckboxInGrid, bringHierarchy);
	}

	@Override
	public boolean syncSelectedNode(List<String> nodesNameWithTestCountAdded,
			List<String> nodesNameWithTestCountDeleted, boolean removeDeleted,
			boolean navigateBackToCycles) {
		return TestPlanningPage.getInstance().syncSelectedNode(nodesNameWithTestCountAdded
				, nodesNameWithTestCountDeleted, removeDeleted, navigateBackToCycles);
	}

	@Override
	public void verifyAbsenceOfTestcaseInCycleAssignmentWindow(
			String testcaseName, boolean navigateBackToCycles) {
	TestPlanningPage.getInstance().verifyAbsenceOfTestcaseInCycleAssignmentWindow(testcaseName
			, navigateBackToCycles);
		
	}

	@Override
	public boolean deleteTestcaseFromSelectedNodeInAssingTestcaseToExecuteWindow(
			List<String> testcaseNamesInSelectedNode,
			boolean navigateBackToCycles) {
		return TestPlanningPage.getInstance().deleteTestcaseFromSelectedNodeInAssingTestcaseToExecuteWindow(testcaseNamesInSelectedNode
				, navigateBackToCycles);
	}

	@Override

	public boolean deleteCyclePhase(String cycleName, String phaseName) {
		
		return TestPlanningPage.getInstance().deleteCyclePhase(cycleName, phaseName);
	}

	@Override
	public boolean verifyTestcaseCountOfSelectedNode(String nodeName,
			int testCaseCount, boolean navigateBackToCycles) {
		return TestPlanningPage.getInstance().verifyTestcaseCountOfSelectedNode(nodeName, testCaseCount,navigateBackToCycles);
	}

	@Override
	public boolean verifyRequirementApp(String releaseName) {
		return RequirementPage.getInstance().verifyRequirementApp(releaseName);
	}

	@Override
	public boolean verifyTestRepositorySummaryPage(String releaseName) {
		return TestRepositoryPage.getInstance().verifyTestRepositorySummaryPage(releaseName);
	}

	@Override
	public boolean verifyTestPlanningPage(String releaseName) {
		return TestPlanningPage.getInstance().verifyTestPlanningPage(releaseName);
	}
	@Override
	public boolean createRequirementNode(String phaseName, String nodeName, String nodeDescription) {
		return RequirementPage.getInstance().createNode(phaseName, nodeName, nodeDescription);
	}
	@Override
	public boolean cloneRequirement(String nodeName,String requirementId) {
		return RequirementPage.getInstance().cloneRequirement(nodeName, requirementId);
	}
	@Override
	public boolean navigateToNodesInTestExecution(List<String> nodeList) {
		return TestExecutionPage.getInstance().navigateToNodesInTestExecution(nodeList);
	}

	@Override
	public boolean verifyAssignedTestcaseInSelectedNodeInTCE(
			String testcaseName, String assingedTo, String status) {
		return TestExecutionPage.getInstance().verifyAssignedTestcaseInSelectedNodeInTCE(testcaseName
				, assingedTo, status);
	}

	@Override
	public boolean executeTestcaseInSelectedNodeAndVerify(String testcaseName,
			String status) {
		return TestExecutionPage.getInstance().executeTestcaseInSelectedNodeAndVerify(testcaseName, status);
	}

	@Override
	public boolean bulkExecuteTestcaseInSelectedNodeAndVerify(
			List<String> testNames, String status) {
		return TestExecutionPage.getInstance().bulkExecuteTestcaseInSelectedNodeAndVerify(testNames, status);
	}

	@Override
	public boolean executeTestStepAndVerify(String testcaseName, String stepId,
			String status, boolean expandStepsSection,
			boolean expectedExecuteTestcasePopup, String executeTestcaseStatus) {
		return TestExecutionPage.getInstance().executeTestStepAndVerify(testcaseName, stepId, status, expandStepsSection
				, expectedExecuteTestcasePopup, executeTestcaseStatus);
	}

	@Override
	public boolean addExecutionAttachmentsNotesActualTime(String testcaseName,
			String attachmentFileWithPath, String notes, String actualTime) {
		return TestExecutionPage.getInstance().addExecutionAttachmentsNotesActualTime(testcaseName
				, attachmentFileWithPath, notes, actualTime);
	}

	@Override
	public boolean switchExecutionViewAndVerify(String folderOrSearch) {
		return TestExecutionPage.getInstance().switchExecutionViewAndVerify(folderOrSearch);
	}

	@Override
	public boolean executionSearchAndVerifyTestcase(
			String searchTypeQuickOrAdvanced, String searchQuery,
			List<String> testcaseNamesToVerify) {
		return TestExecutionPage.getInstance().executionSearchAndVerifyTestcase(searchTypeQuickOrAdvanced, searchQuery, testcaseNamesToVerify);
	}

	@Override
	public boolean verifyTestExecutionDetailsInSearch(String testcaseName,
			Map<String, String> values) {
		return TestExecutionPage.getInstance().verifyTestExecutionDetailsInSearch(testcaseName, values);
	}

	@Override
	public boolean deleteRequirement(String nodeName,String requirementId) {
		return RequirementPage.getInstance().deleteRequirement(nodeName, requirementId);
	}


	@Override
	public boolean addTestcaseToFreeformNodeFromAnotherCycle(String fromCycle,
			String fromPhase, String withStatus,
			List<String> expectedTestcases, boolean selectAllCheckboxInGrid,
			boolean bringHierarchy) {
		return TestPlanningPage.getInstance().addTestcaseToFreeformNodeFromAnotherCycle(fromCycle, fromPhase, withStatus
				, expectedTestcases, selectAllCheckboxInGrid, bringHierarchy);
	}

	@Override
	public boolean searchAndLinkDefect(String testcaseName,
			String searchChoice, String searchValue, String defectSummary,
			String defectID) {
		return TestExecutionPage.getInstance().searchAndLinkDefect(testcaseName, searchChoice, searchValue, defectSummary, defectID);
	}

	@Override
	public boolean linkNewDefect(String testcaseName, Map<String, String> values) {
		return TestExecutionPage.getInstance().linkNewDefect(testcaseName, values);
	}



	public boolean bulkEditTestCase(Map<String, String> values) {
		
		return TestRepositoryPage.getInstance().bulkEditTestCase(values);
	}

	@Override
	public boolean launchDashboard() {
		return HomePage.getInstance().launchDashboard();
	}

	@Override
	public boolean createDashboard(String dashboardName,
			String dashboardDescription, String layout, String accessType) {
		return DashboardPage.getInstance().createDashboard(dashboardName, dashboardDescription, layout, accessType);
	}

	@Override
	public boolean editDashboard(String dashboardName, String dashboardNewName,
			String dashboardDescription, String layout, String accessType) {
		return DashboardPage.getInstance().editDashboard(dashboardName, dashboardNewName, dashboardDescription, layout, accessType);
	}

	@Override
	public boolean verifyDashboard(String dashboardName,
			String dashboardDescription) {
		return DashboardPage.getInstance().verifyDashboard(dashboardName, dashboardDescription);
	}

	@Override
	public boolean selectDashboard(String dashboardName) {
		return DashboardPage.getInstance().selectDashboard(dashboardName);
	}

	@Override
	public boolean addDailyPulseGadgets(String projectName, String releaseName,
			String trackedBy, String timeFrame) {
		return DashboardPage.getInstance().addDailyPulseGadgets(projectName, releaseName, trackedBy, timeFrame);
	}

	@Override
	public boolean addExecutionBacklogGadget(String projectName,
			String releaseName, String filterBy,
			List<String> listOfFilterByValues, String refreshRate) {
		return DashboardPage.getInstance().addExecutionBacklogGadget(projectName, releaseName, filterBy, listOfFilterByValues, refreshRate);
	}

	@Override
	public boolean deallocateRequirement(String reqName) {
		return RequirementPage.getInstance().deallocateRequirement(reqName);
	}

	@Override
	public boolean verifyRequirement(String reqName,
			Map<String, String> reqFieldsValues) {
		return RequirementPage.getInstance().verifyRequirement(reqName, reqFieldsValues);
	}

	@Override
	public boolean allocateRequirement(String reqName) {
		return RequirementPage.getInstance().allocateRequirement(reqName);
	}

	@Override
	public boolean mapTestcaseToRequirement(String reqName,
			List<String> navigateToTCCTreeNodes, String testcaseName) {
		return RequirementPage.getInstance().mapTestcaseToRequirement(reqName, navigateToTCCTreeNodes, testcaseName);
	}

	@Override
	public boolean modifyRequirement(String reqName, Map<String, String> values, String nodeName) {
		return RequirementPage.getInstance().modifyRequirement(reqName, values, nodeName);
	}

	@Override
	public boolean switchRequirementSearchFolderView(String view) {
		return RequirementPage.getInstance().switchRequirementSearchFolderView(view);
	}

	@Override
	public boolean searchRequirements(String type, String query,
			List<String> reqNames) {
		return RequirementPage.getInstance().searchRequirements(type, query, reqNames);
	}

	@Override
	public boolean updateRequirementCustomFieldValue(String reqName,
			Map<String, String> typeNameAndValue) {
		return RequirementPage.getInstance().updateRequirementCustomFieldValue(reqName, typeNameAndValue);
	}

	@Override
	public boolean checkOrUncheckRequirementFieldsInGrid(List<String> fieldNames, boolean check) {
		return RequirementPage.getInstance().checkOrUncheckRequirementFieldsInGrid(fieldNames, check);
	}

	@Override
	public boolean changePassword(String newPassword, String oldPassword) {
		return HomePage.getInstance().changePassword(newPassword, oldPassword);
	}

	@Override
	public boolean setUserAuthenticationToLdap(String ldapHost, String baseDN,
			String bindDN, String bindPassword, String searchAttribute,
			String userName, String password) {
		return UserAuthentication.getInstance().setUserAuthenticationToLdap(ldapHost, baseDN, bindDN, bindPassword, 
				searchAttribute, userName, password);
	}

	@Override
	public boolean setUserAuthenticationToCrowd(String serverURL,
			String applicationName, String applicationPassword,
			String userName, String password) {
		return UserAuthentication.getInstance().setUserAuthenticationToCrowd(serverURL, applicationName, 
				applicationPassword, userName, password);
	}

	@Override
	public boolean setUserAuthenticationToWebService(String webServiceURL,
			String userName, String password) {
		return UserAuthentication.getInstance().setUserAuthenticationToWebService(webServiceURL, userName, password);
	}

	@Override
	public boolean enableDisableSecondaryAuthentication() {
		return CustomizationPage.getInstance().enableDisableSecondaryAuthentication();
	}

	@Override
	public boolean doFullReindex() {
		return CustomizationPage.getInstance().doFullReindex();
	}

	@Override
	public boolean runETLJobForTrendForToday(boolean testcase,
			boolean execution) {
		return CustomizationPage.getInstance().runETLJobForTrendForToday(testcase, execution);
	}

	@Override
	public boolean createNewDefectFromDefectTrackingApp(
			Map<String, String> values) {
		return DefectTrackingPage.getInstance().createNewDefectFromDefectTrackingApp(values);
	}
	
	@Override
	public boolean createNewDefectwithCustomfield(Map<String, String> values) {
		return DefectTrackingPage.getInstance().createNewDefectwithCustomfield(values);
	}
	
	@Override
	public boolean setJiraUser(String username, String password){
		return DefectTrackingConfigurationPage.getInstance().setJiraUser(username, password);
	}

	@Override
	public boolean verifySearchedDefect(Map<String, String> valuesToVerify) {
		return DefectTrackingPage.getInstance().verifySearchedDefect(valuesToVerify);
	}

	@Override
	public boolean searchByIdOrJqlOrFilter(String searchType,
			String searchValue, boolean launchAdvanced, Map<String, String> valuesToVerify) {
		return DefectTrackingPage.getInstance().searchByIdOrJqlOrFilter(searchType, searchValue, launchAdvanced, valuesToVerify);
	}

	@Override
	public boolean navigateToTestcaseLinkedWithDefectFromDefectTrackingApp(
			String defectSummay, String linkedTestcaseName) {
		if(DefectTrackingPage.getInstance().navigateToTestcaseLinkedWithDefectFromDefectTrackingApp(defectSummay, linkedTestcaseName)){
			return TestExecutionPage.getInstance().verifyTestExecutionDetailsInSearch(linkedTestcaseName, null);
		}
		return false;
		
	}

	@Override
	public boolean navigateToManageDashboardPage() {
		return DashboardPage.getInstance().navigateToManageDashboardPage();
	}

	@Override
	public boolean deleteDashbaord(String dashboardName) {
		return DashboardPage.getInstance().deleteDashbaord(dashboardName);
	}

	@Override
	public boolean exportSelectedNodeOfTCC(String nodeName, String reportType,
			String outputAs) {
		return TestRepositoryPage.getInstance().exportSelectedNodeOfTCC(nodeName, reportType, outputAs);
	}

	@Override
	public boolean exportGridTestcaseOfTCC(String reportType, String outputAs) {
		return TestRepositoryPage.getInstance().exportGridTestcaseOfTCC(reportType, outputAs);
	}
	@Override
	public boolean moveNode(String moveNodeName, String oldParentNodeName, String newParentNodeName, List<String> nodeList) {
		return TestRepositoryPage.getInstance().moveNode(moveNodeName, oldParentNodeName, newParentNodeName, nodeList);
	}
	@Override
	public boolean copyNode(String copyNodeName, String oldParentNodeName, String newParentNodeName, List<String> nodeList) {
		return TestRepositoryPage.getInstance().copyNode(copyNodeName, oldParentNodeName, newParentNodeName, nodeList);
	}

	@Override
	public boolean exportCycle(String cycleName, String reportType, String outputAs) {
		return TestPlanningPage.getInstance().exportCycle(cycleName, reportType, outputAs);
	}

	@Override
	public boolean exportSelectedNodeOfTCE(String nodeName, String reportType, String outputAs) {
		return TestExecutionPage.getInstance().exportSelectedNodeOfTCE(nodeName, reportType, outputAs);
	}

	@Override
	public boolean exportGridTestcaseOfTCE(String reportType, String outputAs) {
		return TestExecutionPage.getInstance().exportGridTestcaseOfTCE(reportType, outputAs);
	}

	@Override
	public boolean exportSearchedDefectResults() {
		return DefectTrackingPage.getInstance().exportSearchedDefectResults();
	}

	@Override
	public boolean exportAllSearchedExecutionInTCE(String reportType, String outputAs) {
		return TestExecutionPage.getInstance().exportAllSearchedExecutionInTCE(reportType, outputAs);
	}

	@Override
	public boolean exportSelectedRequirementTreeNode(String treeNodeName, String reportType, String outputAs) {
		return RequirementPage.getInstance().exportSelectedRequirementTreeNode(treeNodeName, reportType, outputAs);
	}

	@Override
	public boolean exportAllRequirementFromGridOfSelectedTreeNode(String reportType, String outputAs) {
		return RequirementPage.getInstance().exportAllRequirementFromGridOfSelectedTreeNode(reportType, outputAs);
	}
	
	@Override
	public boolean importJiraRequirements(String jql, List<String> issueSummay, String renameNode) {
		return RequirementPage.getInstance().importJiraRequirements(jql, issueSummay, renameNode);
	}

	@Override
	public boolean moveImportedNode(String importedNodeContent, String nodeName) {
		return RequirementPage.getInstance().moveImportedNode(importedNodeContent, nodeName);
	}

	@Override
	public boolean copyImportedNode(String importedNodeContent, String nodeName) {
		return RequirementPage.getInstance().copyImportedNode(importedNodeContent, nodeName);
	}

	@Override
	public boolean DeleteRelease(String ReleaseName) {
		
		return ReleaseSetupPage.getInstance().DeleteRelease(ReleaseName);
	}
	public boolean CloneRelease(String ReleaseName) {
		
		return ReleaseSetupPage.getInstance().CloneRelease(ReleaseName);
	}
	
	public boolean CloneRelease(String Projectname, String ReleaseName, String User) {
		return ReleaseSetupPage.getInstance().CloneRelease(Projectname, ReleaseName, User);
	}

	public boolean renameRelease(String ReleaseName, String newReleaseName, String releaseDescription, String releaseEndDate){
		return ReleaseSetupPage.getInstance().renameRelease(ReleaseName, newReleaseName, releaseDescription,releaseEndDate);
	
	}

	@Override
	public void verifyReleaseSummaryPage(String expectedReleaseName, String expecteRrequirementCount,
		String expectetestcaseCount, String expectedexecutionProgress, String expectedtotalLinkedDefects) {
		ReleaseSummaryPage.getInstance().verifyReleaseSummaryPage(expectedReleaseName, expecteRrequirementCount, expectetestcaseCount, expectedexecutionProgress, expectedtotalLinkedDefects);
	}

	@Override
	public Map<String, String> getReleaseSummaryCountDetails(String releaseName) {
		return ReleaseSummaryPage.getInstance().getReleaseSummaryCountDetails(releaseName);
	}

	@Override
	public boolean pasteCopiedImportedNode(String parentNodeName) {
		return RequirementPage.getInstance().pasteCopiedImportedNode(parentNodeName);
	}	

	@Override
	public boolean exportEntireTraceabilityOfSelectedRequirementTreeNode(String treeNodeName, String reportType,
			String outputAs) {
		return RequirementPage.getInstance().exportEntireTraceabilityOfSelectedRequirementTreeNode(treeNodeName, reportType, outputAs);
	}

	@Override
	public boolean exportEntireTraceablilityOfAllRequirementFromGridOfSelectedTreeNode(String reportType,
			String outputAs) {
		return RequirementPage.getInstance().exportEntireTraceablilityOfAllRequirementFromGridOfSelectedTreeNode(reportType, outputAs);
	}

	@Override
	public boolean exportAllRequirementSearchedResults(String reportType, String outputAs) {
		return RequirementPage.getInstance().exportAllRequirementSearchedResults(reportType, outputAs);
	}

	@Override
	public boolean exportAllSearchedTestcaseInTCC(String reportType, String outputAs, boolean navigateBackToFolder) {
		return TestRepositoryPage.getInstance().exportAllSearchedTestcaseInTCC(reportType, outputAs, navigateBackToFolder);
	}

	@Override
	public boolean exportNodeFromTestPlanningAssignmentWindow(String nodeName, String reportType, String outputAs, boolean navigateBackToCycle) {
		return TestPlanningPage.getInstance().exportNodeFromTestPlanningAssignmentWindow(nodeName, reportType, outputAs, navigateBackToCycle);
	}

	@Override
	public boolean copyImportedNodeByDragNDrop(String nodeName) {
		return RequirementPage.getInstance().copyImportedNodeByDragNDrop(nodeName);
	}

	@Override
	public boolean setDefectAdminProperties(String category, String name, String value) {
		return DefectAdminPage.getInstance().setDefectAdminProperties(category, name, value);
	}

	@Override
	public boolean setPaginationPageSizeInTestRepository(String size) {
		return TestRepositoryPage.getInstance().setPaginationPageSizeInTestRepository(size);
	}

	@Override
	public boolean verifyTestcasesInSelectedNodeOfTestRepository(List<String> testcasesNames) {
		return TestRepositoryPage.getInstance().verifyTestcasesInSelectedNodeOfTestRepository(testcasesNames);
	}

	@Override
	public boolean navigateToNextOrPrevPageInTestRepositoryGrid(String nextOrPrev) {
		return TestRepositoryPage.getInstance().navigateToNextOrPrevPageInTestRepositoryGrid(nextOrPrev);
	}

	@Override
	public boolean setPaginationPageSizeInRequirement(String size) {
		return RequirementPage.getInstance().setPaginationPageSizeInRequirement(size);
	}

	@Override
	public boolean verifyRequirementInSelectedNodeOfRequirementApp(List<String> requirementNames) {
		return RequirementPage.getInstance().verifyRequirementInSelectedNodeOfRequirementApp(requirementNames);
	}

	@Override
	public boolean navigateToNextOrPrevPageInRequirementGrid(String nextOrPrev) {
		return RequirementPage.getInstance().navigateToNextOrPrevPageInRequirementGrid(nextOrPrev);
	}
		
	@Override
	public boolean mapRequirementToTestcase(String testcaseName, List<String> navigateToReqTreeNodes, String requirementName) {
		return TestRepositoryPage.getInstance().mapRequirementToTestcase(testcaseName, navigateToReqTreeNodes, requirementName);
	}

	@Override
	public boolean changeTestcaseFromManualToAutomated(String tcName, String scriptName, String id, String path) {
		return TestRepositoryPage.getInstance().changeTestcaseFromManualToAutomated(tcName, scriptName, id, path);
	}

	@Override
	public boolean performSearchInEASAddTestcaseToFreeformWindow(String searchType, String searchQuery,
			String setPageSize, int expectedNoOfPages, Map<Integer, List<String>> pageAndexpectedTestcases) {
		return TestPlanningPage.getInstance().performSearchInEASAddTestcaseToFreeformWindow(searchType
				, searchQuery, setPageSize, expectedNoOfPages, pageAndexpectedTestcases);
	}

	@Override
	public boolean setPageSizeInTCEGrid(String size) {
		return TestExecutionPage.getInstance().setPageSizeInTCEGrid(size);
	}

	@Override
	public boolean navigateToNextOrPrevPageInTCEGrid(String nextOrPrev) {
		return TestExecutionPage.getInstance().navigateToNextOrPrevPageInTCEGrid(nextOrPrev);
	}

	@Override
	public void doProjectLevelReindex(String projectName) {
		CustomizationPage.getInstance().doProjectLevelReindex(projectName);
	}

	public boolean addCustomField(String customFieldName, String customFieldType, String customFieldDescription,
			boolean searchable, boolean mandatory, String projectName, boolean unique, boolean all) {
		return CustomizationPage.getInstance().addCustomField(customFieldName, customFieldType, customFieldDescription, searchable, mandatory, projectName, unique, all);
	}

	@Override
	public boolean attemptToUpdateRequirementUniqueCustomFieldWithDuplicateValue(String reqName,
			Map<String, String> typeNameAndValue) {
		return RequirementPage.getInstance().updateRequirementUniqueCustomFieldWithDuplicateValue(reqName, typeNameAndValue);
	}

	@Override
	public String getRequirementCustomFieldValue(String ReqId, Map<String, String> typeNameAndValue) {
		return RequirementPage.getInstance().getRequirementCustomFieldValue(ReqId, typeNameAndValue);
	}

	@Override
	public boolean uncheckUniqueReqCustomField(String customFieldName) {
		return CustomizationPage.getInstance().uncheckUniqueReqCustomField(customFieldName);
	}
	

	/*@Override
	public String createAutomationJob(String automationTool, String scriptPath, String resultPath,
			boolean packageStructure, String zbot, String startDate, String endDate) {
		return ZAutomationPage.getInstance().createAutomationJob(automationTool, scriptPath, resultPath
				, packageStructure, zbot, startDate, endDate);
	}
	*/

	@Override
	public String createAutomationJob(String automationTool, String scriptPath, String resultPath
			, boolean packageStructure, String zbot, String startDate, String endDate, String jobName, String cycleName,String phaseName)
			{
		return ZAutomationPage.getInstance().createAutomationJob(automationTool, scriptPath, resultPath, 
				packageStructure, zbot, startDate, endDate,jobName,cycleName, phaseName);
	}


	@Override
	public boolean verifyAutomationJobCreated(String jobId, String automationTool, String scriptPath, String resultPath,
			String status, String zbot, String startDate, String endDate) {
		return ZAutomationPage.getInstance().verifyAutomationJobCreated(jobId, automationTool
				, scriptPath, resultPath, status, zbot, startDate, endDate);
	}

	@Override
	public boolean executeAutomationJob(String jobId, String cycleName, String phaseName, boolean setPostFixTimeStamp, String user, String expectedNotificationCount) {
		return ZAutomationPage.getInstance().executeAutomationJob(jobId, cycleName, phaseName, setPostFixTimeStamp, user, expectedNotificationCount);
	}

	@Override
	public boolean addTestcaseToFreeformNodeBrowse(String freeFormName, String phaseName, String nodeName
			,String subNodeName,boolean bringHierarchy){
		return TestPlanningPage.getInstance().addTestcaseToFreeformNodeBrowse(freeFormName, phaseName, nodeName, subNodeName, bringHierarchy);
	}

	@Override
	public boolean attemptToAddDuplicateValueToTestcaseHavingUniqueCustomField(String customfieldName,
			String customfieldValue, String customfieldType) {
		return TestRepositoryPage.getInstance().attemptToAddDuplicateValueToTestcaseHavingUniqueCustomField(customfieldName, customfieldValue, customfieldType);
	}

	@Override
	public String getTestcaseCustomFieldValue(String customfieldName, String customfieldType, String TcId) {
		return TestRepositoryPage.getInstance().getTestcaseCustomFieldValue(customfieldName, customfieldType, TcId);
	}

	@Override
	public boolean uncheckUniqueTestcaseCustomField(String customFieldName) {
		return CustomizationPage.getInstance().uncheckUniqueTestcaseCustomField(customFieldName);
	}

	@Override
	public boolean verifyCycleAndPhaseDetailsInTestPlanning(String cycleName, String cycleStartDateExpected,
			String cycleEndDateExpected, String phaseName, String phaseStartDateExpected, String phaseEndDateExpected) {
		return TestPlanningPage.getInstance().verifyCycleAndPhaseDetailsInTestPlanning(cycleName,
				cycleStartDateExpected, cycleEndDateExpected, phaseName, phaseStartDateExpected,
				phaseEndDateExpected);
	}

	public boolean applyNotification(String expectedNotificationCount) {
		return HomePage.getInstance().applyNotification(expectedNotificationCount);
	}

	@Override
	public boolean verifyPhase(String phaseName, String phaseDescription) {
		return TestRepositoryPage.getInstance().verifyPhase(phaseName, phaseDescription);
	}

	@Override
	public boolean verifyNode(String parentNodename, String nodeName, String nodeDescription) {
		return TestRepositoryPage.getInstance().verifyNode(parentNodename, nodeName, nodeDescription);
	}

	@Override
	public String verifyDefaultTestcase(int testcaseNum) {
		return TestRepositoryPage.getInstance().verifyDefaultTestcase(testcaseNum);
	}

	@Override
	public boolean createNodeinReqGlobal(String parentNodeName, String nodeName, String nodeDescription) {
		return RequirementPage.getInstance().createNodeinReqGlobal(parentNodeName, nodeName, nodeDescription);
	}

	@Override
	public boolean verifyNodeinReqGlobal(String parentNodename, String nodeName, String nodeDescription) {
		return RequirementPage.getInstance().verifyNodeinReqGlobal(parentNodename, nodeName, nodeDescription);
	}

	@Override
	public boolean verifyMapTestcaseToRequirement(String reqName, String mapCount) {
		return RequirementPage.getInstance().verifyMapTestcaseToRequirement(reqName, mapCount);
	}

	@Override
	public boolean verifyTestcaseExecutionStatus(String testcaseName, String status) {
		return TestExecutionPage.getInstance().verifyTestcaseExecutionStatus(testcaseName, status);
	}

	@Override
	public boolean SelectTestcase(String tcName) {
		return TestRepositoryPage.getInstance().SelectTestcase(tcName);
	}

	@Override
	public boolean verifyTeststepExecutionStatus(String testcaseName, String stepId, String status,
			boolean expandStepsSection, boolean expectedExecuteTestcasePopup, String executeTestcaseStatus) {
		return TestExecutionPage.getInstance().verifyTeststepExecutionStatus(testcaseName, stepId, status, expandStepsSection, expectedExecuteTestcasePopup, executeTestcaseStatus);
	}
	
	@Override
	public boolean addTestcaseMap(String mapName, String rowNumber, String selectDiscriminator, String mapDescription,
			String testcaseNameColumn, String testStepColumn, String expectedResultColumn, String externalIdColumn,
			String testDataColumn, List<String> otherFieldsMappingIfAny) {
		return TestRepositoryPage.getInstance().addTestcaseMap(mapName, rowNumber, selectDiscriminator
				, mapDescription, testcaseNameColumn, testStepColumn, expectedResultColumn, externalIdColumn
				, testDataColumn, otherFieldsMappingIfAny);
	}
	
	@Override
	public boolean importTestcase(String jobName, String mapName, String importFileNameWithPath) {
		return TestRepositoryPage.getInstance().importTestcase(jobName, mapName, importFileNameWithPath);
	}
	
	@Override
	public boolean navigateToTCCNodeUnderImportedNode(String nodeNameContains) {
		return TestRepositoryPage.getInstance().navigateToTCCNodeUnderImportedNode(nodeNameContains);
	}
	
	@Override
	public boolean renameSelectedTCCImportedNodeAndDragToRelease(String nodeNameContains, String renameImportedNode,
			String releaseNodeNameToDrop, boolean dragWithControl) {
		return TestRepositoryPage.getInstance().renameSelectedTCCImportedNodeAndDragToRelease(
				nodeNameContains, renameImportedNode, releaseNodeNameToDrop, dragWithControl);
	}
	
	@Override
	public boolean addRequirementMap(String mapName, String rowNumber, String selectDiscriminator,
			String mapDescription, String requirementNameColumn, List<String> otherFieldsMappingIfAny) {
		return RequirementPage.getInstance().addRequirementMap(mapName, rowNumber, selectDiscriminator
				, mapDescription, requirementNameColumn, otherFieldsMappingIfAny);
	}
	@Override
	public boolean importRequirement(String jobName, String mapName, String importFileNameWithPath) {
		return RequirementPage.getInstance().importRequirement(jobName, mapName, importFileNameWithPath);
	}

	@Override
	public boolean navigateToRequirementNodeUnderImportedNode(String nodeNameContains) {
		return RequirementPage.getInstance().navigateToRequirementNodeUnderImportedNode(nodeNameContains);
	}

	@Override
	public boolean verifyForceLogoutPopupAndClickOk() {
		return HomePage.getInstance().verifyForceLogoutPopupAndClickOk();
	}

	@Override
	public boolean launchGlobalTCCWindow(String releaseName) {
		return TestRepositoryPage.getInstance().launchGlobalTCCWindow(releaseName);
	}

	@Override
	public boolean navigateToNodeInGlobalTCC(List<String> nodeList) {
		return TestRepositoryPage.getInstance().navigateToNodeInGlobalTCC(nodeList);
	}

	@Override
	public boolean DnDGlobalTestcaseToLocalRelease(String localReleaseNodeName, String globalSelectedNodeNameOrNull,
			List<String> elseTestcaseNamesToDraged) {
		return TestRepositoryPage.getInstance().DnDGlobalTestcaseToLocalRelease(localReleaseNodeName, globalSelectedNodeNameOrNull, elseTestcaseNamesToDraged);
	}

	@Override
	public boolean navigateToLocalReleaseNodeInGlobalTCC(List<String> nodeList) {
		return TestRepositoryPage.getInstance().navigateToLocalReleaseNodeInGlobalTCC(nodeList);
	}

	@Override
	public boolean checkOrUncheckTestcaseFieldsInGridAndVerify(List<String> fieldNames, boolean check) {
		return TestRepositoryPage.getInstance().checkOrUncheckTestcaseFieldsInGridAndVerify(fieldNames, check);
	}

	@Override
	public boolean resetTestcaseGridToDefaultAndVerifyAbsenceOfCustomizedFields(List<String> fieldNamesNotToBePresent) {
		return TestRepositoryPage.getInstance().resetTestcaseGridToDefaultAndVerifyAbsenceOfCustomizedFields(fieldNamesNotToBePresent);
	}

	@Override
	public boolean resetRequirementGridToDefaultAndVerifyAbsenceOfCustomizedFields(
			List<String> fieldNamesNotToBePresent) {
		return RequirementPage.getInstance().resetRequirementGridToDefaultAndVerifyAbsenceOfCustomizedFields(fieldNamesNotToBePresent);
	}
	
	@Override
	public boolean attemptToaddNewProjectWithDuplicateName(String projectName, String projectType,
			String projectDescription, String startDate, String endDate, String leadName, String jiraProjectName) {
		return ManageProjects.getInstance().attemptToaddNewProjectWithDuplicateName(projectName, projectType, projectDescription, startDate, endDate, leadName, jiraProjectName);
	}

	@Override
	public boolean performNodeSync(String parentNodeName) {
		return RequirementPage.getInstance().performNodeSync(parentNodeName);
	}

	@Override
	public boolean attemptToAddDuplicateProject(String projectName, String projectType, String projectDescription,
			String startDate, String endDate, String leadName, String jiraProjectName) {
		return ManageProjects.getInstance().attemptToAddDuplicateProject(projectName, projectType, projectDescription, startDate, endDate, leadName, jiraProjectName);
	}

	@Override
	public boolean closeCustomfield() {
		return CustomizationPage.getInstance().closeCustomfield();
	}

	@Override
	public boolean verifyTestcaseVersion(int testcaseId, String versionNo) {
		return TestRepositoryPage.getInstance().verifyTestcaseVersion(testcaseId, versionNo);
	}

	@Override
	public boolean verifyTestcaseVersion(String testcaseName, String versionNo) {
		return TestRepositoryPage.getInstance().verifyTestcaseVersion(testcaseName, versionNo);
	}

	@Override
	public boolean clickOnTestcase(String tctId) {
		return TestRepositoryPage.getInstance().clickOnTestcase(tctId);
	}

	@Override
	public boolean navigateBackToTestcaseList() {
		return TestRepositoryPage.getInstance().navigateBackToTestcaseList();
	}

	@Override
	public boolean navigateBackToReqList() {
		return RequirementPage.getInstance().navigateBackToReqList();
	}

	@Override
	public boolean navigateBackToCycles() {
		return TestPlanningPage.getInstance().navigateBackToCycles();
	}
	
	@Override
	public boolean setMultiJira() {
		//HomePage.getInstance().launchAdministration();
		HomePage.getInstance().launchAdminApps("DefectTracking");
		//HomePage.getInstance().launchAdminApps("DefectTracking");
		return DefectTrackingConfigurationPage.getInstance().setMultiJira();
	}

	@Override
	public boolean deleteTestcase(String nodeName, int testcaseId) {
		return TestRepositoryPage.getInstance().deleteTestcase(nodeName, testcaseId);
	}

	@Override
	public boolean verifyTraceability(Map<String, Map<String, Map<String, String>>> reqTraceability) {
		return RequirementPage.getInstance().verifyTraceability(reqTraceability);
	}

	@Override
	public boolean exportSelectedRequirementTraceabilityInFolderView(List<String> reqName) {
		return RequirementPage.getInstance().exportSelectedRequirementTraceabilityInFolderView(reqName);
	}

	@Override
	public boolean exportAllSearchedRequirementTraceability() {
		return RequirementPage.getInstance().exportAllSearchedRequirementTraceability();
	}

	@Override
	public boolean verifyTestExecutionDetailInGrid(String testcaseName, String version) {
		return TestExecutionPage.getInstance().verifyTestExecutionDetailInGrid(testcaseName, version);
	}

	@Override
	public boolean clickonTestcaseCoverageLink(String reqName1) {
		return RequirementPage.getInstance().clickonTestcaseCoverageLink(reqName1);
	}

	@Override
	public boolean clickonReqCoverageLink(String TcName) {
		return TestRepositoryPage.getInstance().clickonReqCoverageLink(TcName);
	}

	@Override
	public boolean verifyTestcasesInGridOfSelectedPageInAddTestcaseToFreeformScreen(List<String> testcasesNames) {
		return TestPlanningPage.getInstance().verifyTestcasesInGridOfSelectedPageInAddTestcaseToFreeformScreen(testcasesNames);
	}

	@Override
	public boolean unhideCycle() {
		return TestPlanningPage.getInstance().unhideCycle();
	}

	@Override
	public boolean sort(boolean TestcaseID) {
		return TestPlanningPage.getInstance().sort(TestcaseID);
	}

	
	// Project Repository 
	
	@Override
	public boolean createProjectRepoPhase(String releaseName, String phaseName, String phaseDescription) {
		return  TestRepositoryPage.getInstance().createProjectRepoPhase(releaseName, phaseName, phaseDescription);
	}

	@Override
	public boolean createProjectRepoNode(List<String> parentTee, String parentNodeName, String nodeName,
			String nodeDescription) {
		return TestRepositoryPage.getInstance().createProjectRepoNode(parentTee, parentNodeName, nodeName, nodeDescription);
	}

	@Override
	public String verifyDefaultTestcaseProjectRepo(int testcaseNum) {
		return TestRepositoryPage.getInstance().verifyDefaultTestcaseProjectRepo(testcaseNum);
	}

	@Override
	public String addDefaultTestcaseProjectRepo(String nodeName) {
		return TestRepositoryPage.getInstance().addDefaultTestcaseProjectRepo(nodeName);
	}

	@Override
	public boolean modifyTestcaseProjectRepo(Map<String, String> values) {
		return TestRepositoryPage.getInstance().modifyTestcaseProjectRepo(values);
	}

	@Override
	public boolean verifyTestcaseVersionProjectRepo(String testcaseName, String versionNo) {
		return TestRepositoryPage.getInstance().verifyTestcaseVersionProjectRepo(testcaseName, versionNo);
	}

	@Override
	public boolean cloneTestcaseProjectRepo(String nodeName, String testcaseName, String stepstatus) {
		return TestRepositoryPage.getInstance().cloneTestcaseProjectRepo(nodeName, testcaseName, stepstatus);
	}

	@Override
	public String getTestcaseProjectRepo(String nodeName) {
		return TestRepositoryPage.getInstance().getTestcaseProjectRepo(nodeName);
	}

	@Override
	public String getTestcaseProjectRepo(String nodeName, String testcaseName) {
		return TestRepositoryPage.getInstance().getTestcaseProjectRepo(nodeName, testcaseName);
	}

	@Override
	public boolean deleteTestcaseProjectRepo(String nodeName, int testcaseId) {
		return TestRepositoryPage.getInstance().deleteTestcaseProjectRepo(nodeName, testcaseId);
	}

	@Override
	public boolean deleteTestcaseProjectRepo(String nodeName, List<String> testcaseId) {
		return TestRepositoryPage.getInstance().deleteTestcaseProjectRepo(nodeName, testcaseId);
	}

	@Override
	public boolean deleteNodeProjectRepo(String deleteNodeName) {
		return TestRepositoryPage.getInstance().deleteNodeProjectRepo(deleteNodeName);
	}

	@Override
	public boolean exportSelectedNodeOfTCCProjectRepo(String nodeName, String reportType, String outputAs) {
		return TestRepositoryPage.getInstance().exportSelectedNodeOfTCCProjectRepo(nodeName, reportType, outputAs);
	}

	@Override
	public boolean verifyTestcasesInSelectedNodeOfTestRepositoryProjectRepo(List<String> testcasesNames) {
		return TestRepositoryPage.getInstance().verifyTestcasesInSelectedNodeOfTestRepositoryProjectRepo(testcasesNames);
	}

	@Override
	public boolean dndsharenodeToRelease(String sourceNodeSelection, String destinationNode, boolean dragWithControl) {
		return TestRepositoryPage.getInstance().dndsharenodeToRelease(sourceNodeSelection, destinationNode, dragWithControl);
	}

	@Override
	public boolean navigateToNodesProjectRepo(List<String> nodeList) {
		return TestRepositoryPage.getInstance().navigateToNodesProjectRepo(nodeList);
	}

	@Override
	public boolean dndsharenodeToProjectRepo(String sourceNodeSelection, String destinationNode,
			boolean dragWithControl) {
		return TestRepositoryPage.getInstance().dndsharenodeToProjectRepo(sourceNodeSelection, destinationNode, dragWithControl);
	}

	@Override
	public boolean launchShareTCCWindowProjectRepo(String releaseName) {
		return TestRepositoryPage.getInstance().launchShareTCCWindowProjectRepo(releaseName);
	}

	@Override
	public boolean launchGlobalRepository() {
		return HomePage.getInstance().launchGlobalRepository();
	}

	@Override
	public void verifyAppTopHeader(boolean globalRepos, boolean dashboard, boolean Administration) {
		HomePage.getInstance().verifyAppTopHeader(globalRepos, dashboard, Administration);
		
	}

	@Override
	public boolean editRole(String roleName, String roleDescription, boolean systemSetup, boolean userSetup,
			boolean projectSetup, boolean defectsAdmin, boolean releaseSetup, boolean requirements,
			boolean testPlanning, boolean testRepository, boolean testExecution, boolean defectTracking,
			boolean closeWindowAfterCreation, boolean globalTestRepository, boolean globalRepoConfig) {
		
		return CustomizationPage.getInstance().editRole(roleName, roleDescription, systemSetup, userSetup,
				projectSetup, defectsAdmin, releaseSetup, requirements, testPlanning, testRepository, 
				testExecution, defectTracking, closeWindowAfterCreation, globalTestRepository, globalRepoConfig);
	}

	@Override
	public boolean launchGlobalApps(String appNameToBeLaunched) {
		
		return HomePage.getInstance().launchGlobalApps(appNameToBeLaunched);
	}

	@Override
	public boolean globalRepoProjectAssignment(List<String> projectNames) {
		return CustomizationPage.getInstance().globalRepoProjectAssignment(projectNames);
	}


	
	@Override
	public boolean VerifyToReleaseOptionsNotpresent(String optionsName, String nodeName) {
		
		return TestRepositoryPage.getInstance().VerifyToReleaseOptionsNotpresent(optionsName, nodeName);
	}

	@Override
	public boolean verifyclonetestcasecoverage(String testcaseId, String coverage) {
		return TestRepositoryPage.getInstance().verifyclonetestcasecoverage(testcaseId, coverage);
	}

	@Override
	public boolean customizwGadgetRefreshRate(String refreshRate) {
		
		return DashboardPage.getInstance().customizwGadgetRefreshRate(refreshRate);
	}

	@Override
	public boolean createGadgetwithCustomizeRefreshRate(String projectName, String releaseName, String refreshRate) {
		return DashboardPage.getInstance().createGadgetwithCustomizeRefreshRate(projectName, releaseName, refreshRate);
	}

	@Override
	public boolean bulkexecuteSteps(String testcaseName, String status, boolean expandStepsSection) {
		
		
		return TestExecutionPage.getInstance().bulkexecuteSteps(testcaseName, status, expandStepsSection);
	}

	@Override
	public boolean bulkexecuteStepsUsingHotKey(String testcaseName, boolean expandStepsSection) {
		return TestExecutionPage.getInstance().bulkexecuteStepsUsingHotKey(testcaseName, expandStepsSection);
	}

	@Override
	public boolean autoUpadteExecution(String projectName) {
		return ManageProjects.getInstance().autoUpadteExecution(projectName);
	}

	@Override
	public boolean autoUpadteStatusbulkexecuteSteps(String testcaseName, String status, boolean expandStepsSection) {
		return TestExecutionPage.getInstance().autoUpadteStatusbulkexecuteSteps(testcaseName, status, expandStepsSection);
	}

	@Override
	public boolean cloneRequirement(String reqName) {
		return RequirementPage.getInstance().cloneRequirement(reqName);
	}

	@Override
	public boolean dupicateRequiremnetNode(String releaseName, String phaseName, String phaseDescription) {
		return RequirementPage.getInstance().dupicateRequiremnetNode(releaseName, phaseName, phaseDescription);
	}

	@Override
	public boolean copyPasteSteps(Map<String, String> values) {
		return TestRepositoryPage.getInstance().copyPasteSteps(values);
	}

	@Override
	public boolean testcaseReorder(String testcaseName) {
		return TestRepositoryPage.getInstance().testcaseReorder(testcaseName);
	}

	@Override
	public String getDefectIDLinkDefect(String testcaseName) {
		return TestExecutionPage.getInstance().getDefectIDLinkDefect(testcaseName);
	}

	@Override
	public String getStatusInExecution(String testcaseName) {
		return TestExecutionPage.getInstance().getStatusInExecution(testcaseName);
	}

	@Override
	public boolean checkUsageHistory(Map<String, String> values) {
		return TestRepositoryPage.getInstance().checkUsageHistory(values);
	}



}
