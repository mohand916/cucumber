package com.thed.zeuihtml.ze.impl.zehtmlpages;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.yaml.snakeyaml.constructor.SafeConstructor.ConstructYamlOmap;

import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;

public class ManageProjects {

	Logger logger;
	
	public ManageProjects(){
		logger = Logger.getLogger(this.getClass());
	}
	
	public static ManageProjects getInstance(){
		return PageFactory.initElements(Driver.driver, ManageProjects.class);
	}
	
	/******************************************************
	 * 	WEBELEMENTS
	 *****************************************************/
	@FindBy(xpath="//b[text()='Project Setup']")
	private WebElement headerProjectSetup;
	
	@FindBy(xpath="//h4[text()='Advanced Project Configuration']")
	private WebElement headerAdvancedProjectConfiguration;
	
	@FindBy(xpath="//button[@title='Add project']")
	private WebElement buttonAddProject;
	
	@FindBy(xpath="//input[@id='project-name']")
	private WebElement textBoxProjectName;
	
	@FindBy(xpath="//input[@id='project-description']")
	private WebElement textBoxProjectDescription;
	
	@FindBy(xpath="//div[@id='project-startdate']/calendar/div/input")
	private WebElement inputProjectStartDate;
	
	@FindBy(xpath="//div[@id='project-enddate']/calendar/div/input")
	private WebElement inputProjectEndDate;
	
	@FindBy(xpath="//b[text()='Lead :']/parent::label/following-sibling::div//select")
	private WebElement selectLead;
	
	@FindBy(xpath="//b[text()='Map external Defect project :']/parent::label/following-sibling::div//select")
	private WebElement selectExternalJiraProject;
	
	@FindBy(xpath="//b[text()='Connected JIRA :']/parent::label/following-sibling::div//select")
	private WebElement selectExternalJira;
	
	@FindBy(xpath="//b[normalize-space(text())='Type :']/parent::label/following-sibling::a")
	private WebElement linkProjectType;
	
	//span[text()='Restricted']/parent::label/preceding-sibling::input
	@FindBy(xpath="//span[text()='Restricted']/preceding-sibling::div")
	private WebElement radioButtonRestricted;
	
	//span[text()='Isolated']/parent::label/preceding-sibling::input
	@FindBy(xpath="//span[text()='Isolated']/preceding-sibling::div")
	private WebElement radioButtonIsolated;
	
	//span[text()='Normal']/parent::label/preceding-sibling::input
	@FindBy(xpath="//span[text()='Normal']/preceding-sibling::div")
	private WebElement radioButtonNormal;
	
	@FindBy(xpath="//h4[text()='Advanced Project Configuration']/parent::div/following-sibling::div/button[@class='close']")
	private WebElement buttonCloseAdvancedProjectConfiguration;
	
	@FindBy(xpath="//button[text()='Add']")
	private WebElement buttonAdd;
	
	@FindBy(xpath="//button[text()='Save']")
	private WebElement buttonSave;
	
	@FindBy(xpath="//div/p[text()='Users']/parent::div//span[@class='forward-image']")
	private WebElement addSelectedResource;
	
	@FindBy(xpath="//h4[text()='Add Project']")
	private WebElement headerAddProject;
	
	@FindBy(xpath="//h4[text()='Edit Project']")
	private WebElement headerEditProject;
	
	@FindBy (xpath="//div[@class='clearfix form-footer']//button[text()='Cancel']")
	private WebElement buttonCancel;
	
    @FindBy(xpath="//button[@value='HIDE_PROJECT_FORM']")
	private WebElement buttonContinue;
    
    @FindBy (xpath= "//*[@id='confirmation-modal-unsaved-data']//h4")
    private WebElement unsavedChnage;
    
    @FindBy(xpath="//*[@id='confirmation-modal-unsaved-data']//button[@value = 'CONTINUE_CLICK']")
    private WebElement unsavedContinoue;
    
    @FindBy(xpath=".//div[@id='jira-connection-switch-modal']//h4")
    private WebElement warningPOP;
    
    @FindBy(xpath=".//div[@id='jira-connection-switch-modal']//button[text()='Yes']")
    private WebElement popupJiraConnectionChange;
    
    @FindBy(xpath="//input[@id='sharecheckbox']")
    private WebElement shareCheckbox;
    
    @FindBy(xpath=".//*[@id='confirmation-modal-shared']//h4[text()='WARNING']")
    private WebElement shareWarningPopup;
    
    @FindBy(xpath=".//*[@id='confirmation-modal-shared']//button[text()='Yes']")
    private WebElement shareWarningPopupYes;
    
    @FindBy(xpath=".//*[@id='confirmation-modal-shared']//button[text()='No']")
    private WebElement shareWarningPopupNo;
    
	@FindBy(xpath="//div/p[text()='Projects']/parent::div//span[@class='forward-image']")
	private WebElement addSelectedProject;
	
	@FindBy(xpath="//b[contains(text(),'Auto update execution status based on test step status')]")
	private WebElement checkboxAutoUpdateExecution;
	
	
	
    
    
    
    
    
	
	/******************************************************
	 * 	Methods
	 *****************************************************/
	
	public boolean addNewProject(String projectName, String projectType, String projectDescription, String startDate, String endDate, 
			String leadName, String jiraProjectName){
			
		HomePage.getInstance().waitForProgressBarToComplete();
		if(CommonUtil.visibilityOfElementLocated(headerProjectSetup)){
			if(CommonUtil.visibilityOfElementLocated(buttonAddProject)){
				CommonUtil.normalWait(2000);
				CommonUtil.isElementClickable(buttonAddProject);
				buttonAddProject.click();
//				unsavedChanges();
				CommonUtil.normalWait(2000);
				CommonUtil.visibilityOfElementLocated(headerAddProject,5);
				if(CommonUtil.visibilityOfElementLocated(textBoxProjectName, 5)){
					logger.info("Going to type project Name");
					textBoxProjectName.sendKeys(projectName);
					logger.info("Typed project Name successfully");	
						try{
							if(projectDescription!=null){
								logger.info("Going to type project Description");
								CommonUtil.normalWait(1000);
								textBoxProjectDescription.sendKeys(projectDescription);
								CommonUtil.normalWait(1000);
								logger.info("Typed project Description successfully");
							}
							HomePage.getInstance().waitForProgressBarToComplete();
							logger.info("Going to Select project Start Date as : " + startDate);
							CommonUtil.normalWait(1000);
							inputProjectStartDate.sendKeys(startDate);
							logger.info("Project Start Date selected successfully as : " +startDate);
							CommonUtil.normalWait(1000);
							if(endDate!=null){
								logger.info("Going to Select project End Date as : " + endDate);
								CommonUtil.normalWait(1000);
								inputProjectEndDate.sendKeys(endDate);
								logger.info("Project End Date selected successfully as : " +endDate);
								CommonUtil.normalWait(1000);
							}
							if(leadName!=null){
								logger.info("Going to Select project Lead : " + leadName);
								CommonUtil.normalWait(1000);
								CommonUtil.selectListWithVisibleText(selectLead, leadName);
								CommonUtil.normalWait(1000);
								logger.info("Project Lead selected successfully as : " +leadName);
							}
							if(jiraProjectName!=null){
								logger.info("Going to Map Jira Project : " + jiraProjectName);
								CommonUtil.normalWait(1000);
								CommonUtil.selectListWithVisibleText(selectExternalJiraProject, jiraProjectName);
								CommonUtil.normalWait(1000);
								logger.info("Project Mapped  successfully to Jira project : " +jiraProjectName);
							}
							if(projectType!=null){
								if(!selectProjectType(projectType))
									return false;
							}
							HomePage.getInstance().waitForProgressBarToComplete();
							CommonUtil.normalWait(2000);
							CommonUtil.isElementClickable(buttonAdd);
							buttonAdd.click();
							HomePage.getInstance().closeToastPopup();
							HomePage.getInstance().waitForProgressBarToComplete();
							CommonUtil.normalWait(5000);
					/*		if(!CommonUtil.visibilityOfElementLocated(headerEditProject,3)){
								buttonAdd.click();
								HomePage.getInstance().waitForProgressBarToComplete();
								CommonUtil.normalWait(5000);
							}*/
							
							CommonUtil.normalWait(1000);
						}catch(Exception e){
							e.printStackTrace();
							return false;
						}	
						
				}else{
					logger.info("Text Box Project Name not found");
					return false;
				}
			}else{
				logger.info("Add New Project Button not found");
				return false;
			}
		}else{
			logger.info("Project Setup header not found");
			return false;
		}
		
		return true;
	}
	
	public boolean unsavedChanges()
	{
		if(CommonUtil.isElementPresent(unsavedChnage))
		{
			logger.info("Unsaved pop-up is there");
			CommonUtil.normalWait(2000);
			unsavedContinoue.click();
			return true;
			}
		else {
			logger.info("no unsaved pop-up found");
		}
		
		return true;
	}

	public boolean attemptToaddNewProjectWithDuplicateName(String projectName, String projectType, String projectDescription, String startDate, String endDate, 
			String leadName, String jiraProjectName) {
			
		HomePage.getInstance().waitForProgressBarToComplete();
		if(CommonUtil.visibilityOfElementLocated(headerProjectSetup,2)){
			if(CommonUtil.visibilityOfElementLocated(buttonAddProject,2)){
				CommonUtil.normalWait(1000);
				buttonAddProject.click();
				CommonUtil.normalWait(1000);
				CommonUtil.visibilityOfElementLocated(headerAddProject,2);
				if(CommonUtil.visibilityOfElementLocated(textBoxProjectName,2)){
					logger.info("Going to type project Name");
					textBoxProjectName.sendKeys(projectName);
					logger.info("Typed project Name successfully");	
						try{
							if(projectDescription!=null){
								logger.info("Going to type project Description");
								CommonUtil.normalWait(1000);
								textBoxProjectDescription.sendKeys(projectDescription);
								CommonUtil.normalWait(1000);
								logger.info("Typed project Description successfully");
							}
							HomePage.getInstance().waitForProgressBarToComplete();
							logger.info("Going to Select project Start Date as : " + startDate);
							CommonUtil.normalWait(1000);
							inputProjectStartDate.sendKeys(startDate);
							logger.info("Project Start Date selected successfully as : " +startDate);
							CommonUtil.normalWait(1000);
							if(endDate!=null){
								logger.info("Going to Select project End Date as : " + endDate);
								CommonUtil.normalWait(1000);
								inputProjectEndDate.sendKeys(endDate);
								logger.info("Project End Date selected successfully as : " +endDate);
								CommonUtil.normalWait(1000);
							}
							if(leadName!=null){
								logger.info("Going to Select project Lead : " + leadName);
								CommonUtil.normalWait(1000);
								CommonUtil.selectListWithVisibleText(selectLead, leadName);
								CommonUtil.normalWait(1000);
								logger.info("Project Lead selected successfully as : " +leadName);
							}
							if(jiraProjectName!=null){
								logger.info("Going to Map Jira Project : " + jiraProjectName);
								CommonUtil.normalWait(1000);
								CommonUtil.selectListWithVisibleText(selectExternalJiraProject, jiraProjectName);
								CommonUtil.normalWait(1000);
								logger.info("Project Mapped  successfully to Jira project : " +jiraProjectName);
							}
							if(projectType!=null){
								if(!selectProjectType(projectType))
									return false;
							}
							HomePage.getInstance().waitForProgressBarToComplete();
							logger.info("Verifying disabled Add button");
							Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@class='clearfix form-footer']//button[@disabled='']"), "Add button should not be enabled for duplicate project name");
							logger.info("Verified");
							logger.info("Verifying Project name box for Invalid name");
							Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@class='clearfix']//input[contains(@class,'ng-invalid')][@id='project-name']"),
									"Project name text box should become invalid for duplicate project name");
							logger.info("Verified");
							CommonUtil.normalWait(1000);
							CommonUtil.returnWebElement("//div[@class='clearfix form-footer']//button[text()='Cancel']").click();
							CommonUtil.normalWait(1000);
							CommonUtil.returnWebElement("//div[@id='confirmation-modal']//div[@class='modal-footer modal-draggable-handle']//button[text()='Continue']").click();
						}catch(Exception e){
							e.printStackTrace();
							return false;
						}	
						
				}else{
					logger.info("Text Box Project Name not found");
					return false;
				}
			}else{
				logger.info("Add New Project Button not found");
				return false;
			}
		}else{
			logger.info("Project Setup header not found");
			return false;
		}
		
		return true;
	}
	
	public boolean editProject(String projectName, String newProjectName, String projectType, String projectDescription, String startDate, String endDate, 
			String leadName, String jiraProjectName, String Jiraconnection, String CustomfieldText, List<String> resourceNameToAdd, List<String> resourceNameToRemove, List<String> ProjectNameToAdd){
			HomePage.getInstance().waitForProgressBarToComplete();
		if(CommonUtil.visibilityOfElementLocated(headerProjectSetup)){
			if(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-projectSetup']//div[text()='"+projectName+"']")){
				CommonUtil.normalWait(2000);
				CommonUtil.returnWebElement("//div[@id='grid-table-projectSetup']//div[text()='"+projectName+"']").click();
				CommonUtil.normalWait(7000);
				HomePage.getInstance().waitForProgressBarToComplete();
				try{
				
				if(newProjectName!=null){
					if(CommonUtil.visibilityOfElementLocated(textBoxProjectName)){
						logger.info("Going to edit project Name");
						textBoxProjectName.clear();
						textBoxProjectName.sendKeys(newProjectName);
						logger.info("Typed project Name successfully");	
					}else{
						logger.info("Text Box Project Name not found");
						return false;
					}
				}
						
				if(projectDescription!=null){
					logger.info("Going to type project Description");
					CommonUtil.normalWait(1000);
					textBoxProjectDescription.sendKeys(projectDescription);
					CommonUtil.normalWait(1000);
					logger.info("Typed project Description successfully");
				}
				
				if(startDate!=null){
					logger.info("Going to Select project Start Date as : " + startDate);
					CommonUtil.normalWait(1000);
					inputProjectStartDate.sendKeys(startDate);
					CommonUtil.normalWait(1000);
					logger.info("Project Start Date selected successfully as : " +startDate);
					CommonUtil.normalWait(500);
				}
							
							
				if(endDate!=null){
					logger.info("Going to Select project End Date as : " + endDate);
					CommonUtil.normalWait(1000);
					inputProjectEndDate.sendKeys(endDate);
					CommonUtil.normalWait(1000);
					logger.info("Project End Date selected successfully as : " +endDate);
				}
							
				if(leadName!=null){
					logger.info("Going to Select project Lead : " + leadName);
					CommonUtil.normalWait(3000);
					CommonUtil.moveToElement(selectLead);
					selectLead.click();
					CommonUtil.normalWait(1000);
					CommonUtil.returnWebElement("//b[text()='Lead :']/parent::label/following-sibling::div//select/option[text()='"+leadName+"']").click();
				//	CommonUtil.selectListWithVisibleText(selectLead, leadName);
					CommonUtil.normalWait(3000);
					logger.info("Project Lead selected successfully as : " +leadName);
				}
				
				if(Jiraconnection!=null){
					logger.info("Going to map jira connection:" + Jiraconnection);
					CommonUtil.normalWait(3000);
					CommonUtil.moveToElement(selectExternalJira);
					selectExternalJira.click();
					CommonUtil.normalWait(1000);
					CommonUtil.returnWebElement("//b[text()='Connected JIRA :']/parent::label/following-sibling::div//select/option[text()='"+Jiraconnection+"']").click();
					//CommonUtil.selectListWithVisibleText(selectExternalJira, Jiraconnection);
					CommonUtil.normalWait(3000);
					if(CommonUtil.visibilityOfElementLocated(warningPOP)){
						popupJiraConnectionChange.click();
					}
					logger.info("Jira connection mapped to Project");
				}
							
				if(jiraProjectName!=null){
					logger.info("Going to Map Jira Project : " + jiraProjectName);
					CommonUtil.normalWait(3000);
					CommonUtil.moveToElement(selectExternalJiraProject);
					selectExternalJiraProject.click();
					CommonUtil.normalWait(1000);
					CommonUtil.returnWebElement("//b[text()='Map external Defect project :']/parent::label/following-sibling::div//select/option[text()='"+jiraProjectName+"']").click();
					//CommonUtil.selectListWithVisibleText(selectExternalJiraProject, jiraProjectName);
					CommonUtil.normalWait(1000);
					logger.info("Project Mapped  successfully to Jira project : " +jiraProjectName);
				}
				
				if(CustomfieldText!=null){
					logger.info("Going to add the Custom field Text");
					CommonUtil.normalWait(500);
					CommonUtil.returnWebElement("//span[@title='Proj_Sample Custom 1']/following-sibling::span//span[@placeholder='None']").click();
					WebElement wbProj1CfTextbox = CommonUtil.returnWebElement("//span[@title='Proj_Sample Custom 1']/following-sibling::span//input");
					wbProj1CfTextbox.sendKeys(CustomfieldText);
					textBoxProjectDescription.click();
					
				}
				
				if(projectType!=null){
					if(!selectProjectType(projectType))
						return false;
				}
				
				if(resourceNameToAdd!=null){
					addResourcesToProject(resourceNameToAdd);
				}
				
				if(ProjectNameToAdd!=null){
					addProjectToShare(ProjectNameToAdd);
				}
				
				
				if(resourceNameToRemove!=null){
					
				}
				
				CommonUtil.normalWait(1000);
				CommonUtil.isElementClickable(buttonSave);
				buttonSave.click();
				HomePage.getInstance().closeToastPopup();
				HomePage.getInstance().waitForProgressBarToComplete();
							
			}catch(Exception e){
				e.printStackTrace();
				return false;
			}	
						
			}else{
				logger.info("Project not found in Grid by name : " + projectName);
				return false;
			}
		}else{
			logger.info("Project Setup header not found");
			return false;
		}
		
		return false;
	}
	
	
		
	
	private boolean addResourcesToProject(List<String> resourceNames){
		
		for(String resourceName : resourceNames){
			
			CommonUtil.returnWebElement("//div[@class='unselected-list']//label[text()='"+ resourceName +"']").click();
			CommonUtil.normalWait(500);
		}
		addSelectedResource.click();
		CommonUtil.normalWait(500);
		verifyResourcesAddedToProject(resourceNames);
		return true;
	}
	
	private boolean verifyResourcesAddedToProject(List<String> resourceNames){
		
		for(String resourceName : resourceNames){
			if(CommonUtil.visibilityOfElementLocated("//div[@class='selected-list']//label[text()='"+ resourceName +"']")){
				logger.info("Verified Resource added in Project : " + resourceName);
			}else{
				logger.info("Added Resource not found in Project by Resource name as : " + resourceName);
				Assert.assertTrue(false, "Added Resource not found in Project by Resource name as : " + resourceName);
				return false;
			}
		}
		return true;
	}
	
	public void verifyProject(String projectName, String projectType, String projectDescription, String startDate, String endDate, 
			String leadName, String jiraProjectName, List<String> allResourceNameInProject, String membersInProject){
	
		HomePage.getInstance().waitForProgressBarToComplete();
		if(CommonUtil.visibilityOfElementLocated(headerProjectSetup)){
			
			if(projectName!=null){
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-projectSetup']//div[text()='"+projectName+"']")
						, "Project not found by name: " + projectName);
			}
			
			if(projectType!=null){
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-projectSetup']//div[text()='"+projectName+"']/parent::div/parent::div/following-sibling::div//div[text()='"+projectType+"']")
						, "Project Type not found as: " + projectType);
			}
			if(leadName!=null){
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-projectSetup']//div[text()='"+projectName+"']/parent::div/parent::div/following-sibling::div//div[text()='"+leadName+"']")
						, "Project Lead not found as: " + leadName);
			}
			if(startDate!=null){
				String startD[] = startDate.split("/");
				String yr[] = startD[2].split("0");
				String verifyStartDate = startD[0]+"/"+startD[1]+"/"+yr[1];
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-projectSetup']//div[text()='"+projectName+"']/parent::div/parent::div/following-sibling::div//div[text()='"+startDate+"']")
						, "Project Start date not found as: " + startDate);
			}
			if(endDate!=null){
				String endD[] = endDate.split("/");
				String yr[] = endD[2].split("0");
				String verifyEndDate = endD[0]+"/"+endD[1]+"/"+yr[1];
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-projectSetup']//div[text()='"+projectName+"']/parent::div/parent::div/following-sibling::div//div[text()='"+verifyEndDate+"']")
						, "Project End date not found as: " + verifyEndDate);
			}	
			if(allResourceNameInProject!=null){
				
				CommonUtil.normalWait(2000);
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-projectSetup']//div[text()='"+projectName+"']/parent::div/parent::div/following-sibling::div//div[text()='"+membersInProject+" members"+"']")
						, "Resource Count in project "+projectName+" not found as: " + membersInProject+" members");
				
				CommonUtil.returnWebElement("//div[@id='grid-table-projectSetup']//div[text()='"+projectName+"']").click();
				CommonUtil.normalWait(1000);
				verifyResourcesAddedToProject(allResourceNameInProject);
			}
			
			CommonUtil.normalWait(3000);
			buttonCancel.click();
			//unsavedChanges();
					
		}else{
			logger.info("Project Setup header not found");
			Assert.assertTrue(false, "Project Setup header not found");
			
		}
		
	}

	private boolean selectProjectType(String projectType){
		if(CommonUtil.visibilityOfElementLocated(linkProjectType)){
			if(!projectType.equalsIgnoreCase("Normal")){
				linkProjectType.click();
				
				if(CommonUtil.visibilityOfElementLocated(headerAdvancedProjectConfiguration)){
					if(projectType.equalsIgnoreCase("Restricted")){
						try{
							logger.info("Going to click on Radio Button Restricted");
							radioButtonRestricted.click();
							logger.info("Clicked successfully on Radio Button Restricted");
						}catch(Exception e){
							e.printStackTrace();
							return false;
						}	
					}
					else{
						
						try{
							logger.info("Going to click on Radio Button Isolated");
							radioButtonIsolated.click();
							logger.info("Clicked successfully on Radio Button Isolated");
						}catch(Exception e){
							e.printStackTrace();
							return false;
						}	
					}
					CommonUtil.normalWait(500);
					buttonCloseAdvancedProjectConfiguration.click();
					CommonUtil.normalWait(500);
				}else{
					logger.info("Header Advanced Project Configuration not found");
					return false;
				}	
				}
			
		}else{
			logger.info("Link Project Type not found");
			return false;
		}
		
		return true;
	}

	public boolean attemptToAddDuplicateProject(String projectName, String projectType, String projectDescription,
			String startDate, String endDate, String leadName, String jiraProjectName) {
		HomePage.getInstance().waitForProgressBarToComplete();
		
				buttonAddProject.click();
				CommonUtil.normalWait(2000);
				CommonUtil.visibilityOfElementLocated(headerAddProject);
				//if(CommonUtil.visibilityOfElementLocated(textBoxProjectName)){
					logger.info("Going to type project Name");
					textBoxProjectName.sendKeys(projectName);
					logger.info("Typed project Name successfully");	
								logger.info("Going to type project Description");
								CommonUtil.normalWait(1000);
								textBoxProjectDescription.sendKeys(projectDescription);
								CommonUtil.normalWait(1000);
								logger.info("Typed project Description successfully");
							
							HomePage.getInstance().waitForProgressBarToComplete();
							logger.info("Going to Select project Start Date as : " + startDate);
							CommonUtil.normalWait(1000);
							inputProjectStartDate.sendKeys(startDate);
							logger.info("Project Start Date selected successfully as : " +startDate);
							CommonUtil.normalWait(1000);
							if(endDate!=null){
								logger.info("Going to Select project End Date as : " + endDate);
								CommonUtil.normalWait(1000);
								inputProjectEndDate.sendKeys(endDate);
								logger.info("Project End Date selected successfully as : " +endDate);
								CommonUtil.normalWait(1000);
							}
							
							
							if(projectType!=null){
								if(!selectProjectType(projectType))
									return false;
							}
							CommonUtil.normalWait(2000);
							HomePage.getInstance().waitForProgressBarToComplete();
							if(buttonAdd.isEnabled())
							{
								buttonAdd.click();
								logger.info("save button is enabled");
								return false;
									}
							else
							{
								logger.info("save button is not enabled");
								CommonUtil.ExplicitWaitForElement(buttonCancel);
								buttonCancel.click();
								CommonUtil.ExplicitWaitForElement(buttonContinue);
								Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonContinue),"Continue button is not found");
								logger.info("Going to click on continue");
								buttonContinue.click();
								CommonUtil.normalWait(1000);
							}
				
		return true;
	}
	
	private boolean addProjectToShare(List<String> projectNames){
		
		for(String projectName : projectNames){
			CommonUtil.scrollToWebElement(shareCheckbox);
			shareCheckbox.click();
			CommonUtil.normalWait(1000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(shareWarningPopup), "Warning Pop-up not Visible");
			shareWarningPopupYes.click();
	//	WebElement we =	CommonUtil.returnWebElement("//div[@class='unselected-list']//label[text()='"+ projectName +"']");
		//	CommonUtil.scrollToWebElement(we);
			CommonUtil.normalWait(2000);
			CommonUtil.returnWebElement("//div[@class='unselected-list']//label[text()='"+ projectName +"']").click();
			CommonUtil.normalWait(1000);
		}
		addSelectedProject.click();
		CommonUtil.normalWait(500);
		verifyProjectAddedToProject(projectNames);
		return true;
	}
	
	private boolean verifyProjectAddedToProject(List<String> projectNames){
		
		for(String projectName : projectNames){
			if(CommonUtil.visibilityOfElementLocated("//div[@class='selected-list']//label[text()='"+ projectName +"']")){
				logger.info("Verified Resource added in Project : " + projectName);
			}else{
				logger.info("Added Resource not found in Project by Resource name as : " + projectName);
				Assert.assertTrue(false, "Added Resource not found in Project by Resource name as : " + projectName);
				return false;
			}
		}
		return true;
	}
	
	public boolean autoUpadteExecution(String projectName) {
		
				HomePage.getInstance().waitForProgressBarToComplete();
			if(CommonUtil.visibilityOfElementLocated(headerProjectSetup)){
				if(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-projectSetup']//div[text()='"+projectName+"']")){
					CommonUtil.normalWait(2000);
					CommonUtil.returnWebElement("//div[@id='grid-table-projectSetup']//div[text()='"+projectName+"']").click();
					CommonUtil.normalWait(7000);
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.scrollToWebElement(checkboxAutoUpdateExecution);
					checkboxAutoUpdateExecution.click();
					CommonUtil.normalWait(1000);
					CommonUtil.isElementClickable(buttonSave);
					buttonSave.click();
					HomePage.getInstance().closeToastPopup();
					HomePage.getInstance().waitForProgressBarToComplete();
				}
			}
		
		return true;
	}
	
}
	

	
