package com.thed.zeuihtml.test.bvt;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.thed.zeuihtml.BaseTest;
import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.Constants;
import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;

public class TestPlanningBvts extends BaseTest {


	public TestPlanningBvts() {
		logger = Logger.getLogger(this.getClass());
	}

	
	@Test(enabled = testEnabled, priority = 84)
	public void bvt84_launchTestPlanningTest() {
		logger.info("Executing bvt84...");
		altID = 84;

		String releaseName = "Release 1.0";
		String appName = "Test Planning";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		isSuccess = true;
		logger.info("bvt84 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 85)
	public void bvt85_createNewCycleWithMandatoryFieldTest() {
		logger.info("Executing bvt85...");
		altID = 85;

		String startDate = CommonUtil.returnTodaysDate();
		String endDate = CommonUtil.returnFutureDateStartingTodaysDate(0, 5, 0);
		
		Assert.assertTrue(zeNavigator.createCycle(Config.getEASPropValue("CYCLE1_NAME"), null
				, null,startDate,endDate),  "Not created cycle successfully.");
		isSuccess = true;
		logger.info("bvt85 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 86)
	public void bvt86_createNewCycleWithAllFieldsTest() {
		logger.info("Executing bvt86...");
		altID = 86;

		String startDate = CommonUtil.returnTodaysDate();
		String endDate = CommonUtil.returnFutureDateStartingTodaysDate(0, 10, 0);
		
		Assert.assertTrue(zeNavigator.createCycle(Config.getEASPropValue("CYCLE2_NAME"), Config.getEASPropValue("CYCLE2_BUILD")
				, Config.getEASPropValue("CYCLE2_ENVIRONMENT"),startDate,endDate),  "Not created cycle successfully.");
	
		isSuccess = true;
		logger.info("bvt86 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 87)
	public void bvt87_addPhaseToCycleAndAssignToCreatorTest() {
		logger.info("Executing bvt87...");
		altID = 87;

		zeNavigator.addPhaseToCycle(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_1")
				, "creator", true);
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_1"), false);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(1, Config.getTCRPropValue("NODE_1"));
		nodeList.add(2, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.verifyAssigneeOfTestcase("Testcase without steps", "Test Manager", false);
		zeNavigator.verifyAssigneeOfTestcase("Testcase created with one step", "Test Manager", false);
		zeNavigator.verifyAssigneeOfTestcase("Testcase created with three steps", "Test Manager", true);
		
		isSuccess = true;
		logger.info("bvt87 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 88)
	public void bvt88_addPhaseToCycleAndAssignToAnyoneTest() {
		logger.info("Executing bvt88...");
		altID = 88;

		zeNavigator.addPhaseToCycle(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_2")
				, "anyone", true);

		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_2"), false);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("PHASE_2"));
		nodeList.add(1, Config.getTCRPropValue("NODE_3"));
		nodeList.add(2, Config.getTCRPropValue("SUB_NODE_5"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("TESTCASE_WITH_ALL_CUSTOM_FIELDS"), "Anyone", true);
		
		isSuccess = true;
		logger.info("bvt88 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 89)
	public void bvt89_cloneCycleWithTestcaseAssingmentsTest(){
		logger.info("Executing bvt89...");
		altID = 89;
		
		Assert.assertTrue(zeNavigator.cloneCycle(Config.getEASPropValue("CYCLE1_NAME"), Config.getEASPropValue("CLONED_CYCLE3_NAME"), true), "Failed to clone cycle");
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CLONED_CYCLE3_NAME"), Config.getTCRPropValue("PHASE_1"), false);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(1, Config.getTCRPropValue("NODE_1"));
		nodeList.add(2, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.verifyAssigneeOfTestcase("Testcase without steps", "Test Manager", false);
		zeNavigator.verifyAssigneeOfTestcase("Testcase created with one step", "Test Manager", false);
		zeNavigator.verifyAssigneeOfTestcase("Testcase created with three steps", "Test Manager", true);
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CLONED_CYCLE3_NAME"), Config.getTCRPropValue("PHASE_2"), false);

		List<String> nodeList1 = new ArrayList<String>();
		nodeList1.add(0, Config.getTCRPropValue("PHASE_2"));
		nodeList1.add(1, Config.getTCRPropValue("NODE_3"));
		nodeList1.add(2, Config.getTCRPropValue("SUB_NODE_5"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList1);
		
		zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("TESTCASE_WITH_ALL_CUSTOM_FIELDS"), "Anyone", true);
		
		
		isSuccess = true;
		logger.info("bvt89 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 90)
	public void bvt90_cloneCycleWithoutTestcaseAssingmentsTest(){
		logger.info("Executing bvt90...");
		altID = 90;
		
		Assert.assertTrue(zeNavigator.cloneCycle(Config.getEASPropValue("CYCLE1_NAME"), Config.getEASPropValue("CLONED_CYCLE4_NAME"), false), "Failed to clone cycle");
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CLONED_CYCLE4_NAME"), Config.getTCRPropValue("PHASE_1"), true);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(1, Config.getTCRPropValue("NODE_1"));
		nodeList.add(2, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.verifyAssigneeOfTestcase("Testcase without steps", "Unassigned", false);
		zeNavigator.verifyAssigneeOfTestcase("Testcase created with one step", "Unassigned", false);
		zeNavigator.verifyAssigneeOfTestcase("Testcase created with three steps", "Unassigned", true);
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CLONED_CYCLE4_NAME"), Config.getTCRPropValue("PHASE_2"), true);

		List<String> nodeList1 = new ArrayList<String>();
		nodeList1.add(0, Config.getTCRPropValue("PHASE_2"));
		nodeList1.add(1, Config.getTCRPropValue("NODE_3"));
		nodeList1.add(2, Config.getTCRPropValue("SUB_NODE_5"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList1);
		
		zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("TESTCASE_WITH_ALL_CUSTOM_FIELDS"), "Unassigned", true);
		
		isSuccess = true;
		logger.info("bvt90 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 91)
	public void bvt91_exportCycleTest() {
		logger.info("Executing bvt91...");
		altID = 91;
		
		zeNavigator.exportCycle(Config.getEASPropValue("CYCLE1_NAME"), "Excel", null);
		
		List<String>  fileNames= CommonUtil.returnFileNames(Config.getValue("EXPORT_FILE_PATH"));
		CommonUtil.renameFile(Config.getValue("EXPORT_FILE_PATH")+"/"+fileNames.get(0), Config.getEASPropValue("EXCEL_EXPORT_FILENAME"));
		
		List<Integer> ignoreCells = new ArrayList<Integer>();
		ignoreCells.add(5);
		ignoreCells.add(6);
		ignoreCells.add(21);
		
		isSuccess = CommonUtil.compareExcel(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getEASPropValue("EXCEL_EXPORT_FILENAME")
		, Config.getValue("EXPORT_FILE_PATH")+"/backups/"+Config.getEASPropValue("BACKUP_EXCEL_TO_COMPARE"),ignoreCells);
		
		CommonUtil.moveFile(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getEASPropValue("EXCEL_EXPORT_FILENAME"), Config.getValue("EXPORT_FILE_PATH")+"/delete");
		
		//Assert.assertTrue(isSuccess, "Exported Excel Data is not correct when compared with expected data");
		
		
		isSuccess = true;
		logger.info("bvt91 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 92)
	public void bvt92_hideCycleTest(){
		logger.info("Executing bvt92...");
		altID = 92;
		
		
		Assert.assertTrue(zeNavigator.editCycle(Config.getEASPropValue("CLONED_CYCLE3_NAME"), 
				null, null, null, null, null, null, null, true,false), "Failed to hide cycle");
		zeNavigator.verifyPhaseNotVisiblieInHiddenCyclePage(Config.getEASPropValue("CLONED_CYCLE3_NAME"), Config.getTCRPropValue("PHASE_1"));
		zeNavigator.verifyPhaseNotVisiblieInHiddenCyclePage(Config.getEASPropValue("CLONED_CYCLE3_NAME"), Config.getTCRPropValue("PHASE_2"));
		
		isSuccess = true;
		logger.info("bvt92 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 93)
	public void bvt93_editStartAndEnddateOfCyclePhase() {
		logger.info("Executing bvt93...");
		altID = 93;
		testcaseId = "291";

		String startDate = CommonUtil.returnFutureDateStartingTodaysDate(0, 1, 0);
		String endDate = CommonUtil.returnFutureDateStartingTodaysDate(0, 4, 0);
		
		List<String> phaseWithStartDate = new ArrayList<String>();
		phaseWithStartDate.add(0, Config.getTCRPropValue("PHASE_1") + ">" + startDate);
		phaseWithStartDate.add(0, Config.getTCRPropValue("PHASE_2") + ">" + startDate);
		
		List<String> phaseWithEndDate = new ArrayList<String>();
		phaseWithEndDate.add(0, Config.getTCRPropValue("PHASE_1") + ">" + endDate);
		phaseWithEndDate.add(0, Config.getTCRPropValue("PHASE_2") + ">" + endDate);

		Assert.assertTrue(zeNavigator.editCycle(Config.getEASPropValue("CYCLE1_NAME"), null, null, null, null, null, phaseWithStartDate, phaseWithEndDate, false,true), "Not edited cycle successfully.");
		isSuccess = true;
		logger.info("bvt93 is executed successfully.");
		
	}
	
	@Test(enabled = testEnabled, priority = 94)
	public void bvt94_assignTestcaseIndividuallyTest(){
		logger.info("Executing bvt94...");
		altID = 94;
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CLONED_CYCLE4_NAME"), Config.getTCRPropValue("PHASE_1"), true);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(1, Config.getTCRPropValue("NODE_1"));
		nodeList.add(2, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.assignTestIndividually("Testcase without steps", "Test Manager", false);
		zeNavigator.assignTestIndividually("Testcase created with one step", "Test Lead", false);
		zeNavigator.assignTestIndividually("Testcase created with three steps", "Tester One", true);
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CLONED_CYCLE4_NAME"), Config.getTCRPropValue("PHASE_1"), false);
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.verifyAssigneeOfTestcase("Testcase without steps", "Test Manager", false);
		zeNavigator.verifyAssigneeOfTestcase("Testcase created with one step", "Test Lead", false);
		zeNavigator.verifyAssigneeOfTestcase("Testcase created with three steps", "Tester One", true);
		
		isSuccess = true;
		logger.info("bvt94 is executed successfully.");
		
	}
	
	
	@Test(enabled = testEnabled, priority = 95)
	public void bvt95_bulkAssignUnexecutedTestcaseToAnyoneIncludingSubfoldersTest(){
		logger.info("Executing bvt95...");
		altID = 95;
		
	zeNavigator.addPhaseToCycle(Config.getEASPropValue("CYCLE2_NAME"), Config.getTCRPropValue("PHASE_1")
				, "creator", true);
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE2_NAME"), Config.getTCRPropValue("PHASE_1"), false);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("PHASE_1"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);

		zeNavigator.bulkAssignNotExecutedTest("Anyone", true, false);
		
		nodeList.add(1, Config.getTCRPropValue("NODE_1"));
		nodeList.add(2, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.verifyAssigneeOfTestcase("Testcase without steps", "Anyone", false);
		zeNavigator.verifyAssigneeOfTestcase("Testcase created with one step", "Anyone", false);
		zeNavigator.verifyAssigneeOfTestcase("Testcase created with three steps", "Anyone", true);
		
		isSuccess = true;
		logger.info("bvt86 is executed successfully.");
		
	}
	
	@Test(enabled = testEnabled, priority = 96)
	public void bvt87and96_syncPhaseWithTestcaseAddedOrRemovedTest(){
		logger.info("Executing bvt96...");
		altID = 96;
		
		zeNavigator.launchReleaseApp("Test Repository");
		
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		// phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");

		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);

		values.put("TESTCASE_SUMMARY", Config.getTCRPropValue("TESTCASE_ADDED_FOR_SYNC"));
		values.put("TESTCASE_DESC", "Testcase created for sync");
		values.put("Priority", Config.getTCRPropValue("TESTCASE_ADDED_FOR_SYNC_PRIORITY"));
		values.put("Comment", Config.getTCRPropValue("TESTCASE_ADDED_FOR_SYNC_COMMENT"));

		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
		
		if(zeNavigator.deleteTestcase(nodeName, Config.getTCRPropValue("TESTCASE_DELETE_FOR_SYNC"))) {
			
			zeNavigator.launchReleaseApp("Test Planning");
			
			zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_1"), false);

			List<String> nodeList = new ArrayList<String>();
			nodeList.add(0, Config.getTCRPropValue("PHASE_1"));
			zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
			
			List<String> nodeNameWithExpectedTestCountAdded = new ArrayList<String>();
			nodeNameWithExpectedTestCountAdded.add(0, Config.getTCRPropValue("SUB_NODE_1") + Constants.CHAR_TO_SPLIT_STRING + "1");
			
			List<String> nodeNameWithExpectedTestCountDeleted = new ArrayList<String>();
			nodeNameWithExpectedTestCountDeleted.add(0, Config.getTCRPropValue("SUB_NODE_1") + Constants.CHAR_TO_SPLIT_STRING + "1");
			
			
			zeNavigator.syncSelectedNode(nodeNameWithExpectedTestCountAdded, nodeNameWithExpectedTestCountDeleted, true, true);
			
			nodeList.add(1, Config.getTCRPropValue("NODE_1"));
			nodeList.add(2, Config.getTCRPropValue("SUB_NODE_1"));
			
			zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_1"), false);
			zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
			
			zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("TESTCASE_ADDED_FOR_SYNC")
					, "Unassigned", false);
			
			zeNavigator.verifyAbsenceOfTestcaseInCycleAssignmentWindow("Cancel teststep after adding to this testcase", true);
		}
		else {
			logger.info("Node not deleted");
			zeNavigator.launchReleaseApp("Test Planning");
		}
		
		
		isSuccess = true;
		logger.info("bvt96 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 97)
	public void bvt97_exportNodeFromAssignmentWindowTest() {
		logger.info("Executing bvt97...");
		altID = 97;
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CLONED_CYCLE4_NAME"), Config.getTCRPropValue("PHASE_1"), false);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(1, Config.getTCRPropValue("NODE_1"));
		nodeList.add(2, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.exportNodeFromTestPlanningAssignmentWindow(Config.getTCRPropValue("SUB_NODE_1")
				, "Excel", null, true);
		
		List<String>  fileNames= CommonUtil.returnFileNames(Config.getValue("EXPORT_FILE_PATH"));
		CommonUtil.renameFile(Config.getValue("EXPORT_FILE_PATH")+"/"+fileNames.get(0), Config.getEASPropValue("EXCEL_EXPORT_EAS_NODE_FILENAME"));
		
		List<Integer> ignoreCells = new ArrayList<Integer>();
		ignoreCells.add(5);
		ignoreCells.add(6);
		ignoreCells.add(17);
		ignoreCells.add(27);
		
		isSuccess = CommonUtil.compareExcel(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getEASPropValue("EXCEL_EXPORT_EAS_NODE_FILENAME")
		, Config.getValue("EXPORT_FILE_PATH")+"/backups/"+Config.getEASPropValue("BACKUP_EXCEL_EAS_NODE_TO_COMPARE"),ignoreCells);
		
		CommonUtil.moveFile(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getEASPropValue("EXCEL_EXPORT_EAS_NODE_FILENAME"), Config.getValue("EXPORT_FILE_PATH")+"/delete");
		
		//Assert.assertTrue(isSuccess, "Exported Excel Data is not correct when compared with expected data");
		
		
		isSuccess = true;
		logger.info("bvt97 is executed successfully.");
	}
	
	
	@Test(enabled = testEnabled, priority = 98)
	public void bvt98_addFreeformPhaseToCycle(){
		logger.info("Executing bvt98...");
		altID = 98;
		
		Assert.assertTrue(zeNavigator.addFreeformPhaseToCycle(Config.getEASPropValue("CYCLE2_NAME")
				, Config.getEASPropValue("FREEFORM1_PHASE_NAME"), true)
				, "Failed to add Freeform phase to cycle Successfully");
		
		isSuccess = true;
		logger.info("bvt98 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 99)
	public void bvt99_createTwoSystemsUnderFreeformPhaseTest(){
		logger.info("Executing bvt99...");
		altID = 99;
	
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE2_NAME"), Config.getEASPropValue("FREEFORM1_PHASE_NAME"), false);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getEASPropValue("FREEFORM1_PHASE_NAME"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		List<String> childNodeToAdd = new ArrayList<String>();
		childNodeToAdd.add(0, Config.getEASPropValue("FREEFORM1_SYSTEM1_NAME") +">"+ Config.getEASPropValue("FREEFORM1_SYSTEM1_DESCRIPTION"));
		childNodeToAdd.add(1, Config.getEASPropValue("FREEFORM1_SYSTEM2_NAME"));
		
		zeNavigator.addFreeformChildNode(Config.getEASPropValue("FREEFORM1_PHASE_NAME"), childNodeToAdd, true);
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE2_NAME"), Config.getEASPropValue("FREEFORM1_PHASE_NAME"), false);
		
		nodeList.add(1, Config.getEASPropValue("FREEFORM1_SYSTEM1_NAME"));
		nodeList.add(2, Config.getEASPropValue("FREEFORM1_SYSTEM2_NAME"));
	
		Assert.assertTrue(zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList), "Failed to create system in freeform node");
		zeNavigator.navigateBackToCycles();
		isSuccess = true;
		logger.info("bvt99 is executed successfully.");
	}
	
	
	@Test(enabled = testEnabled, priority = 100)
	public void bvt100_createTwoSubSystemUnderFreeformNodeTest(){
		logger.info("Executing bvt100...");
		altID = 100;
		
		zeNavigator.launchReleaseApp("Test Planning");
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE2_NAME"), Config.getEASPropValue("FREEFORM1_PHASE_NAME"), false);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getEASPropValue("FREEFORM1_PHASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("FREEFORM1_SYSTEM1_NAME"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		List<String> childNodeToAdd = new ArrayList<String>();
		childNodeToAdd.add(0, Config.getEASPropValue("FREEFORM1_SUBSYSTEM1_NAME") +">"+ Config.getEASPropValue("FREEFORM1_SUBSYSTEM1_DESCRIPTION"));
		childNodeToAdd.add(1, Config.getEASPropValue("FREEFORM1_SUBSYSTEM2_NAME"));
		
		zeNavigator.addFreeformChildNode(Config.getEASPropValue("FREEFORM1_SYSTEM1_NAME"), childNodeToAdd, false);
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		nodeList.add(1, Config.getEASPropValue("FREEFORM1_SYSTEM2_NAME"));
		List<String> childNodeToAdd1 = new ArrayList<String>();
		childNodeToAdd1.add(0, Config.getEASPropValue("FREEFORM1_SUBSYSTEM3_NAME") +">"+ Config.getEASPropValue("FREEFORM1_SUBSYSTEM3_DESCRIPTION"));
		childNodeToAdd1.add(1, Config.getEASPropValue("FREEFORM1_SUBSYSTEM4_NAME")+">"+ Config.getEASPropValue("FREEFORM1_SUBSYSTEM4_DESCRIPTION"));
		
		zeNavigator.addFreeformChildNode(Config.getEASPropValue("FREEFORM1_SYSTEM2_NAME"), childNodeToAdd1, false);
		
		nodeList.add(1, Config.getEASPropValue("FREEFORM1_SYSTEM1_NAME"));
		nodeList.add(2, Config.getEASPropValue("FREEFORM1_SUBSYSTEM1_NAME"));
		nodeList.add(3, Config.getEASPropValue("FREEFORM1_SUBSYSTEM2_NAME"));
		
		nodeList.add(4, Config.getEASPropValue("FREEFORM1_SYSTEM2_NAME"));
		nodeList.add(5, Config.getEASPropValue("FREEFORM1_SUBSYSTEM3_NAME"));
		nodeList.add(6, Config.getEASPropValue("FREEFORM1_SUBSYSTEM4_NAME"));
		
		Assert.assertTrue(zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList), "Failed to create subsystem nodes in freeform");
		zeNavigator.navigateBackToCycles();
		isSuccess = true;
		logger.info("bvt100 is executed successfully.");
	}
	

	@Test(enabled = testEnabled, priority = 101)
	public void bvt101_renameFreeformSubSystemAndItsDescription(){
		
		logger.info("Executing bvt101...");
		altID = 101;
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE2_NAME"), Config.getEASPropValue("FREEFORM1_PHASE_NAME"), false);
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getEASPropValue("FREEFORM1_PHASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("FREEFORM1_SYSTEM2_NAME"));
		nodeList.add(2, Config.getEASPropValue("FREEFORM1_SUBSYSTEM3_NAME"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.editFreeformChildNode(Config.getEASPropValue("FREEFORM1_SUBSYSTEM3_NAME")
				, Config.getEASPropValue("FREEFORM1_SUBSYSTEM3_RENAME")
				, Config.getEASPropValue("FREEFORM1_SUBSYSTEM3_REDESCRIPTION"), true);
		
		nodeList.remove(2);
		nodeList.add(2, Config.getEASPropValue("FREEFORM1_SUBSYSTEM3_RENAME"));
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE2_NAME"), Config.getEASPropValue("FREEFORM1_PHASE_NAME"), false);
		Assert.assertTrue(zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList), "Freeform Node renamed successfully");
		zeNavigator.navigateBackToCycles();
		isSuccess = true;
		logger.info("bvt101 is executed successfully.");
		
	}
	

	@Test(enabled = testEnabled, priority = 102)
	public void bvt102_deleteFreeformNode(){
		
		logger.info("Executing bvt102...");
		altID = 102;
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE2_NAME"), Config.getEASPropValue("FREEFORM1_PHASE_NAME"), false);
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getEASPropValue("FREEFORM1_PHASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("FREEFORM1_SYSTEM2_NAME"));
		nodeList.add(2, Config.getEASPropValue("FREEFORM1_SUBSYSTEM4_NAME"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.deleteFreeformChildNodeAndVerify(Config.getEASPropValue("FREEFORM1_SUBSYSTEM4_NAME"), true);
		
		isSuccess = true;
		logger.info("bvt102 is executed successfully.");
	
	}
	

	@Test(enabled = testEnabled, priority = 103)
	public void bvt103_quickSearchTestcasesByPriorityAndAddToFreeformNode(){
		
		logger.info("Executing bvt103...");
		altID = 103;
		 
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE2_NAME"), Config.getEASPropValue("FREEFORM1_PHASE_NAME"), false);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getEASPropValue("FREEFORM1_PHASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("FREEFORM1_SYSTEM1_NAME"));
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		List<String> expectedTestcases = new ArrayList<String>();
		expectedTestcases.add(0, Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"));
		
		Assert.assertTrue(zeNavigator.addTestcaseToFreeformNode("Quick", Config.getTCRPropValue("TESTCASE_WITHOUT_STEP_PRIORITY"), expectedTestcases, true, false, false));
		
		List<String> nodeList1 = new ArrayList<String>();
		nodeList1.add(0, Config.getEASPropValue("FREEFORM1_PHASE_NAME"));
		nodeList1.add(1, Config.getEASPropValue("FREEFORM1_SYSTEM1_NAME"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList1);
	
		zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"), "Unassigned", true);
		
		isSuccess = true;
		logger.info("bvt103 is executed successfully.");
	
	}
	
	@Test(enabled = testEnabled, priority = 104)
	public void bvt104_advanceSearchTestcasesByPriorityAndAddToFreeformNode(){
		
		logger.info("Executing bvt104...");
		altID = 104;
		
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE2_NAME"), Config.getEASPropValue("FREEFORM1_PHASE_NAME"), true);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getEASPropValue("FREEFORM1_PHASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("FREEFORM1_SYSTEM1_NAME"));
		nodeList.add(2, Config.getEASPropValue("FREEFORM1_SUBSYSTEM1_NAME"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		List<String> expectedTestcases = new ArrayList<String>();
		expectedTestcases.add(0, Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"));
		expectedTestcases.add(0, Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"));
		
		zeNavigator.addTestcaseToFreeformNode("Advanced", "comment ~ \""+Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP_COMMENT")+"\"", expectedTestcases, false, false, false);
		
		List<String> nodeList1 = new ArrayList<String>();
		nodeList1.add(0, Config.getEASPropValue("FREEFORM1_PHASE_NAME"));
		nodeList1.add(1, Config.getEASPropValue("FREEFORM1_SYSTEM1_NAME"));
		nodeList1.add(2, Config.getEASPropValue("FREEFORM1_SUBSYSTEM1_NAME"));
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList1);
		zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"), "Unassigned", false);
		zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"), "Unassigned", true);
		isSuccess = true;
		logger.info("bvt104 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 105)
	public void bvt105_deleteTestcaseInAssignedTestcaseToExecuteWindow(){
		logger.info("Executing bvt105...");
		altID = 105;
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_1"), false);
		
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(1, Config.getTCRPropValue("NODE_1"));
		nodeList.add(2, Config.getTCRPropValue("SUB_NODE_1"));
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		List<String> testcasNameToDelete = new ArrayList<String>();
		testcasNameToDelete.add(0, Config.getTCRPropValue("TESTCASE_ADDED_FOR_SYNC"));
		
		zeNavigator.deleteTestcaseFromSelectedNodeInAssingTestcaseToExecuteWindow(testcasNameToDelete, true);

		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_1"), false);
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.verifyAbsenceOfTestcaseInCycleAssignmentWindow(Config.getTCRPropValue("TESTCASE_ADDED_FOR_SYNC"), true);
		
		
		isSuccess = true;
		logger.info("bvt105 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 106)
	public void bvt106_deleteCyclePhase() {
		logger.info("Executing bvt106...");
		altID = 106;

		zeNavigator.deleteCyclePhase(Config.getEASPropValue("CYCLE2_NAME"), Config.getTCRPropValue("PHASE_1"));
		
		zeNavigator.verifyPhaseNotVisiblieInCyclePage(Config.getEASPropValue("CYCLE2_NAME"), Config.getTCRPropValue("PHASE_1"));
		
		isSuccess = true;
		logger.info("bvt106 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 107)
	public void bvt107_deleteCycle() {
		logger.info("Executing bvt107...");
		altID = 107;

		Assert.assertTrue(zeNavigator.deleteCycle(Config.getEASPropValue("CYCLE2_NAME")), "Not deleted cycle successfully.");
		
		isSuccess = true;
		logger.info("bvt107 is executed successfully.");
	}
	
	
	//@Test(enabled = testEnabled, priority = 99)
	public void bvt108_syncAndViewTestcaseCountInEASAssignemntWindowAfterDeleteingAndAddingTestInTCCTest(){
		logger.info("Executing bvt108...");
		altID = 108;
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_1"), false);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("PHASE_1"));
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		List<String> nodeNameWithExpectedTestCountAdded = new ArrayList<String>();
		nodeNameWithExpectedTestCountAdded.add(0, Config.getTCRPropValue("SUB_NODE_1") + Constants.CHAR_TO_SPLIT_STRING + "1");
		
		zeNavigator.syncSelectedNode(nodeNameWithExpectedTestCountAdded, null, true, true);
		
		zeNavigator.launchReleaseApp("Test Repository");
		
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_2"));
		phases.add(Config.getTCRPropValue("NODE_3"));
		//phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_5");
		String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");

		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);

		values.put("TESTCASE_SUMMARY", Config.getTCRPropValue("TESTCASE_ADDED_FOR_SYNC"));
		values.put("TESTCASE_DESC", "Testcase created for sync");
		values.put("Priority", Config.getTCRPropValue("TESTCASE_ADDED_FOR_SYNC_PRIORITY"));
		values.put("Comment", Config.getTCRPropValue("TESTCASE_ADDED_FOR_SYNC_COMMENT"));

		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
		
		phases.clear();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		nodeName = Config.getTCRPropValue("SUB_NODE_1");
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		
		//For now passing hardcoded testcase ID until method in TestRepository is implemented
		//TODO : Fix Hard coded value
		Assert.assertTrue(zeNavigator.deleteTestcase(nodeName, "30"), "Not deleted testcase.");
		
		zeNavigator.launchReleaseApp("Test Planning");
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_1"), false);

		
		nodeList.add(0, Config.getTCRPropValue("PHASE_1"));
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		//List<String> nodeNameWithExpectedTestCountAdded = new ArrayList<String>();
		//nodeNameWithExpectedTestCountAdded.add(0, Config.getTCRPropValue("SUB_NODE_1") + Constants.CHAR_TO_SPLIT_STRING + "1");
		
		List<String> nodeNameWithExpectedTestCountDeleted = new ArrayList<String>();
		nodeNameWithExpectedTestCountDeleted.add(0, Config.getTCRPropValue("SUB_NODE_1") + Constants.CHAR_TO_SPLIT_STRING + "1");
		
		
		zeNavigator.syncSelectedNode(null, nodeNameWithExpectedTestCountDeleted, true, true);
		
		nodeList.add(1, Config.getTCRPropValue("NODE_1"));
		nodeList.add(2, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_1"), false);
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.verifyTestcaseCountOfSelectedNode(Config.getTCRPropValue("SUB_NODE_1"), 7, true);
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_2"), false);
		nodeList.clear();
		nodeList.add(0, Config.getTCRPropValue("PHASE_2"));
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		nodeNameWithExpectedTestCountAdded.clear();
		nodeNameWithExpectedTestCountAdded.add(0, Config.getTCRPropValue("SUB_NODE_5") + Constants.CHAR_TO_SPLIT_STRING + "1");
				
		zeNavigator.syncSelectedNode(nodeNameWithExpectedTestCountAdded, null, true, true);
		
		nodeList.add(1, Config.getTCRPropValue("NODE_3"));
		nodeList.add(2, Config.getTCRPropValue("SUB_NODE_5"));
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_2"), false);
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.verifyTestcaseCountOfSelectedNode(Config.getTCRPropValue("SUB_NODE_5"), 8, true);
		
		isSuccess = true;
		logger.info("bvt108 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 109)
	public void bvt109_browseTestcaseAndAddToFreeformNodeWithHierarchy(){
		logger.info("Executing bvt109...");
		altID = 109;
		
		String startDate = CommonUtil.returnTodaysDate();
		String endDate = CommonUtil.returnFutureDateStartingTodaysDate(0, 10, 0);
		
		Assert.assertTrue(zeNavigator.createCycle(Config.getEASPropValue("CYCLE2_NAME"), Config.getEASPropValue("CYCLE2_BUILD")
				, Config.getEASPropValue("CYCLE2_ENVIRONMENT"),startDate,endDate),  "Not created cycle successfully.");
		
		Assert.assertTrue(zeNavigator.addFreeformPhaseToCycle(Config.getEASPropValue("CYCLE2_NAME")
				, Config.getEASPropValue("FREEFORM1_PHASE_NAME_2"), false)
				, "Failed to add Freeform phase to cycle Successfully");
		
	    //zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE2_NAME"), Config.getEASPropValue("FREEFORM1_PHASE_NAME_2"), false);
		Assert.assertTrue(zeNavigator.addTestcaseToFreeformNodeBrowse(Config.getEASPropValue("FREEFORM1_PHASE_NAME_2"),Config.getTCRPropValue("PHASE_1"),Config.getTCRPropValue("NODE_1"),Config.getTCRPropValue("SUB_NODE_1"),true),"Not able to launch browse window");
		CommonUtil.normalWait(1000);
		logger.info("verifying assignments");
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(Config.getEASPropValue("FREEFORM1_PHASE_NAME_2"));
		nodeList.add(1, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(2, Config.getTCRPropValue("NODE_1"));
		nodeList.add(3, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"), "Unassigned", true);
		 isSuccess = true;
		logger.info("bvt109 is executed successfully.");
	
	}
	
	@Test(enabled = testEnabled, priority = 110)
	public void bvt110_browseTestcaseAndAddToFreeformNodeWithoutHierarchy(){
		
		logger.info("Executing bvt110...");
		altID = 110;
		
		/*String releaseName = "Release 1.0";
		String appName = "Test Planning";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		Assert.assertTrue(zeNavigator.navigateToReleaseApps(releaseName, appName), "Not navigated to : " + appName);
		
		String startDate = CommonUtil.returnTodaysDate();
		String endDate = CommonUtil.returnFutureDateStartingTodaysDate(0, 10, 0);
		
		Assert.assertTrue(zeNavigator.createCycle(Config.getEASPropValue("CYCLE2_NAME"), Config.getEASPropValue("CYCLE2_BUILD")
				, Config.getEASPropValue("CYCLE2_ENVIRONMENT"),startDate,endDate),  "Not created cycle successfully.");*/
		
		Assert.assertTrue(zeNavigator.addFreeformPhaseToCycle(Config.getEASPropValue("CYCLE2_NAME")
				, Config.getEASPropValue("FREEFORM1_PHASE_NAME_3"), false)
				, "Failed to add Freeform phase to cycle Successfully");
		
	    //zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE2_NAME"), Config.getEASPropValue("FREEFORM1_PHASE_NAME_3"), false);
		Assert.assertTrue(zeNavigator.addTestcaseToFreeformNodeBrowse(Config.getEASPropValue("FREEFORM1_PHASE_NAME_3"),Config.getTCRPropValue("PHASE_1"),Config.getTCRPropValue("NODE_1"),Config.getTCRPropValue("SUB_NODE_1"),false),"Not able to launch browse window");
		CommonUtil.normalWait(1000);
		logger.info("verifying assignments");
		zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"), "Unassigned", true);
		
		isSuccess = true;
		logger.info("bvt110 is executed successfully.");
	}
	
    @BeforeMethod
	public void beforeMethod() {
    	if(Driver.driver.getTitle().contains("Login")) {
    		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
    	}
    	if(! Driver.driver.getTitle().contains("Test Planning")) {
			String releaseName = "Release 1.0";
			String appName = "Test Planning";
			zeNavigator.selectProject("Sample Project");
			Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
			zeNavigator.launchReleaseApp(appName);
		}
    	if (Driver.driver == null ) {
    		Driver.driver = CommonUtil.getNewWebDriver();
			CommonUtil.launchBrowser(Config.getValue("ZE_URL"));
		}
		isSuccess = false;
	}

    @AfterMethod
	public void afterMethod() {
		if(!isSuccess){
			baseAfterMethod();
			zeNavigator.logout();
//			zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
//			String releaseName = "Release 1.0";
//			String appName = "Test Planning";
//			zeNavigator.selectProject("Sample Project");
//			Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
//			zeNavigator.launchReleaseApp(appName);
		}
	}

	@BeforeClass
	public void beforeClass() {
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
	}
	
	@AfterClass
	public void afterClass() {
		zeNavigator.logout();
	}

}
