package com.thed.zeuihtml.test.bvt;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.thed.zeuihtml.BaseTest;
import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.Constants;
import com.thed.zeuihtml.utils.CommonUtil;





public class GlobalRepositoryBvts extends BaseTest {
	
	public GlobalRepositoryBvts() {
	logger = Logger.getLogger(this.getClass());
	} 



@Test(enabled = testEnabled, priority=270)
public void bvt271_ViewGloablRepositoryIfUserHavePermission() {
	
	logger.info("Executing bvt271...");
	altID = 271;
	testcaseId = "271";
	
	
	CommonUtil.normalWait(7000);
	Assert.assertTrue(zeNavigator.launchAdministration(), "Failed to navigate Administration Page");
	Assert.assertTrue(zeNavigator.launchAdminApps("Customizations"), "Failed to launch Customization App");
	Assert.assertTrue(zeNavigator.launchCustomizationOptions("Roles"),
			"Failed to launch Customize Roles Window");
	Assert.assertTrue(zeNavigator.editRole(Config.getValue("ROLE_LEAD"), null, false, false, false, false, false, false, false, false, false, false, true, true, true), "Failed to Edit Role");
	
	
	zeNavigator.logout();
	zeNavigator.doLogin(Config.getValue("ZE_LEAD_USERNAME"), Config.getValue("ZE_LEAD_PASSWORD"));
	CommonUtil.normalWait(4000);
	zeNavigator.verifyAppTopHeader(true, true, false);
	isSuccess = true;
	logger.info("bvt271 is executed successfully.");
	}

@Test(enabled = testEnabled, priority=271)

public void bvt272_ViewGloablRepositoryIfUserdoNotHavePermission() {
	
	logger.info("Executing bvt272...");
	altID = 272;
	testcaseId = "272";
	
	zeNavigator.logout();
	zeNavigator.doLogin(Config.getValue("ZE_TESTER_USERNAME"), Config.getValue("ZE_TESTER_PASSWORD"));
	CommonUtil.normalWait(4000);
	zeNavigator.verifyAppTopHeader(false, true, false);
	isSuccess = true;
	logger.info("bvt272 is executed successfully.");
	}

@Test(enabled = testEnabled, priority=272)
public void bvt273_AddTestcaseSysSubSystemPhaseGlobalRepo() {
	
	logger.info("Executing bvt273...");
	altID = 273;
	testcaseId = "273";
	zeNavigator.logout();
	zeNavigator.doLogin(Config.getValue("ZE_LEAD_USERNAME"), Config.getValue("ZE_LEAD_PASSWORD"));
	CommonUtil.normalWait(4000);
	zeNavigator.launchGlobalRepository();
	zeNavigator.launchGlobalApps("Test Repository");
	
	
	String phaseName = Config.getTCRPropValue("GLOBAL_PHASE_1");
	String phaseDescription = phaseName + " description";
	
	Assert.assertTrue(zeNavigator.createPhase(Config.getTCRPropValue("GLOBAL_REPO"), phaseName, phaseDescription),
			"Phase not created successfully.");
	
	//Create a Node in Global repository
		String parentNodeName = Config.getTCRPropValue("GLOBAL_PHASE_1");
		String nodeOneName = Config.getTCRPropValue("GLOBAL_NODE_1");
		String nodeOneDescription = nodeOneName + " description";
		
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("GLOBAL_REPO"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");
		
		//Create a Sub-Node in Global Repository
		
		String parentNodeName1 = Config.getTCRPropValue("GLOBAL_NODE_1");
		String nodeOneName1 = Config.getTCRPropValue("GLOBAL_SUBNODE_1");
		String nodeOneDescription1 = nodeOneName1 + " description";

		List<String> phases1 = new ArrayList<String>();
		phases1.add(Config.getTCRPropValue("GLOBAL_REPO"));
		phases1.add(Config.getTCRPropValue("GLOBAL_PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases1), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.createNode(phases1, parentNodeName1, nodeOneName1, nodeOneDescription1),
				"Node not created successfully.");
		isSuccess = true;
		logger.info("bvt273 is executed successfully.");
	}

@Test(enabled = testEnabled, priority=273)
public void bvt274_createTestcaseGlobalrepository() {
	logger.info("Executing bvt274...");
	altID = 274;
	testcaseId = "274";
	
	CommonUtil.normalWait(4000);
	zeNavigator.launchGlobalRepository();
	zeNavigator.launchGlobalApps("Test Repository");
	
	List<String> phases = new ArrayList<String>();
	phases.add(Config.getTCRPropValue("GLOBAL_REPO"));
	phases.add(Config.getTCRPropValue("GLOBAL_PHASE_1"));
	phases.add(Config.getTCRPropValue("GLOBAL_NODE_1"));
	Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
	String nodeName = Config.getTCRPropValue("GLOBAL_SUBNODE_1");
	String testcaseId = zeNavigator.addDefaultTestcaseProjectRepo(nodeName);
	Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");

	System.out.println("Testcase IDs : " + testcaseId);

	Map<String, String> values = new HashMap<String, String>();
	values.put("NODE_NAME", nodeName);
	values.put("TESTCASE_ID", testcaseId);
	values.put("TESTCASE_SUMMARY", "Modified summary");
	values.put("TESTCASE_DESC", "Modified description");
	values.put("TESTCASE_SUMMARY",Config.getTCRPropValue("TESTCASE_FOR_GLOBAL_REPO"));
	values.put("TESTCASE_DESC", "Testcase for the Project repository description");
	values.put("Priority", Config.getTCRPropValue("TESTCASE_FOR_GLOBAL_REPO_PRIORITY"));
	values.put("Comment", Config.getTCRPropValue("TESTCASE_FOR_GLOBAL_REPO_COMMENT"));

	Assert.assertTrue(zeNavigator.modifyTestcaseProjectRepo(values), "Not added default testcase successfully.");
	zeNavigator.verifyTestcaseVersionProjectRepo(Config.getTCRPropValue("TESTCASE_FOR_GLOBAL_REPO"), "1");
	isSuccess = true;
	logger.info("bvt274 is executed successfully.");
}
@Test (enabled= testEnabled, priority=274)
public void bvt275_Clone_BulkEditDeleteTestcaseGlobalRepo() {
	logger.info ("Executing Bvt275...");
	altID = 275;
	testcaseId = "275";
	CommonUtil.normalWait(4000);
	zeNavigator.launchGlobalRepository();
	zeNavigator.launchGlobalApps("Test Repository");
	
	List<String> phases = new ArrayList<String>();
	phases.add(Config.getTCRPropValue("GLOBAL_REPO"));
	phases.add(Config.getTCRPropValue("GLOBAL_PHASE_1"));
	phases.add(Config.getTCRPropValue("GLOBAL_NODE_1"));
	
	Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
	String nodeName = Config.getTCRPropValue("GLOBAL_SUBNODE_1");
	String testcaseName = Config.getTCRPropValue("TESTCASE_FOR_GLOBAL_REPO");
	List<String> testcaseID2= new ArrayList<String>();
	for (int i=1; i<4; i++) {
		Assert.assertTrue(zeNavigator.cloneTestcaseProjectRepo(nodeName, testcaseName, "withoutsteps"), "Testcase is not cloned");
		String testcaseId = zeNavigator.getTestcaseProjectRepo(nodeName);
		System.out.println("Testcase IDs : " + testcaseId);
		testcaseID2.add(testcaseId);
		System.out.println("*****************************"+testcaseID2);
		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY","Clone Testcase Project Repo" + i);
		values.put("TESTCASE_DESC", "Testcase for the Project repository description" + i );
		values.put("Priority", Config.getTCRPropValue("TESTCASE_FOR_PROJECT_REPO_PRIORITY"));
		values.put("Comment", "clone" + i);

		Assert.assertTrue(zeNavigator.modifyTestcaseProjectRepo(values), "Not added default testcase successfully.");
	
	}
	Map<String, String> values = new HashMap<String, String>();
	values.put("ALTID", "12.12.23");
	values.put("Comment", "Bulk Edited testcase");
	values.put("Tags", "Bulk");
	values.put("estimatedTime", Config.getTCRPropValue("NEW_ESTIMATED_TIME"));
	values.put("priority", Config.getTCRPropValue("TC_PRIORITY_2"));
	values.put("Automated", "BVTAutomation" + Constants.CHAR_TO_SPLIT_STRING + "001"
			+ Constants.CHAR_TO_SPLIT_STRING + Config.getTCRPropValue("Automation_Path"));
	Assert.assertTrue(zeNavigator.bulkEditTestCase(values), "Bulk edit not done succefully..");
	
	Assert.assertTrue(zeNavigator.deleteTestcaseProjectRepo(nodeName, testcaseID2 ), "TestCase not deleted" );
	
	
	isSuccess = true;
	logger.info("bvt275 is executed successfully.");
}

@Test (enabled= testEnabled, priority=275)
public void bvt276_DeleteSingleTestcase_Phase_globalRepository()
{
	
	CommonUtil.normalWait(4000);
	zeNavigator.launchGlobalRepository();
	zeNavigator.launchGlobalApps("Test Repository");
	
	String phaseName = Config.getTCRPropValue("GLOBAL_DELETE_PHASE");
	String phaseDescription = phaseName + " description";
	Assert.assertTrue(zeNavigator.createPhase(Config.getTCRPropValue("GLOBAL_REPO"), phaseName, phaseDescription),
			"Phase not created successfully.");
	
	List<String> phases = new ArrayList<String>();
	phases.add(Config.getTCRPropValue("GLOBAL_REPO"));
	phases.add(Config.getTCRPropValue("GLOBAL_DELETE_PHASE"));
	//phases.add(Config.getTCRPropValue("PRO_NODE_1"));
	Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
	String nodeName = Config.getTCRPropValue("GLOBAL_DELETE_PHASE");
	String deleteNodeName = Config.getTCRPropValue("GLOBAL_DELETE_PHASE");
	String testcaseId = zeNavigator.addDefaultTestcaseProjectRepo(nodeName);
	Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");
	Assert.assertTrue(zeNavigator.deleteTestcaseProjectRepo(nodeName, Integer.parseInt(testcaseId)), "Not deleted testcase.");
	Assert.assertTrue(zeNavigator.deleteNode(deleteNodeName), "Node not renamed successfully.");
	isSuccess = true;
	logger.info("bvt272 is executed successfully.");
}

@Test (enabled= testEnabled, priority=276)
public void bvt277ImportTestcase_copy_GlobalRepo()
{
	logger.info("Executing bvt277...");
	altID = 277;
	zeNavigator.logout();
	zeNavigator.doLogin(Config.getValue("ZE_LEAD_USERNAME"), Config.getValue("ZE_LEAD_PASSWORD"));
	zeNavigator.launchGlobalRepository();
	zeNavigator.launchGlobalApps("Test Repository");
	Assert.assertTrue(zeNavigator.addTestcaseMap("Map3", "2", "By ID Change", "testcase map", "H", "J", "L", "G", "K", null), "Not able to add testcase map");
	Assert.assertTrue(zeNavigator.importTestcase("Job3", "Map3",
			CommonUtil.getCompleteFilePath("\\src\\test\\resources\\export_import\\backups\\tccgridbackuppro.xlsx")), "Testcase not imported");
	zeNavigator.navigateToTCCNodeUnderImportedNode("tccgridbackuppro.xlsx");

	List<String> testcasesNames = new ArrayList<String>();
	testcasesNames.add(Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"));
	testcasesNames.add(Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"));
	testcasesNames.add(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"));

	
	
	Assert.assertTrue(zeNavigator.renameSelectedTCCImportedNodeAndDragToRelease("tccgridbackuppro.xlsx", "Global Imported Testcase",
			Config.getTCRPropValue("GLOBAL_REPO"), true));

	List<String> nodes = new ArrayList<String>();
	nodes.add(Config.getTCRPropValue("GLOBAL_REPO"));
	nodes.add("Global Imported Testcase");
	Assert.assertTrue(zeNavigator.navigateToNodes(nodes), "Not navigated to nodes.");

	

	zeNavigator.verifyTestcasesInSelectedNodeOfTestRepositoryProjectRepo(testcasesNames);

	isSuccess = true;
	logger.info("bvt277 is executed successfully.");
}

@Test (enabled= testEnabled, priority=277)
public void bvt278ShareTestcasefromGlobalRepo()
{
	logger.info("Executing bvt278...");
	altID = 278;
	zeNavigator.logout();
	zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_USERNAME"));
	zeNavigator.launchGlobalRepository();
	zeNavigator.launchGlobalApps("Configuration");
	List<String> projectNames = new  ArrayList<String>();
	projectNames.add(Config.getProjectPropValue("PROJECT1_NAME"));
	projectNames.add(Config.getProjectPropValue("DEFAULT_PROJECT"));
	zeNavigator.globalRepoProjectAssignment(projectNames);
	
	String releaseName = "Release 1.0";
	String appName = "Test Repository";
	zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"));
	Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
	zeNavigator.launchReleaseApp(appName);
	List<String> phases = new ArrayList<String>();
	phases.add(Config.getTCRPropValue("PROJECT_REPO"));
	Assert.assertTrue(zeNavigator.navigateToNodesProjectRepo(phases), "Not navigated to nodes.");
	
	zeNavigator.launchShareTCCWindowProjectRepo(Config.getTCRPropValue("PROJECT_REPO"));
	
	List<String> nodeList = new ArrayList<String>();
	nodeList.add("Global Test Repository");
	nodeList.add("Global Imported Testcase");
	zeNavigator.navigateToNodeInGlobalTCC(nodeList);
	zeNavigator.DnDGlobalTestcaseToLocalRelease(Config.getTCRPropValue("PROJECT_REPO"), "Global Imported Testcase", null);
	isSuccess = true;
	logger.info("bvt278 is executed successfully.");
	
	
}

@Test (enabled= testEnabled, priority=278)
public void bvt279VerifyShareOptionNotPresentincontextMenu()
{
	logger.info("Executing bvt279...");
	altID = 279;
//	zeNavigator.logout();
//	zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_USERNAME"));
	zeNavigator.launchGlobalRepository();
	zeNavigator.launchGlobalApps("Test Repository");
	List<String> phases = new ArrayList<String>();
	phases.add(Config.getTCRPropValue("GLOBAL_REPO"));
	
	String optionName = "Share from Project Releases";
	Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
	Assert.assertTrue(zeNavigator.VerifyToReleaseOptionsNotpresent(optionName,Config.getTCRPropValue("GLOBAL_REPO") ));
	isSuccess = true;
	logger.info("bvt279 is executed successfully.");
	
}
	

	@BeforeMethod
	public void beforeMethod() {
	
		isSuccess = false;
	}

	@AfterMethod
	public void afterMethod() {
		baseAfterMethod();
		if(!isSuccess){
			zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
			CommonUtil.normalWait(7000);
			//zeNavigator.launchAdministration();
		}
		}
	

	@BeforeClass
	public void beforeClass() {
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
	}
	
	@AfterClass
	public void afterClass() {
		zeNavigator.logout();
	}
}

