package com.thed.zeuihtml.ze.impl.zehtmlpages;

import java.io.File;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;

public class TestExecutionPage {

	Logger logger;

	public TestExecutionPage() {
		logger = Logger.getLogger(this.getClass());
	}

	public static TestExecutionPage getInstance() {
		return PageFactory.initElements(Driver.driver, TestExecutionPage.class);
	}

	/******************************************************
	 * WEBELEMENTS
	 *****************************************************/

	@FindBy(xpath = "//span[text()='Change Bulk Status']")
	private WebElement dropdownSelectStatusToBulkExecute;

	@FindBy(xpath = "//*[@id='testcase-details']//a[text()='Test Step']")
	private WebElement headerStepDetails;

	@FindBy(xpath = "//button[text()='Execute']")
	private WebElement buttonExecuteInExecuteTestcasePopup;

	@FindBy(xpath = "//button[text()='Execute']/preceding-sibling::button[text()='Cancel']")
	private WebElement buttonCancelInExecuteTestcasePopup;

	@FindBy(xpath = "//div[@class='attachments-wrapper']//input[@name='releaseTestSchedule']/parent::form/parent::div//input[@id='uploadFilereleaseTestScheduletce']")
	private WebElement executionAttachmentUploadLink;

	@FindBy(xpath = "//*[@id='_build']/div/strong[text()='Build:']")
	private WebElement labelBuild;

	@FindBy(xpath = ".//*[@id='_environment']/div/strong[text()='Environment:']")
	private WebElement labelEnvironment;

	@FindBy(xpath = "//strong[text()='Change multiple :']")
	private WebElement labelChangeMultiple;

	@FindBy(xpath="//*[@id='anyoneCheck']/following-sibling::label/b[text()='Include Anyone']")
	private WebElement includeAnyone;
	
	@FindBy(xpath = "//span[normalize-space(text())='E']")
	private WebElement buttonE;

	@FindBy(xpath = "//button[@id='zui-export-modal-trigger-tcr_5']")
	private WebElement buttonExport;

	@FindBy(xpath = "//i[contains(@class,'zui-search-icon')]")
	private WebElement iconMagnifyingGlassInSearch;

	@FindBy(xpath = "//h3[normalize-space(text())='Search']")
	private WebElement headerSearch;

	@FindBy(xpath = "//label[@for='zui-search-quick']/span[text()='Quick']")
	private WebElement labelQuick;

	@FindBy(xpath = "//label[@for='zui-search-zql']/span[text()='Advanced']")
	private WebElement labelAdvanced;

	@FindBy(xpath = "//input[@id='zui-search-textarea']")
	private WebElement textareaQuickSearch;

	@FindBy(xpath = "//input[@id='zql-search-input-req-search']")
	private WebElement textBoxZqlSearch;

	@FindBy(xpath = "//zui-zephyr-search//b[text()='In this release :']")
	private WebElement labelInThisRelease;

	@FindBy(xpath = "//select[@class='zql-search-previous']")
	private WebElement selectZqlPreviousSearch;

	@FindBy(xpath = "//button[text()='Export']")
	private WebElement buttonExportInSearch;

	@FindBy(xpath = "//div[@id='grid-table-tce_search']")
	private WebElement searchGridTable;

	@FindBy(xpath = "//div[@class='zui-tcr-folder-view']//i[contains(@class,'fa-folder-open')]")
	private WebElement iconFolderView;
	
	@FindBy(xpath="//button[text()='Go']")
	private WebElement buttonGo;
	
	@FindBy(xpath="//div[@id='defect-link-modal']//h4[text()='Link Defect']")
	private WebElement headerLinkDefect;
	
	@FindBy(xpath="//span[@id='select2-searchChoice-container']")
	private WebElement dropdownDefectSearchChoice;
	
	@FindBy(xpath="//li[text()='JQL']")
	private WebElement dropdownListJQL;
	
	@FindBy(xpath="//li[text()='Defect Id']")
	private WebElement dropdownListDefectId;
	
	@FindBy(xpath="//li[text()='My Filters']")
	private WebElement dropdownListMyFilters;
	
	@FindBy(xpath="//input[@id='defectId']")
	private WebElement textboxSearchByDefectId;
	
	@FindBy(xpath="//input[@id='searchDefectsJQL']")
	private WebElement textboxSearchByDefectsJQL;
	
	@FindBy(xpath="//div[@id='defect-link-modal']//button[text()='Search']")
	private WebElement buttonSearchDefect;
	
	@FindBy(xpath="(//*[@id='defect-link-modal']//button[@class='close'])[1]")
	private WebElement buttonCloseLinkDefectWindow;
	
	@FindBy(xpath="//button[text()='Create Defect']")
	private WebElement buttonLinkNewDefect;
	
	@FindBy(xpath="//h4[text()='File New Defect']")
	private WebElement headerFileNewDefect;
	
	@FindBy(xpath="//span[@id='select2-fileNewDefectProject-container']")
	private WebElement dropdownSelectProjectInFileNewDefect;
	
	@FindBy(xpath="//label/b[text()='Issue Type']/parent::label/parent::span/following-sibling::span//span[@id='select2-issueType-container']")
	private WebElement dropdownSelectIssueTypeInFileNewDefect;
	
	@FindBy(xpath="//div[@id='defect-link-modal']//button[text()='Next']")
	private WebElement buttonNextInFileNewDefect;
	
	@FindBy(xpath="//b[text()='Summary']/parent::label/parent::span/parent::div/following-sibling::div//input")
	private WebElement textboxDefectSummary;
	
	@FindBy(xpath="//b[text()='Description']/parent::label/parent::span/parent::div/following-sibling::div//textarea")
	private WebElement textareaDescription;
	
	@FindBy(xpath="//select[@id='priority-field']/following-sibling::span")
	private WebElement dropdownSelectPriority;
	
	@FindBy(xpath="//select[@id='multiComponents-field']")
	private WebElement selectComponents;
	
	@FindBy(xpath="//button[text()='Create']")
	private WebElement buttonCreateDefect;
	
	@FindBy(xpath="//div[contains(@id,'defect-advanced-detail-modal')]//h4[contains(text(),'Update Defect :')]")
	private WebElement headerUpdateDefect;

	@FindBy(xpath="//div[contains(@id,'defect-advanced-detail-modal')]//button[text()='Cancel']")
	private WebElement buttonCancelInUpdateDefectWindow;
	
	@FindBy(xpath="//div[contains(@id,'defect-advanced-detail-modal')]//h4[contains(text(),'Update Defect :')]/parent::div/following-sibling::div/button")
	private WebElement buttonCloseUpdateDefectWindow;
	
	@FindBy(xpath="//select[@id='copySteps']")
	private WebElement selectDefectDescriptionDropdownList;
	
	@FindBy(xpath="//div[contains(@class,'contextMenuIcon')]")
	private WebElement releaseOptionsBtn;
	
	//Export
	
	@FindBy(xpath="//a[text()='Export']")
	private WebElement linkExportInContextMenu;
	
	@FindBy(xpath="//span[text()='Data (Excel only)']")
	private WebElement radioButtonDataExcel;
		
	@FindBy(xpath="//span[text()='Detailed']")
	private WebElement radioButtonDetailed;
		
	@FindBy(xpath="//span[text()='HTML']")
	private WebElement radioButtonHtml;
		
	@FindBy(xpath="//span[text()='PDF']")
	private WebElement radioButtonPdf;
		
	@FindBy(xpath="//span[text()='Word']")
	private WebElement radioButtonWord;
		
	@FindBy(xpath="//span[text()='Summary']")
	private WebElement radioButtonSummary;
		
	@FindBy(xpath="//div[@id='zui-export-modal-tcr_5']//button[text()='Save']")
	private WebElement buttonSaveExport;
		
	@FindBy(xpath="//div[@id='zui-export-modal-tcr_5-download']//h4[text()='Download File']")
	private WebElement headerDownloadFileInPopup;
		
	@FindBy(xpath="//div[@id='zui-export-modal-tcr_5-download']//button[text()='Download']")
	private WebElement buttonDownload;
		
	@FindBy(xpath="//input[@id='testcase_select']")
	private WebElement checboxSelectAllTestcases;
		
	@FindBy(xpath="//input[@id='testcase_select']")
	private WebElement checkboxSelectAllExecutionInSearchWindow;
		
	@FindBy(xpath="//button[text()='Export']")
	private WebElement buttonExportFromGrid;
		
	@FindBy(xpath="//h4[text()='Customize and Export Reports']/parent::div/parent::div//button[@class='close']")
	private WebElement buttonCloseExportWindow;
		
	//Pagination
		
	@FindBy(xpath="//select[@id='pagination-page-size-tce']")
	private WebElement selectPaginationPageSize;
		
	@FindBy(xpath="//section[@id='ze-main-app']/testcase-execution//div[@class='grid-pagination']//span[text()='Next']/parent::a")
	private WebElement linkNextPage;
			
	@FindBy(xpath="//section[@id='ze-main-app']/testcase-execution//div[@class='grid-pagination']//span[text()='Prev']/parent::a")
	private WebElement linkPrevPage;
		
	@FindBy(xpath="//span[@class='zephyr-inline-field-name']")
	private WebElement detailSearchSummary;
	
	@FindBy(xpath="//select[@id='defectFiltersDropdown']/following-sibling::span")
	private WebElement selectFilter;
	
	@FindBy(xpath="//div[@class='defects-search-container']//button[text()='Search']")
	private WebElement buttonSearchInAdvance;
	
	//Bulk Execute the steps

	
	@FindBy(xpath=".//*[@id='testcase_select_all']")
	private WebElement bulkSelectionSteps;

	@FindBy(xpath="//div[@class='pull-right step-status-details']//span[text()='Change Bulk Status']")
	private WebElement stepBulkStatusDropdown;
	
	@FindBy(xpath=".//*[@id='execute-testcase-tce']//button[text()='Execute']")
	private WebElement executeTestcasepopup;
	
	
	/******************************************************
	 * Methods
	 * 
	 * @return
	 *****************************************************/

	public boolean navigateToNodesInTestExecution(List<String> nodeList) {
		int totalNodeCount = 0;
		for (String nodeName : nodeList) {
			totalNodeCount++;
			if (totalNodeCount == nodeList.size()) {
				CommonUtil.returnWebElement(
						"//a[@data-name='" + nodeName + "']").click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(2000);
				HomePage.getInstance().waitForProgressBarToComplete();
			} else {
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
				String areaExpanded = CommonUtil.returnWebElement(
						"//a[@data-name='" + nodeName + "']/parent::li")
						.getAttribute("aria-expanded");
				System.out.println(nodeName + " : area expanded "
						+ areaExpanded);
				if (areaExpanded != null) {
					if (areaExpanded.equals("true")) {
						logger.info(nodeName = " Node is already Expanded.");
					} else {
						// CommonUtil.returnWebElement("//a[@data-name='"+nodeName+"']").click();
						// CommonUtil.normalWait(1000);
						HomePage.getInstance().waitForProgressBarToComplete();
						WebElement we = CommonUtil
								.returnWebElement("//a[@data-name='" + nodeName
										+ "']/preceding-sibling::i");
						CommonUtil.normalWait(1000);
						we.click();
						HomePage.getInstance().waitForProgressBarToComplete();
						// CommonUtil.doubleClick(we);
						CommonUtil.normalWait(1000);
						logger.info("Waiting for the child Node.");
						CommonUtil
								.visibilityOfElementLocated("//a[@data-name='"
										+ nodeName
										+ "']//following-sibling::ul");
						logger.info("Expanded the Node " + nodeName
								+ " successfully");
					}
				} else {

					CommonUtil.normalWait(1000);
					CommonUtil.returnWebElement(
							"//a[@data-name='" + nodeName + "']").click();
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.normalWait(1000);

					if (!CommonUtil.isElementPresent("//a[@data-name='"
							+ nodeName + "']/following-sibling::ul")) {
						WebElement we = CommonUtil
								.returnWebElement("//a[@data-name='" + nodeName
										+ "']/preceding-sibling::i");
						System.out.println("Expand Icon for " + nodeName
								+ " found: " + we);
						if (we != null) {
							we.click();
							HomePage.getInstance()
									.waitForProgressBarToComplete();
						}
					}
				}
			}

		}

		return true;
	}

	public boolean verifyAssignedTestcaseInSelectedNodeInTCE(
			String testcaseName, String assingedTo, String status) {

		try {

			Assert.assertTrue(
					CommonUtil
							.visibilityOfElementLocated("//div[@id='grid-table-tce']//div[text()='"
									+ testcaseName + "']"),
					"Testcase not found in assingment grid in TCE by name: "
							+ testcaseName);

			if (assingedTo != null) {
				Assert.assertTrue(
						CommonUtil
								.visibilityOfElementLocated("//div[@id='grid-table-tce']//div[text()='"
										+ testcaseName
										+ "']/parent::div/parent::div/following-sibling::div//div[normalize-space(@title)='"
										+ assingedTo + "']"),
						"Assignee of Testcase: " + testcaseName
								+ " not found as " + assingedTo);
			}

			if (status != null) {
				Assert.assertTrue(
						CommonUtil
								.visibilityOfElementLocated("//div[@id='grid-table-tce']//div[text()='"
										+ testcaseName
										+ "']/parent::div/parent::div/following-sibling::div//span[normalize-space(text())='"
										+ status + "']"), "Status of Testcase: "
								+ testcaseName + " not found as " + status);
			}
			
			

		} catch (Exception e) {
			logger.info("Failed to verify Assigned testcase in Test Execution grid");
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean executeTestcaseInSelectedNodeAndVerify(String testcaseName,
			String status) {
		try {
		HomePage.getInstance().waitForProgressBarToComplete();
			logger.info("Going to verify testcase name in grid by name: "
					+ testcaseName);
			Assert.assertTrue(
					CommonUtil
							.visibilityOfElementLocated("//div[@id='grid-table-tce']//div[text()='"
									+ testcaseName + "']"),
					"Testcase not found in assingment grid in TCE by name: "
							+ testcaseName);
			logger.info("Verified testcase name in grid");

			Assert.assertTrue(
					CommonUtil
							.visibilityOfElementLocated("//div[@id='grid-table-tce']//div[text()='"
									+ testcaseName
									+ "']/parent::div/parent::div/following-sibling::div[6]//span[@placeholder='Enter value']"),
					"Status element not found to click and execute testcase");
			CommonUtil.normalWait(1000);
			WebElement statusElement = CommonUtil
					.returnWebElement("//div[@id='grid-table-tce']//div[text()='"
							+ testcaseName
							+ "']/parent::div/parent::div/following-sibling::div[7]//span[@placeholder='Enter value']");
			CommonUtil.moveToElement(statusElement);
			CommonUtil.normalWait(1000);
			WebElement statusDropdownIcon = CommonUtil
					.returnWebElement("//div[@id='grid-table-tce']//div[text()='"+ testcaseName+ "']/parent::div/parent::div/following-sibling::div[7]//span[@placeholder='Enter value']/following-sibling::span");
			logger.info("Moving to Status dropdown");
			CommonUtil.moveToElement(statusDropdownIcon);
			logger.info("Going to click on Status dropdown");
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			statusDropdownIcon.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			logger.info("Clicked Status dropdown successfully");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//span[@class='select2-results']/ul/li[text()='"+ status + "']"),
					"Status not found in dropdown by name: " + status);
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement(
					"//span[@class='select2-results']/ul/li[text()='" + status + "']")
					.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);

			WebElement actulStatus = CommonUtil
					.returnWebElement("//div[@id='grid-table-tce']//div[text()='"
							+ testcaseName
							+ "']/parent::div/parent::div/following-sibling::div[7]//span[@placeholder='Enter value']/span");

			Assert.assertTrue(actulStatus.getText().equals(status),
					"Status not updated to: " + status + " Status found as: "
							+ actulStatus.getText());

		} catch (Exception e) {
			logger.info("Failed to execute testcase cleanly");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean verifyTestcaseExecutionStatus(String testcaseName, String status) {
		try {
				CommonUtil.normalWait(1000);
				WebElement actulStatus = CommonUtil.returnWebElement("//div[@id='grid-table-tce']//div[text()='"
							+ testcaseName
							+ "']/parent::div/parent::div/following-sibling::div[7]//span[@placeholder='Enter value']/span");

				Assert.assertTrue(actulStatus.getText().equals(status),
					"Status not updated to: " + status + " Status found as: "
							+ actulStatus.getText());

		} catch (Exception e) {
			logger.info("Failed to verify Testcase Execution Status");
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean bulkExecuteTestcaseInSelectedNodeAndVerify(
			List<String> testNames, String status) {

		try {
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			for (String testcaseName : testNames) {
				logger.info("Going to verify testcase name in grid by name: "
						+ testcaseName);
				Assert.assertTrue(
						CommonUtil
								.visibilityOfElementLocated("//div[@id='grid-table-tce']//div[text()='"
										+ testcaseName + "']"),
						"Testcase not found in assingment grid in TCE by name: "
								+ testcaseName);
				logger.info("Verified testcase name in grid");

				List<WebElement> testcaseCheckboxByName = CommonUtil
						.returnWebElements("//div[@id='grid-table-tce']//div[text()='"
								+ testcaseName
								+ "']/parent::div/parent::div/preceding-sibling::div//input[@name='testcase_select']");

				for (WebElement checkbox : testcaseCheckboxByName) {
					checkbox.click();
					CommonUtil.normalWait(1000);
				}

			}

			dropdownSelectStatusToBulkExecute.click();
			CommonUtil.normalWait(1000);

			Assert.assertTrue(
					CommonUtil
							.visibilityOfElementLocated("//ul[@class='select2-results__options']/li[text()='"
									+ status + "']"), "Status " + status
							+ " not found in dropdown while bulk execution");

			CommonUtil.returnWebElement(
					"//ul[@class='select2-results__options']/li[text()='"
							+ status + "']").click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);

			for (String testcaseName : testNames) {
				verifyAssignedTestcaseInSelectedNodeInTCE(testcaseName, null,
						status);
			}

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean addExecutionAttachmentsNotesActualTime(String testcaseName,
			String attachmentFileWithPath, String notes, String actualTime) {
		try {

			logger.info("Going to verify testcase name in grid by name: "
					+ testcaseName);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-tce']//div[text()='"
							+ testcaseName + "']"),"Testcase not found in assingment grid in TCE by name: "+ testcaseName);
			logger.info("Verified testcase name in grid");

			WebElement testcaseNameElement = CommonUtil.returnWebElement("//div[@id='grid-table-tce']//div[text()='"
							+ testcaseName + "']");
			WebElement testcaseIdElement = CommonUtil
					.returnWebElement("//div[@id='grid-table-tce']//div[text()='Add attachment to testcase']/parent::div/parent::div/preceding-sibling::div[1]");

			testcaseNameElement.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);

			if (attachmentFileWithPath != null) {
				CommonUtil.scrollToWebElement(executionAttachmentUploadLink);
				CommonUtil.normalWait(1000);
				File file = new File(attachmentFileWithPath);
				System.out.println(file.getAbsolutePath());
				executionAttachmentUploadLink.sendKeys(file.getAbsolutePath());
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(2000);
			}

			if (notes != null) {

			}

			if (actualTime != null) {

			}

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean executeTestStepAndVerify(String testcaseName, String stepId,
			String status, boolean expandStepsSection,
			boolean expectedExecuteTestcasePopup, String executeTestcaseStatus) {

		try {
			logger.info("Going to verify testcase name in grid by name: "+ testcaseName);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-tce']//div[text()='"
									+ testcaseName + "']"),"Testcase not found in assingment grid in TCE by name: "+ testcaseName);
			logger.info("Verified testcase name in grid");
			
			WebElement testcaseNameElement = CommonUtil
					.returnWebElement("//div[@id='grid-table-tce']//div[text()='"+ testcaseName + "']");
			WebElement testcaseIdElement = CommonUtil
					.returnWebElement("//div[@id='grid-table-tce']//div[text()='"+ testcaseName + "']/parent::div/parent::div/preceding-sibling::div[1]");
			WebElement testcaseOlderStatusElement = CommonUtil
					.returnWebElement("//div[@id='grid-table-tce']//div[text()='"+ testcaseName + "']/parent::div/parent::div/following-sibling::div//span[contains(@class,'zephyr-inline-field-name')]/span");
			CommonUtil.moveToElement(testcaseNameElement);
			testcaseNameElement.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);

			CommonUtil.moveToElement(headerStepDetails);
			CommonUtil.normalWait(1000);

			if (expandStepsSection) {
				headerStepDetails.click();
				CommonUtil.normalWait(1000);
			}
			CommonUtil
					.visibilityOfElementLocated("//div[@class='zee-testcase-steps-wrapper']//div[text()='"+ stepId
							+ "']/parent::div/parent::div/following-sibling::div//span[@placeholder='Enter value']");

			WebElement statusDropdown = CommonUtil.returnWebElement("//div[@class='zee-testcase-steps-wrapper']//div[text()='"
							+ stepId+ "']/parent::div/parent::div/following-sibling::div//span[@placeholder='Enter value']");
			CommonUtil.moveToElement(statusDropdown);
			CommonUtil.normalWait(500);

			WebElement statusDropdownIcon = CommonUtil
					.returnWebElement("//div[@class='zee-testcase-steps-wrapper']//div[text()='"+ stepId
							+ "']/parent::div/parent::div/following-sibling::div//span[@placeholder='Enter value']/following-sibling::span");

			CommonUtil.moveToElement(statusDropdownIcon);
			CommonUtil.normalWait(500);

			statusDropdownIcon.click();

			Assert.assertTrue(
					CommonUtil
							.visibilityOfElementLocated("//ul[@class='select2-results__options']/li[text()='"
									+ status + "']"), "Status : " + status+ " not found in step status dropdown");
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement("//ul[@class='select2-results__options']/li[text()='"+status+"']").click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);
			
		
			if (expectedExecuteTestcasePopup) {
				//Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//zui-modal-body/span[normalize-space(text())='All Steps are updated to']/following-sibling::span[normalize-space(text())='"+ status + "']"),"After Executing all steps to status: "+ status+ " Execute Testcase Popup displaying incorrect status in statement");

				/*if (status.equals("Pass") || status.equals("Fail")
						|| status.equals("WIP") || status.equals("Blocked")) {
					Assert.assertTrue(
							CommonUtil
									.visibilityOfElementLocated("//zui-modal-body/span[normalize-space(text())='All Steps are updated to']/following-sibling::span[normalize-space(text())='"
											+ status+ "']/following-sibling::div//span[text()='"+ status + "']"),
							"After Executing all steps to status: "+ status+ " Execute Testcase Popup displaying incorrect status in dropdown");

				} else {
					Assert.assertTrue(
							CommonUtil
									.visibilityOfElementLocated("//zui-modal-body/div//span[text()='Pass']"),
							"After Executing all steps to status: "+ status
									+ " Execute Testcase Popup displaying incorrect status in dropdown");
				}*/

				if (executeTestcaseStatus != null) {
					if (status.equals(executeTestcaseStatus)) {
						buttonExecuteInExecuteTestcasePopup.click();
						HomePage.getInstance().waitForProgressBarToComplete();
						CommonUtil.normalWait(1000);
					} else {
						CommonUtil.normalWait(1000);
						CommonUtil
								.returnWebElement(
										"//zui-modal-body/div//span[text()='"
												+ status + "']").click();
						CommonUtil.normalWait(1000);
						CommonUtil.returnWebElement(
								"//ul[@class='select2-results__options']/li[text()='"
										+ executeTestcaseStatus + "']").click();
						CommonUtil.normalWait(1000);
						buttonExecuteInExecuteTestcasePopup.click();
						HomePage.getInstance().waitForProgressBarToComplete();
						CommonUtil.normalWait(1000);
					}
				} else {
					buttonCancelInExecuteTestcasePopup.click();
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.normalWait(1000);
				}
			}

			WebElement executedStatus = CommonUtil
					.returnWebElement("//div[@class='zee-testcase-steps-wrapper']//div[text()='"
							+ stepId
							+ "']/parent::div/parent::div/following-sibling::div//span[@placeholder='Enter value']/span");

			Assert.assertTrue(executedStatus.getText().equals(status),
					"Step Executed Steps status not matching, Expected: "
							+ status + " found Actual Status: "
							+ executedStatus.getText());

			/*if (expectedExecuteTestcasePopup) {
				if (executeTestcaseStatus != null) {
					CommonUtil.moveToElement(testcaseIdElement);
					WebElement actulTestStatus = CommonUtil
							.returnWebElement("//div[@id='grid-table-tce']//div[text()='"
									+ testcaseIdElement.getText()
									+ "']/parent::div/parent::div/following-sibling::div[5]//span[@placeholder='Enter value']/span");
					Assert.assertTrue(
							actulTestStatus.getText().equals(
									executeTestcaseStatus),
							"Status not updated to: " + executeTestcaseStatus
									+ " Status found as: "
									+ actulTestStatus.getText());
				} else {
					CommonUtil.moveToElement(testcaseIdElement);
					WebElement actulTestStatus = CommonUtil.returnWebElement("//div[@id='grid-table-tce']//div[text()='"
									+ testcaseIdElement.getText()
									+ "']/parent::div/parent::div/following-sibling::div[5]//span[@placeholder='Enter value']/span");
					Assert.assertTrue(actulTestStatus.getText().equals(testcaseOlderStatusElement.getText()),
									"Status got updated to: " + actulTestStatus+ " Status should remain to older status: "
									+ testcaseOlderStatusElement.getText());
				}
			}*/

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		HomePage.getInstance().waitForProgressBarToComplete();
		return true;

	}
	
	public boolean verifyTeststepExecutionStatus(String testcaseName, String stepId, String status, boolean expandStepsSection,
			boolean expectedExecuteTestcasePopup, String executeTestcaseStatus) {

		try {
			logger.info("Going to verify testcase name in grid by name: "
					+ testcaseName);
			Assert.assertTrue(
					CommonUtil
							.visibilityOfElementLocated("//div[@id='grid-table-tce']//div[text()='"
									+ testcaseName + "']"),
					"Testcase not found in assingment grid in TCE by name: "
							+ testcaseName);
			logger.info("Verified testcase name in grid");

			WebElement testcaseNameElement = CommonUtil
					.returnWebElement("//div[@id='grid-table-tce']//div[text()='"+ testcaseName + "']");
			WebElement testcaseIdElement = CommonUtil
					.returnWebElement("//div[@id='grid-table-tce']//div[text()='"+ testcaseName + "']/parent::div/parent::div/preceding-sibling::div[1]");
			WebElement testcaseOlderStatusElement = CommonUtil
					.returnWebElement("//div[@id='grid-table-tce']//div[text()='"+ testcaseName + "']/parent::div/parent::div/following-sibling::div//span[contains(@class,'zephyr-inline-field-name')]/span");

			testcaseNameElement.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);

			CommonUtil.moveToElement(headerStepDetails);
			CommonUtil.normalWait(1000);

			if (expandStepsSection) {
				headerStepDetails.click();
				CommonUtil.normalWait(1000);
			}

			WebElement executedStatus = CommonUtil
					.returnWebElement("//div[@class='zee-testcase-steps-wrapper']//div[text()='"
							+ stepId
							+ "']/parent::div/parent::div/following-sibling::div//span[@placeholder='Enter value']/span");

			Assert.assertTrue(executedStatus.getText().equals(status),
					"Step Executed Steps status not matching, Expected: "
							+ status + " found Actual Status: "
							+ executedStatus.getText());

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;

	}

	public boolean switchExecutionViewAndVerify(String folderOrSearch){
		try{
			if(folderOrSearch.equalsIgnoreCase("Search")){
				
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.moveToElement(iconMagnifyingGlassInSearch);
				iconMagnifyingGlassInSearch.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
			
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(labelQuick)
						, "Label Quick not found in Search View");
				
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(labelAdvanced)
						, "Label Advance not found in Search View");
				
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(labelInThisRelease)
						, "Label 'In This Release' not found in Search View");
				
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonExportInSearch)
						, "Button Export not found in Search View");
				
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(searchGridTable)
						, "Search Execution grid table not found in Search View");
				
			}else{
				if(folderOrSearch.equalsIgnoreCase("Folder")){
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.moveToElement(iconFolderView);
					iconFolderView.click();
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.normalWait(1000);
					
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(labelBuild)
							, "Label Build not found in folder view");
					
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(labelEnvironment)
							, "Label Environment not found in folder view");
					
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(includeAnyone)
							, "Label Include Anyone not found in folder view");
					
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(buttonExport)
							, "Button Export not found in folder view");
					
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}

		public boolean executionSearchAndVerifyTestcase(String searchTypeQuickOrAdvanced, String searchQuery, List<String> testcaseNamesToVerify){
			try{
				
				if(searchTypeQuickOrAdvanced.equalsIgnoreCase("Quick")){
					CommonUtil.normalWait(1000);
					labelQuick.click();
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.normalWait(1000);
					
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textareaQuickSearch)
							, "Text Area not found for quick search");
					
					textareaQuickSearch.sendKeys(searchQuery);
					CommonUtil.normalWait(1000);
					buttonGo.click();
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.normalWait(1000);
					
					
				}else{
					if(searchTypeQuickOrAdvanced.equalsIgnoreCase("Advanced")){
						CommonUtil.normalWait(1000);
						labelAdvanced.click();
						HomePage.getInstance().waitForProgressBarToComplete();
						CommonUtil.normalWait(1000);
						
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textBoxZqlSearch)
								, "Textbox not found for Zql search");
						
						textBoxZqlSearch.sendKeys(searchQuery);
						CommonUtil.normalWait(1000);
						buttonGo.click();
						HomePage.getInstance().waitForProgressBarToComplete();
						CommonUtil.normalWait(1000);
						
					}
				}
				
				for(String testcaseName : testcaseNamesToVerify){
					
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-tce_search']//div[text()='"+testcaseName+"']" , 5)
							, "Testcase not found after Search  by name: " +testcaseName);
					
				}	
				
			}catch(Exception e){
				e.printStackTrace();
				return false;
			}
			return true;
		}
		
		public boolean verifyTestExecutionDetailInGrid(String testcaseName,String version)
		{
		try {
			if(testcaseName!=null) {
				
			
			logger.info("Going to verify testcase name in grid by name: "
					+ testcaseName);
			Assert.assertTrue(
					CommonUtil
							.visibilityOfElementLocated("//div[@id='grid-table-tce']//div[text()='"
									+ testcaseName + "']"),
					"Testcase not found in assingment grid in TCE by name: "
							+ testcaseName);
			logger.info("Verified testcase name in grid");
			}
			
			if(version!=null) {
				logger.info("Going to verify testcase version in grid by Version: "
						+ version);
				Assert.assertTrue(
						CommonUtil
								.visibilityOfElementLocated("//div[@id='grid-table-tce']//div[text()='"
										+ version + "']"),
						"Testcase not found in assingment grid in TCE by version: "
								+ version);
				logger.info("Verified testcase version in grid");
			}
			
			
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
		
		}
			
	
		
		
		public boolean verifyTestExecutionDetailsInSearch(String testcaseName, Map<String, String> values){
			try{
			//	Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-tce_search']//div[text()='"+testcaseName+"']")
				//		, "Testcase not found after Search  by name: " +testcaseName);
				
				
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//*[@id='grid-table-tce_search']//div[@class ='flex-data-item ellipsis td-show']//div[contains(text(),'"+testcaseName+"')]")
								, "Testcase not found after Search  by name: " +testcaseName);
				
				
				
				
				//CommonUtil.returnWebElement("//*[@id='grid-table-tce_search']//div[@class ='grid-column-div']/div[contains(text(),'"+testcaseName+"')]").click();
				//HomePage.getInstance().waitForProgressBarToComplete();
				
				//CommonUtil.normalWait(1000);
				
				//Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//*[@id='grid-table-tce_search']//div[text()='"+testcaseName+"']"), "Testcase name not found in details view below search execution grid by name");
				/*if(values!=null){
					if(values.containsKey("Status")){
						
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//span[@id='type-val']//span[@title='"+values.get("Status")+"']")
								, "Testcase Status "+values.get("Status")+" not found in details in search");
						
					}
					
					//Inprogress to add other fields.
				}*/
				
				
			}catch(Exception e){
				e.printStackTrace();
				return false;
			}
			return true;
		}
	
		public boolean searchAndLinkDefect(String testcaseName, String searchChoice, String searchValue, String defectSummary, String defectID) {
			try {
				
				launchLinkDefectWindow(testcaseName);
				
				dropdownDefectSearchChoice.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
				
				
				if(searchChoice.equals("Defect Id")){
					dropdownListDefectId.click();
					CommonUtil.normalWait(1000);
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textboxSearchByDefectId), "Textbox Search By Defect ID not found");
					textboxSearchByDefectId.sendKeys(searchValue);
				}else{
					if(searchChoice.equals("JQL")){
						dropdownListJQL.click();
						CommonUtil.normalWait(1000);
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textboxSearchByDefectsJQL), "Textbox Search By Defect JQL not found");
						textboxSearchByDefectsJQL.sendKeys(searchValue);
					}else{
						if(searchChoice.equals("My Filters")){
							dropdownListMyFilters.click();
							CommonUtil.normalWait(5000);
							HomePage.getInstance().waitForProgressBarToComplete();
							CommonUtil.normalWait(5000);
							selectFilter.click();
							
							CommonUtil.normalWait(4000);
							CommonUtil.returnWebElement(".//*[@id='select2-defectFiltersDropdown-results']/li[text()='"+searchValue+"']").click();
							buttonSearchInAdvance.click();
							CommonUtil.normalWait(5000);
							HomePage.getInstance().waitForProgressBarToComplete();
							CommonUtil.normalWait(5000);
							HomePage.getInstance().waitForProgressBarToComplete();
							
						}
					}
				}
				CommonUtil.normalWait(1000);
				buttonSearchDefect.click();
				CommonUtil.normalWait(1000);
				HomePage.getInstance().waitForProgressBarToComplete();
				
				
				if(!CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-DEFECTS_LINK_SEARCH']//div[text()='"+defectSummary+"']", 2)){
					
					//Pagination code will be written later for now assumption is that searched defect will be in first 50 results
					
					Assert.assertTrue(false,"Defect not found after search by name: " + defectSummary);
				}
				
				CommonUtil.returnWebElement("//div[@id='grid-table-DEFECTS_LINK_SEARCH']//div[text()='"+defectSummary+"']/parent::div/parent::div/following-sibling::div//span[@class='link-icon grid-icon defect-link-icon']")
				.click();
				CommonUtil.normalWait(1000);
				HomePage.getInstance().waitForProgressBarToComplete();
				
				logger.info("Going to verify linked defect");

				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-CURRENTLY_LINKED_DEFECTS']//div[text()='"+defectSummary+"']")
						, "Unable to view the linked defect under Currently Linked defects grid by defect summary: "+defectSummary);
				
				buttonCloseLinkDefectWindow.click();
				CommonUtil.normalWait(1000);
				HomePage.getInstance().waitForProgressBarToComplete();
				
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-tce']//div[text()='"+testcaseName+"']/parent::div/parent::div/following-sibling::div[8]//span[normalize-space(text())='"+defectID+"']")
						, "Defect Id not found in Defect column with ID: " + defectID + " for testcase: " + testcaseName);
				
	
			}catch(Exception e){
				e.printStackTrace();
				return false;
			}
			return true;
		}
		
		
		public boolean linkNewDefect(String testcaseName, Map<String, String> values){
			
			try{
				launchLinkDefectWindow(testcaseName);
				CommonUtil.moveToElement(buttonLinkNewDefect);
				buttonLinkNewDefect.click();
				CommonUtil.normalWait(3000);
				HomePage.getInstance().waitForProgressBarToComplete();
				
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerFileNewDefect)
						, "Header not found as File New Defect in popup after clicking on button 'Link New Defect'");
				
				CommonUtil.normalWait(1000);
				
				if(values.containsKey("Project")){
					CommonUtil.moveToElement(dropdownSelectProjectInFileNewDefect);
					dropdownSelectProjectInFileNewDefect.click();
					CommonUtil.normalWait(1000);
					CommonUtil.returnWebElement("//li[text()='"+values.get("Project")+"']").click();
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.normalWait(1000);
				}
				
				if(values.containsKey("Issue Type")){
					CommonUtil.moveToElement(dropdownSelectIssueTypeInFileNewDefect);
					dropdownSelectIssueTypeInFileNewDefect.click();
					CommonUtil.normalWait(1000);
					CommonUtil.returnWebElement("//li[text()='"+values.get("Issue Type")+"']").click();
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.normalWait(3000);
					
				}
				
				buttonNextInFileNewDefect.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
	
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textboxDefectSummary), "Textbox Defect Summary not found");
				
				if(values.containsKey("Summary")){
					textboxDefectSummary.sendKeys(values.get("Summary"));
					CommonUtil.normalWait(1000);
				}else{
					Assert.assertTrue(false, "Summary of defect is mandatory");
				}
	
				if(values.containsKey("Description")){
					String description = values.get("Description");
					if(description.equals("As plain text")||description.equals("As wiki markup")){
						CommonUtil.selectListWithVisibleText(selectDefectDescriptionDropdownList, description);
					}else{
						textareaDescription.sendKeys(description);
						}
					CommonUtil.normalWait(1000);
				}
				
				if(values.containsKey("Priority")){
					dropdownSelectPriority.click();
					CommonUtil.normalWait(1000);
					CommonUtil.returnWebElement("//li[text()='"+values.get("Priority")+"']").click();
					CommonUtil.normalWait(1000);
				}
				
				if(values.containsKey("Components")){
					CommonUtil.returnWebElement("//div[@id='multiComponents-field-wrap-file-new']").click();
					CommonUtil.normalWait(1000);
					String compNameXpath = "//li[text()='"+values.get("Components")+"']";
					CommonUtil.returnWebElement(compNameXpath).click();	
					//CommonUtil.selectListWithVisibleText(selectComponents, values.get("Components"));
					CommonUtil.normalWait(1000);
				}
				
				HomePage.getInstance().waitForProgressBarToComplete();
				buttonCreateDefect.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				
				CommonUtil.visibilityOfElementLocated(headerUpdateDefect);
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.ExplicitWaitForElement(buttonCloseUpdateDefectWindow);
				buttonCloseUpdateDefectWindow.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				
				logger.info("Going to verify linked defect");

				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-CURRENTLY_LINKED_DEFECTS']//div[text()='"+values.get("Summary")+"']")
						, "Unable to view the linked defect under Currently Linked defects grid by defect summary: "+values.get("Summary"));
				
				WebElement defectKeyElement = CommonUtil.returnWebElement("//div[@id='grid-table-CURRENTLY_LINKED_DEFECTS']//div[text()='"+values.get("Summary")+"']/parent::div/parent::div/preceding-sibling::div[2]/div/div/span");
				String defectID = defectKeyElement.getText();
				CommonUtil.visibilityOfElementLocated(buttonCloseLinkDefectWindow);
				buttonCloseLinkDefectWindow.click();
				CommonUtil.normalWait(1000);
				HomePage.getInstance().waitForProgressBarToComplete();
				
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-tce']//div[text()='"+testcaseName+"']/parent::div/parent::div/following-sibling::div[8]//span[normalize-space(text())='"+defectID+"']")
						, "Defect Id not found in Defect column with ID: " + defectID + " for testcase: " + testcaseName);
				
			}catch(Exception e){
				e.printStackTrace();
				return false;
			}
			return true;
		}
		
		
		
		private boolean launchLinkDefectWindow(String testcaseName){
			
			try{
				HomePage.getInstance().waitForProgressBarToComplete();
				logger.info("Going to verify testcase name in grid by name: "
						+ testcaseName);
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-tce']//div[text()='"
						+ testcaseName + "']"),"Testcase not found in assingment grid in TCE by name: "+ testcaseName);
				logger.info("Verified testcase name in grid");

				Assert.assertTrue(
						CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-tce']//div[text()='"+ testcaseName
							+ "']/parent::div/parent::div/following-sibling::div[8]//span[normalize-space(text())='D']"),
							"D button not found to link and add defects");
				CommonUtil.normalWait(1000);
				
				CommonUtil.returnWebElement("//div[@id='grid-table-tce']//div[text()='"+ testcaseName
							+ "']/parent::div/parent::div/following-sibling::div[8]//span[normalize-space(text())='D']").click();	
			
				HomePage.getInstance().waitForProgressBarToComplete();
			
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerLinkDefect)
						, "Header link Defect not found after clicking on D button");
				HomePage.getInstance().waitForProgressBarToComplete();
				
				
			}catch(Exception e){
				e.printStackTrace();
				return false;
			}
			
			return true;
		}
		
		
		public boolean exportSelectedNodeOfTCE(String nodeName, String reportType, String outputAs){
			try{
				logger.info("Going to launch Export Window");
				CommonUtil.normalWait(1000);
				
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//a[@data-name = '" + nodeName + "']"), "Node name not found by name: "+ nodeName);
				
				WebElement we = CommonUtil.returnWebElement("//a[@data-name = '" + nodeName + "']");
				we.click();
				CommonUtil.normalWait(1000);
				CommonUtil.actionClass().moveToElement(we).build().perform();
				logger.info("Hovered on Phase successfully.");
				CommonUtil.normalWait(500);
				releaseOptionsBtn.click();
				logger.info("Clicked on Node Options on the Phase successfully.");
				CommonUtil.normalWait(5000);
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkExportInContextMenu), "Link Export not found in context menu");
				linkExportInContextMenu.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(3000);
				
				if(reportType.equalsIgnoreCase("Excel")){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDataExcel), "Excel export not found in Export window");
					radioButtonDataExcel.click();
						
				}else{
					if(reportType.equalsIgnoreCase("Summary")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonSummary), "Summary export not found in Export window");
						radioButtonSummary.click();
						
					}else{
						if(reportType.equalsIgnoreCase("Detailed")){
							Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDetailed), "Detailed export not found in Export window");
							radioButtonDetailed.click();
						}
					}
					CommonUtil.normalWait(1000);
					if(outputAs.equalsIgnoreCase("HTML")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonHtml), "HTML type not found in Export window");
						radioButtonHtml.click();
					}else{
						if(outputAs.equalsIgnoreCase("PDF")){
							Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonPdf), "PDF type not found in Export window");
							radioButtonPdf.click();
						}else{
							if(outputAs.equalsIgnoreCase("Word")){
								Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonWord), "Word type not found in Export window");
								radioButtonWord.click();
							}
						}
					}
					
				}
				CommonUtil.normalWait(1000);
				buttonSaveExport.click();
				CommonUtil.normalWait(1000);
				HomePage.getInstance().waitForProgressBarToComplete();
				
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerDownloadFileInPopup), "Header Download File not found");
				buttonDownload.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(10000);
				
			}catch(Exception e){
				logger.info("Failed to export node successfully");
				e.printStackTrace();
				return false;
			}finally {
				if(CommonUtil.visibilityOfElementLocated(buttonCloseExportWindow)) {
					buttonCloseExportWindow.click();
					CommonUtil.normalWait(3000);
				}
			}
			
			
			return true;
		}
		
		
		public boolean exportGridTestcaseOfTCE(String reportType, String outputAs){
			try{
				HomePage.getInstance().waitForProgressBarToComplete();
				logger.info("Going to launch Export Window");
				CommonUtil.normalWait(1000);
				
				checboxSelectAllTestcases.click();
				CommonUtil.normalWait(1000);
				buttonExportFromGrid.click();
				CommonUtil.normalWait(5000);
				
				if(reportType.equalsIgnoreCase("Excel")){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDataExcel), "Excel export not found in Export window");
					radioButtonDataExcel.click();
						
				}else{
					if(reportType.equalsIgnoreCase("Summary")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonSummary), "Summary export not found in Export window");
						radioButtonSummary.click();
						
					}else{
						if(reportType.equalsIgnoreCase("Detailed")){
							Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDetailed), "Detailed export not found in Export window");
							radioButtonDetailed.click();
						}
					}
					CommonUtil.normalWait(1000);
					if(outputAs.equalsIgnoreCase("HTML")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonHtml), "HTML type not found in Export window");
						radioButtonHtml.click();
					}else{
						if(outputAs.equalsIgnoreCase("PDF")){
							Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonPdf), "PDF type not found in Export window");
							radioButtonPdf.click();
						}else{
							if(outputAs.equalsIgnoreCase("Word")){
								Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonWord), "Word type not found in Export window");
								radioButtonWord.click();
							}
						}
					}
					
				}
				CommonUtil.normalWait(1000);
				buttonSaveExport.click();
				CommonUtil.normalWait(1000);
				HomePage.getInstance().waitForProgressBarToComplete();
				
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerDownloadFileInPopup), "Header Download File not found");
				buttonDownload.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(10000);
				
			}catch(Exception e){
				logger.info("Failed to export node successfully");
				e.printStackTrace();
				return false;
			}finally {
				if(CommonUtil.visibilityOfElementLocated(buttonCloseExportWindow)) {
					buttonCloseExportWindow.click();
					CommonUtil.normalWait(3000);
				}
			}
			return true;
		}
		
		
		public boolean exportAllSearchedExecutionInTCE(String reportType, String outputAs){
			try{
				HomePage.getInstance().waitForProgressBarToComplete();
				logger.info("Going to launch Export Window");
				CommonUtil.normalWait(1000);
				
				checkboxSelectAllExecutionInSearchWindow.click();
				CommonUtil.normalWait(1000);
				buttonExportFromGrid.click();
				CommonUtil.normalWait(5000);
				
				if(reportType.equalsIgnoreCase("Excel")){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDataExcel), "Excel export not found in Export window");
					radioButtonDataExcel.click();
						
				}else{
					if(reportType.equalsIgnoreCase("Summary")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonSummary), "Summary export not found in Export window");
						radioButtonSummary.click();
						
					}else{
						if(reportType.equalsIgnoreCase("Detailed")){
							Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonDetailed), "Detailed export not found in Export window");
							radioButtonDetailed.click();
						}
					}
					CommonUtil.normalWait(1000);
					if(outputAs.equalsIgnoreCase("HTML")){
						Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonHtml), "HTML type not found in Export window");
						radioButtonHtml.click();
					}else{
						if(outputAs.equalsIgnoreCase("PDF")){
							Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonPdf), "PDF type not found in Export window");
							radioButtonPdf.click();
						}else{
							if(outputAs.equalsIgnoreCase("Word")){
								Assert.assertTrue(CommonUtil.visibilityOfElementLocated(radioButtonWord), "Word type not found in Export window");
								radioButtonWord.click();
							}
						}
					}
					
				}
				CommonUtil.normalWait(1000);
				buttonSaveExport.click();
				CommonUtil.normalWait(1000);
				HomePage.getInstance().waitForProgressBarToComplete();
				
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerDownloadFileInPopup), "Header Download File not found");
				buttonDownload.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(10000);
				
			}catch(Exception e){
				logger.info("Failed to export node successfully");
				e.printStackTrace();
				return false;
			}finally {
				if(CommonUtil.visibilityOfElementLocated(buttonCloseExportWindow)) {
					buttonCloseExportWindow.click();
					CommonUtil.normalWait(3000);
				}
			}
			return true;
		}
		
		public boolean setPageSizeInTCEGrid(String size) {
			try {
				
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
				CommonUtil.selectListWithVisibleText(selectPaginationPageSize, size);
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
				
			}catch (Exception e) {
				logger.info("Failed to change page size to: "+ size);
				e.printStackTrace();
				return false;
			}
			return true;
		}
		
		public boolean navigateToNextOrPrevPageInTCEGrid(String nextOrPrev) {
			try {
				if(nextOrPrev.equalsIgnoreCase("Next")) {
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkNextPage), "Link Next page not found");
					linkNextPage.click();
				}else {
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(linkPrevPage), "Link Prev page not found");
					linkPrevPage.click();
				}
				CommonUtil.normalWait(1000);
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
			}catch (Exception e) {
				logger.info("Failed to navigate ot "+nextOrPrev+" Page.");
				e.printStackTrace();
				return false;
			}
			return true;
		}
		
		public boolean bulkexecuteSteps(String testcaseName, 
				String status, boolean expandStepsSection) {
			try {
				logger.info("Going to verify testcase name in grid by name: "+ testcaseName);
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-tce']//div[text()='"
										+ testcaseName + "']"),"Testcase not found in assingment grid in TCE by name: "+ testcaseName);
				logger.info("Verified testcase name in grid");
				
				WebElement testcaseNameElement = CommonUtil
						.returnWebElement("//div[@id='grid-table-tce']//div[text()='"+ testcaseName + "']");
				WebElement testcaseIdElement = CommonUtil
						.returnWebElement("//div[@id='grid-table-tce']//div[text()='"+ testcaseName + "']/parent::div/parent::div/preceding-sibling::div[1]");
				WebElement testcaseOlderStatusElement = CommonUtil
						.returnWebElement("//div[@id='grid-table-tce']//div[text()='"+ testcaseName + "']/parent::div/parent::div/following-sibling::div//span[contains(@class,'zephyr-inline-field-name')]/span");
				CommonUtil.moveToElement(testcaseNameElement);
				testcaseNameElement.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);

				CommonUtil.moveToElement(headerStepDetails);
				CommonUtil.normalWait(1000);

				if (expandStepsSection) {
					headerStepDetails.click();
					CommonUtil.normalWait(1000);
				}
					bulkSelectionSteps.click();
					CommonUtil.normalWait(1000);
					stepBulkStatusDropdown.click();
					CommonUtil.returnWebElement("//span[@class='select2-results']//li[text()='"+status+"']").click();
					CommonUtil.normalWait(2000);
					//executeTestcasepopup.click();
					Assert.assertEquals(CommonUtil.getText("//*[@id='execute-testcase-tce']//span[@class='bold-font']"), status);
					executeTestcasepopup.click();
					
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
			HomePage.getInstance().waitForProgressBarToComplete();	
					
			
			return true;
		}
		
		public boolean bulkexecuteStepsUsingHotKey(String testcaseName, boolean expandStepsSection) {
			try {
				logger.info("Going to verify testcase name in grid by name: "+ testcaseName);
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-tce']//div[text()='"
										+ testcaseName + "']"),"Testcase not found in assingment grid in TCE by name: "+ testcaseName);
				logger.info("Verified testcase name in grid");
				
				WebElement testcaseNameElement = CommonUtil
						.returnWebElement("//div[@id='grid-table-tce']//div[text()='"+ testcaseName + "']");
				WebElement testcaseIdElement = CommonUtil
						.returnWebElement("//div[@id='grid-table-tce']//div[text()='"+ testcaseName + "']/parent::div/parent::div/preceding-sibling::div[1]");
				WebElement testcaseOlderStatusElement = CommonUtil
						.returnWebElement("//div[@id='grid-table-tce']//div[text()='"+ testcaseName + "']/parent::div/parent::div/following-sibling::div//span[contains(@class,'zephyr-inline-field-name')]/span");
				CommonUtil.moveToElement(testcaseNameElement);
				testcaseNameElement.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);

				CommonUtil.moveToElement(headerStepDetails);
				CommonUtil.normalWait(1000);

				if (expandStepsSection) {
					headerStepDetails.click();
					CommonUtil.normalWait(1000);
				}
					bulkSelectionSteps.click();
					CommonUtil.normalWait(1000);
					CommonUtil.actionClass().keyDown(Keys.CONTROL).sendKeys("2").keyUp(Keys.CONTROL).perform();
				//	CommonUtil.actionClass().sendKeys(Keys.NUMPAD2).perform();
					executeTestcasepopup.click();
					
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
			HomePage.getInstance().waitForProgressBarToComplete();	
					return true;
			}
		public boolean autoUpadteStatusbulkexecuteSteps(String testcaseName, 
				String status, boolean expandStepsSection) {
			try {
				logger.info("Going to verify testcase name in grid by name: "+ testcaseName);
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-tce']//div[text()='"
										+ testcaseName + "']"),"Testcase not found in assingment grid in TCE by name: "+ testcaseName);
				logger.info("Verified testcase name in grid");
				
				WebElement testcaseNameElement = CommonUtil
						.returnWebElement("//div[@id='grid-table-tce']//div[text()='"+ testcaseName + "']");
				WebElement testcaseIdElement = CommonUtil
						.returnWebElement("//div[@id='grid-table-tce']//div[text()='"+ testcaseName + "']/parent::div/parent::div/preceding-sibling::div[1]");
				WebElement testcaseOlderStatusElement = CommonUtil
						.returnWebElement("//div[@id='grid-table-tce']//div[text()='"+ testcaseName + "']/parent::div/parent::div/following-sibling::div//span[contains(@class,'zephyr-inline-field-name')]/span");
				CommonUtil.moveToElement(testcaseNameElement);
				testcaseNameElement.click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);

				CommonUtil.moveToElement(headerStepDetails);
				CommonUtil.normalWait(1000);

				if (expandStepsSection) {
					headerStepDetails.click();
					CommonUtil.normalWait(1000);
				}
					bulkSelectionSteps.click();
					CommonUtil.normalWait(1000);
					stepBulkStatusDropdown.click();
					CommonUtil.returnWebElement("//span[@class='select2-results']//li[text()='"+status+"']").click();
					CommonUtil.normalWait(2000);
					//executeTestcasepopup.click();
					
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
			HomePage.getInstance().waitForProgressBarToComplete();	
					
			
			return true;
		}
		
		public String getDefectIDLinkDefect(String testcaseName) {
			String	defectID  = CommonUtil.getText(".//*[@id='grid-table-tce']//div[@class='name-as-link'][text()='"+testcaseName+"']/parent::div/parent::div/following-sibling::div//span[@class='grid_link_select_click popover-indication defect-detail-popover']");
					return defectID;
		}
		
		public String getStatusInExecution(String testcaseName) {
			String status = CommonUtil.getText(".//*[@id='grid-table-tce']//div[@class='name-as-link'][text()='"+testcaseName+"']/parent::div/parent::div/following-sibling::div//span[@class='execution-status-class text-center']");
			return status;
		}
}
