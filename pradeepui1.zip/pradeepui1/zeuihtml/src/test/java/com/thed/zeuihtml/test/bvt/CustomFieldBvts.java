package com.thed.zeuihtml.test.bvt;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.thed.zeuihtml.BaseTest;
import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.Constants;
import com.thed.zeuihtml.utils.CommonUtil;

public class CustomFieldBvts extends BaseTest{
	
	public CustomFieldBvts() {
		logger = Logger.getLogger(this.getClass());
	}
	
	@Test(enabled = testEnabled, priority = 194)
	public void bvt222_createUniqueCustomFieldInRequirement() {
		logger.info("Executing bvt222...");
		altID = 222;
		
		zeNavigator.launchAdministration();
		Assert.assertTrue(zeNavigator.launchAdminApps("Customizations"), "Failed to launch Customization App");
		
		Assert.assertTrue(zeNavigator.launchCustomizationOptions("RequirementCustomField"),
				"Failed to launch Requirement Custom Field Window");

		Assert.assertTrue(zeNavigator.addCustomField(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_UNIQUE_TEXT_1"),
				Config.getReqPropValue("TEXT_CUSTOM_FIELD_TYPE"),
				Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_UNIQUE_TEXT"), 
				true, false, Config.getProjectPropValue("DEFAULT_PROJECT"), true, false),
				"Failed to Add custom field");
		
		zeNavigator.closeCustomfield();
		
		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		String reqName = "Requirement with unique custom field value - check";
		List<String> phases = new ArrayList<String>();
		phases.add("Release 1.0");
		phases.add(Config.getReqPropValue("PHASE_3"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		CommonUtil.normalWait(1000);
		String requirementId = zeNavigator.addDefaultRequirement(Config.getReqPropValue("PHASE_3"));
		Assert.assertNotNull(requirementId, "Not added default requirement successfully.");
		Map<String, String> values = new HashMap<String, String>();
		values.put("NAME", reqName);
		zeNavigator.modifyRequirement("Untitled requirement", values,null);
		
		Map<String, String> typeNameAndValue = new HashMap<String, String>();
		typeNameAndValue.put("Text", Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_UNIQUE_TEXT_1") + Constants.CHAR_TO_SPLIT_STRING + "check");
		zeNavigator.updateRequirementCustomFieldValue(reqName , typeNameAndValue);
		
		isSuccess = true;
		logger.info("bvt222 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 195)
	public void bvt224_attemptToSaveReqWithDuplicateValueInUniqueCustomField() {
		logger.info("Executing bvt224...");
		altID = 224;
		
		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);

		String reqName = "Requirement to check duplicate unique custom field value";
		List<String> phases = new ArrayList<String>();
		phases.add("Release 1.0");
		phases.add(Config.getReqPropValue("PHASE_3"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		CommonUtil.normalWait(1000);
		String requirementId = zeNavigator.addDefaultRequirement(Config.getReqPropValue("PHASE_3"));
		Assert.assertNotNull(requirementId, "Not added default requirement successfully.");
		Map<String, String> values = new HashMap<String, String>();
		values.put("NAME", reqName);
		zeNavigator.modifyRequirement("Untitled requirement", values,null);
		
		Map<String, String> typeNameAndValue = new HashMap<String, String>();
		typeNameAndValue.put("Text", Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_UNIQUE_TEXT_1") + Constants.CHAR_TO_SPLIT_STRING + "check");
		zeNavigator.attemptToUpdateRequirementUniqueCustomFieldWithDuplicateValue(reqName , typeNameAndValue);
		
		isSuccess = true;
		logger.info("bvt224 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 196)
	public void bvt239_cloneRequirementWhichHasUniqueCustomFieldValue() {
		logger.info("Executing bvt239...");
		altID = 239;

		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		List<String> phases = new ArrayList<String>();
		phases.add("Release 1.0");
		phases.add(Config.getReqPropValue("PHASE_3"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		String reqName = "Req with unique custom field to clone";
		String requirementId = zeNavigator.addDefaultRequirement(Config.getReqPropValue("PHASE_3"));
		Assert.assertNotNull(requirementId, "Not added default requirement successfully.");
		Map<String, String> values = new HashMap<String, String>();
		values.put("NAME", reqName);
		zeNavigator.modifyRequirement("Untitled requirement", values,null);
		
		Map<String, String> typeNameAndValue = new HashMap<String, String>();
		typeNameAndValue.put("Text", Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_UNIQUE_TEXT_1") + Constants.CHAR_TO_SPLIT_STRING + "clone");
		zeNavigator.updateRequirementCustomFieldValue(reqName , typeNameAndValue);
		
		CommonUtil.normalWait(1000);
		boolean cloneReqStatus = zeNavigator.cloneRequirement(Config.getReqPropValue("PHASE_3"), requirementId);
		Assert.assertTrue(cloneReqStatus, "Not cloned Requirements successfully.");
		
		int clonedReqId = Integer.parseInt(requirementId);
		++clonedReqId;
		
		CommonUtil.normalWait(1000);
		String fieldValue = zeNavigator.getRequirementCustomFieldValue(Integer.toString(clonedReqId), typeNameAndValue);
		
		Assert.assertTrue(fieldValue.equals(""), "Cloned requirement should not have unique custom field value");		
		
		isSuccess = true;
		logger.info("bvt239 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 197)
	public void bvt226_uncheckUniqueFieldOfRequirementCustomField() {
		logger.info("Executing bvt226...");
		altID = 226;
		
		zeNavigator.launchAdministration();
		Assert.assertTrue(zeNavigator.launchAdminApps("Customizations"), "Failed to launch Customization App");
		
		Assert.assertTrue(zeNavigator.launchCustomizationOptions("RequirementCustomField"),
				"Failed to launch Requirement Custom Field Window");

		Assert.assertTrue(zeNavigator.uncheckUniqueReqCustomField(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_UNIQUE_TEXT_1")));
		Assert.assertTrue(zeNavigator.closeCustomfield());
		
		isSuccess = true;
		logger.info("bvt226 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 198)
	public void bvt223_createUniqueCustomFieldInTestcase() {
		logger.info("Executing bvt223...");
		altID = 223;
		
		zeNavigator.launchAdministration();
		Assert.assertTrue(zeNavigator.launchAdminApps("Customizations"), "Failed to launch Customization App");
		
		Assert.assertTrue(zeNavigator.launchCustomizationOptions("TestcaseCustomField"),
				"Failed to launch Testcase Custom Field Window");

		Assert.assertTrue(zeNavigator.addCustomField(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_UNIQUE_NUMBER_1"),
				Config.getTCRPropValue("NUMBER_CUSTOM_FIELD_TYPE"),
				Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_UNIQUE_NUMBER"), 
				true, false, Config.getProjectPropValue("DEFAULT_PROJECT"), true, false),
				"Failed to Add custom field");
		
		zeNavigator.closeCustomfield();
		
		String releaseName = "Release 1.0";
		String appName = "Test Repository";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		String tcName = "Testcase with unique custom field value - 12345";
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		CommonUtil.normalWait(1000);
		String nodeName = Config.getTCRPropValue("PHASE_1");
		String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");
		
		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY", tcName);
		values.put("TESTCASE_DESC", "Testcase with unique custom field value");
		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
		CommonUtil.normalWait(1000);
		Assert.assertTrue(zeNavigator.clickOnTestcase(testcaseId), "Not able to click on testcase");
		CommonUtil.normalWait(1000);
		Assert.assertTrue(zeNavigator.addCustomfieldToTestcase(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_UNIQUE_NUMBER_1"), Config.getTCRPropValue("TC_NUM_UNIQUE_FIELD_VALUE_1"), Config.getTCRPropValue("NUMBER_CUSTOM_FIELD_TYPE")),"Customfield Field number not added");
		zeNavigator.navigateBackToTestcaseList();
		
		isSuccess = true;
		logger.info("bvt223 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 199)
	public void bvt225_attemptToSaveTestcaseWithDuplicateValueInUniqueCustomField() {
		logger.info("Executing bvt225...");
		altID = 225;
		
		String releaseName = "Release 1.0";
		String appName = "Test Repository";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);

		String tcName = "Testcase to check duplicate unique custom field value";
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		CommonUtil.normalWait(1000);
		String nodeName = Config.getTCRPropValue("PHASE_1");
		String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");
		
		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY", tcName);
		values.put("TESTCASE_DESC", "Testcase with unique custom field value");
		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
		CommonUtil.normalWait(1000);
		Assert.assertTrue(zeNavigator.clickOnTestcase(testcaseId), "Not able to click on testcase");
		CommonUtil.normalWait(1000);
		Assert.assertTrue(zeNavigator.attemptToAddDuplicateValueToTestcaseHavingUniqueCustomField(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_UNIQUE_NUMBER_1"), Config.getTCRPropValue("TC_NUM_UNIQUE_FIELD_VALUE_1"), Config.getTCRPropValue("NUMBER_CUSTOM_FIELD_TYPE")),"Customfield Field number not added");
		
		isSuccess = true;
		logger.info("bvt225 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 200)
	public void bvt228_cloneTestcaseWhichHasUniqueCustomField() {
		logger.info("Executing bvt228...");
		altID = 228;

		String releaseName = "Release 1.0";
		String appName = "Test Repository";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		String tcName = "Testcase with unique custom field to clone";
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		CommonUtil.normalWait(1000);
		String nodeName = Config.getTCRPropValue("PHASE_1");
		String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");
		
		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY", tcName);
		values.put("TESTCASE_DESC", tcName);
		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
		CommonUtil.normalWait(1000);
		Assert.assertTrue(zeNavigator.clickOnTestcase(testcaseId), "Not able to click on testcase");
		Assert.assertTrue(zeNavigator.addCustomfieldToTestcase(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_UNIQUE_NUMBER_1"), "98765", Config.getTCRPropValue("NUMBER_CUSTOM_FIELD_TYPE")),"Customfield Field number not added");
		zeNavigator.navigateBackToTestcaseList();
		CommonUtil.normalWait(1000);
		Assert.assertTrue(zeNavigator.cloneTestcase(nodeName,tcName,"withoutsteps"),"Testcase is not cloned");
		
		int clonedtcId = Integer.parseInt(testcaseId);
		++clonedtcId;
		CommonUtil.normalWait(1000);
		String fieldValue = zeNavigator.getTestcaseCustomFieldValue(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_UNIQUE_NUMBER_1"), Config.getTCRPropValue("NUMBER_CUSTOM_FIELD_TYPE") ,Integer.toString(clonedtcId));
		
		Assert.assertTrue(fieldValue.equals(""), "Cloned testcase should not have unique custom field value");		
		
		isSuccess = true;
		logger.info("bvt228 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 201)
	public void bvt227_uncheckUniqueFieldOfTestcaseCustomFieldValue() {
		logger.info("Executing bvt227...");
		altID = 227;
		
		zeNavigator.launchAdministration();
		Assert.assertTrue(zeNavigator.launchAdminApps("Customizations"), "Failed to launch Customization App");
		
		Assert.assertTrue(zeNavigator.launchCustomizationOptions("TestcaseCustomField"),
				"Failed to launch Testcase Custom Field Window");

		Assert.assertTrue(zeNavigator.uncheckUniqueTestcaseCustomField(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_UNIQUE_NUMBER_1")));
		Assert.assertTrue(zeNavigator.closeCustomfield());
		
		isSuccess = true;
		logger.info("bvt227 is executed successfully.");
	}
	
	@BeforeMethod
	public void beforeMethod() {
		isSuccess = false;
	}

	@AfterMethod
	public void afterMethod() {
		baseAfterMethod();
		if(!isSuccess){
			zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		}
	}

	@BeforeClass
	public void beforeClass() {
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
	}
	
	@AfterClass
	public void afterClass() {
		zeNavigator.logout();
	}

}
