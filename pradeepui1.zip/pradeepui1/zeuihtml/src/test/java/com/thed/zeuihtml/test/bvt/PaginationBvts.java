package com.thed.zeuihtml.test.bvt;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.thed.zeuihtml.BaseTest;
import com.thed.zeuihtml.Config;

public class PaginationBvts extends BaseTest {


	public PaginationBvts() {
		logger = Logger.getLogger(this.getClass());
	}

	@Test(enabled = testEnabled, priority = 210)
	public void bvt238_customizeTheGridByCheckUncheckFieldsInColumnTest() {
		logger.info("Executing bvt238...");
		altID = 238;
		
		String releaseName = "Release 1.0";
		String appName = "Test Repository";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		List<String> fieldNames = new ArrayList<String>();
		fieldNames.add("Priority");
		fieldNames.add("Alt. ID");
		
		zeNavigator.checkOrUncheckTestcaseFieldsInGridAndVerify(fieldNames, true);
		zeNavigator.checkOrUncheckTestcaseFieldsInGridAndVerify(fieldNames, false);
		zeNavigator.checkOrUncheckTestcaseFieldsInGridAndVerify(fieldNames, true);
		
		appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);

		fieldNames.remove(0);
		zeNavigator.checkOrUncheckRequirementFieldsInGrid(fieldNames, true);
		zeNavigator.checkOrUncheckRequirementFieldsInGrid(fieldNames, false);
		zeNavigator.checkOrUncheckRequirementFieldsInGrid(fieldNames, true);
		
		
		isSuccess = true;
		logger.info("bvt238 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 211)
	public void bvt239_resetGridColumnToDefaultTest() {
		logger.info("Executing bvt239...");
		altID = 239;
		
		String releaseName = "Release 1.0";
		String appName = "Test Repository";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		List<String> fieldNames = new ArrayList<String>();
		fieldNames.add("Priority");
		fieldNames.add("Alt. ID");
		
		zeNavigator.resetTestcaseGridToDefaultAndVerifyAbsenceOfCustomizedFields(fieldNames);
		
		appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);

		fieldNames.remove(0);
		
		zeNavigator.resetRequirementGridToDefaultAndVerifyAbsenceOfCustomizedFields(fieldNames);
		
		isSuccess = true;
		logger.info("bvt239 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 212)
	public void bvt65_navigateBetweenPagesInPaginationOfTestcaseGridTest() {
		logger.info("Executing bvt65...");
		altID = 65;
		
		String releaseName = "Release 1.0";
		String appName = "Test Repository";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		
		zeNavigator.setPaginationPageSizeInTestRepository("10");
		zeNavigator.setPaginationPageSizeInTestRepository("25");
		zeNavigator.setPaginationPageSizeInTestRepository("100");
		zeNavigator.setPaginationPageSizeInTestRepository("50");
		
		isSuccess = true;
		logger.info("bvt65 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 213)
	public void bvt194_createMoreThanTenTestcasesAndNavigateToNextPageTest() {
		logger.info("Executing bvt194...");
		altID = 194;
		
		String releaseName = "Release 1.0";
		String appName = "Test Repository";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		
		String testcaseId=null;
		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		
		for(int i=1; i<6;i++) {
			testcaseId = zeNavigator.addDefaultTestcase(nodeName);
			Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");
			values.put("TESTCASE_ID", testcaseId);
			values.put("TESTCASE_SUMMARY", "Test "+i+"");
			Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
			
		}
		
		zeNavigator.setPaginationPageSizeInTestRepository("10");
		
		List<String> testcasesNames = new ArrayList<String>();
		testcasesNames.add("Test 1");
		testcasesNames.add("Test 2");
		
		zeNavigator.verifyTestcasesInSelectedNodeOfTestRepository(testcasesNames);
		
		zeNavigator.navigateToNextOrPrevPageInTestRepositoryGrid("Next");
		
		List<String> testcasesNames2 = new ArrayList<String>();
		testcasesNames2.add("Test 4");
		testcasesNames2.add("Test 5");
		
		zeNavigator.verifyTestcasesInSelectedNodeOfTestRepository(testcasesNames2);
		
		zeNavigator.navigateToNextOrPrevPageInTestRepositoryGrid("Prev");
		
		zeNavigator.verifyTestcasesInSelectedNodeOfTestRepository(testcasesNames);
		
		isSuccess = true;
		logger.info("bvt194 is executed successfully.");
	}
	
	
	@Test(enabled = testEnabled, priority = 214)
	public void bvt195_createMoreThanTenRequirementAndNavigateToNextPageTest() {
		logger.info("Executing bvt195...");
		altID = 195;
		
		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);

		List<String> phases = new ArrayList<String>();
		phases.add("Release 1.0");
		phases.add(Config.getReqPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		
		Map<String, String> values = new HashMap<String, String>();
		values.put("NAME", "Req 1");
		zeNavigator.modifyRequirement("Untitled requirement", values,null);
		
		String nodeName = Config.getReqPropValue("PHASE_1");
		String requirementId = null;

		for(int i=2;i<13;i++) {
			values.put("NAME", "Req "+i+"");
			requirementId = zeNavigator.addDefaultRequirement(nodeName);
			Assert.assertNotNull(requirementId, "Not added default requirement successfully.");
			zeNavigator.modifyRequirement("Untitled requirement", values, null);
			//zeNavigator.navigateBackToReqList();
		}
		
		zeNavigator.setPaginationPageSizeInRequirement("10");
		
		List<String> requirementNames = new ArrayList<String>();
		
		for(int i=1; i<11;i++) {
			requirementNames.add("Req "+ i);
		}
		
		zeNavigator.verifyRequirementInSelectedNodeOfRequirementApp(requirementNames);
		
		requirementNames.clear();
		zeNavigator.navigateToNextOrPrevPageInRequirementGrid("Next");
		
		requirementNames.add("Req 11");
		requirementNames.add("Req 12");
		
		zeNavigator.verifyRequirementInSelectedNodeOfRequirementApp(requirementNames);
		
		zeNavigator.navigateToNextOrPrevPageInRequirementGrid("Prev");
		
		isSuccess = true;
		logger.info("bvt195 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 215)
	public void bvt197_navigateToNextPageInAddTestcaseToFreeformInEASTest() {
		logger.info("Executing bvt197...");
		altID = 197;
		
		String releaseName = "Release 1.0";
		String appName = "Test Planning";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE5_NAME"), Config.getEASPropValue("FREEFORM2_PHASE_NAME"), true);
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getEASPropValue("FREEFORM2_PHASE_NAME"));
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		Map<Integer, List<String>> pageAndexpectedTestcases = new HashMap<Integer, List<String>>();
		
		
		List<String> testcasesInPage1 = new ArrayList<String>();
		testcasesInPage1.add(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"));
		testcasesInPage1.add(Config.getTCRPropValue("TESTCASE_WITH_ALL_CUSTOM_FIELDS"));
		
		List<String> testcasesInPage2 = new ArrayList<String>();
		testcasesInPage2.add(Config.getTCRPropValue("TESTCASE_WITH_ATTACHMENT"));
		
		List<String> testcasesInPage3 = new ArrayList<String>();
		
		
		List<String> testcasesInPage4 = new ArrayList<String>();
		testcasesInPage4.add("Test 5");
		testcasesInPage4.add("Test 1");
		testcasesInPage4.add("Test 2");
		
		pageAndexpectedTestcases.put(1, testcasesInPage1);
		pageAndexpectedTestcases.put(2, testcasesInPage2);
		pageAndexpectedTestcases.put(3, testcasesInPage3);
		pageAndexpectedTestcases.put(4, testcasesInPage4);
		
	
		
		
		zeNavigator.performSearchInEASAddTestcaseToFreeformWindow("Quick", "Test", "10"
				, 4, pageAndexpectedTestcases);
		
		isSuccess = true;
		logger.info("bvt197 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 216)
	public void bvt196_navigateToNextPageInPaginationInTCEGridTest() {
		logger.info("Executing bvt196...");
		altID = 196;
		
		String releaseName = "Release 1.0";
		String appName = "Test Planning";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		zeNavigator.addPhaseToCycle(Config.getEASPropValue("CYCLE5_NAME"), Config.getTCRPropValue("PHASE_1"), "anyone", true);
		
		zeNavigator.launchReleaseApp("Test Execution");
		
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CYCLE5_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		
		zeNavigator.setPageSizeInTCEGrid("10");
		zeNavigator.verifyAssignedTestcaseInSelectedNodeInTCE("Test 1", null, null);
		zeNavigator.verifyAssignedTestcaseInSelectedNodeInTCE("Test 2", null, null);
		
		zeNavigator.navigateToNextOrPrevPageInTCEGrid("Next");
		zeNavigator.verifyAssignedTestcaseInSelectedNodeInTCE("Test 4", null, null);
		zeNavigator.verifyAssignedTestcaseInSelectedNodeInTCE("Test 5", null, null);
		
		isSuccess = true;
		logger.info("bvt196 is executed successfully.");
	}
	
	
	@BeforeMethod
	public void beforeMethod() {
		isSuccess = false;
	}

	@AfterMethod
	public void afterMethod() {
		baseAfterMethod();
		if(!isSuccess){
			zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		}
	}

	@BeforeClass
	public void beforeClass() {
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
	}
	
	@AfterClass
	public void afterClass() {
		zeNavigator.logout();
	}

}
