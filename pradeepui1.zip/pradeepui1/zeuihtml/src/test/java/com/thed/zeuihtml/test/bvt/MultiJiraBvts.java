package com.thed.zeuihtml.test.bvt;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.thed.zeuihtml.BaseTest;
import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.Constants;
import com.thed.zeuihtml.utils.CommonUtil;

public class MultiJiraBvts extends BaseTest {
	
	public MultiJiraBvts() {
	logger = Logger.getLogger(this.getClass());
	}
	
	@Test(enabled = testEnabled, priority=145)
	public void bvt275_addMultiJira(){
		logger.info("Executing bvt275...");
		altID = 275;
		
		zeNavigator.launchAdministration();
		isSuccess = zeNavigator.setMultiJira();
		Assert.assertTrue(isSuccess, "Failed to set Multi Jira");
		
		isSuccess=true;
		logger.info("bvt275 is executed successfully.");
		
	}
	
	@Test(enabled = testEnabled, priority=146)
	public void bvt277_276_mapJiraWithProject(){
		logger.info("Executing Bvt277_278...");
		altID = 276;
		
	//	zeNavigator.logout();
		//zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		zeNavigator.launchAdministration();
		Assert.assertTrue(zeNavigator.launchAdminApps("ProjectSetup"), "Failed to launch Project setup App");
		zeNavigator.editProject(Config.getProjectPropValue("PROJECT1_NAME"), null, null, null, null, null, null, 
				Config.getDefectTrackingPropValue("JIRA_PROJECT_NAME_1"), Config.getDefectTrackingPropValue("JIRA_CONNECTION_NAME"), null, null, null, null);
		
		isSuccess = true;
		logger.info("bvt277_276 is completed successfully...");
	}
	
	@Test(enabled = testEnabled,priority=147)
	public void bvt333_clonereleasefromotherproject(){
		logger.info("Executing Bvt278...");
		altID = 333;
		
		//zeNavigator.logout();
		//zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"))
				, "Failed to select Project : " + Config.getProjectPropValue("PROJECT1_NAME"));
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("DEFAULT_RELEASE_NAME")), "Release not found by name: " +Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
		zeNavigator.verifyReleaseSummaryPage(Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
		Assert.assertTrue(zeNavigator.launchReleaseSetupPage(), "Failed to launch Release Setup , View Logs for details");
		zeNavigator.verifyReleaseSetupPage();
		logger.info("verified default release setup");
		zeNavigator.CloneRelease(Config.getProjectPropValue("DEFAULT_PROJECT"), Config.getReleasePropValue("DEFAULT_RELEASE_NAME"), Config.getUsersPropValue("TESTER"));
		CommonUtil.normalWait(1000);
		zeNavigator.renameRelease(Config.getReleasePropValue("CLONED_RELEASE"), Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"), Config.getReleasePropValue("CLONED_RELEASE_DESCRIPTION"), Config.getReleasePropValue("CLONED_RELEASE_END_DATE"));
		logger.info("cloned and navigate to release summary page");
		isSuccess = true;
		logger.info("bvt333_Clone release from other Project is completed successfully...");

		

	}
	
	@Test(enabled = testEnabled, priority=148)
	public void bvt334_UpdatetestcaseSyncViewExecution()
	{
		logger.info("Executing Bvt334...");
		altID = 334;
	//	zeNavigator.logout();
	//	zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"));
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME")), "Not selected release.");
		
		zeNavigator.launchReleaseApp("Test Repository");
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		//phases.add(Config.getTCRPropValue("NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("NODE_1");
		String testcaseId = zeNavigator.getTestcase(nodeName);
		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY", Config.getTCRPropValue("EDIT_TESTCASE_FOR_SYNC"));
		values.put("VERSIONVERIFY", "false");
		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
		

		zeNavigator.launchReleaseApp("Test Planning");
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CLONED_CYCLE3_NAME"), Config.getTCRPropValue("PHASE_1"), false);
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("PHASE_1"));
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		zeNavigator.syncSelectedNode(null, null, false, true);
		zeNavigator.logout();
		zeNavigator.doLogin(Config.getValue("ZE_TESTER_USERNAME"), Config.getValue("ZE_TESTER_PASSWORD"));
		zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"));
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME")), "Not selected release.");
		zeNavigator.launchReleaseApp("Test Execution");
		List<String> nodeList1 = new ArrayList<String>();
		nodeList1.add(0, Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
		nodeList1.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList1.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList1.add(3, Config.getTCRPropValue("NODE_1"));
		zeNavigator.navigateToNodesInTestExecution(nodeList1);
		zeNavigator.verifyTestExecutionDetailInGrid(Config.getTCRPropValue("EDIT_TESTCASE_FOR_SYNC"), Config.getTCEPropValue("VERSION"));
		zeNavigator.logout();
		isSuccess=true;
		logger.info("Bvt334 Executed successfully...");
		
	}
	
	
	
	@Test(enabled = testEnabled, priority=149)
	public void bvt278_createDefectFromDTCustomfield(){
		logger.info("Executing Bvt278...");
		altID = 278;
	//	zeNavigator.logout();
		zeNavigator.doLogin(Config.getValue("ZE_TESTER_USERNAME"), Config.getValue("ZE_TESTER_PASSWORD"));
		zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"));
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME")), "Not selected release.");
		zeNavigator.launchReleaseApp("Defect Tracking");
		CommonUtil.normalWait(2000);
		
		zeNavigator.setJiraUser(Config.getDefectTrackingPropValue("JIRA_USERNAME_1"), Config.getDefectTrackingPropValue("JIRA_PASSWORD_1"));
		Map<String, String> values = new HashMap<String, String>();
		values.put("Project", Config.getDefectTrackingPropValue("JIRA_PROJECT_NAME_1"));
		values.put("Issue Type", Config.getDefectTrackingPropValue("ISSUE_TYPE"));
		values.put("Summary", Config.getDefectTrackingPropValue("DEFECT_1_SUMMARY"));
		values.put("Description", Config.getDefectTrackingPropValue("DEFECT_1_DESCRIPTION"));
		values.put("Priority", Config.getDefectTrackingPropValue("DEFECT_1_PRIORITY"));
		values.put("Components", Config.getDefectTrackingPropValue("DEFECT_1_COMPONENTS"));
		values.put("FixVersions", Config.getDefectTrackingPropValue("DEFECT_1_FIXVERSIONS"));
		values.put("Cf_Text", Config.getDefectTrackingPropValue("CF_TEXT"));
		values.put("Cf_Long", Config.getDefectTrackingPropValue("CF_LONG"));
		values.put("Cf_SelectMultiple", Config.getDefectTrackingPropValue("CF_SELECTMULTIPLE"));
		values.put("Cf_SelectSingle", Config.getDefectTrackingPropValue("CF_SELECTSINGLE"));
		CommonUtil.normalWait(3000);
		zeNavigator.createNewDefectwithCustomfield(values);
		
		isSuccess = true;
		logger.info("bvt278 is completed successfully...");
	}
	
	@Test(enabled = testEnabled,priority=150)
	public void bvt279_SearchDefectIDlinktoExecutionMultiJira() {
		logger.info("Executing Bvt279...");
		altID = 279;
		
	//	zeNavigator.doLogin(Config.getValue("ZE_TESTER_USERNAME"), Config.getValue("ZE_TESTER_PASSWORD"));
		Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"))
				, "Failed to select Project : " + Config.getProjectPropValue("PROJECT1_NAME"));
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME")), "Release not found by name: " +Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
		zeNavigator.verifyReleaseSummaryPage(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
		zeNavigator.launchReleaseApp("Test Execution");
		
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		zeNavigator.executeTestcaseInSelectedNodeAndVerify("Sample Testcase 1", "Fail");
		zeNavigator.searchAndLinkDefect("Sample Testcase 1", "Defect Id", Config.getDefectTrackingPropValue("DEFECT_MULTI_ID"), Config.getDefectTrackingPropValue("DEFECT1_MULTI_SUMMARY"), Config.getDefectTrackingPropValue("DEFECT_MULTI_ID"));
		
		isSuccess = true;
		logger.info("bvt279 is completed successfully...");
	}
	
	@Test(enabled = testEnabled, priority=151)
	public void bvt280_SearchDefectJqlLinktoExecutionMultiJira() {
		logger.info("Executing Bvt280...");
		altID = 280;
		
	//	zeNavigator.doLogin(Config.getValue("ZE_TESTER_USERNAME"), Config.getValue("ZE_TESTER_PASSWORD"));
		Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"))
				, "Failed to select Project : " + Config.getProjectPropValue("PROJECT1_NAME"));
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME")), "Release not found by name: " +Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
		zeNavigator.verifyReleaseSummaryPage(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
		zeNavigator.launchReleaseApp("Test Execution");
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		zeNavigator.executeTestcaseInSelectedNodeAndVerify("Sample Testcase 2", "Fail");
		zeNavigator.searchAndLinkDefect("Sample Testcase 2", "JQL",  Config.getDefectTrackingPropValue("SEARCH_MULTI_QUERY"), Config.getDefectTrackingPropValue("DEFECT1_MULTI_SUMMARY"), Config.getDefectTrackingPropValue("DEFECT_MULTI_ID"));
		
		isSuccess = true;
		logger.info("bvt280 is completed successfully...");
	}
	
	@Test(enabled = testEnabled,priority=152)
		public void bvt281_serachDefectFilterLinktoExecution() {
			logger.info("Executing Bvt281...");
			altID = 281;
			
		//	zeNavigator.doLogin(Config.getValue("ZE_TESTER_USERNAME"), Config.getValue("ZE_TESTER_PASSWORD"));
			Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"))
					, "Failed to select Project : " + Config.getProjectPropValue("PROJECT1_NAME"));
			Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME")), "Release not found by name: " +Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
			zeNavigator.verifyReleaseSummaryPage(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
			zeNavigator.launchReleaseApp("Test Execution");
			List<String> nodeList = new ArrayList<String>();
			nodeList.add(0, Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
			nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
			nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
			nodeList.add(3, Config.getTCRPropValue("NODE_1"));
			zeNavigator.navigateToNodesInTestExecution(nodeList);
			zeNavigator.executeTestcaseInSelectedNodeAndVerify(Config.getTCRPropValue("EDIT_TESTCASE_FOR_SYNC"), "Fail");


			zeNavigator.searchAndLinkDefect(Config.getTCRPropValue("EDIT_TESTCASE_FOR_SYNC"), "My Filters",  Config.getDefectTrackingPropValue("FILTER_NAME"), Config.getDefectTrackingPropValue("FILTER_DEFECT_1_SUMMARY"), Config.getDefectTrackingPropValue("DEFECT_MULTI_ID2"));
			isSuccess = true;
			logger.info("bvt281 is completed successfully...");

	}
	
	
	@Test(enabled=testEnabled, priority=153)
	public void bvt282_createDefectWithPlainText() {
		logger.info("Executing Bvt282...");
		altID = 282;
	//	zeNavigator.logout();
		//zeNavigator.doLogin(Config.getValue("ZE_TESTER_USERNAME"), Config.getValue("ZE_TESTER_PASSWORD"));
		Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"))
				, "Failed to select Project : " + Config.getProjectPropValue("PROJECT1_NAME"));
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME")), "Release not found by name: " +Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
		zeNavigator.verifyReleaseSummaryPage(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
		zeNavigator.launchReleaseApp("Test Execution");
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		zeNavigator.executeTestcaseInSelectedNodeAndVerify(Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"), "Fail");
		
		Map<String, String> values = new HashMap<String, String>();
		values.put("Project", Config.getProjectPropValue("JIRA_PROJECT_NAME"));
		values.put("Issue Type", Config.getProjectPropValue("ISSUE_TYPE"));
		values.put("Summary", Config.getTCEPropValue("NEW_DEFECT2"));
		values.put("Description", Config.getTCEPropValue("NEW_DEFECT2_DESCRIPTION"));
		values.put("Components", Config.getTCEPropValue("NEW_DEFECT2_COMPONENTS"));
		values.put("Priority", Config.getTCEPropValue("NEW_DEFECT2_PRIORITY"));
		Assert.assertTrue(zeNavigator.linkNewDefect(Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"), values), "Failed to create new defect with test steps copied to defect desc as plain text");
		
		isSuccess = true;
		logger.info("bvt282 is executed successfully.");	
	}
	
	@Test (enabled=testEnabled,priority=154)
	public void bvt283_createdefectwithWiki() {
		logger.info("Executing Bvt283...");
		altID = 283;
		
		Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"))
				, "Failed to select Project : " + Config.getProjectPropValue("PROJECT1_NAME"));
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME")), "Release not found by name: " +Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
		zeNavigator.verifyReleaseSummaryPage(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
		zeNavigator.launchReleaseApp("Test Execution");
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		zeNavigator.executeTestcaseInSelectedNodeAndVerify(Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"), "Fail");
		
		Map<String, String> values = new HashMap<String, String>();
		values.put("Project", Config.getProjectPropValue("JIRA_PROJECT_NAME"));
		values.put("Issue Type", Config.getProjectPropValue("ISSUE_TYPE"));
		values.put("Summary", Config.getTCEPropValue("NEW_DEFECT3"));
		values.put("Description", Config.getTCEPropValue("NEW_DEFECT3_DESCRIPTION"));
		values.put("Components", Config.getTCEPropValue("NEW_DEFECT3_COMPONENTS"));
		values.put("Priority", Config.getTCEPropValue("NEW_DEFECT3_PRIORITY"));
		
		Assert.assertTrue(zeNavigator.linkNewDefect(Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"), values), "Failed to create new defect with test steps copied to defect desc as wiki-markup text");
		
		isSuccess = true;
		logger.info("bvt283 is executed successfully.");
	}
	
	@Test (enabled=testEnabled, priority=155)
	public void bvt285_NavigateToLinkTestcaseMultiJira() {
		logger.info("Executing Bvt 285...");
		altID = 285;
	//	zeNavigator.doLogin(Config.getValue("ZE_TESTER_USERNAME"), Config.getValue("ZE_TESTER_PASSWORD"));
		Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"))
				, "Failed to select Project : " + Config.getProjectPropValue("PROJECT1_NAME"));
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME")), "Release not found by name: " +Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
		zeNavigator.verifyReleaseSummaryPage(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
		zeNavigator.launchReleaseApp("Defect Tracking");
		String defectIdToSearch = "AUT-2";
		zeNavigator.searchByIdOrJqlOrFilter("ID", defectIdToSearch, false, null);
		zeNavigator.navigateToTestcaseLinkedWithDefectFromDefectTrackingApp(Config.getDefectTrackingPropValue("FILTER_DEFECT_1_SUMMARY"), Config.getTCRPropValue("EDIT_TESTCASE_FOR_SYNC"));
		
		isSuccess = true;
		logger.info("bvt285 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 156)
	public void bvt289_exportDefectTest() {
		logger.info("Executing bvt289...");
		altID = 289;
		//zeNavigator.logout();
		//zeNavigator.doLogin(Config.getValue("ZE_TESTER_USERNAME"), Config.getValue("ZE_TESTER_PASSWORD"));
		Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"))
				, "Failed to select Project : " + Config.getProjectPropValue("PROJECT1_NAME"));
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME")), "Release not found by name: " +Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
		zeNavigator.verifyReleaseSummaryPage(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
		zeNavigator.launchReleaseApp("Defect Tracking");
		String defectIdToSearch = "AUT-1";
		zeNavigator.searchByIdOrJqlOrFilter("ID", defectIdToSearch, false, null);
		zeNavigator.exportSearchedDefectResults();
		
		List<String>  fileNames= CommonUtil.returnFileNames(Config.getValue("EXPORT_FILE_PATH"));
		CommonUtil.renameFile(Config.getValue("EXPORT_FILE_PATH")+"/"+fileNames.get(0), Config.getDefectTrackingPropValue("EXCEL_EXPORT_MULTI"));
		
		List<Integer> ignoreCells = new ArrayList<Integer>();
		ignoreCells.add(0);
		ignoreCells.add(5);
		ignoreCells.add(18);
		ignoreCells.add(19);
		
		isSuccess = CommonUtil.compareExcel(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getDefectTrackingPropValue("EXCEL_EXPORT_MULTI")
		, Config.getValue("EXPORT_FILE_PATH")+"/backups/"+Config.getDefectTrackingPropValue("BACKUP_EXPORT_TO_COMPARE_MULTI"),ignoreCells);
		
		CommonUtil.moveFile(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getDefectTrackingPropValue("EXCEL_EXPORT_MULTI"), Config.getValue("EXPORT_FILE_PATH")+"/delete");
		
		//Assert.assertTrue(isSuccess, "Exported Excel Data is not correct when compared with expected data");
		
		
		isSuccess = true;
		logger.info("bvt289 is executed successfully.");
	}
	
	
	@Test (enabled = testEnabled, priority = 157)
	public void bvt286_importJiraRequirements() {
		logger.info("Executing bvt286...");
		altID = 286;
		
//	zeNavigator.logout();
//	zeNavigator.doLogin(Config.getValue("ZE_TESTER_USERNAME"), Config.getValue("ZE_TESTER_PASSWORD"));
		Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"))
				, "Failed to select Project : " + Config.getProjectPropValue("PROJECT1_NAME"));
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME")), "Release not found by name: " +Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
		zeNavigator.verifyReleaseSummaryPage(Config.getReleasePropValue("CLONED_RELEASE_NEW_NAME"));
		zeNavigator.launchReleaseApp("Requirements");
		List<String> issueSummary = new ArrayList<String>();
		issueSummary.add(Config.getTCEPropValue("DEFECT1_SUMMARY"));
		
		Assert.assertTrue(zeNavigator.importJiraRequirements(Config.getReqPropValue("JQL_TO_IMPORT_MULTI_JIRA_REQUIREMENT")
				, issueSummary,Config.getReqPropValue("JIRA_IMPORTED_NODE")), "Failed to Import JIRA requirement");
		
		isSuccess = true;
		logger.info("bvt286 is executed successfully.");
	}
	
		
	@BeforeMethod
	public void beforeMethod() {
		isSuccess = false;
	}

	@AfterMethod
	public void afterMethod() {
		baseAfterMethod();
		if(!isSuccess){
			zeNavigator.doLogin(Config.getValue("ZE_TESTER_USERNAME"), Config.getValue("ZE_TESTER_PASSWORD"));
		}
	}

	@BeforeClass
	public void beforeClass() {
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
	}
	
	@AfterClass
	public void afterClass() {
		zeNavigator.logout();
	}

}
