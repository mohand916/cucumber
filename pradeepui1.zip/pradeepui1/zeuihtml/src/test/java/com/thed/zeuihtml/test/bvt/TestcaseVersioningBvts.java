package com.thed.zeuihtml.test.bvt;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.thed.zeuihtml.Constants;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.thed.zeuihtml.BaseTest;
import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.utils.CommonUtil;

public class TestcaseVersioningBvts extends BaseTest{

	public TestcaseVersioningBvts() {
		logger = Logger.getLogger(this.getClass());
	}

	@Test(enabled = testEnabled, priority = 242)
	public void bvt258_addTestcaseEditAndVerifySameVersionGetsUpdated() {
		logger.info("Executing bvt258...");
		altID = 258;

		String releaseName = "Release 1.0";
		String appName = "Test Repository";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);

		String phaseName = Config.getTCRPropValue("VER_PHASE_1");
		String phaseDescription = phaseName + " description";
		//String projectRepository = "Release 1.0";
		Assert.assertTrue(zeNavigator.createPhase(releaseName, phaseName, phaseDescription),
				"Phase not created successfully.");
		
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("VER_PHASE_1");
		testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");

		System.out.println("Testcase IDs : " + testcaseId);

		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY",Config.getTCRPropValue("TESTCASE_FOR_VERSION1"));
		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
		Assert.assertTrue(zeNavigator.verifyTestcaseVersion(Config.getTCRPropValue("TESTCASE_FOR_VERSION1"), "1"));

		isSuccess = true;
		logger.info("bvt258 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 243)
	public void bvt259_editTestcaseWhenTheTestcaseIsScheduledInACycle() {
		logger.info("Executing bvt259...");
		altID = 259;
		String releaseName = "Release 1.0";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp("Test Planning");
		
		String startDate = CommonUtil.returnTodaysDate();
		String endDate = CommonUtil.returnFutureDateStartingTodaysDate(0, 5, 0);
		
		Assert.assertTrue(zeNavigator.createCycle(Config.getEASPropValue("CYCLE7_NAME"), null
				, null,startDate,endDate),  "Not created cycle successfully.");
		
		zeNavigator.addPhaseToCycle(Config.getEASPropValue("CYCLE7_NAME"), Config.getTCRPropValue("VER_PHASE_1")
				, "anyone", true);

		zeNavigator.launchReleaseApp("Test Repository");

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("VER_PHASE_1");
		String testcaseId = zeNavigator.getTestcase(nodeName);
		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY1",Config.getTCRPropValue("TESTCASE_FOR_VERSION1"));
		values.put("TESTCASE_SUMMARY",Config.getTCRPropValue("TESTCASE_FOR_VERSION2"));
		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
		zeNavigator.verifyTestcaseVersion(Config.getTCRPropValue("TESTCASE_FOR_VERSION2"), "2");
		
		isSuccess = true;
		logger.info("bvt259 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 244)
	public void bvt260_getLatestVersionByNormalPhaseSyncInTestPlanning() {
		logger.info("Executing bvt260...");
		altID = 260;
		String releaseName = "Release 1.0";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp("Test Planning");

		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE7_NAME"), Config.getTCRPropValue("VER_PHASE_1"), false);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("VER_PHASE_1"));
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);

		zeNavigator.syncSelectedNode(null, null, false, false);
		List<String> testcaseNames = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("TESTCASE_FOR_VERSION2"));
		Assert.assertTrue(zeNavigator.verifyTestcasesInGridOfSelectedPageInAddTestcaseToFreeformScreen(testcaseNames));
		zeNavigator.navigateBackToCycles();

		isSuccess = true;
		logger.info("bvt260 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 245)
	public void bvt261_syncNormalPhaseThatHasExecutedTestcaseWhichHasDifferentVersionInTestRepo() {
		logger.info("Executing bvt261...");
		altID = 261;
		String releaseName = "Release 1.0";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp("Test Execution");

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CYCLE7_NAME"));
		nodeList.add(2, Config.getTCRPropValue("VER_PHASE_1"));

		zeNavigator.navigateToNodesInTestExecution(nodeList);

		Assert.assertTrue(zeNavigator.executeTestcaseInSelectedNodeAndVerify(Config.getTCRPropValue("TESTCASE_FOR_VERSION2"), "Pass")
				, "Failed to execute Test");

		zeNavigator.launchReleaseApp("Test Repository");

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("VER_PHASE_1");
		String testcaseId = zeNavigator.getTestcase(nodeName);
		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY",Config.getTCRPropValue("TESTCASE_FOR_VERSION3"));
		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
		zeNavigator.verifyTestcaseVersion(Config.getTCRPropValue("TESTCASE_FOR_VERSION3"), "3");

		zeNavigator.launchReleaseApp("Test Planning");

		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE7_NAME"), Config.getTCRPropValue("VER_PHASE_1"), false);

		nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("VER_PHASE_1"));
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);

		zeNavigator.syncSelectedNode(null, null, false, false);
		List<String> testcaseNames = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("TESTCASE_FOR_VERSION2"));
		Assert.assertTrue(zeNavigator.verifyTestcasesInGridOfSelectedPageInAddTestcaseToFreeformScreen(testcaseNames));
		zeNavigator.navigateBackToCycles();

		isSuccess = true;
		logger.info("bvt261 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 246)
	public void bvt262_getLatestVersionByFreeFormPhaseSyncInTestPlanning() {
		logger.info("Executing bvt262...");
		altID = 262;
		String releaseName = "Release 1.0";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp("Test Planning");
		Assert.assertTrue(zeNavigator.addFreeformPhaseToCycle(Config.getEASPropValue("CYCLE7_NAME")
				, Config.getEASPropValue("FREEFORM1_VERSION"), false)
				, "Failed to add Freeform phase to cycle Successfully");
		Assert.assertTrue(zeNavigator.addTestcaseToFreeformNodeBrowse(Config.getEASPropValue("FREEFORM1_VERSION"), null, null,Config.getTCRPropValue("VER_PHASE_1"),false),"Not able to launch browse window");
		CommonUtil.normalWait(1000);
		zeNavigator.bulkAssignUnassignedTest("Anyone", true, false);
		zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("TESTCASE_FOR_VERSION3"), "Anyone", true);

		zeNavigator.launchReleaseApp("Test Repository");

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("VER_PHASE_1");
		String testcaseId = zeNavigator.getTestcase(nodeName);
		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY",Config.getTCRPropValue("TESTCASE_FOR_VERSION4"));
		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
		zeNavigator.verifyTestcaseVersion(Config.getTCRPropValue("TESTCASE_FOR_VERSION4"), "4");

		zeNavigator.launchReleaseApp("Test Planning");

		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE7_NAME"), Config.getEASPropValue("FREEFORM1_VERSION"), false);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getEASPropValue("FREEFORM1_VERSION"));
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);

		zeNavigator.syncSelectedNode(null, null, false, false);
		List<String> testcaseNames = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("TESTCASE_FOR_VERSION4"));
		Assert.assertTrue(zeNavigator.verifyTestcasesInGridOfSelectedPageInAddTestcaseToFreeformScreen(testcaseNames));
		zeNavigator.navigateBackToCycles();

		isSuccess = true;
		logger.info("bvt262 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 247)
	public void bvt263_syncFreeFormPhaseThatHasExecutedTestcaseWhichHasDifferentVersionInTestRepo() {
		logger.info("Executing bvt263...");
		altID = 263;
		String releaseName = "Release 1.0";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp("Test Execution");

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CYCLE7_NAME"));
		nodeList.add(2, Config.getEASPropValue("FREEFORM1_VERSION"));

		zeNavigator.navigateToNodesInTestExecution(nodeList);

		Assert.assertTrue(zeNavigator.executeTestcaseInSelectedNodeAndVerify(Config.getTCRPropValue("TESTCASE_FOR_VERSION4"), "Pass")
				, "Failed to execute Test");

		zeNavigator.launchReleaseApp("Test Repository");

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("VER_PHASE_1");
		String testcaseId = zeNavigator.getTestcase(nodeName);
		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY",Config.getTCRPropValue("TESTCASE_FOR_VERSION5"));
		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
		zeNavigator.verifyTestcaseVersion(Config.getTCRPropValue("TESTCASE_FOR_VERSION5"), "5");

		zeNavigator.launchReleaseApp("Test Planning");

		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE7_NAME"), Config.getEASPropValue("FREEFORM1_VERSION"), false);

		nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getEASPropValue("FREEFORM1_VERSION"));
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);

		zeNavigator.syncSelectedNode(null, null, false, false);
		List<String> testcaseNames = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("TESTCASE_FOR_VERSION4"));
		Assert.assertTrue(zeNavigator.verifyTestcasesInGridOfSelectedPageInAddTestcaseToFreeformScreen(testcaseNames));
		zeNavigator.navigateBackToCycles();

		isSuccess = true;
		logger.info("bvt263 is executed successfully.");
	}

	@BeforeMethod
	public void beforeMethod() {
		isSuccess = false;
	}

	@AfterMethod
	public void afterMethod() {
		baseAfterMethod();
		if(!isSuccess){
			zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));	
		}
	}

	@BeforeClass
	public void beforeClass() {
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
	}
	
	@AfterClass
	public void afterClass() {
		zeNavigator.logout();
	}
	
}
