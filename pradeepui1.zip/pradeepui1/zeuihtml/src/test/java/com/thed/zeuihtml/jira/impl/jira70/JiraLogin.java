package com.thed.zeuihtml.jira.impl.jira70;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.thed.zeuihtml.Constants;
import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;



/**
 * This is JIRA's Login page, what user sees before login i.e. where user gives username and password.
 * @author 
 *
 */
public class JiraLogin {
	Logger logger;
	
	public JiraLogin(){
		logger = Logger.getLogger(this.getClass());
	}
	public static JiraLogin getInstance(){
		return PageFactory.initElements(Driver.driver, JiraLogin.class);
	}
	
	
	
	/******************************************************
	 * 	WEBELEMENTS
	 *****************************************************/
	
	@FindBy(id="login-form-username")
	private WebElement usernameEditbox;
	
	// password edit box in jira's login page.		
	@FindBy(id="login-form-password")
	private WebElement passwordEditbox;
	
	// Login button in jira's login page.		
	@FindBy(name="login")
	private WebElement loginButton;
	
	// Login again link in Jira's login page.
	@FindBy(xpath="//a[text()='Log in again.']")
	private WebElement xpathForLogInAgain;
	
	
	
	/******************************************************
	 * 	PAGE OBJECT METHODS
	 *****************************************************/
	/**
	 * 
	 * This method is used to login to jira and it will show jira landing page.
	 * @param JIRA_USERNAME This parameter contains jira's username for login to jira.
	 * @param JIRA_PASSWORD This parameter contains jira's password for login to jira.
	 * @return The boolean value i.e. True or False.
	 */

/******************************************************
 * 	Methods
 *****************************************************/
	
	
	public boolean jiraLogin(String username, String password){
		
		try {
			 logger.info("Login to Jira started.......");
		        usernameEditbox.clear();
		        logger.info("Typing Username: " + username);
				usernameEditbox.sendKeys(username);
				passwordEditbox.clear();
				logger.info("Typing Username: " + password);
				passwordEditbox.sendKeys(password);
				loginButton.click();
				CommonUtil.implicitWait(60);
				logger.info("Login to Jira Successfully.");
			return true;
		} catch (Exception e) {
			return false;
		}
		
	       
	}

}


