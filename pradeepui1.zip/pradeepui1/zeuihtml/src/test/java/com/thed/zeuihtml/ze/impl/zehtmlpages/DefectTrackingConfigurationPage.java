package com.thed.zeuihtml.ze.impl.zehtmlpages;

import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.xerces.impl.xs.identity.ValueStore;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;

public class DefectTrackingConfigurationPage {

	Logger logger;
	
	public DefectTrackingConfigurationPage(){
		logger = Logger.getLogger(this.getClass());
	}
	public static DefectTrackingConfigurationPage getInstance(){
		return PageFactory.initElements(Driver.driver, DefectTrackingConfigurationPage.class);
	}
	
	/******************************************************
	 * 	WEBELEMENTS
	 *****************************************************/
	
	@FindBy(xpath="//h3/b[text()='Defect Tracking']")
	private WebElement headerDefectTracking;
	
	@FindBy(xpath="//select[@id='defect-system-select2']")
	private WebElement dropdownSelectDT;
	
	@FindBy(xpath="//*[@id='borderLayout_eGridPanel']//input[@placeholder = 'Enter JIRA connection name']")
	private WebElement textjiraName;
	
	@FindBy(xpath="//*[@id='borderLayout_eGridPanel']//input[@placeholder = 'Enter JIRA connection URL']")
	private WebElement textBoxURL;
	
	@FindBy(xpath="//*[@id='borderLayout_eGridPanel']//input[@placeholder = 'Enter Username']")
	private WebElement textBoxUsername;
	
	@FindBy(xpath="//input[@id='samplePassword']")
	private WebElement textBoxPassword;
	
	@FindBy(xpath="//*[@id='borderLayout_eGridPanel']//i[@title='Save']")
	private WebElement buttonSave;
	
	@FindBy(xpath="//*[@id='borderLayout_eGridPanel']//div[2]//i[@title='Save']")
	private WebElement buttonSave1;
	
	@FindBy(xpath=".//*[@id='borderLayout_eGridPanel']//i[@title='Cancel']")
	private WebElement buttonCancel;
	
	@FindBy(xpath =".//*[@id='borderLayout_eGridPanel']//i[@title='Edit']")
	private WebElement buttonEdit;
	
	@FindBy(xpath="//button[text()='Yes']")
	private WebElement buttonYes;
	
	@FindBy(xpath="//div[@id='toast-container']/div/div[text()='Success']")
	private WebElement popupSuccess;
	
	@FindBy(xpath="//*[@id='ze-main-app']/admin/defect-tracking-integration//button[@title ='Add JIRA connection']")
	private WebElement addJiraconnection;
	
	@FindBy(xpath = "//a[@class='zui-icon-btn']")
	private WebElement backToProject;
	
	
	// Set Defect User Element
	@FindBy(xpath="//div[@id='defect-update-user-modal']//h4[text()='External DTS Login']")
	private WebElement externalDtsPopUp;
	
	@FindBy(xpath=".//*[@id='defect-update-user-modal']//input[@name='username']")
	private WebElement usernameText;
	
	@FindBy(xpath=".//*[@id='defect-update-user-modal']//input[@name='password']")
	private WebElement passwordText;
	
	@FindBy(xpath=".//*[@id='defect-update-user-modal']//input[@name='reEnterPassword']")
	private WebElement reEnterPassword;
	
	@FindBy(xpath=".//*[@id='defect-update-user-modal']//button[text()='Save']")
	private WebElement dtsUserSave;
	
	
	/******************************************************
	 * 	Methods
	 *****************************************************/
	
	
	
	
	
	
	public boolean verifyDefectTrackingApp(){
		return false;
	}
	
	public boolean setDefectTracking(){
		logger.info("Going to Set Defect Tracking");
		logger.info("Waiting For Defect Tracking App Launched");
		
		if(CommonUtil.visibilityOfElementLocated(headerDefectTracking)){
			logger.info("Going to select jira from dropdown");
			CommonUtil.selectListWithVisibleText(dropdownSelectDT, "JIRA");
			logger.info("Going to type jira name:" + Config.getValue("JIRA_NAME"));
			textjiraName.clear();
			textjiraName.sendKeys(Config.getValue("JIRA_NAME"));
			CommonUtil.normalWait(500);
			logger.info("Going to type jira URL: " + Config.getValue("JIRA_URL"));
			textBoxURL.clear();
			textBoxURL.sendKeys(Config.getValue("JIRA_URL"));
			CommonUtil.normalWait(500);
			logger.info("Going to type jira username: " + Config.getValue("JIRA_USERNAME"));
			textBoxUsername.clear();
			textBoxUsername.sendKeys(Config.getValue("JIRA_USERNAME"));
			CommonUtil.normalWait(500);
			logger.info("Going to type jira password: " + Config.getValue("JIRA_PASSWORD"));
			textBoxPassword.clear();
			textBoxPassword.sendKeys(Config.getValue("JIRA_PASSWORD"));
			CommonUtil.normalWait(500);
			logger.info("Going to click on save button");
			buttonSave.click();
			CommonUtil.normalWait(500);
			logger.info("Going to click on Yes button in confirmation popup");
			buttonYes.click();
			
			if(CommonUtil.visibilityOfElementLocated(popupSuccess)){
				logger.info("Success Message Popup found successfylly : " + popupSuccess.getText());
				HomePage.getInstance().waitForProgressBarToComplete();
				logger.info("Refreshing Browser Page");
				CommonUtil.normalWait(5000);
				CommonUtil.browserRefresh();
				//CommonUtil.normalWait(10000);
				HomePage.getInstance().waitForProgressBarToComplete();
				if(CommonUtil.visibilityOfElementLocated(headerDefectTracking)){
					logger.info("Verified Defect Tracking Header after refreshing browser");
				}
			}else{
				logger.info("Success Message Popup not found");
				return false;
			}
			
		}else{
			logger.info("Defect Tracking App not found, Tried to verify Header");
			return false;
		}
		
		return true;
		
	}
	
	

public boolean setMultiJira(){
	
	logger.info("Going to Set Multi Jira");
	logger.info("Waiting For Defect Tracking App Launched");
	
	if(CommonUtil.visibilityOfElementLocated(headerDefectTracking)){
	CommonUtil.normalWait(1000);
	addJiraconnection.click();
	logger.info("Going to type jira name:" + Config.getDefectTrackingPropValue("JIRA_NAME_1"));
	textjiraName.clear();
	textjiraName.sendKeys(Config.getDefectTrackingPropValue("JIRA_NAME_1"));
	CommonUtil.normalWait(500);
	logger.info("Going to type jira URL: " + Config.getDefectTrackingPropValue("JIRA_URL_1"));
	textBoxURL.clear();
	textBoxURL.sendKeys(Config.getDefectTrackingPropValue("JIRA_URL_1"));
	CommonUtil.normalWait(500);
	logger.info("Going to type jira username: " + Config.getDefectTrackingPropValue("JIRA_USERNAME_1"));
	textBoxUsername.clear();
	textBoxUsername.sendKeys(Config.getDefectTrackingPropValue("JIRA_USERNAME_1"));
	CommonUtil.normalWait(500);
	logger.info("Going to type jira password: " + Config.getDefectTrackingPropValue("JIRA_PASSWORD_1"));
	textBoxPassword.clear();
	textBoxPassword.sendKeys(Config.getDefectTrackingPropValue("JIRA_PASSWORD_1"));
	CommonUtil.normalWait(500);
	logger.info("Going to click on save button");
	buttonSave1.click();
	CommonUtil.normalWait(500);
	logger.info("Going to click on Yes button in confirmation popup");
	buttonYes.click();
	
	if(CommonUtil.visibilityOfElementLocated(popupSuccess)){
		logger.info("Success Message Popup found successfylly : " + popupSuccess.getText());
		HomePage.getInstance().waitForProgressBarToComplete();
		logger.info("Refreshing Browser Page");
		CommonUtil.normalWait(5000);
		CommonUtil.browserRefresh();
		//CommonUtil.normalWait(10000);
		HomePage.getInstance().waitForProgressBarToComplete();
		if(CommonUtil.visibilityOfElementLocated(headerDefectTracking)){
			logger.info("Verified Defect Tracking Header after refreshing browser");
		}
	}else{
		logger.info("Success Message Popup not found");
		return false;
	}
	
}else{
	logger.info("Defect Tracking App not found, Tried to verify Header");
	return false;
}

return true;

}


public boolean setJiraUser(String username, String password){
	logger.info("Going to Set Jira Users");
	logger.info("Waiting For Defect Tracking App Launched");
	CommonUtil.normalWait(1000);
	if(CommonUtil.visibilityOfElementLocated(externalDtsPopUp)){
		CommonUtil.normalWait(1000);
		usernameText.sendKeys(username);
		passwordText.sendKeys(password);
		reEnterPassword.sendKeys(password);
		CommonUtil.normalWait(1000);
		dtsUserSave.click();
	}
	
	else{
		logger.info("Defect User is already set");
	}
	
	
	return true;
}


}



	
	
