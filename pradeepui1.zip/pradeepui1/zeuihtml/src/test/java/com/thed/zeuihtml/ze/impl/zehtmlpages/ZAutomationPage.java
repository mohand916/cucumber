package com.thed.zeuihtml.ze.impl.zehtmlpages;


import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;

public class ZAutomationPage {

	Logger logger;
	
	public ZAutomationPage(){
		logger = Logger.getLogger(this.getClass());
	}
	
	public static ZAutomationPage getInstance(){
		return PageFactory.initElements(Driver.driver, ZAutomationPage.class);
	}
	
	/******************************************************
	 * 	WEBELEMENTS
	 *****************************************************/
	
	@FindBy(xpath="//zee-automation//span[text()='AUTOMATION']")
	private WebElement automationTab;

	@FindBy(xpath="//zee-automation//span[text()='AUTOMATION']")
	private WebElement folderWatcherTab;
	
	@FindBy(xpath="//button[@title='ADD-Configure-Job']")
	private WebElement buttonAddConfigureJob;
	
	@FindBy(xpath="//h2[text()='Automation Jobs Creation']")
	private WebElement headerAutomationJobsCreation;
	
//	@FindBy(xpath="//select[@id='zautoAutoTool']")
//	private WebElement selectAutomationTool;
	
	
	//Rasagna
	@FindBy(xpath = "//*[@id='jobName']")
	private WebElement selectJobName;
	
	@FindBy(xpath ="//*[@id='cycleName']")
			private WebElement selectCycleName;	
	
	@FindBy(xpath ="//*[@id='phaseName']")
	private WebElement selectfolderName;	
	
	//Rasagna
	@FindBy(xpath = "//div[@id='zeAutomation']//span[@class='select2-selection__placeholder']")
	private WebElement selectAutomationTool;

	@FindBy(xpath="//input[@id='chkbx']")
	private WebElement checkboxInvokeTheScript;
	
	@FindBy(xpath="//input[@id='SCRIPT']")
	private WebElement textboxScriptPath;
	
	@FindBy(xpath="//input[@id='ResultPath']")
	private WebElement textboxResultPath;
	
	@FindBy(xpath="//input[@id='clrpkg']")
	private WebElement checkboxPackageStructure;
	
	@FindBy(xpath = "//*[@id='Zbotagenmachine']/select")
	private WebElement selectZbot;
	
	@FindBy(xpath="//select[@id='cycleduration']")
	private WebElement selectCycleDuration;
	
	@FindBy(xpath="//button[text()='Add']")
	private WebElement buttonAdd;
	
	@FindBy(xpath="//div[@id='prefix-add-modal']//h2[text()='Add Cycle Name']")
	private WebElement headerAddPrefixToTestcaseCycle;
	
	@FindBy(xpath="//input[@id='prefix-value']")
	private WebElement textboxCycleName;

	@FindBy(xpath="//input[@id='phase-value']")
	private WebElement textboxPhaseName;

	@FindBy(xpath="//input[@id='timeStamp']")
	private WebElement checkBoxPostFixTimeStamp;

	@FindBy(xpath = "(//b[text()='Select User :']/parent::label/following-sibling::div//span)[1]")
	private WebElement selectUser;
	
	@FindBy(xpath="(//*[@id='check'])[1]")
	private WebElement buttonExecuteInPrefixPopup;
	
	@FindBy(xpath="//button[text()='Apply']")
	private WebElement buttonApplyNotification;
	
	/******************************************************
	 * 	Methods
	 *****************************************************/
	
	/*public String createAutomationJob( String automationTool, String scriptPath, String resultPath
			, boolean packageStructure, String zbot, String startDate, String endDate, String jobName)*/
	public String createAutomationJob( String automationTool, String scriptPath, String resultPath
			, boolean packageStructure, String zbot, String startDate, String endDate, String jobName,String cycleName,String phaseName ){
		String jobId = null;
		try {

			int sizeOfJobsBefore=0;

			WebElement we2;
			try {
				we2 = Driver.driver.findElement(By.xpath("//*[@id='grid-table-zauto']/div[@class='grid-content']/div"));
				if(we2!=null){
					if(we2.isDisplayed()) {
						sizeOfJobsBefore = CommonUtil
								.returnSizeOfElements("//*[@id='grid-table-zauto']/div[@class='grid-content']/div");
						logger.info("Size of elements before : " + sizeOfJobsBefore);
					}
				}
			} catch (Exception e) {
				logger.info("No previous Jobs found");
			}

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(automationTab)
					, "Header ZEE Automation not found");
			automationTab.click();
			
			buttonAddConfigureJob.click();
			CommonUtil.normalWait(2000);
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerAutomationJobsCreation)
					, "Header Automation Jobs Creation not found");
			selectJobName.sendKeys(jobName);
			CommonUtil.normalWait(1000);
			
			System.out.println("jobname entered");
			//CommonUtil.selectListWithVisibleText(selectAutomationTool, automationTool);
			CommonUtil.visibilityOfElementLocated(selectAutomationTool);
			selectAutomationTool.click();
			CommonUtil.normalWait(1000);
			CommonUtil.returnWebElement("//span//ul//li[text()='"+automationTool+"']").click();
			CommonUtil.normalWait(1000);
			
			if(scriptPath!=null) {
				checkboxInvokeTheScript.click();
				CommonUtil.normalWait(2000);
				textboxScriptPath.sendKeys(scriptPath);
				CommonUtil.normalWait(2000);
			}
			
			textboxResultPath.sendKeys(resultPath);
			CommonUtil.normalWait(2000);
			
			if(packageStructure) {
				checkboxPackageStructure.click();
				CommonUtil.normalWait(5000);
			}
			
			CommonUtil.selectListWithVisibleText(selectZbot, zbot);
			CommonUtil.normalWait(2000);
			
			//CommonUtil.selectListWithVisibleText(selectCycleDuration, cycleDuration);
			CommonUtil.returnWebElement("//div[@id='zeAutomation']//b[contains(text(), 'Cycle Start Date')]/parent::label/following-sibling::div//input").sendKeys(startDate);
			CommonUtil.returnWebElement("//div[@id='zeAutomation']//b[contains(text(), 'Cycle End Date')]/parent::label/following-sibling::div//input").sendKeys(endDate);
			CommonUtil.normalWait(2000);
			//rasagna
			selectCycleName.sendKeys(cycleName);
			CommonUtil.normalWait(2000);
			selectfolderName.sendKeys(phaseName);
			//rasagna
			buttonAdd.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(2000);

			int sizeOfJobsAfter = CommonUtil
					.returnSizeOfElements("//*[@id='grid-table-zauto']/div[@class='grid-content']/div");

			Assert.assertTrue(sizeOfJobsBefore + 1 == sizeOfJobsAfter, "Jobs size not increased.");
			logger.info("Jobs size verified Successfully.");

			String xpathForJobId = "//*[@id='grid-table-zauto']/div[@class='grid-content']/div[" + sizeOfJobsAfter
					+ "]/div[@data-col-index='1']/div/div";
			jobId = CommonUtil.getText(xpathForJobId);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jobId;
	}
	
	public boolean verifyAutomationJobCreated(String jobId, String automationTool, String scriptPath, String resultPath
			, String status, String zbot, String startDate, String endDate) {
		try {
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-zauto']//div[text()='"+jobId+"']")
					, "Job ID not found as:" + jobId);

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-zauto']//div[text()='"+jobId+"']/parent::div/parent::div/following-sibling::div//div[text()='"+zbot+"']")
					, "Zbot name for saved job not found as: "+ zbot);
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-zauto']//div[text()='"+jobId+"']/parent::div/parent::div/following-sibling::div//div[text()='"+resultPath+"']")
					, "Result Path for saved job not found as: "+ resultPath);
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-zauto']//div[text()='"+jobId+"']/parent::div/parent::div/following-sibling::div//div[text()='"+automationTool+"']")
					, "Framework for saved job not found as: "+ automationTool);
			
			if(status!=null) {
				verifyJobStatus(jobId, status);
			}

			
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean executeAutomationJob(String jobId, String cycleName, String phaseName, boolean setPostFixTimeStamp, String user, String expectedNotificationCount) {
		try {
			
			CommonUtil.normalWait(2000);
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-zauto']//div[text()='"+jobId+"']")
					, "Job ID not found as:" + jobId);
			CommonUtil.normalWait(2000);
			CommonUtil.returnWebElement("//div[@id='grid-table-zauto']//div[text()='"+jobId+"']/parent::div/parent::div/parent::div//span[text()='E']").click();
			
			/*	//----Rasagna	
			 * Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerAddPrefixToTestcaseCycle)
					, "Header AddPrefixToTestcaseCycle not found");
			
			CommonUtil.normalWait(2000);
	
			textboxCycleName.sendKeys(cycleName);
			CommonUtil.normalWait(1000);
			textboxPhaseName.sendKeys(phaseName);
			CommonUtil.normalWait(1000);
			if (setPostFixTimeStamp) {
				checkBoxPostFixTimeStamp.click();
			}
			CommonUtil.normalWait(1000);
			selectUser.click();
			CommonUtil.normalWait(1000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//ul[@id='select2--results']/li[text()='"+user+"']"),"User Not Found!");
			CommonUtil.returnWebElement("//ul[@id='select2--results']/li[text()='"+user+"']").click();

			buttonExecuteInPrefixPopup.click();
			CommonUtil.normalWait(2000);
			HomePage.getInstance().waitForProgressBarToComplete();
			
			//verifyJobStatus(jobId, "new");*/ //----Rasagna
			CommonUtil.normalWait(3000);
			//Rasagna 
			/*  Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//notifications//span[text()='"+expectedNotificationCount+"']")
					, "Expected notification count not found as: "+ expectedNotificationCount);*/ 
//Rasagna
		//Rasagna	
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//notifications//span[text()='"+expectedNotificationCount+"']")
					, "Expected notification count not found as: "+ expectedNotificationCount);
			CommonUtil.moveToElement(CommonUtil.returnWebElement("//*[@class='notification-wrapper']"));
					//*[@class='notification-wrapper'])
					System.out.println("CLICKED ON NOTIFICATION ");
					//("//notifications//span[text()='"+expectedNotificationCount+"']"));
			//Rasagna
			CommonUtil.normalWait(2000);
						buttonApplyNotification.click();
						System.out.println("CLICKED ON Apply ");
			CommonUtil.normalWait(2000);
	//	rasagna	//HomePage.getInstance().waitForProgressBarToComplete();
			
			//	rasagna //verifyJobStatus(jobId, "complete");
			
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	private boolean verifyJobStatus(String jobId, String status) {
		try {
			System.out.println("entered verify wala try ");
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-zauto']//div[text()='"+jobId+"']/parent::div/parent::div/following-sibling::div//div[text()='"+status+"']")
					, "Status for saved job not found as: "+ status);
			System.out.println("Done verify wala try ");
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
}

