package com.thed.zeuihtml.ze.impl.zehtmlpages;

import java.security.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.xmlbeans.impl.jam.mutable.MComment;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.utils.Driver;

public class DefectTrackingPage {

	Logger logger;
	
	public DefectTrackingPage(){
		logger = Logger.getLogger(this.getClass());
	}
	
	public static DefectTrackingPage getInstance(){
		return PageFactory.initElements(Driver.driver, DefectTrackingPage.class);
	}
	

	/******************************************************
	 * 	WEBELEMENTS
	 *****************************************************/
	
	@FindBy(xpath="//span[text()='Create Defect']/parent::button")
	private WebElement buttonLaunchCreateDefect;
	
	@FindBy(xpath="//h4[text()='File New Defect']")
	private WebElement headerFileNewDefect;
	
	@FindBy(xpath="//span[@id='select2-fileNewDefectProject-container']")
	private WebElement dropdownSelectProjectInFileNewDefect;
	
	@FindBy(xpath="//label/b[text()='Issue Type']/parent::label/parent::span/following-sibling::span//span[@id='select2-issueType-container']")
	private WebElement dropdownSelectIssueTypeInFileNewDefect;
	
	@FindBy(xpath="//div[@id='file-new-defect-modal']//button[text()='Next']")
	private WebElement buttonNextInFileNewDefect;
	
	@FindBy(xpath="//b[text()='Summary']/parent::label/parent::span/parent::div/following-sibling::div//input")
	private WebElement textboxDefectSummary;
	
	@FindBy(xpath="//select[@id='copySteps']")
	private WebElement selectDefectDescriptionDropdownList;
	
	@FindBy(xpath="//b[text()='Description']/parent::label/parent::span/parent::div/following-sibling::div//textarea")
	private WebElement textareaDescription;
	
	@FindBy(xpath="//select[@id='priority-field']/following-sibling::span")
	private WebElement dropdownSelectPriority;
	
	@FindBy(xpath="//b[text()='Component/s']/parent::label/parent::span/parent::div/following-sibling::div//select")
	private WebElement selectComponents;
	
	@FindBy(xpath=".//*[@id='multiComponents-field-wrap-file-new']//input")
	private WebElement componentclick;
	
	@FindBy(xpath=".//*[@id='fixVersions-field-wrap-file-new']//input")
	private WebElement selectFixversions;
	
	@FindBy(xpath="//label[@title='Text single line']/parent::span/parent::div/following-sibling::div//input")
	private WebElement Cf_text;
	
	@FindBy(xpath="//b[text()='Text Multi Line']/parent::label/parent::span/parent::div/following-sibling::div//textarea")
	private WebElement Cf_long;
	
	@FindBy(xpath="//b[text()='Select Multiple']/parent::label/parent::span/parent::div/following-sibling::div//input")
	private WebElement Cf_selectMultipleClick;
	
	@FindBy(xpath="//b[text()='Select single']/parent::label/parent::span/parent::div/following-sibling::div//span[text()='Please select a value']")
	private WebElement Cf_selectSingleClick;
	
	
	@FindBy(xpath="//button[text()='Create']")
	private WebElement buttonCreateDefect;
	
	@FindBy(xpath="//a[text()='Advanced']")
	private WebElement linkAdvanced;
	
	@FindBy(xpath="//input[@id='searchDefectsJQL']")
	private WebElement textboxJQL;
	
	@FindBy(xpath="//div[@class='defects-advanced-search-container']//button[text()='Search']")
	private WebElement buttonSearchInAdvance;
	
	@FindBy(xpath="//input[@name='gridBarDefectId']")
	private WebElement textboxDefectID;
	
	@FindBy(xpath="//input[@name='gridBarDefectId']/following-sibling::span//button[@class='zui-btn zui-btn-primary']")
	private WebElement buttonSearchByID;
	
	@FindBy(xpath="//a[text()='Basic']")
	private WebElement linkBasicSearch;
	
	@FindBy(xpath="//select[@id='searchChoice']/following-sibling::span")
	private WebElement dropdownSearchType;
	
	@FindBy(xpath="//select[@id='defectFiltersDropdown']/following-sibling::span")
	private WebElement selectFilter;
	
	@FindBy(xpath="//div[contains(@id,'defect-advanced-detail-modal')]//h4[contains(text(),'Update Defect :')]")
	private WebElement headerUpdateDefect;

	@FindBy(xpath="//div[contains(@id,'defect-advanced-detail-modal')]//button[text()='Update']/preceding-sibling::button[text()='Cancel']")
	private WebElement buttonCancelInUpdateDefectWindow;
	
	//Export
	
	@FindBy(xpath="//input[@id='defect_select']")
	private WebElement checkboxSealectAllSearchedDefct;
	
	@FindBy(xpath="//button[text()='Export']")
	private WebElement buttonExport;
	
	@FindBy(xpath="//h4[text()='Download File']")
	private WebElement headerDownloadFile;
	
	@FindBy(xpath="//button[text()='Download']")
	private WebElement buttonDownload;
	
	/******************************************************
	 * 	Methods
	 *****************************************************/
	
	public boolean createNewDefectFromDefectTrackingApp(Map<String, String> values){
		
		try{
			String defectSummary = values.get("Summary") + " " +  new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
			
			
			HomePage.getInstance().waitForProgressBarToComplete();
			buttonLaunchCreateDefect.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerFileNewDefect)
					, "Header not found as File New Defect in popup after clicking on button 'Link New Defect'");
			
			CommonUtil.normalWait(1000);
			
			if(values.containsKey("Project")){
				dropdownSelectProjectInFileNewDefect.click();
				CommonUtil.normalWait(1000);
				CommonUtil.returnWebElement("//li[text()='"+values.get("Project")+"']").click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
			}
			
			if(values.containsKey("Issue Type")){
				dropdownSelectIssueTypeInFileNewDefect.click();
				CommonUtil.normalWait(1000);
				CommonUtil.returnWebElement("//li[text()='"+values.get("Issue Type")+"']").click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(3000);
				
			}
			
			buttonNextInFileNewDefect.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textboxDefectSummary), "Textbox Defect Summary not found");
			
			if(values.containsKey("Summary")){
				textboxDefectSummary.sendKeys(defectSummary);
				CommonUtil.normalWait(1000);
			}else{
				Assert.assertTrue(false, "Summary of defect is mandatory");
			}
			
			if(values.containsKey("Components")){
				componentclick.click();
				CommonUtil.normalWait(1000);
				CommonUtil.returnWebElement(".//ul[@id='select2-multiComponents-field-results']/li[text()='"+values.get("Components")+"']").click();
				
				//CommonUtil.selectListWithVisibleText(selectComponents, values.get("Components"));
				CommonUtil.normalWait(1000);
			}
			
			if(values.containsKey("FixVersions")){
				selectFixversions.click();
				CommonUtil.normalWait(1000);
				CommonUtil.returnWebElement(".//*[@id='select2-fixVersions-field-results']/li[text()='"+values.get("FixVersions")+"']").click();
				//CommonUtil.selectListWithVisibleText(selectFixversions, values.get("FixVersions"));
				CommonUtil.normalWait(1000);
			}

			if(values.containsKey("Description")){
				String description = values.get("Description");
				if(description.equals("As plain text")||description.equals("As wiki markup")){
					CommonUtil.selectListWithVisibleText(selectDefectDescriptionDropdownList, description);
				}else{
					textareaDescription.sendKeys(description);
					}
				CommonUtil.normalWait(1000);
			}
			
			if(values.containsKey("Priority")){
				dropdownSelectPriority.click();
				CommonUtil.normalWait(1000);
				CommonUtil.returnWebElement("//li[text()='"+values.get("Priority")+"']").click();
				CommonUtil.normalWait(1000);
			}
			
			HomePage.getInstance().waitForProgressBarToComplete();
			buttonCreateDefect.click();
			logger.info("Defect created successfully");
			CommonUtil.normalWait(3000);
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(2000);
			CommonUtil.visibilityOfElementLocated(headerUpdateDefect);
			CommonUtil.normalWait(3000);
			buttonCancelInUpdateDefectWindow.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			
			logger.info("Going to verify created defect by name: " + defectSummary);
			
			linkAdvanced.click();
			CommonUtil.normalWait(3000);
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(2000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textboxJQL), "Textbox JQL not found after clicking on Advance link");
			textboxJQL.sendKeys("summary ~ \""+defectSummary+"\"");
			CommonUtil.normalWait(2000);
			buttonSearchInAdvance.click();
			CommonUtil.normalWait(2000);
			HomePage.getInstance().waitForProgressBarToComplete();
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-DEFECT_DETAILS']//div[text()='"+defectSummary+"']"), "Defect not found in advance search after creating by name: "+ defectSummary);
			
			CommonUtil.returnWebElement("//div[@id='grid-table-DEFECT_DETAILS']//div[text()='"+defectSummary+"']").click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
		
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//b[text()='Component']/parent::strong/following-sibling::span//span[text()='"+values.get("Components")+"']")
					, "For created defect Component not found as: " + values.get("Components"));
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//b[text()='Fix Versions']/parent::strong/following-sibling::span//span[text()='"+values.get("FixVersions")+"']")
					, "For created defect Fix Versions not found as: " + values.get("FixVersions"));
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		finally {
			linkBasicSearch.click();
		}
		return true;
	}
	
	public boolean verifySearchedDefect(Map<String, String> valuesToVerify){
		try{
			
			if(valuesToVerify.containsKey("Summary")){
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-DEFECT_DETAILS']//div[text()='"+valuesToVerify.get("Summary")+"']"), "Defect not found after search by name: "+ valuesToVerify.get("Summary"));
				CommonUtil.returnWebElement("//div[@id='grid-table-DEFECT_DETAILS']//div[text()='"+valuesToVerify.get("Summary")+"']").click();
				CommonUtil.normalWait(2000);
				HomePage.getInstance().waitForProgressBarToComplete();
			
				if(valuesToVerify.containsKey("Components")){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//b[text()='Component']/parent::strong/following-sibling::span//span[text()='"+valuesToVerify.get("Components")+"']")
							, "For created defect Component not found as: " + valuesToVerify.get("Components"));
				}
				if(valuesToVerify.containsKey("FixVersions")){
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//b[text()='Fix Versions']/parent::strong/following-sibling::span//span[text()='"+valuesToVerify.get("FixVersions")+"']")
							, "For created defect Fix Versions not found as: " + valuesToVerify.get("FixVersions"));
				}
				
			}
			

		}catch(Exception e){
			logger.info("Failed to search defect by ID");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean searchByIdOrJqlOrFilter(String searchType, String searchValue, boolean launchAdvanced, Map<String, String> valuesToVerify){
		try{
			HomePage.getInstance().waitForProgressBarToComplete();
			if(searchType.equalsIgnoreCase("ID")){
				Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textboxDefectID), "Textbox to search by defectID not found");
				textboxDefectID.sendKeys(searchValue);
				CommonUtil.normalWait(3000);
				buttonSearchByID.click();
				CommonUtil.normalWait(3000);
				HomePage.getInstance().waitForProgressBarToComplete();
				
			}else{
				if(launchAdvanced){
					linkAdvanced.click();
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.normalWait(2000);
				}
				HomePage.getInstance().waitForProgressBarToComplete();
				dropdownSearchType.click();
				CommonUtil.normalWait(5000);
				if(searchType.equalsIgnoreCase("JQL")){
					CommonUtil.returnWebElement("//li[text()='JQL']").click();
					HomePage.getInstance().waitForProgressBarToComplete();
					CommonUtil.normalWait(5000);
					Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textboxJQL), "Textbox JQL not found after clicking on Advance link");
					textboxJQL.clear();
					CommonUtil.normalWait(5000);
					textboxJQL.sendKeys(searchValue);
					CommonUtil.normalWait(5000);
					buttonSearchInAdvance.click();
					CommonUtil.normalWait(5000);
					HomePage.getInstance().waitForProgressBarToComplete();
				}else{
					if(searchType.equalsIgnoreCase("My Filter")){
						CommonUtil.returnWebElement("//li[text()='My Filters']").click();
						CommonUtil.normalWait(5000);
						HomePage.getInstance().waitForProgressBarToComplete();
						CommonUtil.normalWait(5000);
						selectFilter.click();
						CommonUtil.normalWait(1000);
						CommonUtil.returnWebElement(".//*[@id='select2-defectFiltersDropdown-results']/li[text()='"+searchValue+"']").click();
						buttonSearchInAdvance.click();
						CommonUtil.normalWait(5000);
						HomePage.getInstance().waitForProgressBarToComplete();
						
					}else{
						Assert.assertTrue(false, "Search Type not valid please provide search type as: ID or JQL or My Filter");
						return false;
					}
				}
				if (valuesToVerify!=null) {
					verifySearchedDefect(valuesToVerify);
				}
			}
			
		}catch(Exception e){
			logger.info("Failed to search defect");
			e.printStackTrace();
			return false;
		}
		finally {
			if (launchAdvanced) {
				CommonUtil.normalWait(1000);
				linkBasicSearch.click();
				CommonUtil.normalWait(1000);
			}
		}
		return true;
	}
	
	public boolean navigateToTestcaseLinkedWithDefectFromDefectTrackingApp(String defectSummay, String linkedTestcaseName){
		
		try{
			CommonUtil.returnWebElement("//div[@id='grid-table-DEFECT_DETAILS']//div[text()='"+defectSummay+"']").click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-DEFECT_DETAILS']//div[text()='"+defectSummay+"']/parent::div/parent::div/following-sibling::div[5]//span[text()='"+linkedTestcaseName+"']")
					, "Failed to find the linked testcases by name: "+linkedTestcaseName+" after defect search for defect summary: "+defectSummay );
			
			CommonUtil.returnWebElement("//div[@id='grid-table-DEFECT_DETAILS']//div[text()='"+defectSummay+"']/parent::div/parent::div/following-sibling::div[5]//span[text()='"+linkedTestcaseName+"']/parent::div/parent::div/parent::div/preceding-sibling::div//div/a")
			.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			
		}catch(Exception e){
			logger.info("Failed to navigate to testcase successfully");
			e.printStackTrace();
			return false;
		}
		return true;
		
	}
	
	public boolean exportSearchedDefectResults() {
		try {
			logger.info("Going to click on select all searched checkbox");
			checkboxSealectAllSearchedDefct.click();
			CommonUtil.normalWait(1000);
			logger.info("Going to click Export button after selecting all checkbox");
			buttonExport.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerDownloadFile)
					, "Header Download File not found");
			logger.info("Going to click on Download button");
			buttonDownload.click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
			logger.info("Defect Exported successfully");
		} catch (Exception e) {
			logger.info("Failed to export defect successfully");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
public boolean createNewDefectwithCustomfield(Map<String, String> values){
		
		try{
			String defectSummary = values.get("Summary") + " " +  new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
			
			CommonUtil.normalWait(3000);
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.moveToElement(buttonLaunchCreateDefect);
			buttonLaunchCreateDefect.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(headerFileNewDefect)
					, "Header not found as File New Defect in popup after clicking on button 'Link New Defect'");
			
			CommonUtil.normalWait(1000);
			
			if(values.containsKey("Project")){
				dropdownSelectProjectInFileNewDefect.click();
				CommonUtil.normalWait(1000);
				CommonUtil.returnWebElement("//li[text()='"+values.get("Project")+"']").click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(1000);
			}
			
			if(values.containsKey("Issue Type")){
				dropdownSelectIssueTypeInFileNewDefect.click();
				CommonUtil.normalWait(1000);
				CommonUtil.returnWebElement("//li[text()='"+values.get("Issue Type")+"']").click();
				HomePage.getInstance().waitForProgressBarToComplete();
				CommonUtil.normalWait(3000);
				
			}
			
			buttonNextInFileNewDefect.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(1000);

			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textboxDefectSummary), "Textbox Defect Summary not found");
			
			if(values.containsKey("Summary")){
				textboxDefectSummary.sendKeys(defectSummary);
				CommonUtil.normalWait(1000);
			}else{
				Assert.assertTrue(false, "Summary of defect is mandatory");
			}
			
			if(values.containsKey("Components")){
				componentclick.click();
				CommonUtil.normalWait(1000);
				CommonUtil.returnWebElement(".//ul[@id='select2-multiComponents-field-results']/li[text()='"+values.get("Components")+"']").click();
				
				//CommonUtil.selectListWithVisibleText(selectComponents, values.get("Components"));
				CommonUtil.normalWait(1000);
			}
			
			if(values.containsKey("FixVersions")){
				selectFixversions.click();
				CommonUtil.normalWait(1000);
				CommonUtil.returnWebElement(".//*[@id='select2-fixVersions-field-results']/li[text()='"+values.get("FixVersions")+"']").click();
				//CommonUtil.selectListWithVisibleText(selectFixversions, values.get("FixVersions"));
				CommonUtil.normalWait(1000);
			}

			if(values.containsKey("Description")){
				String description = values.get("Description");
				if(description.equals("As plain text")||description.equals("As wiki markup")){
					CommonUtil.selectListWithVisibleText(selectDefectDescriptionDropdownList, description);
				}else{
					textareaDescription.sendKeys(description);
					}
				CommonUtil.normalWait(1000);
			}
			
			if(values.containsKey("Priority")){
				dropdownSelectPriority.click();
				CommonUtil.normalWait(1000);
				CommonUtil.returnWebElement("//li[text()='"+values.get("Priority")+"']").click();
				
				CommonUtil.normalWait(1000);
			}
			
			if(values.containsKey("Cf_Text")){
				String cf_text = values.get("Cf_Text");
				Cf_text.clear();
				Cf_text.sendKeys(cf_text);
				CommonUtil.normalWait(1000);
			}
			
			if(values.containsKey("Cf_Long")){
				String cf_long = values.get("Cf_Long");
				Cf_long.clear();
				Cf_long.sendKeys(cf_long);
				CommonUtil.normalWait(1000);
			}
			
			if(values.containsKey("Cf_SelectMultiple")){
				CommonUtil.normalWait(1000);
				Cf_selectMultipleClick.click();
				CommonUtil.returnWebElement(".//*[@class ='select2-results']//li[text()='"+values.get("Cf_SelectMultiple")+"']").click();
				CommonUtil.normalWait(1000);
			}
			
			if(values.containsKey("Cf_SelectSingle")){
				CommonUtil.normalWait(1000);
				Cf_selectSingleClick.click();
				CommonUtil.returnWebElement("//*[@class ='select2-results']//li[text()='"+values.get("Cf_SelectSingle")+"']").click();
				CommonUtil.normalWait(1000);
				
			}
			
			HomePage.getInstance().waitForProgressBarToComplete();
			buttonCreateDefect.click();
			logger.info("Defect created successfully");
			CommonUtil.normalWait(3000);
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(2000);
			CommonUtil.visibilityOfElementLocated(headerUpdateDefect);
			CommonUtil.normalWait(3000);
			buttonCancelInUpdateDefectWindow.click();
			HomePage.getInstance().waitForProgressBarToComplete();
			
			logger.info("Going to verify created defect by name: " + defectSummary);
			
			linkAdvanced.click();
			CommonUtil.normalWait(3000);
			HomePage.getInstance().waitForProgressBarToComplete();
			CommonUtil.normalWait(2000);
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated(textboxJQL), "Textbox JQL not found after clicking on Advance link");
			textboxJQL.sendKeys("summary ~ \""+defectSummary+"\"");
			CommonUtil.normalWait(2000);
			buttonSearchInAdvance.click();
			CommonUtil.normalWait(2000);
			HomePage.getInstance().waitForProgressBarToComplete();
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//div[@id='grid-table-DEFECT_DETAILS']//div[text()='"+defectSummary+"']"), "Defect not found in advance search after creating by name: "+ defectSummary);
			
			CommonUtil.returnWebElement("//div[@id='grid-table-DEFECT_DETAILS']//div[text()='"+defectSummary+"']").click();
			CommonUtil.normalWait(1000);
			HomePage.getInstance().waitForProgressBarToComplete();
		
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//b[text()='Component']/parent::strong/following-sibling::span//span[text()='"+values.get("Components")+"']")
					, "For created defect Component not found as: " + values.get("Components"));
			
			Assert.assertTrue(CommonUtil.visibilityOfElementLocated("//b[text()='Fix Versions']/parent::strong/following-sibling::span//span[text()='"+values.get("FixVersions")+"']")
					, "For created defect Fix Versions not found as: " + values.get("FixVersions"));
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
}
