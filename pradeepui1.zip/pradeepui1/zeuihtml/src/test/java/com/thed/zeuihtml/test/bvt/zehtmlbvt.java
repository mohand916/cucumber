package com.thed.zeuihtml.test.bvt;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.thed.zeuihtml.BaseTest;
import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.Constants;
import com.thed.zeuihtml.utils.CommonUtil;
import com.thed.zeuihtml.ze.ZeNavigator;

public class zehtmlbvt extends BaseTest {


	public zehtmlbvt() {
		logger = Logger.getLogger(this.getClass());
	}

	@Test(enabled = testEnabled, priority = 1)
	public void bvt1_launchZephyrTest() {
		logger.info("Executing bvt1...");
		altID = 1;
		testcaseId = "218";
		
		zeNavigator.verifyLoginPage();
		isSuccess = true;
		logger.info("bvt1 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 2)
	public void bvt2_loginToZephyrTest() {
		logger.info("Executing bvt2...");
		altID = 2;
		testcaseId = "219";

		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
		zeNavigator.verifyProjectSummaryPage("Sample Project", "Test Manager", null, null, null, null, null);

		isSuccess = true;
		logger.info("bvt2 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 3)
	public void bvt3_launchAllAppsTest() {
		logger.info("Executing bvt3...");
		altID = 3;

		if (zeNavigator.selectReleaseFromGrid("Release 1.0")) {
			zeNavigator.verifyReleaseSummaryPage("Release 1.0");
		} else {
			isSuccess = false;
			Assert.assertTrue(isSuccess,
					"Failed to Select and Launch Release Summary Page for Release Name: " + "Release 1.0");
		}
		// Inprogress to check for all Apps

		isSuccess = true;
		logger.info("bvt3 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 4)
	public void bvt4_setMailComapanyAndSystemNameTest() {
		logger.info("Executing bvt4...");
		altID = 4;
		zeNavigator.launchAdministration();
		zeNavigator.verifySystemConfigPage("Your Company", "Test Department", Config.getValue("ZE_DESKTOP_URL"),
				Config.getValue("ZE_DASHBOARD_URL"), "0.0.0.0", "25", null);
		zeNavigator.changeSystemConfigurations("Zephyr", "QA", Config.getValue("MAILSERVER_IP"),
				Config.getValue("MAILSERVER_PORT"), Config.getValue("MAILSERVER_USERNAME"),
				Config.getValue("MAILSERVER_PASSWORD"));
		zeNavigator.verifySystemConfigPage("Zephyr", "QA", Config.getValue("ZE_DESKTOP_URL"),
				Config.getValue("ZE_DASHBOARD_URL"), Config.getValue("MAILSERVER_IP"),
				Config.getValue("MAILSERVER_PORT"), Config.getValue("MAILSERVER_USERNAME"));
		isSuccess = true;
		logger.info("bvt4 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 5)
	public void bvt5_setDTJiraTest() {
		logger.info("Executing bvt5...");
		altID = 5;

		isSuccess = zeNavigator.setDefectTracking();
		Assert.assertTrue(isSuccess, "Failed to set Defect Tracking");
		logger.info("bvt5 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 6)
	public void bvt6_setDefectUserInDefectAdminTest() {
		logger.info("Executing bvt6...");
		altID = 6;

		isSuccess = zeNavigator.setUserJiraCredentialsinExternalPopup();
		Assert.assertTrue(isSuccess, "Failed to set User Credentials in External popup");
		zeNavigator.launchAdminApps("ManageProjects");
		logger.info("bvt6 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 7)
	public void bvt7_addTestcaseCustomFieldsTest() {
		logger.info("Executing bvt7...");
		altID = 7;

		List<String> pickListValues = new ArrayList<String>();
		pickListValues.add(0, Config.getTCRPropValue("TC_PICKLIST_VALUE_1"));
		pickListValues.add(1, Config.getTCRPropValue("TC_PICKLIST_VALUE_2"));
		pickListValues.add(2, Config.getTCRPropValue("TC_PICKLIST_VALUE_3"));
		pickListValues.add(3, Config.getTCRPropValue("TC_PICKLIST_VALUE_4"));
		
		Assert.assertTrue(zeNavigator.launchAdminApps("Customization"), "Failed to launch Customization App");
		Assert.assertTrue(zeNavigator.launchCustomizationOptions("TestcaseCustomField"),
				"Failed to launch Testcase Custom Field Window");
		Assert.assertTrue(zeNavigator.lockZephyrAccess(true), "Failed to lock Zephyr");

		Assert.assertTrue(
				zeNavigator.addCustomField(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_1"),
						Config.getTCRPropValue("TEXT_CUSTOM_FIELD_TYPE"),
						Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_1"), true, false, Config.getProjectPropValue("DEFAULT_PROJECT"),true),
				"Failed to Add custom field");
		Assert.assertTrue(
				zeNavigator.addCustomField(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_2"),
						Config.getTCRPropValue("LONGTEXT_CUSTOM_FIELD_TYPE"),
						Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_2"), true, false, Config.getProjectPropValue("DEFAULT_PROJECT"),true),
				"Failed to Add custom field");
		Assert.assertTrue(
				zeNavigator.addCustomField(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_3"),
						Config.getTCRPropValue("CHECKBOX_CUSTOM_FIELD_TYPE"),
						Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_3"), true, false, Config.getProjectPropValue("DEFAULT_PROJECT"),true),
				"Failed to Add custom field");
		Assert.assertTrue(
				zeNavigator.addCustomField(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_4"),
						Config.getTCRPropValue("DATE_CUSTOM_FIELD_TYPE"),
						Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_4"), false, false, Config.getProjectPropValue("DEFAULT_PROJECT"),true),
				"Failed to Add custom field");
		Assert.assertTrue(
				zeNavigator.addCustomField(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_5"),
						Config.getTCRPropValue("NUMBER_CUSTOM_FIELD_TYPE"),
						Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_5"), true, false, Config.getProjectPropValue("DEFAULT_PROJECT"),true),
				"Failed to Add custom field");
		Assert.assertTrue(
				zeNavigator.addCustomFieldPicklist(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_6"),
						Config.getTCRPropValue("PICKLIST_CUSTOM_FIELD_TYPE"),
						Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_6"), true, false, pickListValues, Config.getProjectPropValue("DEFAULT_PROJECT"),true),
				"Failed to Add custom field");

		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_1"),
						Config.getTCRPropValue("TEXT_CUSTOM_FIELD_TYPE"),
						Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_1"), true, false),
				"Custom Field verification failed");
		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_2"),
						Config.getTCRPropValue("LONGTEXT_CUSTOM_FIELD_TYPE"),
						Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_2"), true, false),
				"Custom Field verification failed");
		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_3"),
						Config.getTCRPropValue("CHECKBOX_CUSTOM_FIELD_TYPE"),
						Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_3"), true, false),
				"Custom Field verification failed");
		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_4"),
						Config.getTCRPropValue("DATE_CUSTOM_FIELD_TYPE"),
						Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_4"), true, false),
				"Custom Field verification failed");
		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_5"),
						Config.getTCRPropValue("NUMBER_CUSTOM_FIELD_TYPE"),
						Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_5"), true, false),
				"Custom Field verification failed");
		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_6"),
						Config.getTCRPropValue("PICKLIST_CUSTOM_FIELD_TYPE"),
						Config.getTCRPropValue("TC_CUSTOM_FIELD_DESCRIPTION_6"), true, false),
				"Custom Field verification failed");

		Assert.assertTrue(zeNavigator.lockZephyrAccess(false), "Failed to unlock Zephyr Access");
		isSuccess = true;
		logger.info("bvt7 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 8)
	public void bvt8_addRequirementCustomFieldsTest() {
		logger.info("Executing bvt8...");
		altID = 8;

		List<String> pickListValues = new ArrayList<String>();
		pickListValues.add(0, Config.getReqPropValue("RQ_PICKLIST_VALUE_1"));
		pickListValues.add(1, Config.getReqPropValue("RQ_PICKLIST_VALUE_2"));
		pickListValues.add(2, Config.getReqPropValue("RQ_PICKLIST_VALUE_3"));
		pickListValues.add(3, Config.getReqPropValue("RQ_PICKLIST_VALUE_4"));

		Assert.assertTrue(zeNavigator.launchCustomizationOptions("RequirementCustomField"),
				"Failed to launch Requirement Custom Field Window");
		Assert.assertTrue(zeNavigator.lockZephyrAccess(true), "Failed to lock Zephyr");

		Assert.assertTrue(
				zeNavigator.addCustomField(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_1"),
						Config.getReqPropValue("TEXT_CUSTOM_FIELD_TYPE"),
						Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_1"), true, false, Config.getProjectPropValue("DEFAULT_PROJECT"),true),
				"Failed to Add custom field");
		Assert.assertTrue(
				zeNavigator.addCustomField(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_2"),
						Config.getReqPropValue("LONGTEXT_CUSTOM_FIELD_TYPE"),
						Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_2"), true, false, Config.getProjectPropValue("DEFAULT_PROJECT"),true),
				"Failed to Add custom field");
		Assert.assertTrue(
				zeNavigator.addCustomField(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_3"),
						Config.getReqPropValue("CHECKBOX_CUSTOM_FIELD_TYPE"),
						Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_3"), true, false, Config.getProjectPropValue("DEFAULT_PROJECT"),true),
				"Failed to Add custom field");
		Assert.assertTrue(
				zeNavigator.addCustomField(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_4"),
						Config.getReqPropValue("DATE_CUSTOM_FIELD_TYPE"),
						Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_4"), false, false, Config.getProjectPropValue("DEFAULT_PROJECT"),true),
				"Failed to Add custom field");
		Assert.assertTrue(
				zeNavigator.addCustomField(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_5"),
						Config.getReqPropValue("NUMBER_CUSTOM_FIELD_TYPE"),
						Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_5"), true, false, Config.getProjectPropValue("DEFAULT_PROJECT"),true),
				"Failed to Add custom field");
		Assert.assertTrue(
				zeNavigator.addCustomFieldPicklist(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_6"),
						Config.getReqPropValue("PICKLIST_CUSTOM_FIELD_TYPE"),
						Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_6"), true, false, pickListValues, Config.getProjectPropValue("DEFAULT_PROJECT"),true),
				"Failed to Add custom field");

		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_1"),
						Config.getReqPropValue("TEXT_CUSTOM_FIELD_TYPE"),
						Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_1"), true, false),
				"Custom Field verification failed");
		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_2"),
						Config.getReqPropValue("LONGTEXT_CUSTOM_FIELD_TYPE"),
						Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_2"), true, false),
				"Custom Field verification failed");
		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_3"),
						Config.getReqPropValue("CHECKBOX_CUSTOM_FIELD_TYPE"),
						Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_3"), true, false),
				"Custom Field verification failed");
		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_4"),
						Config.getReqPropValue("DATE_CUSTOM_FIELD_TYPE"),
						Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_4"), true, false),
				"Custom Field verification failed");
		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_5"),
						Config.getReqPropValue("NUMBER_CUSTOM_FIELD_TYPE"),
						Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_5"), true, false),
				"Custom Field verification failed");
		Assert.assertTrue(
				zeNavigator.verifyCustomFields(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_6"),
						Config.getReqPropValue("PICKLIST_CUSTOM_FIELD_TYPE"),
						Config.getReqPropValue("RQ_CUSTOM_FIELD_DESCRIPTION_6"), true, false),
				"Custom Field verification failed");

		Assert.assertTrue(zeNavigator.lockZephyrAccess(false), "Failed to unlock Zephyr Access");
		isSuccess = true;
		logger.info("bvt8 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 9)
	public void bvt9_addExecutionCustomStatusTest() {
		logger.info("Executing bvt9...");
		altID = 9;

		Assert.assertTrue(zeNavigator.launchCustomizationOptions("ExecutionStatus"),
				"Failed to launch Manage Execution Status Window");
		System.out.println(Config.getTCEPropValue("CUSTOM_EXECUTION_STATUS_1"));
		String customExecutionStatus = Config.getTCEPropValue("CUSTOM_EXECUTION_STATUS_1");
		Assert.assertTrue(zeNavigator.addExecutionStatus(customExecutionStatus),
				"Failed to Add Custom Status by name: " + customExecutionStatus);
		zeNavigator.verifyExecutionStatus(customExecutionStatus, true);
		isSuccess = true;
		logger.info("bvt9 is completed successfully...");
	}

	@Test(enabled = testEnabled, priority = 10)
	public void bvt10_addStepExecutionCustomStatusTest() {
		logger.info("Executing bvt10...");
		altID = 10;
		Assert.assertTrue(zeNavigator.launchCustomizationOptions("StepExecutionStatus"),
				"Failed to launch Manage Execution Status Window");
		String customExecutionStatus = Config.getTCEPropValue("CUSTOM_STEP_EXECUTION_STATUS_1");
		Assert.assertTrue(zeNavigator.addExecutionStatus(customExecutionStatus),
				"Failed to Add Custom Status by name: " + customExecutionStatus);
		zeNavigator.verifyExecutionStatus(customExecutionStatus, true);
		isSuccess = true;
		logger.info("bvt10 is completed successfully...");
	}

	@Test(enabled = testEnabled, priority = 11)
	public void bvt11_updateEstimatedTimeTest() {
		logger.info("Executing bvt11...");
		altID = 11;

		Assert.assertTrue(zeNavigator.launchCustomizationOptions("EstimatedTime"),
				"Failed to launch Manage Execution Status Window");
		Assert.assertTrue(zeNavigator.updateDefaultEstimatedTime(Config.getTCRPropValue("NEW_ESTIMATED_TIME")),
				"Failed to update estimation time");
		Assert.assertTrue(zeNavigator.launchCustomizationOptions("EstimatedTime"),
				"Failed to launch Manage Execution Status Window");
		zeNavigator.verifyEstimatedTime(Config.getTCRPropValue("NEW_ESTIMATED_TIME"));
		isSuccess = true;
		logger.info("bvt11 is completed successfully...");
	}

	@Test(enabled = testEnabled, priority = 12)
	public void bvt12_updateEstimatedTimeToDefaultTest() {
		logger.info("Executing bvt12...");
		altID = 12;

		Assert.assertTrue(zeNavigator.launchCustomizationOptions("EstimatedTime"),
				"Failed to launch Manage Execution Status Window");
		Assert.assertTrue(zeNavigator.updateDefaultEstimatedTime(Config.getTCRPropValue("DEFAULT_ESTIMATED_TIME")),
				"Failed to update estimation time");
		Assert.assertTrue(zeNavigator.launchCustomizationOptions("EstimatedTime"),
				"Failed to launch Manage Execution Status Window");
		zeNavigator.verifyEstimatedTime(Config.getTCRPropValue("DEFAULT_ESTIMATED_TIME"));
		isSuccess = true;
		logger.info("bvt12 is completed successfully...");
	}

	@Test(enabled = testEnabled, priority = 13)
	public void bvt13_addNewLeadWithMandatoryFieldsTest() {
		logger.info("Executing bvt13...");
		altID = 13;

		Assert.assertTrue(zeNavigator.launchAdminApps("ManageUsers"), "Failed to launch Manage User App");
		Assert.assertTrue(
				zeNavigator.addNewUser(Config.getUsersPropValue("USER1_FIST_LAST_NAME"),
						Config.getUsersPropValue("USER1_ROLE"), Config.getUsersPropValue("USER1_EMAIL"),
						Config.getUsersPropValue("USER1_LOCATION")),
				"Failed to add new user, please check logs for details");
		zeNavigator.verifyUser(Config.getUsersPropValue("USER1_FIST_LAST_NAME"),
				Config.getUsersPropValue("USER1_ROLE"), Config.getUsersPropValue("USER1_EMAIL"),
				Config.getUsersPropValue("USER1_LOCATION"));
		isSuccess = true;

		logger.info("bvt13 is completed successfully...");
	}

	@Test(enabled = testEnabled, priority = 14)
	public void bvt14_addNewTesterWithMandatoryFieldsTest() {
		logger.info("Executing bvt14...");
		altID = 14;

		Assert.assertTrue(
				zeNavigator.addNewUser(Config.getUsersPropValue("USER2_FIST_LAST_NAME"),
						Config.getUsersPropValue("USER2_ROLE"), Config.getUsersPropValue("USER2_EMAIL"),
						Config.getUsersPropValue("USER2_LOCATION")),
				"Failed to add new user, please check logs for details");
		zeNavigator.verifyUser(Config.getUsersPropValue("USER2_FIST_LAST_NAME"),
				Config.getUsersPropValue("USER2_ROLE"), Config.getUsersPropValue("USER2_EMAIL"),
				Config.getUsersPropValue("USER2_LOCATION"));
		isSuccess = true;
		logger.info("bvt14 is completed successfully...");
	}

	@Test(enabled = testEnabled, priority = 15)
	public void bvt15_addNewDashboardUserWithMandatoryFieldsTest() {
		logger.info("Executing bvt15...");
		altID = 15;

		Assert.assertTrue(
				zeNavigator.addNewUser(Config.getUsersPropValue("USER3_FIST_LAST_NAME"),
						Config.getUsersPropValue("USER3_ROLE"), Config.getUsersPropValue("USER3_EMAIL"),
						Config.getUsersPropValue("USER3_LOCATION")),
				"Failed to add new user, please check logs for details");
		zeNavigator.verifyUser(Config.getUsersPropValue("USER3_FIST_LAST_NAME"),
				Config.getUsersPropValue("USER3_ROLE"), Config.getUsersPropValue("USER3_EMAIL"),
				Config.getUsersPropValue("USER3_LOCATION"));
		isSuccess = true;
		logger.info("bvt15 is completed successfully...");
	}

	@Test(enabled = testEnabled, priority = 16)
	public void bvt16_addNormalProjectTest() {
		logger.info("Executing bvt16...");
		altID = 16;

		Assert.assertTrue(zeNavigator.launchAdminApps("ManageProjects"), "Failed to launch Manage Project App");
		zeNavigator.addNewProject(Config.getProjectPropValue("PROJECT1_NAME"),
				Config.getProjectPropValue("PROJECT1_TYPE"), Config.getProjectPropValue("PROJECT1_DESCRIPTION"),
				Config.getProjectPropValue("PROJECT1_STARTDATE"), null, null, null);
		zeNavigator.verifyProject(Config.getProjectPropValue("PROJECT1_NAME"),
				Config.getProjectPropValue("PROJECT1_TYPE"), Config.getProjectPropValue("PROJECT1_DESCRIPTION"),
				Config.getProjectPropValue("PROJECT1_STARTDATE"), null, null, null, null, null);
		isSuccess = true;
		logger.info("bvt16 is completed successfully...");
	}

	@Test(enabled = testEnabled, priority = 17)
	public void bvt17_addRestrictedProjectTest() {
		logger.info("Executing bvt17...");
		altID = 17;

		zeNavigator.addNewProject(Config.getProjectPropValue("PROJECT2_NAME"),
				Config.getProjectPropValue("PROJECT2_TYPE"), Config.getProjectPropValue("PROJECT2_DESCRIPTION"),
				Config.getProjectPropValue("PROJECT2_STARTDATE"), null, null, null);
		zeNavigator.verifyProject(Config.getProjectPropValue("PROJECT2_NAME"),
				Config.getProjectPropValue("PROJECT2_TYPE"), Config.getProjectPropValue("PROJECT2_DESCRIPTION"),
				Config.getProjectPropValue("PROJECT2_STARTDATE"), null, null, null,null, null);
		isSuccess = true;
		logger.info("bvt17 is completed successfully...");

	}

	@Test(enabled = testEnabled, priority = 18)
	public void bvt18_addIsolatedProjectTest() {
		logger.info("Executing bvt18...");
		altID = 18;

		zeNavigator.addNewProject(Config.getProjectPropValue("PROJECT3_NAME"),
				Config.getProjectPropValue("PROJECT3_TYPE"), Config.getProjectPropValue("PROJECT3_DESCRIPTION"),
				Config.getProjectPropValue("PROJECT3_STARTDATE"), null, null, null);
		zeNavigator.verifyProject(Config.getProjectPropValue("PROJECT3_NAME"),
				Config.getProjectPropValue("PROJECT3_TYPE"), Config.getProjectPropValue("PROJECT3_DESCRIPTION"),
				Config.getProjectPropValue("PROJECT3_STARTDATE"), null, null, null,null,null);
		isSuccess = true;
		logger.info("bvt18 is completed successfully...");

	}
	
	/*@Test(enabled = testEnabled, priority = 19)
	public void bvt19_addLeadTwoTesterAndDashboardUserInProjectTest() {
		logger.info("Executing bvt19...");
		altID = 19;
		
		String leadName = Config.getUsersPropValue("USER1_FIST_LAST_NAME");
		List<String> resourceNamesToAdd = new ArrayList<String>();
		resourceNamesToAdd.add(0,Config.getUsersPropValue("TESTER"));
		resourceNamesToAdd.add(1,Config.getUsersPropValue("USER2_FIST_LAST_NAME"));
		resourceNamesToAdd.add(2,Config.getUsersPropValue("USER3_FIST_LAST_NAME"));

		zeNavigator.editProject(Config.getProjectPropValue("PROJECT1_NAME"), null, null, null, null, null, leadName, 
				null, resourceNamesToAdd, null);
		
		zeNavigator.verifyProject(Config.getProjectPropValue("PROJECT1_NAME"), null, null, null, null, 
				leadName, null, resourceNamesToAdd, "4");
		
		isSuccess = true;
		logger.info("bvt19 is completed successfully...");

	}
	
	@Test(enabled = testEnabled, priority = 20)
	public void bvt20_addLeadAndTesterInRestrictedProjectTest() {
		logger.info("Executing bvt20...");
		altID = 20;
		
		String leadName = Config.getUsersPropValue("LEAD");
		List<String> resourceNamesToAdd = new ArrayList<String>();
		resourceNamesToAdd.add(0,Config.getUsersPropValue("TESTER"));

		zeNavigator.editProject(Config.getProjectPropValue("PROJECT2_NAME"), null, null, null, null, null, leadName, 
				null, resourceNamesToAdd, null);
		
		zeNavigator.verifyProject(Config.getProjectPropValue("PROJECT2_NAME"), null, null, null, null, 
				leadName, null, resourceNamesToAdd, "2");
		
		isSuccess = true;
		logger.info("bvt20 is completed successfully...");

	}
	
	@Test(enabled = testEnabled, priority = 21)
	public void bvt21_addLeadAndDashboardUserInIsolatedProjectTest() {
		logger.info("Executing bvt21...");
		altID = 21;
		
		String leadName = Config.getUsersPropValue("LEAD");
		List<String> resourceNamesToAdd = new ArrayList<String>();
		resourceNamesToAdd.add(0,Config.getUsersPropValue("USER3_FIST_LAST_NAME"));

		zeNavigator.editProject(Config.getProjectPropValue("PROJECT3_NAME"), null, null, null, null, null, leadName, 
				null, resourceNamesToAdd, null);
		
		zeNavigator.verifyProject(Config.getProjectPropValue("PROJECT3_NAME"), null, null, null, null, 
				leadName, null, resourceNamesToAdd, "2");
		
		isSuccess = true;
		logger.info("bvt21 is completed successfully...");

	}
	
	@Test(enabled = testEnabled, priority = 22)
	public void bvt22_mapZephyrProjectToJiraProjectAndCheckActivityStreamTest() {
		logger.info("Executing bvt22...");
		altID = 22;
		
		zeNavigator.editProject(Config.getProjectPropValue("PROJECT1_NAME"), null, null, null, null, null, null, 
				Config.getProjectPropValue("JIRA_PROJECT_NAME"), null, null);	
		CommonUtil.normalWait(5000);
		String parentWindowId = CommonUtil.launchNewBrowserWindow(Config.getValue("JIRA_URL"));
		CommonUtil.normalWait(5000);
		jiraNavigator.doJiraLogin(Config.getValue("JIRA_USERNAME"), Config.getValue("JIRA_PASSWORD"));
		isSuccess = jiraNavigator.verifyNewMappedProject(Config.getProjectPropValue("PROJECT1_NAME"), Config.getProjectPropValue("JIRA_PROJECT_NAME"));
		
		CommonUtil.closeCurrentBrowserWindow();
		CommonUtil.returnToParentWindow(parentWindowId);
		Assert.assertTrue(isSuccess, "Activity Stream not found in Jira");
		
		logger.info("bvt21 is completed successfully...");

	}*/
	
	@Test(enabled = testEnabled, priority = 23)
	public void bvt23_createCustomRoleTest() {
		logger.info("Executing bvt23...");
		altID = 23;

		Assert.assertTrue(zeNavigator.launchAdminApps("Customization"), "Failed to launch Customization App");
		Assert.assertTrue(zeNavigator.launchCustomizationOptions("Roles"),
				"Failed to launch Customize Roles Window");
	
		Assert.assertTrue(zeNavigator.addNewRole(Config.getUsersPropValue("ROLE_NAME"), Config.getUsersPropValue("ROLE_DESCRIPTION"), false, true, true, false, 
				true, true, true, true, true, true, true), "Failed to create new Role");
		
		Assert.assertTrue(zeNavigator.launchCustomizationOptions("Roles"),
				"Failed to launch Customize Roles Window");
		zeNavigator.verifyRole(Config.getUsersPropValue("ROLE_NAME"), Config.getUsersPropValue("ROLE_DESCRIPTION"), true);
		isSuccess = true;
		logger.info("bvt23 is completed successfully...");

	}
	
	@Test(enabled = testEnabled, priority = 24)
	public void bvt24_addNewCustomRoleUserTest() {
		logger.info("Executing bvt24...");
		altID = 24;

		Assert.assertTrue(zeNavigator.launchAdminApps("ManageUsers"), "Failed to launch Manage User App");
		Assert.assertTrue(
				zeNavigator.addNewUser(Config.getUsersPropValue("USER4_FIST_LAST_NAME"),
						Config.getUsersPropValue("USER4_ROLE"), Config.getUsersPropValue("USER4_EMAIL"),
						Config.getUsersPropValue("USER4_LOCATION")),
				"Failed to add new custom role user, please check logs for details");
		zeNavigator.verifyUser(Config.getUsersPropValue("USER4_FIST_LAST_NAME"),
				Config.getUsersPropValue("USER4_ROLE"), Config.getUsersPropValue("USER4_EMAIL"),
				Config.getUsersPropValue("USER4_LOCATION"));
		isSuccess = true;
		logger.info("bvt24 is completed successfully...");
	}
	
	
	@Test(enabled = testEnabled, priority = 25)
	public void bvt25_assingMultipleProjectsToCustomRoleUserTest(){
		logger.info("Executing bvt25...");
		altID = 25;
		
		List<String> projectNamesToAdd = new ArrayList<String>();
		projectNamesToAdd.add(0,Config.getProjectPropValue("PROJECT1_NAME"));
		projectNamesToAdd.add(1,Config.getProjectPropValue("PROJECT2_NAME"));
		projectNamesToAdd.add(2,Config.getProjectPropValue("PROJECT3_NAME"));
		
		
		Assert.assertTrue(zeNavigator.assignProjectsToUser(Config.getUsersPropValue("USER4_FIST_LAST_NAME"), projectNamesToAdd)
				, "Failed to assing project to user : " + Config.getUsersPropValue("USER4_FIST_LAST_NAME"));
		
		zeNavigator.verifyProjectsAssignedToUser(Config.getUsersPropValue("USER4_FIST_LAST_NAME"), projectNamesToAdd);
		
		isSuccess = true;
		logger.info("bvt25 is completed successfully...");
	}
	
	@Test(enabled = testEnabled, priority = 26)
	public void bvt26_loginAsCustomRoleAndVerifyAppsTest(){
		logger.info("Executing bvt26...");
		altID = 26;
		
		zeNavigator.logout();
		zeNavigator.doLogin(Config.getUsersPropValue("USER4_USERNAME"), Config.getUsersPropValue("USER4_PASSWORD"));
		zeNavigator.resetPassword(Config.getUsersPropValue("USER4_PASSWORD"));
		
		zeNavigator.launchAdministration();
		zeNavigator.verifyAdminAppsToBePresent(false, true, true, false);
		zeNavigator.selectProject("Success Meet");
		String releaseName = "Release 1.0";
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.verifyReleaseAppsToBePresent(true, true, true, true, true, false);
		
		isSuccess = true;
		logger.info("bvt26 is completed successfully...");
		
	}
	
	@Test(enabled = testEnabled, priority = 27)
	public void bvt27_allAppsCanBeLaunchedTest(){
		logger.info("Executing bvt27...");
		altID = 27;
		
		zeNavigator.launchReleaseApp("Requirements");
		zeNavigator.verifyRequirementApp(Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
		zeNavigator.launchReleaseApp("Test Repository");
		zeNavigator.verifyTestRepositorySummaryPage(Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
		zeNavigator.launchReleaseApp("Test Planning");
		zeNavigator.verifyTestPlanningPage(Config.getReleasePropValue("DEFAULT_RELEASE_NAME"));
				
		zeNavigator.logout();
		zeNavigator.doLogin(Config.getUsersPropValue("ZE_MANAGER_USERNAME"), Config.getUsersPropValue("ZE_MANAGER_PASSWORD"));
		
		isSuccess = true;
		logger.info("bvt27 is completed successfully...");
	}
	

	@Test(enabled = testEnabled, priority = 28)
	public void bvt28_selectOtherProjectFromDropdownAndViewProjectSummaryPageTest(){
		logger.info("Executing bvt28...");
		altID = 28;
		
		Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"))
				, "Failed to select Project : " + Config.getProjectPropValue("PROJECT1_NAME"));
		
		zeNavigator.verifyProjectSummaryPage(Config.getProjectPropValue("PROJECT1_NAME"), Config.getUsersPropValue("MANAGER")
				, 1, 1, 00, 00, 05);
		isSuccess = true;
		logger.info("bvt28 is completed successfully...");
		
	}
	
	@Test(enabled = testEnabled, priority = 29)
	public void bvt29_selectReleaseFromDropdownAndNavigateToReleaseSummayPageTest(){
		logger.info("Executing bvt29...");
		altID = 29;
		
		String releaseName = "Release 1.0";
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.verifyReleaseSummaryPage(releaseName);
		
		isSuccess = true;
		logger.info("bvt29 is completed successfully...");
		
	}
	
	@Test(enabled = testEnabled, priority = 30)
	public void bvt30_clickManageButtonInReleaseSummaryAndLaunchReleaseSetupTest(){
		logger.info("Executing bvt30...");
		altID = 30;
		
		Assert.assertTrue(zeNavigator.launchReleaseSetupPage(), "Failed to launch Release Setup , View Logs for details");
		zeNavigator.verifyReleaseSetupPage();
		
		isSuccess = true;
		logger.info("bvt30 is completed successfully...");
		
	}
	
	@Test(enabled = testEnabled, priority = 31)
	public void bvt31_createNewReleaseTest(){
		logger.info("Executing bvt31...");
		altID = 31;
		
		Assert.assertTrue(zeNavigator.createNewRelease(Config.getReleasePropValue("RELEASE_NAME_1"), Config.getReleasePropValue("RELEASE_DESCRIPTION_1"), 
				false, Config.getReleasePropValue("RELEASE_STARTDATE_1"), null), "failed to create new release");
		
		zeNavigator.verifyReleaseInReleaseSetup(Config.getReleasePropValue("RELEASE_NAME_1"), Config.getReleasePropValue("RELEASE_DESCRIPTION_1"), 
				false, Config.getReleasePropValue("RELEASE_STARTDATE_1"), null);
		
		isSuccess = true;
		logger.info("bvt31 is completed successfully...");
		
	}
	
	@Test(enabled = testEnabled, priority = 32)
	public void bvt32_viewNewlyCreatedReleaseInReleaseDropdownTest(){
		logger.info("Executing bvt32...");
		altID = 32;
		
		Assert.assertTrue(zeNavigator.selectProject(Config.getProjectPropValue("PROJECT1_NAME"))
				, "Failed to select Project : " + Config.getProjectPropValue("PROJECT1_NAME"));
		
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(Config.getReleasePropValue("RELEASE_NAME_1")), "Release not found by name: " +Config.getReleasePropValue("RELEASE_NAME_1"));
		zeNavigator.verifyReleaseSummaryPage(Config.getReleasePropValue("RELEASE_NAME_1"));
		isSuccess = true;
		logger.info("bvt32 is completed successfully...");
		
	}
	
	@Test(enabled = testEnabled, priority = 33)
	public void bvt33_navigateBetweenReleaseFromLeftDropdownTest(){
		logger.info("Executing bvt33...");
		altID = 33;
		
		String releaseOne = Config.getReleasePropValue("DEFAULT_RELEASE_NAME");
		String releaseTwo = Config.getReleasePropValue("RELEASE_NAME_1");
		
		zeNavigator.navigateReleaseFromTopDropdown(releaseOne);
		zeNavigator.navigateReleaseFromTopDropdown(releaseTwo);
		
		isSuccess = true;
		
		logger.info("bvt33 is completed successfully...");
		
	}
	
	@Test(enabled = testEnabled, priority = 34)
	public void bvt34_createHiddenReleaseTest(){
		logger.info("Executing bvt34...");
		altID = 34;
		
		Assert.assertTrue(zeNavigator.launchReleaseSetupPage(), "Failed to launch Release Setup , View Logs for details");
		zeNavigator.verifyReleaseSetupPage();
		
		Assert.assertTrue(zeNavigator.createNewRelease(Config.getReleasePropValue("HIDDEN_RELEASE_NAME"), Config.getReleasePropValue("HIDDEN_RELEASE_dESCRIPTION"), 
				true, Config.getReleasePropValue("HIDDEN_RELEASE_STARTdATE_1"), null), "failed to create new release");
		
		zeNavigator.verifyReleaseInReleaseSetup(Config.getReleasePropValue("HIDDEN_RELEASE_NAME"), Config.getReleasePropValue("HIDDEN_RELEASE_dESCRIPTION"), 
				true, Config.getReleasePropValue("HIDDEN_RELEASE_STARTdATE_1"), null);
		
		isSuccess = true;
		
		logger.info("bvt34 is completed successfully...");
		
	}
	

	@Test(enabled = testEnabled, priority = 35)
	public void bvt35_clickOnTestRepository() {
		logger.info("Executing bvt35...");
		altID = 35;
		testcaseId = "252";

		String releaseName = "Release 1.0";
		String appName = "Test Repository";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		Assert.assertTrue(zeNavigator.navigateToReleaseApps(releaseName, appName), "Not navigated to : " + appName);

		isSuccess = true;
		logger.info("bvt35 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 36)
	public void bvt36_createPhase() {
		logger.info("Executing bvt36...");
		altID = 36;
		testcaseId = "253";

		String releaseName = "Release 1.0";
		String phaseName = Config.getTCRPropValue("PHASE_1");
		String phaseDescription = phaseName + " description";
		Assert.assertTrue(zeNavigator.createPhase(releaseName, phaseName, phaseDescription),
				"Phase not created successfully.");

		phaseName = Config.getTCRPropValue("PHASE_2");
		phaseDescription = phaseName + " description";
		Assert.assertTrue(zeNavigator.createPhase(releaseName, phaseName, phaseDescription),
				"Phase not created successfully.");

		phaseName = Config.getTCRPropValue("PHASE_3");
		phaseDescription = phaseName + " description";
		Assert.assertTrue(zeNavigator.createPhase(releaseName, phaseName, phaseDescription),
				"Phase not created successfully.");

		logger.info("Phases are created successsfully.");
		isSuccess = true;
		logger.info("bvt36 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 37)
	public void bvt37_createNode() {
		logger.info("Executing bvt37...");
		altID = 37;
		testcaseId = "254";
		String parentNodeName = Config.getTCRPropValue("PHASE_1");
		String nodeOneName = Config.getTCRPropValue("NODE_1");
		String nodeOneDescription = nodeOneName + " description";

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");

		String nodeTwoName = Config.getTCRPropValue("NODE_2");
		String nodeTwoDescription = nodeTwoName + " description";
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeTwoName, nodeTwoDescription),
				"Node not created successfully.");
		logger.info("Created nodes for " + parentNodeName + " Successfully.");

		parentNodeName = Config.getTCRPropValue("PHASE_2");
		nodeOneName = Config.getTCRPropValue("NODE_3");
		nodeOneDescription = nodeOneName + " description";

		// Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated
		// to nodes.");
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");

		nodeTwoName = Config.getTCRPropValue("NODE_4");
		nodeTwoDescription = nodeTwoName + " description";
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeTwoName, nodeTwoDescription),
				"Node not created successfully.");
		logger.info("Created nodes for " + parentNodeName + " Successfully.");

		parentNodeName = Config.getTCRPropValue("PHASE_3");
		nodeOneName = Config.getTCRPropValue("NODE_5");
		nodeOneDescription = nodeOneName + " description";

		// Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated
		// to nodes.");
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");

		nodeTwoName = Config.getTCRPropValue("NODE_6");
		nodeTwoDescription = nodeTwoName + " description";
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeTwoName, nodeTwoDescription),
				"Node not created successfully.");
		logger.info("Created nodes for " + parentNodeName + " Successfully.");

		isSuccess = true;
		logger.info("bvt37 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 38)
	public void bvt38_createSubNodes() {
		logger.info("Executing bvt37...");
		altID = 38;
		testcaseId = "255";
		String parentNodeName = Config.getTCRPropValue("NODE_1");
		String nodeOneName = Config.getTCRPropValue("SUB_NODE_1");
		String nodeOneDescription = nodeOneName + " description";

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");

		String nodeTwoName = Config.getTCRPropValue("SUB_NODE_2");
		String nodeTwoDescription = nodeTwoName + " description";
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeTwoName, nodeTwoDescription),
				"Node not created successfully.");
		logger.info("Created nodes for " + parentNodeName + " Successfully.");

		parentNodeName = Config.getTCRPropValue("NODE_2");
		nodeOneName = Config.getTCRPropValue("SUB_NODE_3");
		nodeOneDescription = nodeOneName + " description";

		// List<String> phases = new ArrayList<String>();
		// phases.add(Config.getTCRPropValue("PHASE_1"));
		// Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated
		// to nodes.");
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");

		nodeTwoName = Config.getTCRPropValue("SUB_NODE_4");
		nodeTwoDescription = nodeTwoName + " description";
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeTwoName, nodeTwoDescription),
				"Node not created successfully.");
		logger.info("Created nodes for " + parentNodeName + " Successfully.");

		parentNodeName = Config.getTCRPropValue("NODE_3");
		nodeOneName = Config.getTCRPropValue("SUB_NODE_5");
		nodeOneDescription = nodeOneName + " description";

		phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_2"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");

		nodeTwoName = Config.getTCRPropValue("SUB_NODE_6");
		nodeTwoDescription = nodeTwoName + " description";
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeTwoName, nodeTwoDescription),
				"Node not created successfully.");
		logger.info("Created nodes for " + parentNodeName + " Successfully.");

		parentNodeName = Config.getTCRPropValue("NODE_4");
		nodeOneName = Config.getTCRPropValue("SUB_NODE_7");
		nodeOneDescription = nodeOneName + " description";

		// List<String> phases = new ArrayList<String>();
		// phases.add(Config.getTCRPropValue("PHASE_1"));
		// Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated
		// to nodes.");
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");

		nodeTwoName = Config.getTCRPropValue("SUB_NODE_8");
		nodeTwoDescription = nodeTwoName + " description";
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeTwoName, nodeTwoDescription),
				"Node not created successfully.");
		logger.info("Created nodes for " + parentNodeName + " Successfully.");

		parentNodeName = Config.getTCRPropValue("NODE_5");
		nodeOneName = Config.getTCRPropValue("SUB_NODE_9");
		nodeOneDescription = nodeOneName + " description";

		phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_3"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");

		nodeTwoName = Config.getTCRPropValue("SUB_NODE_10");
		nodeTwoDescription = nodeTwoName + " description";
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeTwoName, nodeTwoDescription),
				"Node not created successfully.");
		logger.info("Created nodes for " + parentNodeName + " Successfully.");

		parentNodeName = Config.getTCRPropValue("NODE_6");
		nodeOneName = Config.getTCRPropValue("SUB_NODE_11");
		nodeOneDescription = nodeOneName + " description";

		// List<String> phases = new ArrayList<String>();
		// phases.add(Config.getTCRPropValue("PHASE_1"));
		// Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated
		// to nodes.");
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");

		nodeTwoName = Config.getTCRPropValue("SUB_NODE_12");
		nodeTwoDescription = nodeTwoName + " description";
		Assert.assertTrue(zeNavigator.createNode(phases, parentNodeName, nodeTwoName, nodeTwoDescription),
				"Node not created successfully.");
		logger.info("Created nodes for " + parentNodeName + " Successfully.");

		logger.info("Created Sub systems for all systems Successfully.");

		isSuccess = true;
		logger.info("bvt38 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 39)
	public void bvt39_renameNode() {
		logger.info("Executing bvt39...");
		altID = 39;
		testcaseId = "256";
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_3"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");

		String renameNodeName = Config.getTCRPropValue("NODE_5");
		String nodeName = Config.getTCRPropValue("NODE_EDIT");
		String nodeDescription = nodeName + " Description";

		Assert.assertTrue(zeNavigator.renameNode(renameNodeName, nodeName, nodeDescription),
				"Node not renamed successfully.");
		isSuccess = true;
		logger.info("bvt39 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 40)
	public void bvt40_deleteNode() {
		logger.info("Executing bvt40...");
		altID = 40;
		testcaseId = "257";
		String deleteNodeName = Config.getTCRPropValue("NODE_DELETE");

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		// phases.add(Config.getTCRPropValue("PHASE_3"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.deleteNode(deleteNodeName), "Node not renamed successfully.");
		isSuccess = true;
		logger.info("bvt40 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 44)
	public void bvt44_filterNodes() {
		logger.info("Executing bvt44...");
		altID = 44;
		testcaseId = "261";
		String filterText = "N";

		Assert.assertTrue(zeNavigator.filterNodes(filterText), "Node not filtered successfully.");

		filterText = "No";

		Assert.assertTrue(zeNavigator.filterNodes(filterText), "Node not filtered successfully.");

		filterText = "Node 1";

		Assert.assertTrue(zeNavigator.filterNodes(filterText), "Node not filtered successfully.");
		isSuccess = true;
		logger.info("bvt44 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 45)
	public void bvt45_createTestcase() {
		logger.info("Executing bvt45...");
		altID = 45;
		testcaseId = "262";

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		// phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");

		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);

		values.put("TESTCASE_SUMMARY", "Modified summary");
		values.put("TESTCASE_DESC", "Modified description");
		
		values.put("TESTCASE_SUMMARY",Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"));
		values.put("TESTCASE_DESC", "Testcase without steps description");
		values.put("Priority", Config.getTCRPropValue("TESTCASE_WITHOUT_STEP_PRIORITY"));
		values.put("Comment", Config.getTCRPropValue("TESTCASE_WITHOUT_STEP_COMMENT"));


		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");

		isSuccess = true;
		logger.info("bvt45 is executed successfully.");
	}
	
	
    @Test(enabled = testEnabled, priority=46)
    public void bvt46_CreateTestcaseWithcustomfield() {
	logger.info("Executing bvt46...");
	altID = 46;
	
	List<String> phases = new ArrayList<String>();
	phases.add(Config.getTCRPropValue("RELEASE_NAME"));
	phases.add(Config.getTCRPropValue("PHASE_2"));
	phases.add(Config.getTCRPropValue("NODE_3"));
	Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
	String nodeName = Config.getTCRPropValue("SUB_NODE_5");
	String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
	Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");
	
	Map<String, String> values = new HashMap<String, String>();
	values.put("NODE_NAME", nodeName);
	values.put("TESTCASE_ID", testcaseId);
	values.put("TESTCASE_SUMMARY", Config.getTCRPropValue("TESTCASE_WITH_ALL_CUSTOM_FIELDS"));
	values.put("TESTCASE_DESC", "Testcase with all the customfield");
	Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
	Assert.assertTrue(zeNavigator.addCustomfieldToTestcase(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_1"), "Customfiled Text", Config.getTCRPropValue("TEXT_CUSTOM_FIELD_TYPE")),"Customfield Field text not added");
	Assert.assertTrue(zeNavigator.addCustomfieldToTestcase(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_2"), "CustomField text Area", Config.getTCRPropValue("LONGTEXT_CUSTOM_FIELD_TYPE")), "Customfield Text area not added");
	Assert.assertTrue(zeNavigator.addCustomfieldToTestcase(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_5"), "12", Config.getTCRPropValue("NUMBER_CUSTOM_FIELD_TYPE")), "Customfield Number not added");
	Assert.assertTrue(zeNavigator.addCustomfieldToTestcase(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_6"), Config.getTCRPropValue("TC_PICKLIST_VALUE_2"), Config.getTCRPropValue("PICKLIST_CUSTOM_FIELD_TYPE")), "Picklist custom filed is not Added");
	Assert.assertTrue(zeNavigator.addCustomfieldToTestcase(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_3"), "true", Config.getTCRPropValue("CHECKBOX_CUSTOM_FIELD_TYPE")), "Customfield checkbox not added");
	Assert.assertTrue(zeNavigator.addCustomfieldToTestcase(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_4"), "currentdate", Config.getTCRPropValue("DATE_CUSTOM_FIELD_TYPE")), "Customfield Date not added");
	
	Assert.assertTrue(zeNavigator.verifyCustomfieldToTestcase(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_1"), Config.getTCRPropValue("TC_TEXT_VALUE"), Config.getTCRPropValue("TEXT_CUSTOM_FIELD_TYPE")), "custom field text not verified");
	Assert.assertTrue(zeNavigator.verifyCustomfieldToTestcase(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_2"), Config.getTCRPropValue("TC_LONGTEXT_VALUE"), Config.getTCRPropValue("LONGTEXT_CUSTOM_FIELD_TYPE")), "custom field textArea not verified");
	Assert.assertTrue(zeNavigator.verifyCustomfieldToTestcase(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_5"), Config.getTCRPropValue("TC_NUMBER_VALUE"), Config.getTCRPropValue("NUMBER_CUSTOM_FIELD_TYPE")), "custom field Number not verified");
	Assert.assertTrue(zeNavigator.verifyCustomfieldToTestcase(Config.getTCRPropValue("TC_CUSTOM_FIELD_NAME_6"), Config.getTCRPropValue("TC_PICKLIST_VALUE_2"), Config.getTCRPropValue("PICKLIST_CUSTOM_FIELD_TYPE")), "custom field picklist not verified");
	
	isSuccess = true;
	logger.info("bvt46 is executed successfully.");
    }
    
    
	@Test(enabled = testEnabled, priority = 47)
	public void bvt47_AddTeststeps() {
		logger.info("Executing bvt47...");
		altID = 47;
		testcaseId = "264";

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		// phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");

		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY", Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"));
		values.put("TESTCASE_DESC", "Testcase having single step");
		values.put("Comment", Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP_COMMENT"));

		JSONArray stepArray = new JSONArray();

		// JSONObject steps = new JSONObject();
		JSONObject step1 = new JSONObject();
		step1.put("step", "step 1");
		step1.put("data", "data 1");
		step1.put("result", "result 1");
		// steps.put("step1", step1);
		stepArray.put(step1);
		values.put("TESTCASE_STEPS", stepArray.toString());
		// values.put("TESTCASE_STEPS_CANCEL", "true");
		System.out.println(values.get("TESTCASE_STEPS"));

		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");

		isSuccess = true;
		logger.info("bvt47 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 48)
	public void bvt48_cancelTeststep() {
		logger.info("Executing bvt48...");
		altID = 48;
		testcaseId = "265";

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		// phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");

		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY", "Cancel teststep after adding to this testcase");
		values.put("TESTCASE_DESC", "Modified description");

		JSONArray stepArray = new JSONArray();

		// JSONObject steps = new JSONObject();
		JSONObject step1 = new JSONObject();
		step1.put("step", "step 1");
		step1.put("data", "data 1");
		step1.put("result", "result 1");
		// steps.put("step1", step1);
		stepArray.put(step1);
		values.put("TESTCASE_STEPS", stepArray.toString());
		values.put("TESTCASE_STEPS_CANCEL", "true");
		System.out.println(values.get("TESTCASE_STEPS"));

		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");

		isSuccess = true;
		logger.info("bvt48 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 49)
	public void bvt49_CreatingTestcaseWithMultipleStepsAndCancelTheChangesDoneToTeststeps() {
		logger.info("Executing bvt49...");
		altID = 49;
		testcaseId = "266";

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		// phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");

		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		//values.put("TESTCASE_SUMMARY", "Cancel teststeps after adding to this testcase");
		//values.put("TESTCASE_DESC", "Cancel teststeps after adding to this testcase");
		values.put("TESTCASE_SUMMARY", Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"));
		values.put("TESTCASE_DESC", "Adding testcase with multiple teststeps");
		
		JSONArray stepArray = new JSONArray();

		// JSONObject steps = new JSONObject();
		JSONObject step1 = new JSONObject();
		step1.put("step", "step 1");
		step1.put("data", "data 1");
		step1.put("result", "result 1");
		JSONObject step2 = new JSONObject();
		step2.put("step", "step 2");
		step2.put("data", "data 2");
		step2.put("result", "result 2");
		JSONObject step3 = new JSONObject();
		step3.put("step", "step 3");
		step3.put("data", "data 3");
		step3.put("result", "result 3");
		// steps.put("step1", step1);
		stepArray.put(step1);
		stepArray.put(step2);
		stepArray.put(step3);
		values.put("TESTCASE_STEPS", stepArray.toString());
		//values.put("TESTCASE_STEPS_CANCEL", "true");
		System.out.println(values.get("TESTCASE_STEPS"));

		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");

		isSuccess = true;
		logger.info("bvt49 is executed successfully.");
	}
	
	
	@Test(enabled = testEnabled, priority = 50)
	public void bvt50_CloneTestcaseWithoutStep(){
		logger.info("Executing bvt50...");
		altID = 50;
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		String testcaseName = Config.getTCRPropValue("TESTCASE_WITHOUT_STEP");
		Assert.assertTrue(zeNavigator.cloneTestcase(nodeName,testcaseName,"withoutsteps"),"Testcase is not cloned");
		isSuccess = true;
		logger.info("bvt50 is executed successfully.");
		
	}
	
	@Test(enabled = testEnabled, priority = 51)
	public void bvt51_CloneTestcaseWithOneStep(){
		logger.info("Executing bvt51...");
		altID = 51;
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		String testcaseName = Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP");
		Assert.assertTrue(zeNavigator.cloneTestcase(nodeName,testcaseName,"withsteps"),"Testcase is not cloned");
		isSuccess = true;
		logger.info("bvt51 is executed successfully.");
		
	}
	
	@Test(enabled = testEnabled, priority = 52)
	public void bvt52_CloneTestcaseWithMultipleStep(){
		logger.info("Executing bvt52...");
		altID = 52;
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		String testcaseName = Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP");
		Assert.assertTrue(zeNavigator.cloneTestcase(nodeName,testcaseName,"withsteps"),"Testcase is not cloned");
		isSuccess = true;
		logger.info("bvt52 is executed successfully.");
		
	}
	
	@Test(enabled = testEnabled, priority = 53)
	public void bvt53_EditNameAndStepsOfClonedTestcasep(){
		logger.info("Executing bvt53...");
		altID = 53;
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		String testcaseId = zeNavigator.getTestcase(nodeName);
		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY", Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"));
		values.put("TESTCASE_DESC", "Testcase created with three steps is Modified");
		values.put("ALT_ID", Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP_ALTID"));
		values.put("VERSIONVERIFY", "false");
		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
		String testStepToBeModified = Config.getTCRPropValue("TESTSTEPS_TO_BE_MODIFIED");
		values.put("TESTCASE_STEPS", testStepToBeModified);
		Assert.assertTrue(zeNavigator.modifyTeststep(values), "Not added default testcase successfully.");

		isSuccess = true;
		logger.info("bvt53 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 54)
	public void bvt54_ViewTestcaseVersionHistory(){
		logger.info("Executing bvt54...");
		altID = 54;
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		String testcaseId = zeNavigator.getTestcase(nodeName);
		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY", Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"));
		values.put("TESTCASE_DESC", "Testcase created with three steps is Modified");
		values.put("VERSIONVERIFY", "true");
		//Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
		String testStepToBeModified = Config.getTCRPropValue("TESTSTEPS_VERSIONCHECK");
		values.put("TESTCASE_STEPS", testStepToBeModified);
		

		Assert.assertTrue(zeNavigator.modifyTeststep(values), "Not added default testcase successfully.");
		isSuccess = true;
		logger.info("bvt54 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 55)
	
	public void bvt55_Create5TestcasesAndNavigateBetweenTestcases(){
		logger.info("Executing bvt55...");
		altID = 55;
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("NODE_1");
		for(int i=1;i<=5;i++){
		String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");
		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY", "Sample Testcase "+i);
		values.put("TESTCASE_DESC", "Description of Sample Testcase "+i);
		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
		}
		Assert.assertTrue(zeNavigator.navigateBetweenTestcases(nodeName,"Sample Testcase "),"Not navigated to next testcase");
		isSuccess = true;
		logger.info("bvt55 is executed successfully.");
	}
	@Test(enabled = testEnabled, priority = 56)
	public void bvt56_BulkEditTestcase()
	{
		int i;
		logger.info("Executing bvt56...");
		altID = 56;
		
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_2");
		for(i=0; i<=2; i++){
		String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");
		
		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY", "Testcase for Bulk Edit");
		values.put("TESTCASE_DESC", "Testcase for Bulk Edit");
		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
		}
		
		Map<String, String> values = new HashMap<String, String>();
		values.put("ALTID", "12.12.23");
		values.put("Comment", "Bulk Edited testcase");
		values.put("Tags", "Bulk");
		values.put("estimatedTime", Config.getTCRPropValue("NEW_ESTIMATED_TIME"));
		values.put("priority", Config.getTCRPropValue("TC_PRIORITY_2"));
		values.put("Automated", "BVTAutomation"+Constants.CHAR_TO_SPLIT_STRING+"001"+Constants.CHAR_TO_SPLIT_STRING+ Config.getTCRPropValue("Automation_Path"));
		Assert.assertTrue(zeNavigator.bulkEditTestCase(values), "Bulk edit not done succefully..");
		isSuccess = true;
		logger.info("bvt56 is executed successfully.");
	}

	
	@Test(enabled = testEnabled, priority = 57)
	public void bvt57_AddAttachmentToTestcase() {
		logger.info("Executing bvt57...");
		altID = 57;
		testcaseId = "274";

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		// phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_2");
		String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");

		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY", "Add attachment to testcase");
		values.put("TESTCASE_DESC", "Add attachment to testcase");
		values.put("TESTCASE_ATTACHMENT", Config.getTCRPropValue("TESTCASE_ATTACHMENT"));
		// values.put("TESTCASE_ATTACHMENT",
		// "D:\\werkspace\\zeuihtml\\src\\test\\resources\\attachments\\attachment.png");

		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");

		isSuccess = true;
		logger.info("bvt57 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 59)
	public void bvt59_deleteTestcase() {
		logger.info("Executing bvt59...");
		altID = 59;
		testcaseId = "276";

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");

		Assert.assertTrue(zeNavigator.deleteTestcase(nodeName, Integer.parseInt(testcaseId)), "Not deleted testcase.");

		isSuccess = true;
		logger.info("bvt59 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 61)
	public void bvt61_FindAndAddTestcaseTo_P_S_SS(){
		logger.info("Executing bvt61...");
		altID = 61;
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("PHASE_2");
		//name ~ "sample"
		
		Assert.assertTrue(zeNavigator.findAndAddTestcase(nodeName,"name ~ \""+Config.getTCRPropValue("TESTCASE_FOR_PHASE_FIND_AND_ADD_")+"\""),"Not clicked on Find And Add");
		
		phases.add(Config.getTCRPropValue("PHASE_2"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		nodeName = Config.getTCRPropValue("NODE_3");
		//priority = "P1"
		Assert.assertTrue(zeNavigator.findAndAddTestcase(nodeName,"priority = \""+Config.getTCRPropValue("TESTACSE_FOR_SYSTEM_FIND_AND_ADD")+"\""),"Not clicked on Find And Add");
		
		phases.add(Config.getTCRPropValue("NODE_3"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		nodeName = Config.getTCRPropValue("SUB_NODE_5");
		//comment ~ "comment1"
		Assert.assertTrue(zeNavigator.findAndAddTestcase(nodeName,"comment ~ \""+Config.getTCRPropValue("TESTCASE_FOR_SUBSYSTEM_FIND_AND_ADD")+"\""),"Not clicked on Find And Add");
		isSuccess = true;
		logger.info("bvt61 is executed successfully.");
	}
	
	
	@Test(enabled = testEnabled, priority = 64)
	public void bvt64_Dock_UnDock_GlobalTree(){
		logger.info("Executing bvt64...");
		altID = 64;
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("NODE_2");
		Assert.assertTrue(zeNavigator.dockUndockGlobalTree(nodeName), "Not clicked on Copy From other Projects");
		isSuccess = true;
		logger.info("bvt64 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 71)
	public void bvt71_quickSearchTescaseByAltId(){
		logger.info("Executing bvt71...");
		altID = 71;
		List<String> expectedTestcases = new ArrayList<String>();
		expectedTestcases.add(0, Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"));
		Assert.assertTrue(zeNavigator.searchTescases("Quick", Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP_ALTID"), expectedTestcases, true),"Not performed Quick Search");
		isSuccess = true;
		logger.info("bvt71 is executed successfully.");
	}
	
	
	@Test(enabled = testEnabled, priority = 72)
	public void bvt72_zqlSearchTescaseByCheckBox(){
		logger.info("Executing bvt72...");
		altID = 72;
		List<String> expectedTestcases = new ArrayList<String>();
		expectedTestcases.add(0, Config.getTCRPropValue("TESTCASE_WITH_ALL_CUSTOM_FIELDS"));
		Assert.assertTrue(zeNavigator.searchTescases("Advanced", "sample-custom-3 = true",expectedTestcases, true),"Not performed Advance Search");
		isSuccess = true;
		logger.info("bvt72 is executed successfully.");
	}
	
	
	@Test(enabled = testEnabled, priority = 74)
	public void bvt74_switchFromSearchToFolder(){
		logger.info("Executing bvt74...");
		altID = 74;
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		Assert.assertTrue(zeNavigator.switchBetweenSearchFolderListDetailView(nodeName),"Not Switched between List and Detail view");
		isSuccess = true;
		logger.info("bvt74 is executed successfully.");
	}
	
	
	@Test(enabled = testEnabled, priority = 75)
	public void bvt75_launchTestPlanningTest() {
		logger.info("Executing bvt75...");
		altID = 75;
		testcaseId = "291";
		String releaseName = "Release 1.0";
		String appName = "Test Planning";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		Assert.assertTrue(zeNavigator.navigateToReleaseApps(releaseName, appName), "Not navigated to : " + appName);
		isSuccess = true;
		logger.info("bvt75 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 76)
	public void bvt76_createNewCycleWithMandatoryFieldTest() {
		logger.info("Executing bvt76...");
		altID = 76;
		testcaseId = "291";

		String startDate = CommonUtil.returnTodaysDate();
		String endDate = CommonUtil.returnFutureDateStartingTodaysDate(0, 5, 0);
		
		Assert.assertTrue(zeNavigator.createCycle(Config.getEASPropValue("CYCLE1_NAME"), null
				, null,startDate,endDate),  "Not created cycle successfully.");
		isSuccess = true;
		logger.info("bvt76 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 77)
	public void bvt77_createNewCycleWithAllFieldsTest() {
		logger.info("Executing bvt77...");
		altID = 77;
		testcaseId = "291";

		String startDate = CommonUtil.returnTodaysDate();
		String endDate = CommonUtil.returnFutureDateStartingTodaysDate(0, 10, 0);
		
		Assert.assertTrue(zeNavigator.createCycle(Config.getEASPropValue("CYCLE2_NAME"), Config.getEASPropValue("CYCLE2_BUILD")
				, Config.getEASPropValue("CYCLE2_ENVIRONMENT"),startDate,endDate),  "Not created cycle successfully.");
	
		isSuccess = true;
		logger.info("bvt77 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 78)
	public void bvt78_addPhaseToCycleAndAssignToCreatorTest() {
		logger.info("Executing bvt78...");
		altID = 78;

		zeNavigator.addPhaseToCycle(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_1")
				, "creator", true);
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_1"), false);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(1, Config.getTCRPropValue("NODE_1"));
		nodeList.add(2, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.verifyAssigneeOfTestcase("Testcase without steps", "Test Manager", false);
		zeNavigator.verifyAssigneeOfTestcase("Testcase created with one step", "Test Manager", false);
		zeNavigator.verifyAssigneeOfTestcase("Testcase created with three steps", "Test Manager", true);
		
		isSuccess = true;
		logger.info("bvt78 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 79)
	public void bvt79_addPhaseToCycleAndAssignToAnyoneTest() {
		logger.info("Executing bvt79...");
		altID = 79;

		zeNavigator.addPhaseToCycle(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_2")
				, "anyone", true);

		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_2"), false);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("PHASE_2"));
		nodeList.add(1, Config.getTCRPropValue("NODE_3"));
		nodeList.add(2, Config.getTCRPropValue("SUB_NODE_5"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("TESTCASE_WITH_ALL_CUSTOM_FIELDS"), "Anyone", true);
		
		isSuccess = true;
		logger.info("bvt79 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 80)
	public void bvt80_cloneCycleWithTestcaseAssingmentsTest(){
		logger.info("Executing bvt80...");
		altID = 80;
		
		Assert.assertTrue(zeNavigator.cloneCycle(Config.getEASPropValue("CYCLE1_NAME"), Config.getEASPropValue("CLONED_CYCLE3_NAME"), true), "Failed to clone cycle");
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CLONED_CYCLE3_NAME"), Config.getTCRPropValue("PHASE_1"), false);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(1, Config.getTCRPropValue("NODE_1"));
		nodeList.add(2, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.verifyAssigneeOfTestcase("Testcase without steps", "Test Manager", false);
		zeNavigator.verifyAssigneeOfTestcase("Testcase created with one step", "Test Manager", false);
		zeNavigator.verifyAssigneeOfTestcase("Testcase created with three steps", "Test Manager", true);
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CLONED_CYCLE3_NAME"), Config.getTCRPropValue("PHASE_2"), false);

		List<String> nodeList1 = new ArrayList<String>();
		nodeList1.add(0, Config.getTCRPropValue("PHASE_2"));
		nodeList1.add(1, Config.getTCRPropValue("NODE_3"));
		nodeList1.add(2, Config.getTCRPropValue("SUB_NODE_5"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList1);
		
		zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("TESTCASE_WITH_ALL_CUSTOM_FIELDS"), "Anyone", true);
		
		
		isSuccess = true;
		logger.info("bvt80 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 81)
	public void bvt81_cloneCycleWithoutTestcaseAssingmentsTest(){
		logger.info("Executing bvt81...");
		altID = 81;
		
		Assert.assertTrue(zeNavigator.cloneCycle(Config.getEASPropValue("CYCLE1_NAME"), Config.getEASPropValue("CLONED_CYCLE4_NAME"), false), "Failed to clone cycle");
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CLONED_CYCLE4_NAME"), Config.getTCRPropValue("PHASE_1"), true);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(1, Config.getTCRPropValue("NODE_1"));
		nodeList.add(2, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.verifyAssigneeOfTestcase("Testcase without steps", "Unassigned", false);
		zeNavigator.verifyAssigneeOfTestcase("Testcase created with one step", "Unassigned", false);
		zeNavigator.verifyAssigneeOfTestcase("Testcase created with three steps", "Unassigned", true);
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CLONED_CYCLE4_NAME"), Config.getTCRPropValue("PHASE_2"), true);

		List<String> nodeList1 = new ArrayList<String>();
		nodeList1.add(0, Config.getTCRPropValue("PHASE_2"));
		nodeList1.add(1, Config.getTCRPropValue("NODE_3"));
		nodeList1.add(2, Config.getTCRPropValue("SUB_NODE_5"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList1);
		
		zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("TESTCASE_WITH_ALL_CUSTOM_FIELDS"), "Unassigned", true);
		
		isSuccess = true;
		logger.info("bvt81 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 83)
	public void bvt83_hideCycleTest(){
		logger.info("Executing bvt83...");
		altID = 83;
		
		
		Assert.assertTrue(zeNavigator.editCycle(Config.getEASPropValue("CLONED_CYCLE3_NAME"), 
				null, null, null, null, null, null, null, true, false), "Failed to hide cycle");
		zeNavigator.verifyPhaseNotVisiblieInCyclePage(Config.getEASPropValue("CLONED_CYCLE3_NAME"), Config.getTCRPropValue("PHASE_1"));
		zeNavigator.verifyPhaseNotVisiblieInCyclePage(Config.getEASPropValue("CLONED_CYCLE3_NAME"), Config.getTCRPropValue("PHASE_2"));
		
		isSuccess = true;
		logger.info("bvt83 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 84)
	public void bvt84_editStartAndEnddateOfCyclePhase() {
		logger.info("Executing bvt84...");
		altID = 84;
		testcaseId = "291";

		String startDate = CommonUtil.returnFutureDateStartingTodaysDate(0, 1, 0);
		String endDate = CommonUtil.returnFutureDateStartingTodaysDate(0, 4, 0);
		
		List<String> phaseWithStartDate = new ArrayList<String>();
		phaseWithStartDate.add(0, Config.getTCRPropValue("PHASE_1") + ">" + startDate);
		phaseWithStartDate.add(0, Config.getTCRPropValue("PHASE_2") + ">" + startDate);
		
		List<String> phaseWithEndDate = new ArrayList<String>();
		phaseWithEndDate.add(0, Config.getTCRPropValue("PHASE_1") + ">" + endDate);
		phaseWithEndDate.add(0, Config.getTCRPropValue("PHASE_2") + ">" + endDate);

		Assert.assertTrue(zeNavigator.editCycle(Config.getEASPropValue("CYCLE1_NAME"), null, null, null, null, null, phaseWithStartDate, phaseWithEndDate, false, true), "Not edited cycle successfully.");
		isSuccess = true;
		logger.info("bvt84 is executed successfully.");
		
	}
	
	@Test(enabled = testEnabled, priority = 85)
	public void bvt85_assignTestcaseIndividuallyTest(){
		logger.info("Executing bvt85...");
		altID = 85;
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CLONED_CYCLE4_NAME"), Config.getTCRPropValue("PHASE_1"), true);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(1, Config.getTCRPropValue("NODE_1"));
		nodeList.add(2, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.assignTestIndividually("Testcase without steps", "Test Manager", false);
		zeNavigator.assignTestIndividually("Testcase created with one step", "Test Lead", false);
		zeNavigator.assignTestIndividually("Testcase created with three steps", "Tester One", true);
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CLONED_CYCLE4_NAME"), Config.getTCRPropValue("PHASE_1"), false);
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.verifyAssigneeOfTestcase("Testcase without steps", "Test Manager", false);
		zeNavigator.verifyAssigneeOfTestcase("Testcase created with one step", "Test Lead", false);
		zeNavigator.verifyAssigneeOfTestcase("Testcase created with three steps", "Tester One", true);
		
		isSuccess = true;
		logger.info("bvt85 is executed successfully.");
		
	}
	
	
	@Test(enabled = testEnabled, priority = 86)
	public void bvt86_bulkAssignUnexecutedTestcaseToAnyoneIncludingSubfoldersTest(){
		logger.info("Executing bvt86...");
		altID = 86;
		
		zeNavigator.addPhaseToCycle(Config.getEASPropValue("CYCLE2_NAME"), Config.getTCRPropValue("PHASE_1")
				, "creator", true);
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE2_NAME"), Config.getTCRPropValue("PHASE_1"), false);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("PHASE_1"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);

		zeNavigator.bulkAssignNotExecutedTest("Anyone", true, false);
		
		nodeList.add(1, Config.getTCRPropValue("NODE_1"));
		nodeList.add(2, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.verifyAssigneeOfTestcase("Testcase without steps", "Anyone", false);
		zeNavigator.verifyAssigneeOfTestcase("Testcase created with one step", "Anyone", false);
		zeNavigator.verifyAssigneeOfTestcase("Testcase created with three steps", "Anyone", true);
		
		isSuccess = true;
		logger.info("bvt86 is executed successfully.");
		
	}
	
	@Test(enabled = testEnabled, priority = 87)
	public void bvt87_syncPhaseWithTestcaseAddedOrRemovedTest(){
		logger.info("Executing bvt87...");
		altID = 87;
		
		zeNavigator.launchReleaseApp("Test Repository");
		
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		// phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_1");
		String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");

		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);

		values.put("TESTCASE_SUMMARY", Config.getTCRPropValue("TESTCASE_ADDED_FOR_SYNC"));
		values.put("TESTCASE_DESC", "Testcase created for sync");
		values.put("Priority", Config.getTCRPropValue("TESTCASE_ADDED_FOR_SYNC_PRIORITY"));
		values.put("Comment", Config.getTCRPropValue("TESTCASE_ADDED_FOR_SYNC_COMMENT"));

		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
		
		//For now passing hardcoded testcase ID until method in TestRepository is implemented
		// 6 is ID of Testcase: Cancel teststep after adding to this testcase
		Assert.assertTrue(zeNavigator.deleteTestcase(nodeName, Config.getTCRPropValue("TESTCASE_DELETE_FOR_SYNC")), "Not deleted testcase.");
		
		zeNavigator.launchReleaseApp("Test Planning");
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_1"), false);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("PHASE_1"));
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		List<String> nodeNameWithExpectedTestCountAdded = new ArrayList<String>();
		nodeNameWithExpectedTestCountAdded.add(0, Config.getTCRPropValue("SUB_NODE_1") + Constants.CHAR_TO_SPLIT_STRING + "1");
		
		List<String> nodeNameWithExpectedTestCountDeleted = new ArrayList<String>();
		nodeNameWithExpectedTestCountDeleted.add(0, Config.getTCRPropValue("SUB_NODE_1") + Constants.CHAR_TO_SPLIT_STRING + "1");
		
		
		zeNavigator.syncSelectedNode(nodeNameWithExpectedTestCountAdded, nodeNameWithExpectedTestCountDeleted, true, true);
		
		nodeList.add(1, Config.getTCRPropValue("NODE_1"));
		nodeList.add(2, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_1"), false);
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("TESTCASE_ADDED_FOR_SYNC")
				, "Unassigned", false);
		
		zeNavigator.verifyAbsenceOfTestcaseInCycleAssignmentWindow("Cancel teststep after adding to this testcase", true);
		
		isSuccess = true;
		logger.info("bvt86 is executed successfully.");
	}
	
	
	
	@Test(enabled = testEnabled, priority = 89)
	public void bvt89_addFreeformPhaseToCycle(){
		logger.info("Executing bvt89...");
		altID = 89;
		
		Assert.assertTrue(zeNavigator.addFreeformPhaseToCycle(Config.getEASPropValue("CYCLE2_NAME")
				, Config.getEASPropValue("FREEFORM1_PHASE_NAME"), true)
				, "Failed to add Freeform phase to cycle Successfully");
		
		isSuccess = true;
		logger.info("bvt89 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 90)
	public void bvt90_createTwoSystemsUnderFreeformPhaseTest(){
		logger.info("Executing bvt90...");
		altID = 90;
	
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE2_NAME"), Config.getEASPropValue("FREEFORM1_PHASE_NAME"), false);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getEASPropValue("FREEFORM1_PHASE_NAME"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		List<String> childNodeToAdd = new ArrayList<String>();
		childNodeToAdd.add(0, Config.getEASPropValue("FREEFORM1_SYSTEM1_NAME") +">"+ Config.getEASPropValue("FREEFORM1_SYSTEM1_DESCRIPTION"));
		childNodeToAdd.add(1, Config.getEASPropValue("FREEFORM1_SYSTEM2_NAME"));
		
		zeNavigator.addFreeformChildNode(Config.getEASPropValue("FREEFORM1_PHASE_NAME"), childNodeToAdd, true);
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE2_NAME"), Config.getEASPropValue("FREEFORM1_PHASE_NAME"), false);
		
		nodeList.add(1, Config.getEASPropValue("FREEFORM1_SYSTEM1_NAME"));
		nodeList.add(2, Config.getEASPropValue("FREEFORM1_SYSTEM2_NAME"));
	
		Assert.assertTrue(zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList), "Failed to create system in freeform node");
		
		isSuccess = true;
		logger.info("bvt90 is executed successfully.");
	}
	
	
	@Test(enabled = testEnabled, priority = 91)
	public void bvt91_createTwoSubSystemUnderFreeformNodeTest(){
		logger.info("Executing bvt91...");
		altID = 91;
		
		zeNavigator.launchReleaseApp("Test Planning");
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE2_NAME"), Config.getEASPropValue("FREEFORM1_PHASE_NAME"), false);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getEASPropValue("FREEFORM1_PHASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("FREEFORM1_SYSTEM1_NAME"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		List<String> childNodeToAdd = new ArrayList<String>();
		childNodeToAdd.add(0, Config.getEASPropValue("FREEFORM1_SUBSYSTEM1_NAME") +">"+ Config.getEASPropValue("FREEFORM1_SUBSYSTEM1_DESCRIPTION"));
		childNodeToAdd.add(1, Config.getEASPropValue("FREEFORM1_SUBSYSTEM2_NAME"));
		
		zeNavigator.addFreeformChildNode(Config.getEASPropValue("FREEFORM1_SYSTEM1_NAME"), childNodeToAdd, false);
		
		nodeList.add(1, Config.getEASPropValue("FREEFORM1_SYSTEM2_NAME"));
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		List<String> childNodeToAdd1 = new ArrayList<String>();
		childNodeToAdd1.add(0, Config.getEASPropValue("FREEFORM1_SUBSYSTEM3_NAME") +">"+ Config.getEASPropValue("FREEFORM1_SUBSYSTEM3_DESCRIPTION"));
		childNodeToAdd1.add(1, Config.getEASPropValue("FREEFORM1_SUBSYSTEM4_NAME")+">"+ Config.getEASPropValue("FREEFORM1_SUBSYSTEM4_DESCRIPTION"));
		
		zeNavigator.addFreeformChildNode(Config.getEASPropValue("FREEFORM1_SYSTEM2_NAME"), childNodeToAdd1, false);
		
		nodeList.add(1, Config.getEASPropValue("FREEFORM1_SYSTEM1_NAME"));
		nodeList.add(2, Config.getEASPropValue("FREEFORM1_SUBSYSTEM1_NAME"));
		nodeList.add(3, Config.getEASPropValue("FREEFORM1_SUBSYSTEM2_NAME"));
		
		nodeList.add(4, Config.getEASPropValue("FREEFORM1_SYSTEM2_NAME"));
		nodeList.add(5, Config.getEASPropValue("FREEFORM1_SUBSYSTEM3_NAME"));
		nodeList.add(6, Config.getEASPropValue("FREEFORM1_SUBSYSTEM4_NAME"));
		
		Assert.assertTrue(zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList), "Failed to create subsystem nodes in freeform");
		
		isSuccess = true;
		logger.info("bvt91 is executed successfully.");
	}
	

	@Test(enabled = testEnabled, priority = 92)
	public void bvt92_renameFreeformSubSystemAndItsDescription(){
		
		logger.info("Executing bvt92...");
		altID = 92;
		
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getEASPropValue("FREEFORM1_PHASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("FREEFORM1_SYSTEM2_NAME"));
		nodeList.add(2, Config.getEASPropValue("FREEFORM1_SUBSYSTEM3_NAME"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.editFreeformChildNode(Config.getEASPropValue("FREEFORM1_SUBSYSTEM3_NAME")
				, Config.getEASPropValue("FREEFORM1_SUBSYSTEM3_RENAME")
				, Config.getEASPropValue("FREEFORM1_SUBSYSTEM3_REDESCRIPTION"), true);
		
		nodeList.remove(2);
		nodeList.add(2, Config.getEASPropValue("FREEFORM1_SUBSYSTEM3_RENAME"));
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE2_NAME"), Config.getEASPropValue("FREEFORM1_PHASE_NAME"), false);
		Assert.assertTrue(zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList), "Freeform Node renamed successfully");
		
		isSuccess = true;
		logger.info("bvt92 is executed successfully.");
		
	}
	

	@Test(enabled = testEnabled, priority = 93)
	public void bvt93_deleteFreeformNode(){
		
		logger.info("Executing bvt93...");
		altID = 93;
		
		zeNavigator.launchReleaseApp("Test Planning");
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE2_NAME"), Config.getEASPropValue("FREEFORM1_PHASE_NAME"), false);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getEASPropValue("FREEFORM1_PHASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("FREEFORM1_SYSTEM2_NAME"));
		nodeList.add(2, Config.getEASPropValue("FREEFORM1_SUBSYSTEM4_NAME"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.deleteFreeformChildNodeAndVerify(Config.getEASPropValue("FREEFORM1_SUBSYSTEM4_NAME"), true);
		
		isSuccess = true;
		logger.info("bvt93 is executed successfully.");
	
	}
	

	@Test(enabled = testEnabled, priority = 94)
	public void bvt94_quickSearchTestcasesByPriorityAndAddToFreeformNode(){
		
		logger.info("Executing bvt94...");
		altID = 94;
		
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE2_NAME"), Config.getEASPropValue("FREEFORM1_PHASE_NAME"), false);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getEASPropValue("FREEFORM1_PHASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("FREEFORM1_SYSTEM1_NAME"));
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		List<String> expectedTestcases = new ArrayList<String>();
		expectedTestcases.add(0, Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"));
		
		zeNavigator.addTestcaseToFreeformNode("Quick", Config.getTCRPropValue("TESTCASE_WITHOUT_STEP_PRIORITY"), expectedTestcases, true, false, false);
		
		zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"), "Unassigned", true);
		
		isSuccess = true;
		logger.info("bvt94 is executed successfully.");
	
	}
	
	@Test(enabled = testEnabled, priority = 95)
	public void bvt95_advanceSearchTestcasesByPriorityAndAddToFreeformNode(){
		
		logger.info("Executing bvt95...");
		altID = 95;
		
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE2_NAME"), Config.getEASPropValue("FREEFORM1_PHASE_NAME"), true);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getEASPropValue("FREEFORM1_PHASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("FREEFORM1_SYSTEM1_NAME"));
		nodeList.add(2, Config.getEASPropValue("FREEFORM1_SUBSYSTEM1_NAME"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		List<String> expectedTestcases = new ArrayList<String>();
		expectedTestcases.add(0, Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"));
		expectedTestcases.add(0, Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"));
		
		zeNavigator.addTestcaseToFreeformNode("Advanced", "comment ~ \""+Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP_COMMENT")+"\"", expectedTestcases, false, false, false);
		
		zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"), "Unassigned", false);
		zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"), "Unassigned", true);
		
		isSuccess = true;
		logger.info("bvt95 is executed successfully.");
	
	}
	
	
	@Test(enabled = testEnabled, priority = 96)
	public void bvt96_deleteTestcaseInAssignedTestcaseToExecuteWindow(){
		logger.info("Executing bvt96...");
		altID = 96;
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_1"), false);
		
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(1, Config.getTCRPropValue("NODE_1"));
		nodeList.add(2, Config.getTCRPropValue("SUB_NODE_1"));
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		List<String> testcasNameToDelete = new ArrayList<String>();
		testcasNameToDelete.add(0, Config.getTCRPropValue("TESTCASE_ADDED_FOR_SYNC"));
		
		zeNavigator.deleteTestcaseFromSelectedNodeInAssingTestcaseToExecuteWindow(testcasNameToDelete, true);

		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_1"), false);
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.verifyAbsenceOfTestcaseInCycleAssignmentWindow(Config.getTCRPropValue("TESTCASE_ADDED_FOR_SYNC"), true);
		
		
		isSuccess = true;
		logger.info("bvt96 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 97)
	public void bvt97_deleteCyclePhase() {
		logger.info("Executing bvt97...");
		altID = 97;

		zeNavigator.deleteCyclePhase(Config.getEASPropValue("CYCLE2_NAME"), Config.getTCRPropValue("PHASE_1"));
		
		zeNavigator.verifyPhaseNotVisiblieInCyclePage(Config.getEASPropValue("CYCLE2_NAME"), Config.getTCRPropValue("PHASE_1"));
		
		isSuccess = true;
		logger.info("bvt97 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 98)
	public void bvt98_deleteCycle() {
		logger.info("Executing bvt98...");
		altID = 98;

		Assert.assertTrue(zeNavigator.deleteCycle(Config.getEASPropValue("CYCLE2_NAME")), "Not created cycle successfully.");
		
		isSuccess = true;
		logger.info("bvt98 is executed successfully.");
	}
	
	
	@Test(enabled = testEnabled, priority = 99)
	public void bvt99_syncAndViewTestcaseCountInEASAssignemntWindowAfterDeleteingAndAddingTestInTCCTest(){
		logger.info("Executing bvt99...");
		altID = 99;
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_1"), false);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("PHASE_1"));
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		List<String> nodeNameWithExpectedTestCountAdded = new ArrayList<String>();
		nodeNameWithExpectedTestCountAdded.add(0, Config.getTCRPropValue("SUB_NODE_1") + Constants.CHAR_TO_SPLIT_STRING + "1");
		
		zeNavigator.syncSelectedNode(nodeNameWithExpectedTestCountAdded, null, true, true);
		
		zeNavigator.launchReleaseApp("Test Repository");
		
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_2"));
		phases.add(Config.getTCRPropValue("NODE_3"));
		//phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("SUB_NODE_5");
		String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");

		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME", nodeName);
		values.put("TESTCASE_ID", testcaseId);

		values.put("TESTCASE_SUMMARY", Config.getTCRPropValue("TESTCASE_ADDED_FOR_SYNC"));
		values.put("TESTCASE_DESC", "Testcase created for sync");
		values.put("Priority", Config.getTCRPropValue("TESTCASE_ADDED_FOR_SYNC_PRIORITY"));
		values.put("Comment", Config.getTCRPropValue("TESTCASE_ADDED_FOR_SYNC_COMMENT"));

		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
		
		//For now passing hardcoded testcase ID until method in TestRepository is implemented
		// 6 is ID of Testcase: Cancel teststep after adding to this testcase
		
		phases.clear();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		nodeName = Config.getTCRPropValue("SUB_NODE_1");
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		
		Assert.assertTrue(zeNavigator.deleteTestcase(nodeName, "27"), "Not deleted testcase.");
		
		zeNavigator.launchReleaseApp("Test Planning");
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_1"), false);

		
		nodeList.add(0, Config.getTCRPropValue("PHASE_1"));
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		//List<String> nodeNameWithExpectedTestCountAdded = new ArrayList<String>();
		//nodeNameWithExpectedTestCountAdded.add(0, Config.getTCRPropValue("SUB_NODE_1") + Constants.CHAR_TO_SPLIT_STRING + "1");
		
		List<String> nodeNameWithExpectedTestCountDeleted = new ArrayList<String>();
		nodeNameWithExpectedTestCountDeleted.add(0, Config.getTCRPropValue("SUB_NODE_1") + Constants.CHAR_TO_SPLIT_STRING + "1");
		
		
		zeNavigator.syncSelectedNode(null, nodeNameWithExpectedTestCountDeleted, true, true);
		
		nodeList.add(1, Config.getTCRPropValue("NODE_1"));
		nodeList.add(2, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_1"), false);
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.verifyTestcaseCountOfSelectedNode(Config.getTCRPropValue("SUB_NODE_1"), 7, true);
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_2"), false);
		nodeList.clear();
		nodeList.add(0, Config.getTCRPropValue("PHASE_2"));
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		nodeNameWithExpectedTestCountAdded.clear();
		nodeNameWithExpectedTestCountAdded.add(0, Config.getTCRPropValue("SUB_NODE_5") + Constants.CHAR_TO_SPLIT_STRING + "1");
				
		zeNavigator.syncSelectedNode(nodeNameWithExpectedTestCountAdded, null, true, true);
		
		nodeList.add(1, Config.getTCRPropValue("NODE_3"));
		nodeList.add(2, Config.getTCRPropValue("SUB_NODE_5"));
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE1_NAME"), Config.getTCRPropValue("PHASE_2"), false);
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		
		zeNavigator.verifyTestcaseCountOfSelectedNode(Config.getTCRPropValue("SUB_NODE_5"), 7, true);
		
		isSuccess = true;
		logger.info("bvt99 is executed successfully.");
	}
	
	
	@Test(enabled = testEnabled, priority = 100)
	public void bvt100_viewAssingmentsInTCEForClonedCycleWithTestcasesAssignedToAnyoneTest(){
		logger.info("Executing bvt100...");
		altID = 100;
		
		Assert.assertTrue(zeNavigator.editCycle(Config.getEASPropValue("CLONED_CYCLE3_NAME"), 
				null, null, null, null, null, null, null, true, true), "Failed to unhide cycle");
		
		zeNavigator.launchReleaseApp("Test Execution");
		
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_2"));
		nodeList.add(3, Config.getTCRPropValue("NODE_3"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_5"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		
		zeNavigator.verifyAssignedTestcaseInSelectedNodeInTCE(Config.getTCRPropValue("TESTCASE_WITH_ALL_CUSTOM_FIELDS")
				, "Anyone", "Not Executed");
		
		isSuccess = true;
		logger.info("bvt100 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 101)
	public void bvt101_treeWithNewTestCycleShownProperlyTest(){
		logger.info("Executing bvt101...");
		altID = 101;
		
		zeNavigator.logout();
		zeNavigator.doLogin(Config.getUsersPropValue("ZE_TESTER_USERNAME"), Config.getUsersPropValue("ZE_TESTER_PASSWORD"));
		
		String releaseName = Config.getReleasePropValue("DEFAULT_RELEASE_NAME");
		zeNavigator.selectProject(Config.getProjectPropValue("DEFAULT_PROJECT"));
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.launchReleaseApp("Test Execution");
		
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_2"));
		nodeList.add(3, Config.getTCRPropValue("NODE_3"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_5"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		
		zeNavigator.verifyAssignedTestcaseInSelectedNodeInTCE(Config.getTCRPropValue("TESTCASE_WITH_ALL_CUSTOM_FIELDS")
				, "Anyone", "Not Executed");
		
		nodeList.clear();
		
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE4_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		zeNavigator.verifyAssignedTestcaseInSelectedNodeInTCE(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP")
				, "Tester One", "Not Executed");
		
		isSuccess = true;
		logger.info("bvt101 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 103)
	public void bvt103_executeTestToPassFailWIPBlockedTest(){
		logger.info("Executing bvt103...");
		altID = 103;

		Assert.assertTrue(zeNavigator.executeTestcaseInSelectedNodeAndVerify(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), "Pass"), "Failed to execute Test");
		
		zeNavigator.logout();
		zeNavigator.doLogin(Config.getUsersPropValue("ZE_MANAGER_USERNAME"), Config.getUsersPropValue("ZE_MANAGER_PASSWORD"));
		String releaseName = Config.getReleasePropValue("DEFAULT_RELEASE_NAME");
		zeNavigator.selectProject(Config.getProjectPropValue("DEFAULT_PROJECT"));
		zeNavigator.selectReleaseFromGrid(releaseName);
		zeNavigator.launchReleaseApp("Test Execution");
		
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		//Modifying testcase created with three steps - Cloned Testcase

		Assert.assertTrue(zeNavigator.executeTestcaseInSelectedNodeAndVerify(Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"), "Pass")
				, "Failed to execute Test");
		
		Assert.assertTrue(zeNavigator.executeTestcaseInSelectedNodeAndVerify(Config.getTCRPropValue("TESTCASE_WITH_ATTACHMENT"), "Fail")
				, "Failed to execute Test");
		Assert.assertTrue(zeNavigator.executeTestcaseInSelectedNodeAndVerify(Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"), "WIP")
				, "Failed to execute Test");
		Assert.assertTrue(zeNavigator.executeTestcaseInSelectedNodeAndVerify(Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"), "Blocked")
				, "Failed to execute Test");
		
		isSuccess = true;
		logger.info("bvt103 is executed successfully.");
		
	}
	
	@Test(enabled = testEnabled, priority = 104)
	public void bvt104_executeTestToCustomStatusTest(){
		logger.info("Executing bvt104...");
		altID = 104;
		
		zeNavigator.executeTestcaseInSelectedNodeAndVerify(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP")
				, Config.getTCEPropValue("CUSTOM_EXECUTION_STATUS_1"));
		
		isSuccess = true;
		logger.info("bvt104 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 106)
	public void bvt106_bulkExecuteTestcasesTest(){
		logger.info("Executing bvt106...");
		altID = 106;
		
		zeNavigator.launchReleaseApp("Test Planning");
		zeNavigator.launchReleaseApp("Test Execution");
		
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CYCLE1_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_1"));
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		
		List<String> testcaseNames = new ArrayList<String>();
		testcaseNames.add(0, Config.getTCRPropValue("TESTCASE_WITH_ATTACHMENT"));
		testcaseNames.add(1, Config.getTCRPropValue("TESTCASE_WITHOUT_STEP"));
		testcaseNames.add(2, Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"));
		
		zeNavigator.bulkExecuteTestcaseInSelectedNodeAndVerify(testcaseNames, "Pass");
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		zeNavigator.bulkExecuteTestcaseInSelectedNodeAndVerify(testcaseNames, "Fail");
		
		
		isSuccess = true;
		logger.info("bvt106 is executed successfully.");
	}
	
	
	@Test(enabled = testEnabled, priority = 107)
	public void bvt107_executeTestStepTest(){
		logger.info("Executing bvt107...");
		altID = 107;
		
		
		zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), "1", "Pass", true, false, null);
		zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), "2", "Fail", false, false, null);
		zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), "3", "WIP", false, false, null);
		
		isSuccess = true;
		logger.info("bvt107 is executed successfully.");
	}
	
	
	@Test(enabled = testEnabled, priority = 108)
	public void bvt108_executeStepToCustomStatus(){
		logger.info("Executing bvt108...");
		altID = 108;
		
		zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP")
				, "1", Config.getTCEPropValue("CUSTOM_STEP_EXECUTION_STATUS_1"), true, true, null);
		
		isSuccess = true;
		logger.info("bvt108 is executed successfully.");
	}
	
	
	@Test(enabled = testEnabled, priority = 109)
	public void bvt109_executeAllStepsToSingleStatusAndSetTestcaseStatusToSuggestedValueTest(){
		logger.info("Executing bvt109...");
		altID = 109;
		
		zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"), "1", "Pass", true, false, null);
		zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"), "2", "Pass", false, false, null);
		zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"), "3", "Pass", false, true, "Pass");
		//zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"), "4", "Pass", false, false, null);
		//zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"), "5", "Pass", false, false, null);
		//zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"), "6", "Pass", false, true, "Pass");
		
		isSuccess = true;
		logger.info("bvt109 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 110)
	public void bvt110_executeAllStepsToStatusNotAvailableAtTestcaseLevelAndVerifyPopupTest(){
		logger.info("Executing bvt110...");
		altID = 110;
		
		zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), "1"
				, Config.getTCEPropValue("CUSTOM_STEP_EXECUTION_STATUS_1"), true, false, null);
		zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), "2"
				, Config.getTCEPropValue("CUSTOM_STEP_EXECUTION_STATUS_1"), false, false, null);
		zeNavigator.executeTestStepAndVerify(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), "3"
				, Config.getTCEPropValue("CUSTOM_STEP_EXECUTION_STATUS_1"), false, true, null);
		
		isSuccess = true;
		logger.info("bvt110 is executed successfully.");
	}
	
	
	@Test(enabled = testEnabled, priority = 111)
	public void bvt111_uploadAttachmentToTestExecutionAndStepsTest(){
		logger.info("Executing bvt111...");
		altID = 111;
		
		zeNavigator.addExecutionAttachmentsNotesActualTime(Config.getTCRPropValue("TESTCASE_WITH_ATTACHMENT")
				, Config.getTCRPropValue("TESTCASE_ATTACHMENT"), null, null);
		
		isSuccess = true;
		logger.info("bvt111 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 114)
	public void bvt114_switchBetweenSearchAndFolderViewInExecutionTest(){
		logger.info("Executing bvt114...");
		altID = 114;
		
		zeNavigator.switchExecutionViewAndVerify("Search");
		zeNavigator.switchExecutionViewAndVerify("Folder");
		zeNavigator.switchExecutionViewAndVerify("Search");
		
		isSuccess = true;
		logger.info("bvt114 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 115)
	public void bvt115_quickSearchExecutionByStatusAndSelectSearchedTestcaseAndVerifyDetailsBelowTest(){
		logger.info("Executing bvt115...");
		altID = 115;
		
		List<String> testcaseNamesToVerify = new ArrayList<String>();
		testcaseNamesToVerify.add(0, Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"));
		
		zeNavigator.executionSearchAndVerifyTestcase("Quick", "Pass", testcaseNamesToVerify);
		
		Map<String, String> testcaseDetails = new HashMap<String, String>();
		testcaseDetails.put("Status", "Pass");
		
		zeNavigator.verifyTestExecutionDetailsInSearch(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), testcaseDetails);
		
		zeNavigator.switchExecutionViewAndVerify("Folder");
		
		isSuccess = true;
		logger.info("bvt115 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 116)
	public void bvt116_advanceSearchExecutionByAssigneeAndCheckboxCustomFieldAndSelectSearchedTestcaseAndVerifyDetailsBelowTest(){
		logger.info("Executing bvt116...");
		altID = 116;
		
		zeNavigator.switchExecutionViewAndVerify("Search");
		
		List<String> testcaseNamesToVerify = new ArrayList<String>();
		testcaseNamesToVerify.add(0, Config.getTCRPropValue("TESTCASE_WITH_ALL_CUSTOM_FIELDS"));
		
		zeNavigator.executionSearchAndVerifyTestcase("Advanced", "assignee = \"any.one\" and sample-custom-3 = true", testcaseNamesToVerify);
		
		Map<String, String> testcaseDetails = new HashMap<String, String>();
		testcaseDetails.put("Status", "Not Executed");
		
		zeNavigator.verifyTestExecutionDetailsInSearch(Config.getTCRPropValue("TESTCASE_WITH_ALL_CUSTOM_FIELDS"), testcaseDetails);
		
		isSuccess = true;
		logger.info("bvt116 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 118)
	public void bvt118_addTestcaseFromAnotherCycleWithDifferentStatusTest(){
		logger.info("Executing bvt118...");
		altID = 118;
		
		zeNavigator.launchReleaseApp("Test Planning");
		
		String startDate = CommonUtil.returnTodaysDate();
		String endDate = CommonUtil.returnFutureDateStartingTodaysDate(0, 2, 0);
		
		Assert.assertTrue(zeNavigator.createCycle(Config.getEASPropValue("CYCLE5_NAME"), null
				, null,startDate,endDate),  "Not created cycle successfully.");
		
		Assert.assertTrue(zeNavigator.addFreeformPhaseToCycle(Config.getEASPropValue("CYCLE5_NAME")
				, Config.getEASPropValue("FREEFORM2_PHASE_NAME"), true)
				, "Failed to add Freeform phase to cycle Successfully");
		
		zeNavigator.navigateToAssignTestcaseToExecuteWindow(Config.getEASPropValue("CYCLE5_NAME"), Config.getEASPropValue("FREEFORM2_PHASE_NAME"), false);

		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getEASPropValue("FREEFORM2_PHASE_NAME"));
		
		zeNavigator.navigateToNodeInAssignTestcaseToExecuteWindow(nodeList);
		//Modifying testcase created with three steps - Cloned Testcase
		
		List<String> expectedTestcases = new ArrayList<String>();
		expectedTestcases.add(0, Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"));
		
		zeNavigator.addTestcaseToFreeformNodeFromAnotherCycle(Config.getEASPropValue("CLONED_CYCLE3_NAME")
				, Config.getTCRPropValue("PHASE_1"), "Pass", expectedTestcases, false, false);
		
		zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"), "Unassigned", false);
		zeNavigator.verifyTestcaseCountOfSelectedNode(Config.getEASPropValue("FREEFORM2_PHASE_NAME"), 1, false);
		
		expectedTestcases.clear();
		expectedTestcases.add(0, Config.getTCRPropValue("TESTCASE_WITH_ATTACHMENT"));
		zeNavigator.addTestcaseToFreeformNodeFromAnotherCycle(Config.getEASPropValue("CLONED_CYCLE3_NAME")
				, Config.getTCRPropValue("PHASE_1"), "Fail", expectedTestcases, false, false);
		
		zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("TESTCASE_WITH_ATTACHMENT"), "Unassigned", false);
		zeNavigator.verifyTestcaseCountOfSelectedNode(Config.getEASPropValue("FREEFORM2_PHASE_NAME"), 2, false);
		
		expectedTestcases.clear();
		expectedTestcases.add(0, Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"));
		zeNavigator.addTestcaseToFreeformNodeFromAnotherCycle(Config.getEASPropValue("CLONED_CYCLE3_NAME")
				, Config.getTCRPropValue("PHASE_1"), Config.getTCEPropValue("CUSTOM_EXECUTION_STATUS_1"), expectedTestcases, false, false);
		
		zeNavigator.verifyAssigneeOfTestcase(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), "Unassigned", false);
		zeNavigator.verifyTestcaseCountOfSelectedNode(Config.getEASPropValue("FREEFORM2_PHASE_NAME"), 3, true);
		
		isSuccess = true;
		logger.info("bvt118 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 119)
	public void bvt119_searchExistingDefectAndLinkToTestcaseTest(){
		logger.info("Executing bvt119...");
		altID = 119;
		
		zeNavigator.launchReleaseApp("Test Execution");
		
		List<String> nodeList = new ArrayList<String>();
		nodeList.add(0, Config.getTCRPropValue("RELEASE_NAME"));
		nodeList.add(1, Config.getEASPropValue("CLONED_CYCLE3_NAME"));
		nodeList.add(2, Config.getTCRPropValue("PHASE_1"));
		nodeList.add(3, Config.getTCRPropValue("NODE_1"));
		nodeList.add(4, Config.getTCRPropValue("SUB_NODE_1"));
		
		zeNavigator.navigateToNodesInTestExecution(nodeList);
		
		zeNavigator.searchAndLinkDefect(Config.getTCRPropValue("TESTCASE_WITH_ATTACHMENT"), "JQL"
				, Config.getTCEPropValue("SEARCH_QUERY1"), Config.getTCEPropValue("DEFECT1_SUMMARY"), Config.getTCEPropValue("DEFECT1_ID"));
		
		isSuccess = true;
		logger.info("bvt119 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 120)
	public void bvt120_createNewDefectFromTCEAndViewRemoteLinkInExternalJiraTest(){
		logger.info("Executing bvt120...");
		altID = 120;
		
		Map<String, String> values = new HashMap<String, String>();
		values.put("Project", Config.getProjectPropValue("JIRA_PROJECT_NAME"));
		values.put("Issue Type", Config.getProjectPropValue("ISSUE_TYPE"));
		values.put("Summary", Config.getTCEPropValue("NEW_DEFECT1"));
		values.put("Description", Config.getTCEPropValue("NEW_DEFECT1_DESCRIPTION"));
		values.put("Priority", Config.getTCEPropValue("NEW_DEFECT1_PRIORITY"));
		
		zeNavigator.linkNewDefect(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), values);
		
		isSuccess = true;
		logger.info("bvt120 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 125)
	public void bvt125_createNewDefectWithTestStepsCopiedToDefectDescriptionAsPlainTextTest(){
		
		logger.info("Executing bvt125...");
		altID = 125;
		
		Map<String, String> values = new HashMap<String, String>();
		values.put("Project", Config.getProjectPropValue("JIRA_PROJECT_NAME"));
		values.put("Issue Type", Config.getProjectPropValue("ISSUE_TYPE"));
		values.put("Summary", Config.getTCEPropValue("NEW_DEFECT2"));
		values.put("Description", Config.getTCEPropValue("NEW_DEFECT2_DESCRIPTION"));
		values.put("Priority", Config.getTCEPropValue("NEW_DEFECT2_PRIORITY"));
		
		zeNavigator.linkNewDefect(Config.getTCRPropValue("EDIT_TESTCASE_WITH_MULTIPLE_STEP"), values);
		
		isSuccess = true;
		logger.info("bvt125 is executed successfully.");
		
	}
	
	@Test(enabled = testEnabled, priority = 126)
	public void bvt126_createNewDefectWithTestStepsCopiedToDefectDescriptionAsWikiMarkupTest(){
		
		logger.info("Executing bvt126...");
		altID = 126;
		
		Map<String, String> values = new HashMap<String, String>();
		values.put("Project", Config.getProjectPropValue("JIRA_PROJECT_NAME"));
		values.put("Issue Type", Config.getProjectPropValue("ISSUE_TYPE"));
		values.put("Summary", Config.getTCEPropValue("NEW_DEFECT3"));
		values.put("Description", Config.getTCEPropValue("NEW_DEFECT3_DESCRIPTION"));
		values.put("Priority", Config.getTCEPropValue("NEW_DEFECT3_PRIORITY"));
		
		zeNavigator.linkNewDefect(Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"), values);
		
		isSuccess = true;
		logger.info("bvt126 is executed successfully.");
		
	}
	
	
	
	@Test(enabled = testEnabled, priority = 145)
	public void bvt145_createRequirementPhase() {
		logger.info("Executing bvt145...");
		altID = 145;

		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		Assert.assertTrue(zeNavigator.navigateToReleaseApps(releaseName, appName), "Not navigated to : " + appName);

		String phaseName = Config.getReqPropValue("PHASE_1");
		String phaseDescription = phaseName + " description";
		Assert.assertTrue(zeNavigator.createReqPhase(releaseName, phaseName, phaseDescription),
				"Phase not created successfully.");

		phaseName = Config.getReqPropValue("PHASE_2");
		phaseDescription = phaseName + " description";
		Assert.assertTrue(zeNavigator.createReqPhase(releaseName, phaseName, phaseDescription),
				"Phase not created successfully.");

		phaseName = Config.getReqPropValue("PHASE_3");
		phaseDescription = phaseName + " description";
		Assert.assertTrue(zeNavigator.createReqPhase(releaseName, phaseName, phaseDescription),
				"Phase not created successfully.");

		logger.info("Phases are created successsfully.");
		isSuccess = true;
		logger.info("bvt145 is executed successfully.");
	}
	@Test(enabled = testEnabled, priority = 145)
	public void bvt146_createSubRequirementPhase() {
		logger.info("Executing bvt146...");
		altID = 146;

		logger.info("");
		String releaseName = "Release 1.0";
//		String appName = "Requirements";
//		zeNavigator.selectProject("Sample Project");
//		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
//		Assert.assertTrue(zeNavigator.navigateToReleaseApps(releaseName, appName), "Not navigated to : " + appName);

		String parentNodeName = Config.getReqPropValue("PHASE_1");
		String nodeOneName = Config.getReqPropValue("SUB_PHASE_1");
		String nodeOneDescription = nodeOneName + " description";
		
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getReqPropValue("RELEASE_NAME"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.createRequirementNode(parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");
		logger.info("Created nodes as "+nodeOneName+" for " + parentNodeName + " Successfully.");

		String nodeTwoName = Config.getReqPropValue("SUB_PHASE_2");
		String nodeTwoDescription = nodeTwoName + " description";
		Assert.assertTrue(zeNavigator.createRequirementNode(parentNodeName, nodeTwoName, nodeTwoDescription),
				"Node not created successfully.");
		logger.info("Created nodes as "+nodeTwoName+" for " + parentNodeName + " Successfully.");

		String nodeThreeName = Config.getReqPropValue("SUB_PHASE_3");
		String nodeThreeDescription = nodeThreeName + " description";
		Assert.assertTrue(zeNavigator.createRequirementNode(parentNodeName, nodeThreeName, nodeThreeDescription),
				"Node not created successfully.");
		logger.info("Created nodes as "+nodeThreeName+" for " + parentNodeName + " Successfully.");
		
		
		parentNodeName = Config.getReqPropValue("PHASE_2");
		nodeOneName = Config.getReqPropValue("SUB_PHASE_4");
		nodeOneDescription = nodeOneName + " description";
		
//		List<String> phases = new ArrayList<String>();
//		phases.add(Config.getReqPropValue("RELEASE_NAME"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.createRequirementNode(parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");
		logger.info("Created nodes as "+nodeOneName+" for " + parentNodeName + " Successfully.");

		nodeTwoName = Config.getReqPropValue("SUB_PHASE_5");
		nodeTwoDescription = nodeTwoName + " description";
		Assert.assertTrue(zeNavigator.createRequirementNode(parentNodeName, nodeTwoName, nodeTwoDescription),
				"Node not created successfully.");
		logger.info("Created nodes as "+nodeTwoName+" for " + parentNodeName + " Successfully.");

		nodeThreeName = Config.getReqPropValue("SUB_PHASE_6");
		nodeThreeDescription = nodeThreeName + " description";
		Assert.assertTrue(zeNavigator.createRequirementNode(parentNodeName, nodeThreeName, nodeThreeDescription),
				"Node not created successfully.");
		logger.info("Created nodes as "+nodeThreeName+" for " + parentNodeName + " Successfully.");
		
		
		parentNodeName = Config.getReqPropValue("PHASE_3");
		nodeOneName = Config.getReqPropValue("SUB_PHASE_7");
		nodeOneDescription = nodeOneName + " description";
		
//		List<String> phases = new ArrayList<String>();
//		phases.add(Config.getReqPropValue("RELEASE_NAME"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.createRequirementNode(parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");
		logger.info("Created nodes as "+nodeOneName+" for " + parentNodeName + " Successfully.");

		nodeTwoName = Config.getReqPropValue("SUB_PHASE_8");
		nodeTwoDescription = nodeTwoName + " description";
		Assert.assertTrue(zeNavigator.createRequirementNode(parentNodeName, nodeTwoName, nodeTwoDescription),
				"Node not created successfully.");
		logger.info("Created nodes as "+nodeTwoName+" for " + parentNodeName + " Successfully.");

		nodeThreeName = Config.getReqPropValue("SUB_PHASE_9");
		nodeThreeDescription = nodeThreeName + " description";
		Assert.assertTrue(zeNavigator.createRequirementNode(parentNodeName, nodeThreeName, nodeThreeDescription),
				"Node not created successfully.");
		logger.info("Created nodes as "+nodeThreeName+" for " + parentNodeName + " Successfully.");
		
//		
//		
//		String phaseName = Config.getReqPropValue("PHASE_1");
//		String phaseDescription = phaseName + " description";
//		Assert.assertTrue(zeNavigator.createReqPhase(releaseName, phaseName, phaseDescription),
//				"Phase not created successfully.");
//
//		phaseName = Config.getReqPropValue("PHASE_2");
//		phaseDescription = phaseName + " description";
//		Assert.assertTrue(zeNavigator.createReqPhase(releaseName, phaseName, phaseDescription),
//				"Phase not created successfully.");
//
//		phaseName = Config.getReqPropValue("PHASE_3");
//		phaseDescription = phaseName + " description";
//		Assert.assertTrue(zeNavigator.createReqPhase(releaseName, phaseName, phaseDescription),
//				"Phase not created successfully.");

		logger.info("Phases are created successsfully.");
		isSuccess = true;
		logger.info("bvt145 is executed successfully.");
	}
	/**
	 * Need to create a node and provide the node in renameNodeName
	 */
	@Test(enabled = testEnabled, priority = 147)
	public void bvt147_renameRequirementNode() {
		logger.info("Executing bvt147...");
		altID = 139;
		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		Assert.assertTrue(zeNavigator.navigateToReleaseApps(releaseName, appName), "Not navigated to : " + appName);

		String renameNodeName = Config.getReqPropValue("PHASE_2");
		String nodeName = Config.getReqPropValue("NODE_1_EDIT");
		String nodeDescription = nodeName + " Description";

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getReqPropValue("RELEASE_NAME"));
		phases.add(Config.getReqPropValue("PHASE_2"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.renameRequirementsNode(renameNodeName, nodeName, nodeDescription),
				"Node not renamed successfully.");
		// Assert.assertTrue(zeNavigator.renameRequirementsNode(renameNodeName,
		// newNodeName, newNodeDescription),"Node not renamed successfully.");

		isSuccess = true;
		logger.info("bvt147 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 148)
	public void bvt148_createRequirement() {
		logger.info("Executing bvt148...");
		altID = 148;

		List<String> phases = new ArrayList<String>();
		phases.add("Release 1.0");
		// phases.add(Config.getTCRPropValue("NODE_1"));
		// phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		String nodeName = Config.getReqPropValue("PHASE_1");
		String requirementId = zeNavigator.addDefaultRequirement(nodeName);
		Assert.assertNotNull(requirementId, "Not added default requirement successfully.");

		isSuccess = true;
		logger.info("bvt148 is executed successfully.");
	}
	@Test(enabled = testEnabled, priority = 150)
	public void bvt150_cloneRequirement() {
		logger.info("Executing bvt150...");
		altID = 150;

		List<String> phases = new ArrayList<String>();
		phases.add("Release 1.0");
		 phases.add(Config.getReqPropValue("PHASE_1"));
		// phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		String nodeName = Config.getReqPropValue("SUB_PHASE_1");
		String requirementId = zeNavigator.addDefaultRequirement(nodeName);
		Assert.assertNotNull(requirementId, "Not added default requirement successfully.");
		
		
		boolean cloneReqStatus = zeNavigator.cloneRequirement(nodeName, requirementId);
		Assert.assertTrue(cloneReqStatus, "Not cloned Requirements successfully.");
		
		isSuccess = true;
		logger.info("bvt150 is executed successfully.");
	}
	@Test(enabled = testEnabled, priority = 155)
	public void bvt155_deleteRequirement() {
		logger.info("Executing bvt155...");
		altID = 155;

		List<String> phases = new ArrayList<String>();
		phases.add("Release 1.0");
		 phases.add(Config.getReqPropValue("PHASE_1"));
		// phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		String nodeName = Config.getReqPropValue("SUB_PHASE_1");
		String requirementId = zeNavigator.addDefaultRequirement(nodeName);
		Assert.assertNotNull(requirementId, "Not added default requirement successfully.");
		
		
		boolean deleteReqStatus = zeNavigator.deleteRequirement(nodeName, requirementId);
		Assert.assertTrue(deleteReqStatus, "Not deleted Requirements successfully.");
		
		isSuccess = true;
		logger.info("bvt155 is executed successfully.");
	}

	@BeforeMethod
	public void beforeMethod() {
		isSuccess = false;
	}

	@AfterMethod
	public void afterMethod() {
		baseAfterMethod();
		try{
			if(!isSuccess && altID==26){
				zeNavigator.logout();
				CommonUtil.browserRefresh();
				zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
			}else{
				if(!isSuccess){
					CommonUtil.browserRefresh();
					CommonUtil.normalWait(15000);
				}
			}
		}catch(Exception e){
			
		}
		
		
		// String bvtRtsId = TestStatusUpdateUtil.getTestcaseId(bvtFilePath,
		// altID);
		// System.out.println("bvtRtsId :"+bvtRtsId);
		/*for (int i = 0; i < scheduleArray.length(); i++) {
			JSONObject json = (JSONObject) scheduleArray.get(i);
			String rtsId = json.get("id").toString();
			JSONObject testcase = json.getJSONObject("tcrTreeTestcase").getJSONObject("testcase");
			// System.out.println(testcase.get("id"));
			if (testcaseId.equals(testcase.get("id").toString().trim())) {
				if (isSuccess) {
					Response response = testStatusUpdate.executeTests(basicAuth, rtsId, 1, 1);
					// System.out.println(response.getBody().asString());
				} else {
					Response response = testStatusUpdate.executeTests(basicAuth, rtsId, 2, 1);
					// System.out.println(response.getBody().asString());
				}
				break;

			}

		}*/
	}

	// @BeforeClass
	public void beforeClass() {
		// ZAPIAPIServiceImpl zapiService = new ZAPIAPIServiceImpl();
		/*DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		String cycleName = "Cycle " + System.currentTimeMillis();
		String startDate = df.format(new Date());
		String endDate = df.format(new Date());

		String releaseId = "1";
		String phaseName = "ZE_BVT";
		String tcrCatalogTreeId = "108";

		String createCyclePayLoad = "{\"name\": \"" + cycleName + "\",\"startDate\": \"" + startDate
				+ "\",\"endDate\": \"" + endDate + "\",\"status\": 0,\"releaseId\": " + releaseId
				+ ",\"cyclePhases\": [{\"name\": \"" + phaseName + "\",\"tcrCatalogTreeId\": " + tcrCatalogTreeId
				+ ",\"freeForm\": false,\"startDate\": \"" + startDate + "\",\"endDate\": \"" + endDate + " \"}]}";
		Response response = testStatusUpdate.createCycle(basicAuth, createCyclePayLoad.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		// System.out.println(response.getBody().asString());
		String cycleId = new JSONObject(response.getBody().asString()).get("id").toString();
		System.out.println(cycleId);
		String os = new JSONObject(response.getBody().asString()).get("cyclePhases").toString();
		tcrCatalogTreeId = new JSONArray(os).getJSONObject(0).get("tcrCatalogTreeId").toString();
		System.out.println(tcrCatalogTreeId);

		response = testStatusUpdate.changeAssignments(basicAuth, cycleId, tcrCatalogTreeId, -1, 1);
		// System.out.println(response.getBody().asString());

		JSONObject json = new JSONObject(response.getBody().asString());
		String s = json.get("Add").toString();
		scheduleArray = new JSONArray(s);
		String rtsId = new JSONArray(s).getJSONObject(0).get("id").toString();
		JSONObject dss = new JSONArray(s).getJSONObject(0).getJSONObject("tcrTreeTestcase").getJSONObject("testcase");
		System.out.println(dss.get("id"));*/
	}

	@AfterClass
	public void afterClass() {
	}
	
	

}
