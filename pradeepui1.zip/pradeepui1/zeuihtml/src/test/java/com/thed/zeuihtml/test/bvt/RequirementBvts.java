package com.thed.zeuihtml.test.bvt;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.thed.zeuihtml.BaseTest;
import com.thed.zeuihtml.Config;
import com.thed.zeuihtml.Constants;
import com.thed.zeuihtml.utils.CommonUtil;

public class RequirementBvts extends BaseTest {


	public RequirementBvts() {
		logger = Logger.getLogger(this.getClass());
	}


	@Test(enabled = testEnabled, priority = 158)
	public void bvt156_createRequirementPhase() {
		logger.info("Executing bvt156...");
		altID = 156;

		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		//Assert.assertTrue(zeNavigator.launchReleaseApp(appName), "Not navigated to : " + appName);
		zeNavigator.launchReleaseApp(appName);

		String phaseName = Config.getReqPropValue("PHASE_1");
		String phaseDescription = phaseName + " description";
		Assert.assertTrue(zeNavigator.createReqPhase(releaseName, phaseName, phaseDescription),
				"Phase not created successfully.");

		phaseName = Config.getReqPropValue("PHASE_2");
		phaseDescription = phaseName + " description";
		Assert.assertTrue(zeNavigator.createReqPhase(releaseName, phaseName, phaseDescription),
				"Phase not created successfully.");

		phaseName = Config.getReqPropValue("PHASE_3");
		phaseDescription = phaseName + " description";
		Assert.assertTrue(zeNavigator.createReqPhase(releaseName, phaseName, phaseDescription),
				"Phase not created successfully.");

		logger.info("Phases are created successsfully.");
		isSuccess = true;
		logger.info("bvt156 is executed successfully.");
	}
	@Test(enabled = testEnabled, priority = 159)
	public void bvt157_createSubRequirementPhase() {
		logger.info("Executing bvt157...");
		altID = 157;

		logger.info("");
		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		//Assert.assertTrue(zeNavigator.launchReleaseApp(appName), "Not navigated to : " + appName);
		zeNavigator.launchReleaseApp(appName);
		String parentNodeName = Config.getReqPropValue("PHASE_1");
		String nodeOneName = Config.getReqPropValue("SUB_PHASE_1");
		String nodeOneDescription = nodeOneName + " description";


		List<String> phases = new ArrayList<String>();
		phases.add(Config.getReqPropValue("RELEASE_NAME"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.createRequirementNode(parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");
		logger.info("Created nodes as "+nodeOneName+" for " + parentNodeName + " Successfully.");

		String nodeTwoName = Config.getReqPropValue("SUB_PHASE_2");
		String nodeTwoDescription = nodeTwoName + " description";
		Assert.assertTrue(zeNavigator.createRequirementNode(parentNodeName, nodeTwoName, nodeTwoDescription),
				"Node not created successfully.");
		logger.info("Created nodes as "+nodeTwoName+" for " + parentNodeName + " Successfully.");

		String nodeThreeName = Config.getReqPropValue("SUB_PHASE_3");
		String nodeThreeDescription = nodeThreeName + " description";
		Assert.assertTrue(zeNavigator.createRequirementNode(parentNodeName, nodeThreeName, nodeThreeDescription),
				"Node not created successfully.");
		logger.info("Created nodes as "+nodeThreeName+" for " + parentNodeName + " Successfully.");


		parentNodeName = Config.getReqPropValue("PHASE_2");
		nodeOneName = Config.getReqPropValue("SUB_PHASE_4");
		nodeOneDescription = nodeOneName + " description";

		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.createRequirementNode(parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");
		logger.info("Created nodes as "+nodeOneName+" for " + parentNodeName + " Successfully.");

		nodeTwoName = Config.getReqPropValue("SUB_PHASE_5");
		nodeTwoDescription = nodeTwoName + " description";
		Assert.assertTrue(zeNavigator.createRequirementNode(parentNodeName, nodeTwoName, nodeTwoDescription),
				"Node not created successfully.");
		logger.info("Created nodes as "+nodeTwoName+" for " + parentNodeName + " Successfully.");

		nodeThreeName = Config.getReqPropValue("SUB_PHASE_6");
		nodeThreeDescription = nodeThreeName + " description";
		Assert.assertTrue(zeNavigator.createRequirementNode(parentNodeName, nodeThreeName, nodeThreeDescription),
				"Node not created successfully.");
		logger.info("Created nodes as "+nodeThreeName+" for " + parentNodeName + " Successfully.");


		parentNodeName = Config.getReqPropValue("PHASE_3");
		nodeOneName = Config.getReqPropValue("SUB_PHASE_7");
		nodeOneDescription = nodeOneName + " description";

		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.createRequirementNode(parentNodeName, nodeOneName, nodeOneDescription),
				"Node not created successfully.");
		logger.info("Created nodes as "+nodeOneName+" for " + parentNodeName + " Successfully.");

		nodeTwoName = Config.getReqPropValue("SUB_PHASE_8");
		nodeTwoDescription = nodeTwoName + " description";
		Assert.assertTrue(zeNavigator.createRequirementNode(parentNodeName, nodeTwoName, nodeTwoDescription),
				"Node not created successfully.");
		logger.info("Created nodes as "+nodeTwoName+" for " + parentNodeName + " Successfully.");

		nodeThreeName = Config.getReqPropValue("SUB_PHASE_9");
		nodeThreeDescription = nodeThreeName + " description";
		Assert.assertTrue(zeNavigator.createRequirementNode(parentNodeName, nodeThreeName, nodeThreeDescription),
				"Node not created successfully.");
		logger.info("Created nodes as "+nodeThreeName+" for " + parentNodeName + " Successfully.");

		logger.info("Phases are created successsfully.");
		isSuccess = true;
		logger.info("bvt157 is executed successfully.");
	}
	/**
	 * Need to create a node and provide the node in renameNodeName
	 */
	@Test(enabled = testEnabled, priority = 160)
	public void bvt158_renameRequirementNode() {
		logger.info("Executing bvt158...");
		altID = 158;
		String releaseName = "Release 1.0";
		String appName = "Requirements";


		//Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		//Assert.assertTrue(zeNavigator.launchReleaseApp(appName), "Not navigated to : " + appName);


		String renameNodeName = Config.getReqPropValue("PHASE_2");
		String nodeName = Config.getReqPropValue("NODE_1_EDIT");
		String nodeDescription = nodeName + " Description";

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getReqPropValue("RELEASE_NAME"));
		phases.add(Config.getReqPropValue("PHASE_2"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.renameRequirementsNode(renameNodeName, nodeName, nodeDescription),
				"Node not renamed successfully.");
		// Assert.assertTrue(zeNavigator.renameRequirementsNode(renameNodeName,
		// newNodeName, newNodeDescription),"Node not renamed successfully.");

		isSuccess = true;
		logger.info("bvt158 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 161)
	public void bvt159_createRequirement() {
		logger.info("Executing bvt159...");
		altID = 159;

		String appName = "Requirements";
		String releaseName = "Release 1.0";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		//Assert.assertTrue(zeNavigator.launchReleaseApp(appName), "Not navigated to : " + appName);
		zeNavigator.launchReleaseApp("Requirements");
		CommonUtil.normalWait(5000);
		List<String> phases = new ArrayList<String>();
		phases.add("Release 1.0");
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		String nodeName = Config.getReqPropValue("PHASE_1");
		String requirementId = zeNavigator.addDefaultRequirement(nodeName);
		phases.add(Config.getReqPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");

		Assert.assertNotNull(requirementId, "Not added default requirement successfully.");
		Map<String, String> values = new HashMap<String, String>();
		values.put("ALTID", Config.getReqPropValue("Req_ALT_ID1"));
		//Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		zeNavigator.modifyRequirement("Untitled requirement", values,null);

		isSuccess = true;
		logger.info("bvt159 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 162)
	public void bvt160_addRequirementWithAllCustomFieldstest(){
		logger.info("Executing bvt160...");
		altID = 160;

		Map<String, String> typeNameAndValue = new HashMap<String, String>();
		typeNameAndValue.put("Text", Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_1") + Constants.CHAR_TO_SPLIT_STRING + "Sample Text");
		typeNameAndValue.put("LongText", Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_2") + Constants.CHAR_TO_SPLIT_STRING + "Sample Long Text");
		typeNameAndValue.put("Checkbox", Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_3"));
		typeNameAndValue.put("Date", Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_4") + Constants.CHAR_TO_SPLIT_STRING + CommonUtil.returnTodaysDate());
		typeNameAndValue.put("Number", Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_5") + Constants.CHAR_TO_SPLIT_STRING + "123");
		typeNameAndValue.put("Picklist", Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_6") + Constants.CHAR_TO_SPLIT_STRING + Config.getReqPropValue("RQ_PICKLIST_VALUE_1"));

		zeNavigator.updateRequirementCustomFieldValue("Untitled requirement", typeNameAndValue);

		isSuccess = true;
		logger.info("bvt160 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 163)
	public void bvt161_cloneRequirement() {
		logger.info("Executing bvt161...");
		altID = 161;
		String releaseName = "Release 1.0";
		List<String> phases = new ArrayList<String>();
		phases.add("Release 1.0");
		 phases.add(Config.getReqPropValue("PHASE_1"));
		// phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		String nodeName = Config.getReqPropValue("SUB_PHASE_1");
		String requirementId = zeNavigator.addDefaultRequirement(nodeName);
		Assert.assertNotNull(requirementId, "Not added default requirement successfully.");


		boolean cloneReqStatus = zeNavigator.cloneRequirement(nodeName, requirementId);
		Assert.assertTrue(cloneReqStatus, "Not cloned Requirements successfully.");

		isSuccess = true;
		logger.info("bvt161 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 164)
	public void bvt163_deallocateRequirementTest(){
		logger.info("Executing bvt163...");
		altID = 163;
		zeNavigator.selectProject("Sample Project");

		String releaseName = "Release 1.0";
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		//Assert.assertTrue(zeNavigator.launchReleaseApp(appName), "Not navigated to : " + appName);
		//
		zeNavigator.launchReleaseApp("Requirements");
		List<String> phases = new ArrayList<String>();
		phases.add("Release 1.0");
		phases.add(Config.getReqPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");

		Assert.assertTrue(zeNavigator.deallocateRequirement("Untitled requirement"));

		phases.clear();
		phases.add("Project Requirements");
		phases.add(Config.getReqPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		zeNavigator.verifyRequirement("Untitled requirement", null);
		zeNavigator.navigateBackToReqList();

		isSuccess = true;
		logger.info("bvt163 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 165)
	public void bvt162_allocateRequirementTest(){
		logger.info("Executing bvt162...");
		altID = 162;

		zeNavigator.selectProject("Sample Project");
		String releaseName = "Release 1.0";
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		//Assert.assertTrue(zeNavigator.launchReleaseApp(appName), "Not navigated to : " + appName);
		//
		zeNavigator.launchReleaseApp("Requirements");
		List<String> phases = new ArrayList<String>();
		phases.add("Project Requirements");
		phases.add(Config.getReqPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.allocateRequirement("Untitled requirement"));

		phases.clear();
		phases.add("Release 1.0");
		phases.add(Config.getReqPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		zeNavigator.verifyRequirement("Untitled requirement", null);
		zeNavigator.navigateBackToReqList();

		isSuccess = true;
		logger.info("bvt162 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 166)
	public void bvt175_mapTestcaseToInternalRequirementTest(){
		logger.info("Executing bvt175...");
		altID = 175;

		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		//Assert.assertTrue(zeNavigator.launchReleaseApp(appName), "Not navigated to : " + appName);
		zeNavigator.launchReleaseApp(appName);
		
		List<String> phases = new ArrayList<String>();
		phases.add("Release 1.0");
		phases.add(Config.getReqPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");

		List<String> testcaseTreeNodes = new ArrayList<String>();
		testcaseTreeNodes.add(0, "Release 1.0");
		testcaseTreeNodes.add(1, Config.getTCRPropValue("PHASE_1"));
		testcaseTreeNodes.add(2, Config.getTCRPropValue("NODE_1"));
		testcaseTreeNodes.add(3, Config.getTCRPropValue("SUB_NODE_1"));

		Assert.assertTrue(zeNavigator.mapTestcaseToRequirement("Untitled requirement", testcaseTreeNodes, "Add attachment to testcase"),"Failed to map testcase to internal requirement");
		zeNavigator.navigateBackToReqList();
		isSuccess = true;
		logger.info("bvt175 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 167)
	public void bvt165_deallocateRequirementIfAllocatedToMultipleReleaseTest(){
		logger.info("Executing bvt165...");
		altID = 165;
		zeNavigator.selectProject("Sample Project");
		String releaseOne = Config.getReleasePropValue("DEFAULT_RELEASE_NAME");
		String releaseTwo = Config.getReleasePropValue("RELEASE_NAME_1");
		Assert.assertTrue(zeNavigator.navigateReleaseFromTopDropdown(releaseTwo), "Not selected release.");
		//zeNavigator.navigateReleaseFromLeftDropdown(releaseTwo);

		String releaseName = releaseTwo;
		String appName = "Requirements";
		zeNavigator.launchReleaseApp(appName);

		List<String> phases = new ArrayList<String>();
		phases.add("Project Requirements");
		phases.add(Config.getReqPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");

		Assert.assertTrue(zeNavigator.allocateRequirement("Untitled requirement"));
		phases.clear();
		phases.add(releaseTwo);
		phases.add(Config.getReqPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		zeNavigator.verifyRequirement("Untitled requirement", null);
		zeNavigator.navigateBackToReqList();
		Assert.assertTrue(zeNavigator.deallocateRequirement("Untitled requirement"));

		phases.clear();
		phases.add("Project Requirements");
		phases.add(Config.getReqPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		zeNavigator.verifyRequirement("Untitled requirement", null);
		zeNavigator.navigateBackToReqList();

		zeNavigator.navigateReleaseFromTopDropdown(releaseOne);

		releaseName = releaseOne;
		zeNavigator.launchReleaseApp(appName);

		isSuccess = true;
		logger.info("bvt165 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 168)
	public void bvt166_deleteRequirement() {
		logger.info("Executing bvt166...");
		altID = 166;

		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.navigateReleaseFromTopDropdown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);

		List<String> phases = new ArrayList<String>();
		phases.add("Release 1.0");
		phases.add(Config.getReqPropValue("PHASE_1"));
		String nodeName = Config.getReqPropValue("SUB_PHASE_1");
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");

		String requirementId = zeNavigator.addDefaultRequirement(nodeName);
		Assert.assertNotNull(requirementId, "Not added default requirement successfully.");


		boolean deleteReqStatus = zeNavigator.deleteRequirement(nodeName, requirementId);
		CommonUtil.normalWait(2000);
		Assert.assertTrue(deleteReqStatus, "Not deleted Requirements successfully.");

		isSuccess = true;
		logger.info("bvt166 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 169)
	public void bvt167_saveRequirementWithTextCustomFieldAndAddCustomFieldInGridAndVerifyValueTest(){
		logger.info("Executing bvt167...");
		altID = 167;

		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);

		List<String> phases = new ArrayList<String>();
		phases.add("Release 1.0");
		phases.add(Config.getReqPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");

		List<String> fieldNames = new ArrayList<String>();
		fieldNames.add(Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_1"));

		Assert.assertTrue(zeNavigator.checkOrUncheckRequirementFieldsInGrid(fieldNames, true));

		Map<String, String> reqFieldsValues = new HashMap<String, String>();
		reqFieldsValues.put("CUSTOMFIELDS", Config.getReqPropValue("RQ_CUSTOM_FIELD_NAME_1") + Constants.CHAR_TO_SPLIT_STRING + "Sample Text");

		zeNavigator.verifyRequirement("Untitled requirement", reqFieldsValues);
		zeNavigator.navigateBackToReqList();
		isSuccess = true;
		logger.info("bvt167 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 170)
	public void bvt168_exportRequirementTreeNodeInExcelTest() {
		logger.info("Executing bvt168...");
		altID = 168;
		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		List<String> phases = new ArrayList<String>();
		phases.add("Release 1.0");
		phases.add(Config.getReqPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");


		zeNavigator.exportSelectedRequirementTreeNode(Config.getReqPropValue("PHASE_1")
				, "Excel", null);

		List<String>  fileNames= CommonUtil.returnFileNames(Config.getValue("EXPORT_FILE_PATH"));
		CommonUtil.renameFile(Config.getValue("EXPORT_FILE_PATH")+"/"+fileNames.get(0), Config.getReqPropValue("EXCEL_TREE_EXPORT_FILENAME"));

		List<Integer> ignoreCells = new ArrayList<Integer>();
		ignoreCells.add(4);
		ignoreCells.add(12);
		ignoreCells.add(14);
		ignoreCells.add(20);

		isSuccess = CommonUtil.compareExcel(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getReqPropValue("EXCEL_TREE_EXPORT_FILENAME")
		, Config.getValue("EXPORT_FILE_PATH")+"/backups/"+Config.getReqPropValue("BACKUP_TREE_EXCEL_TO_COMPARE"),ignoreCells);

		CommonUtil.moveFile(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getReqPropValue("EXCEL_TREE_EXPORT_FILENAME"), Config.getValue("EXPORT_FILE_PATH")+"/delete");

		//Assert.assertTrue(isSuccess, "Exported Excel Data is not correct when compared with expected data");


		isSuccess = true;
		logger.info("bvt168 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 171)
	public void bvt169_exportRequirementTreeNodeInDetailedReportTest() {
		logger.info("Executing bvt169...");
		altID = 169;
		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		List<String> phases = new ArrayList<String>();
		phases.add("Release 1.0");
		phases.add(Config.getReqPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		
		zeNavigator.exportSelectedRequirementTreeNode(Config.getReqPropValue("PHASE_1"), "Detailed", "PDF");
		List<String>  fileNames= CommonUtil.returnFileNames(Config.getValue("EXPORT_FILE_PATH"));
		System.out.println("Summary File Name: " + fileNames.get(0));

		CommonUtil.renameFile(Config.getValue("EXPORT_FILE_PATH")+"/"+fileNames.get(0), Config.getReqPropValue("PDF_EXPORT_FILENAME"));

		isSuccess = CommonUtil.compareTwoPDFFilesData(Config.getValue("EXPORT_FILE_PATH")+"/backups/"+Config.getReqPropValue("BACKUP_PDF_TO_COMPARE"),
		Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getReqPropValue("PDF_EXPORT_FILENAME"));

		CommonUtil.moveFile(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getReqPropValue("PDF_EXPORT_FILENAME"), Config.getValue("EXPORT_FILE_PATH")+"/delete");

		//Assert.assertTrue(isSuccess, "PDF exported is not matching to expected data");

		isSuccess = true;
		logger.info("bvt169 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 172)
	public void bvt170_exportRequirementFromGridTest() {
		logger.info("Executing bvt170...");
		altID = 170;
		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		List<String> phases = new ArrayList<String>();
		phases.add("Release 1.0");
		phases.add(Config.getReqPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		
		zeNavigator.exportAllRequirementFromGridOfSelectedTreeNode("Summary", "PDF");

		List<String>  fileNames= CommonUtil.returnFileNames(Config.getValue("EXPORT_FILE_PATH"));
		System.out.println("Summary File Name: " + fileNames.get(0));

		CommonUtil.renameFile(Config.getValue("EXPORT_FILE_PATH")+"/"+fileNames.get(0), Config.getReqPropValue("PDF_EXPORT_GRID_FILENAME"));

		isSuccess = CommonUtil.compareTwoPDFFilesData(Config.getValue("EXPORT_FILE_PATH")+"/backups/"+Config.getReqPropValue("BACKUP_PDF_GRID_TO_COMPARE"),
		Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getReqPropValue("PDF_EXPORT_GRID_FILENAME"));

		CommonUtil.moveFile(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getReqPropValue("PDF_EXPORT_GRID_FILENAME"), Config.getValue("EXPORT_FILE_PATH")+"/delete");

		//Assert.assertTrue(isSuccess, "PDF exported is not matching to expected data");

		isSuccess = true;
		logger.info("bvt170 is executed successfully.");
	}

	@Test (enabled = testEnabled, priority = 173)
	public void bvt172_importJiraRequirements() {
		logger.info("Executing bvt172...");
		altID = 172;
		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		List<String> phases = new ArrayList<String>();
		phases.add("Release 1.0");
		List<String> issueSummary = new ArrayList<String>();
		issueSummary.add(Config.getTCEPropValue("DEFECT1_SUMMARY"));

		Assert.assertTrue(zeNavigator.importJiraRequirements(Config.getReqPropValue("JQL_TO_IMPORT_JIRA_REQUIREMENTS")
				, issueSummary,Config.getReqPropValue("JIRA_IMPORTED_NODE")), "Failed to Import JIRA requirement");

		isSuccess = true;
		logger.info("bvt172 is executed successfully.");
	}

	@Test (enabled = testEnabled, priority = 174)
	public void bvt176_MapTestcaseToImportedJiraReqAndViewRemoteLinkInJira() {
		logger.info("Executing bvt176....");
		altID = 176;

		String category = "General Configuration";
		String name = "jira.remote.link.additional.links.req-tc.enabled";
		String value = "true";

		zeNavigator.launchAdministration();
		zeNavigator.launchAdminApps("DefectAdmin");
		zeNavigator.setDefectAdminProperties(category, name, value);
		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);

		CommonUtil.normalWait(3000);
		
		zeNavigator.copyImportedNode("AP-1",Config.getReqPropValue("JIRA_IMPORTED_NODE"));
		List<String> phases = new ArrayList<String>();
		
		phases.add(Config.getReqPropValue("RELEASE_NAME"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		String parentNodeName = Config.getReqPropValue("PHASE_3");
		zeNavigator.pasteCopiedImportedNode(parentNodeName);
		phases.add(Config.getReqPropValue("PHASE_3"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");

		phases.add(Config.getReqPropValue("JIRA_IMPORTED_NODE"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");

		List<String> tcNodes = new ArrayList<String>();
		tcNodes.add(Config.getTCRPropValue("RELEASE_NAME"));
		tcNodes.add(Config.getTCRPropValue("PHASE_1"));
		tcNodes.add(Config.getTCRPropValue("NODE_1"));
		tcNodes.add(Config.getTCRPropValue("SUB_NODE_1"));
		Assert.assertTrue(zeNavigator.mapTestcaseToRequirement(Config.getTCEPropValue("DEFECT1_SUMMARY"), tcNodes, (Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"))), "Failed to Map Testcase");
		zeNavigator.navigateBackToReqList();

		String parentWindowId = CommonUtil.launchNewBrowserWindow(Config.getReqPropValue("JIRA_ISSUE_URL"));
		CommonUtil.normalWait(5000);
		jiraNavigator.doJiraLogin(Config.getValue("JIRA_USERNAME"), Config.getValue("JIRA_PASSWORD"));
		CommonUtil.browserRefresh();
		CommonUtil.normalWait(1000);
		CommonUtil.browserRefresh();
		Assert.assertTrue(jiraNavigator.verifyIssueLink((Config.getTCRPropValue("TESTCASE_WITH_SINGLE_STEP"))), "Unable to verify Remote Link");
		CommonUtil.closeCurrentBrowserWindow();
		CommonUtil.returnToParentWindow(parentWindowId);

		isSuccess = true;
		logger.info("bvt176 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 175)
	public void bvt164_deallocateJiraRequirementMappedToTestcasesWithDefectsFiled(){
		logger.info("Executing bvt164...");
		altID = 164;

		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getReqPropValue("RELEASE_NAME"));
		phases.add(Config.getReqPropValue("PHASE_3"));
		phases.add(Config.getReqPropValue("JIRA_IMPORTED_NODE"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.deallocateRequirement(Config.getTCEPropValue("DEFECT1_SUMMARY")), "Requirement not de-allocated");

		isSuccess = true;
		logger.info("bvt164 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 176)
	public void bvt173_ctrlDnDImportedNodeToReleaseLevel() {
		logger.info("Executing bvt173...");
		altID = 173;

		List<String> phases1 = new ArrayList<String>();
		phases1.add("Imported");
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases1), "Not navigated to nodes.");

		Assert.assertTrue(zeNavigator.copyImportedNodeByDragNDrop(Config.getReqPropValue("JIRA_IMPORTED_NODE")));

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getReqPropValue("RELEASE_NAME"));
		phases.add(Config.getReqPropValue("JIRA_IMPORTED_NODE"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");

		List<String> reqList = new ArrayList<String>();
		reqList.add(Config.getTCEPropValue("DEFECT1_SUMMARY"));
		Assert.assertTrue(zeNavigator.verifyRequirementInSelectedNodeOfRequirementApp(reqList));

		isSuccess = true;
		logger.info("bvt173 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 177)
	public void bvt177_uploadAttachmentToRequirement(){
		logger.info("Executing bvt177...");
		altID = 177;

		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getReqPropValue("RELEASE_NAME"));
		phases.add(Config.getReqPropValue("PHASE_1"));

		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");

		Map<String, String> values = new HashMap<String, String>();
		values.put("ATTACHMENT", Config.getTCRPropValue("TESTCASE_ATTACHMENT"));

		Assert.assertTrue(zeNavigator.modifyRequirement("Untitled requirement", values, null),"Failed to add attachment to Requirement");

		isSuccess = true;
		logger.info("bvt177 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 178)
	public void bvt178_exportRequirementTraceabilityFromNodeInExcelTest() {
		logger.info("Executing bvt178...");
		altID = 178;
		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getReqPropValue("RELEASE_NAME"));
		phases.add(Config.getReqPropValue("PHASE_1"));

		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		zeNavigator.exportEntireTraceabilityOfSelectedRequirementTreeNode(Config.getReqPropValue("PHASE_1")
				, "Excel", null);

		List<String>  fileNames= CommonUtil.returnFileNames(Config.getValue("EXPORT_FILE_PATH"));
		CommonUtil.renameFile(Config.getValue("EXPORT_FILE_PATH")+"/"+fileNames.get(0), Config.getReqPropValue("EXCEL_TREE_EXPORT_ET_FILENAME"));
		CommonUtil.normalWait(2000);
		List<Integer> ignoreCells = new ArrayList<Integer>();
		ignoreCells.add(4);
		ignoreCells.add(16);

		isSuccess = CommonUtil.compareExcel(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getReqPropValue("EXCEL_TREE_EXPORT_ET_FILENAME")
		, Config.getValue("EXPORT_FILE_PATH")+"/backups/"+Config.getReqPropValue("BACKUP_TREE_EXCEL_ET_TO_COMPARE"),ignoreCells);

		CommonUtil.moveFile(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getReqPropValue("EXCEL_TREE_EXPORT_ET_FILENAME"), Config.getValue("EXPORT_FILE_PATH")+"/delete");

		//Assert.assertTrue(isSuccess, "Exported Excel Data is not correct when compared with expected data");


		isSuccess = true;
		logger.info("bvt178 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 179)
	public void bvt179_exportRequirementTraceabilityFromNodeInSummayTest() {
		logger.info("Executing bvt179...");
		altID = 179;
		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getReqPropValue("RELEASE_NAME"));
		phases.add(Config.getReqPropValue("PHASE_1"));

		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		CommonUtil.normalWait(1000);

		zeNavigator.exportEntireTraceabilityOfSelectedRequirementTreeNode(Config.getReqPropValue("PHASE_1"),
				"Summary", "PDF");

		List<String>  fileNames= CommonUtil.returnFileNames(Config.getValue("EXPORT_FILE_PATH"));
		System.out.println("Summary File Name: " + fileNames.get(0));

		CommonUtil.renameFile(Config.getValue("EXPORT_FILE_PATH")+"/"+fileNames.get(0), Config.getReqPropValue("PDF_EXPORT_TREE_ET_FILENAME"));

		isSuccess = CommonUtil.compareTwoPDFFilesData(Config.getValue("EXPORT_FILE_PATH")+"/backups/"+Config.getReqPropValue("BACKUP_PDF_TREE_ET_TO_COMPARE"),
		Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getReqPropValue("PDF_EXPORT_TREE_ET_FILENAME"));

		CommonUtil.moveFile(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getReqPropValue("PDF_EXPORT_TREE_ET_FILENAME"), Config.getValue("EXPORT_FILE_PATH")+"/delete");

		//Assert.assertTrue(isSuccess, "PDF exported is not matching to expected data");


		isSuccess = true;
		logger.info("bvt179 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 180)
	public void bvt180_exportRequirementTraceabilityFromGridInSummayTest() {
		logger.info("Executing bvt180...");
		altID = 180;
		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getReqPropValue("RELEASE_NAME"));
		phases.add(Config.getReqPropValue("PHASE_1"));

		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");

		zeNavigator.exportEntireTraceablilityOfAllRequirementFromGridOfSelectedTreeNode("Summary", "PDF");

		List<String>  fileNames= CommonUtil.returnFileNames(Config.getValue("EXPORT_FILE_PATH"));
		System.out.println("Summary File Name: " + fileNames.get(0));

		CommonUtil.renameFile(Config.getValue("EXPORT_FILE_PATH")+"/"+fileNames.get(0), Config.getReqPropValue("PDF_EXPORT_GRID_ET_FILENAME"));

		isSuccess = CommonUtil.compareTwoPDFFilesData(Config.getValue("EXPORT_FILE_PATH")+"/backups/"+Config.getReqPropValue("BACKUP_PDF_GRID_ET_TO_COMPARE"),
		Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getReqPropValue("PDF_EXPORT_GRID_ET_FILENAME"));

		CommonUtil.moveFile(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getReqPropValue("PDF_EXPORT_GRID_ET_FILENAME"), Config.getValue("EXPORT_FILE_PATH")+"/delete");

		//Assert.assertTrue(isSuccess, "PDF exported is not matching to expected data");


		isSuccess = true;
		logger.info("bvt180 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 181)
	public void bvt181_switchBetweenSearchAndFolderViewInRequirementPageTest(){
		logger.info("Executing bvt181...");
		altID = 181;
		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getReqPropValue("RELEASE_NAME"));
		phases.add(Config.getReqPropValue("PHASE_1"));

		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		Assert.assertTrue(zeNavigator.switchRequirementSearchFolderView("Search"));
		Assert.assertTrue(zeNavigator.switchRequirementSearchFolderView("Folder"));

		isSuccess = true;
		logger.info("bvt181 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 182)
	public void bvt182_quickSearchRequirementByNameTest(){
		logger.info("Executing bvt182...");
		altID = 182;

		zeNavigator.switchRequirementSearchFolderView("Search");
		List<String> reqNames = new ArrayList<String>();
		reqNames.add(0, "Untitled requirement");
		Assert.assertTrue(zeNavigator.searchRequirements("Quick", "Untitled requirement", reqNames));
		zeNavigator.switchRequirementSearchFolderView("Folder");

		isSuccess = true;
		logger.info("bvt182 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 183)
	public void bvt183_exportQuickSearchedRequirementResultsTest() {
		logger.info("Executing bvt183...");
		altID = 183;

		zeNavigator.switchRequirementSearchFolderView("Search");
		Assert.assertTrue(zeNavigator.searchRequirements("Quick", "Untitled requirement", null));
		zeNavigator.exportAllRequirementSearchedResults("Excel", null);

		zeNavigator.exportEntireTraceabilityOfSelectedRequirementTreeNode(Config.getReqPropValue("PHASE_1")
				, "Excel", null);

		List<String>  fileNames= CommonUtil.returnFileNames(Config.getValue("EXPORT_FILE_PATH"));
		CommonUtil.renameFile(Config.getValue("EXPORT_FILE_PATH")+"/"+fileNames.get(0), Config.getReqPropValue("EXCEL_SEARCH_EXPORT_FILENAME"));

		List<Integer> ignoreCells = new ArrayList<Integer>();
		ignoreCells.add(4);
		ignoreCells.add(12);
		ignoreCells.add(14);

		isSuccess = CommonUtil.compareExcel(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getReqPropValue("EXCEL_SEARCH_EXPORT_FILENAME")
		, Config.getValue("EXPORT_FILE_PATH")+"/backups/"+Config.getReqPropValue("BACKUP_EXCEL_SEARCH_EXPORT_FILENAME"),ignoreCells);

		CommonUtil.moveFile(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getReqPropValue("EXCEL_SEARCH_EXPORT_FILENAME"), Config.getValue("EXPORT_FILE_PATH")+"/delete");

		//Assert.assertTrue(isSuccess, "Exported Excel Data is not correct when compared with expected data");
		zeNavigator.switchRequirementSearchFolderView("Folder");

		isSuccess = true;
		logger.info("bvt183 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 184)
	public void bvt184_advanceSearchRequirementByCustomFieldOfTextTypeTest(){
		logger.info("Executing bvt184...");
		altID = 184;

		zeNavigator.switchRequirementSearchFolderView("Search");
		List<String> reqNames = new ArrayList<String>();
		reqNames.add(0, "Untitled requirement");
		zeNavigator.searchRequirements("Advance", "req-sample-custom-1 ~ \"Sample Text\"", reqNames);
		zeNavigator.switchRequirementSearchFolderView("Folder");
		isSuccess = true;
		logger.info("bvt184 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 185)
	public void bvt171_importRequiremnetsFromExcelByDiscriminatorRequirementNameChangeTest() {
		logger.info("Executing bvt171...");
		altID = 171;

		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);

		//zeNavigator.switchRequirementSearchFolderView("Folder");

		Assert.assertTrue(zeNavigator.addRequirementMap("Req Map", "2","By Requirement Name Change", "req map desc", "F", null));
		Assert.assertTrue(zeNavigator.importRequirement("req job", "Req Map", CommonUtil.getCompleteFilePath("\\src\\test\\resources\\export_import\\backups\\requirement-for-import.xlsx")));

		zeNavigator.navigateToRequirementNodeUnderImportedNode("requirement-for-import.xlsx");
		List<String> requirementNames = new ArrayList<String>();
		requirementNames.add("Requirement One");
		requirementNames.add("Requirement Two");
		requirementNames.add("Requirement Three");
		zeNavigator.verifyRequirementInSelectedNodeOfRequirementApp(requirementNames);

		isSuccess = true;
		logger.info("bvt171 is executed successfully.");
	}

	@Test(enabled = testEnabled, priority = 186)
	public void bvt67_mapRequirementToTestcase() {
		logger.info("Executing bvt67...");
		altID = 67;

		String releaseName = "Release 1.0";
		String appName = "Test Repository";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		zeNavigator.navigateToNodes(phases);
		List<String> reqPhases = new ArrayList<String>();
		reqPhases.add(Config.getReqPropValue("RELEASE_NAME"));
		reqPhases.add(Config.getReqPropValue("PHASE_1"));
		CommonUtil.normalWait(1000);
		String reqName = "Untitled requirement";
		zeNavigator.mapRequirementToTestcase((Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP")), reqPhases, reqName);
		zeNavigator.navigateBackToTestcaseList();
		isSuccess = true;
		logger.info("bvt67 is executed successfully.");
	}
	
	@Test(enabled = testEnabled, priority = 187)
	public void bvt280_cloneTestcasewithMapping() {
		logger.info("Executing bvt280...");
		altID = 280;
		String releaseName = "Release 1.0";
		String appName = "Test Repository";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);

		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("RELEASE_NAME"));
		phases.add(Config.getTCRPropValue("PHASE_1"));
		phases.add(Config.getTCRPropValue("NODE_1"));
		phases.add(Config.getTCRPropValue("SUB_NODE_1"));
		zeNavigator.navigateToNodes(phases);
		zeNavigator.cloneTestcase(Config.getTCRPropValue("SUB_NODE_1"), (Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP")), null);
		String coverage = "1 Requirement(s)";
		String testcaseId = zeNavigator.getTestcase(Config.getTCRPropValue("SUB_NODE_1"));
		Map<String, String> values = new HashMap<String, String>();
		values.put("NODE_NAME",Config.getTCRPropValue("SUB_NODE_1"));
		values.put("TESTCASE_ID", testcaseId);
		values.put("TESTCASE_SUMMARY","Clone testcase with the coverage");
		Assert.assertTrue(zeNavigator.modifyTestcase(values), "Not added default testcase successfully.");
		zeNavigator.verifyclonetestcasecoverage(testcaseId, coverage);
		isSuccess = true;
		logger.info("bvt280 is executed successfully.");
	}
	
	

	@Test(enabled = testEnabled, priority = 188)
	public void bvt174_syncParentChildReqNodeWithIssueModifiedInJira() {
		logger.info("Executing bvt174...");
		altID = 174;

		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);

		CommonUtil.normalWait(1000);

		String parentWindowId = CommonUtil.launchNewBrowserWindow(Config.getReqPropValue("JIRA_ISSUE_URL"));
		jiraNavigator.doJiraLogin(Config.getValue("JIRA_USERNAME"), Config.getValue("JIRA_PASSWORD"));
		jiraNavigator.editIssue("AP-1", null, Config.getReqPropValue("RQ_PRIORITY_VALUE"));
		CommonUtil.returnToParentWindow(parentWindowId);

		CommonUtil.normalWait(5000);
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getReqPropValue("RELEASE_NAME"));
		phases.add(Config.getReqPropValue("JIRA_IMPORTED_NODE"));
		zeNavigator.navigateToNodesInRequirements(phases);
		Assert.assertTrue(zeNavigator.performNodeSync(Config.getReqPropValue("JIRA_IMPORTED_NODE")));

		Map<String, String> reqFieldsValues = new HashMap<String, String>();
		reqFieldsValues.put("Priority", Config.getReqPropValue("RQ_PRIORITY_VALUE"));

		zeNavigator.navigateToNodesInRequirements(phases);
		zeNavigator.verifyRequirement(Config.getReqPropValue("IMPORTED_RQ_NAME"), reqFieldsValues);
		zeNavigator.navigateBackToReqList();

		CommonUtil.launchNewBrowserWindow(Config.getReqPropValue("JIRA_ISSUE_URL"));
		jiraNavigator.editIssue("AP-1", null, "Major");
		CommonUtil.returnToParentWindow(parentWindowId);
		isSuccess = true;
		logger.info("bvt174 is executed successfully.");
	}

	@Test (enabled = testEnabled, priority = 189)
	public void bvt314_viewReqTraceabilityReportInFolderView() {
		logger.info("Executing bvt314...");
		altID = 314;
		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);

		CommonUtil.normalWait(1000);
		List<String> phases = new ArrayList<String>();
		phases.add("Release 1.0");
		phases.add(Config.getReqPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");

		Map<String,String> testcaseExecutionDefect1 = new HashMap<String, String>();
		testcaseExecutionDefect1.put("ExeCount", "3");
		testcaseExecutionDefect1.put("DefectCount", "1");
		Map<String,String> testcaseExecutionDefect2 = new HashMap<String, String>();
		testcaseExecutionDefect2.put("ExeCount", "2");

		Map<String, Map<String, String>> ted1 = new HashMap<String, Map<String, String>>();
		ted1.put(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), testcaseExecutionDefect1);
		ted1.put(Config.getTCRPropValue("TESTCASE_WITH_ATTACHMENT"), testcaseExecutionDefect2);

		Map<String, Map<String, Map<String, String>>> reqTraceability = new HashMap<String, Map<String, Map<String, String>>>();
		reqTraceability.put("Untitled requirement", ted1);

		Assert.assertTrue(zeNavigator.verifyTraceability(reqTraceability));

		isSuccess = true;
		logger.info("bvt314 executed successfully.");
	}

	@Test (enabled = testEnabled, priority = 190)
	public void bvt315_quickSearchRequirementAndViewReqTraceability() {
		logger.info("Executing bvt315...");
		altID = 315;

		zeNavigator.switchRequirementSearchFolderView("Search");
		List<String> reqNames = new ArrayList<String>();
		reqNames.add(0, "Untitled requirement");
		Assert.assertTrue(zeNavigator.searchRequirements("Quick", Config.getReqPropValue("Req_ALT_ID1"), reqNames));

		Map<String,String> testcaseExecutionDefect1 = new HashMap<String, String>();
		testcaseExecutionDefect1.put("ExeCount", "3");
		testcaseExecutionDefect1.put("DefectCount", "1");
		Map<String,String> testcaseExecutionDefect2 = new HashMap<String, String>();
		testcaseExecutionDefect2.put("ExeCount", "2");

		Map<String, Map<String, String>> ted1 = new HashMap<String, Map<String, String>>();
		ted1.put(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), testcaseExecutionDefect1);
		ted1.put(Config.getTCRPropValue("TESTCASE_WITH_ATTACHMENT"), testcaseExecutionDefect2);

		Map<String, Map<String, Map<String, String>>> reqTraceability = new HashMap<String, Map<String, Map<String, String>>>();
		reqTraceability.put("Untitled requirement", ted1);

		Assert.assertTrue(zeNavigator.verifyTraceability(reqTraceability));

		isSuccess = true;
		logger.info("bvt315 executed successfully.");
	}

	@Test (enabled = testEnabled, priority = 191)
	public void bvt316_advanceSearchRequirementAndViewReqTraceability() {
		logger.info("Executing bvt316...");
		altID = 316;

		zeNavigator.switchRequirementSearchFolderView("Search");
		List<String> reqNames = new ArrayList<String>();
		reqNames.add(0, "Untitled requirement");
		zeNavigator.searchRequirements("Advance", "altId ~ \"Trace\"", reqNames);

		Map<String,String> testcaseExecutionDefect1 = new HashMap<String, String>();
		testcaseExecutionDefect1.put("ExeCount", "3");
		testcaseExecutionDefect1.put("DefectCount", "1");
		Map<String,String> testcaseExecutionDefect2 = new HashMap<String, String>();
		testcaseExecutionDefect2.put("ExeCount", "2");

		Map<String, Map<String, String>> ted1 = new HashMap<String, Map<String, String>>();
		ted1.put(Config.getTCRPropValue("TESTCASE_WITH_MULTIPLE_STEP"), testcaseExecutionDefect1);
		ted1.put(Config.getTCRPropValue("TESTCASE_WITH_ATTACHMENT"), testcaseExecutionDefect2);

		Map<String, Map<String, Map<String, String>>> reqTraceability = new HashMap<String, Map<String, Map<String, String>>>();
		reqTraceability.put("Untitled requirement", ted1);

		Assert.assertTrue(zeNavigator.verifyTraceability(reqTraceability));

		zeNavigator.switchRequirementSearchFolderView("Folder");

		isSuccess = true;
		logger.info("bvt316 executed successfully.");
	}

	@Test (enabled = testEnabled, priority = 192)
	public void bvt317_exportTraceabilityInFolderAndSearchView() {
		logger.info("Executing bvt317...");
		altID = 317;

		List<String> phases = new ArrayList<String>();
		phases.add("Release 1.0");
		phases.add(Config.getReqPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");

		List<String> reqNames = new ArrayList<String>();
		reqNames.add(0, "Untitled requirement");
		zeNavigator.exportSelectedRequirementTraceabilityInFolderView(reqNames);
		List<String>  fileNames= CommonUtil.returnFileNames(Config.getValue("EXPORT_FILE_PATH"));
		CommonUtil.renameFile(Config.getValue("EXPORT_FILE_PATH")+"/"+fileNames.get(0), Config.getReqPropValue("EXCEL_TRACEABILITY_EXPORT_FILENAME"));
		List<Integer> ignoreCells = new ArrayList<Integer>();
		ignoreCells.add(4);
		ignoreCells.add(12);
		ignoreCells.add(14);
		ignoreCells.add(20);
		//isSuccess = CommonUtil.compareExcel(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getReqPropValue("EXCEL_TRACEABILITY_EXPORT_FILENAME"), Config.getValue("EXPORT_FILE_PATH")+"/backups/"+Config.getReqPropValue("BACKUP_TREE_EXCEL_TO_COMPARE"),ignoreCells);
		CommonUtil.moveFile(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getReqPropValue("EXCEL_TRACEABILITY_EXPORT_FILENAME"), Config.getValue("EXPORT_FILE_PATH")+"/delete");
		//Assert.assertTrue(isSuccess, "Exported Excel Data is not correct when compared with expected data");

		zeNavigator.switchRequirementSearchFolderView("Search");
		zeNavigator.searchRequirements("Advance", "altId ~ \"Trace\"", reqNames);
		zeNavigator.exportAllSearchedRequirementTraceability();
		fileNames= CommonUtil.returnFileNames(Config.getValue("EXPORT_FILE_PATH"));
		CommonUtil.renameFile(Config.getValue("EXPORT_FILE_PATH")+"/"+fileNames.get(0), Config.getReqPropValue("PDF_TRACEABILITY_EXPORT_FILENAME"));
		//isSuccess = CommonUtil.compareExcel(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getReqPropValue("PDF_TRACEABILITY_EXPORT_FILENAME"), Config.getValue("EXPORT_FILE_PATH")+"/backups/"+Config.getReqPropValue("BACKUP_TREE_EXCEL_TO_COMPARE"),ignoreCells);
		CommonUtil.moveFile(Config.getValue("EXPORT_FILE_PATH")+"/"+Config.getReqPropValue("PDF_TRACEABILITY_EXPORT_FILENAME"), Config.getValue("EXPORT_FILE_PATH")+"/delete");
		//Assert.assertTrue(isSuccess, "Exported Excel Data is not correct when compared with expected data");
		zeNavigator.switchRequirementSearchFolderView("Folder");

		isSuccess = true;
		logger.info("bvt317 executed successfully.");
	}
	
	@Test (enabled = testEnabled, priority = 193)
	public void bvt295_clickOnTestcaseCoverageLink() {
		logger.info("Executing bvt295...");
		altID = 295;
		
		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		
	    zeNavigator.launchReleaseApp(appName);

		String phaseName = Config.getReqPropValue("PHASE_5");
		String phaseDescription = phaseName + " description";
		Assert.assertTrue(zeNavigator.createReqPhase(releaseName, phaseName, phaseDescription),
				"Phase not created successfully.");
	
		String requirementId = zeNavigator.addDefaultRequirement(phaseName);
		Assert.assertNotNull(requirementId, "Not added default requirement successfully.");
		
		List<String> testcaseTreeNodes = new ArrayList<String>();
		testcaseTreeNodes.add(0, "Release 1.0");
		testcaseTreeNodes.add(1, Config.getTCRPropValue("PHASE_1"));
		testcaseTreeNodes.add(2, Config.getTCRPropValue("NODE_1"));
		testcaseTreeNodes.add(3, Config.getTCRPropValue("SUB_NODE_1"));

		Assert.assertTrue(zeNavigator.mapTestcaseToRequirement("Untitled requirement", testcaseTreeNodes, "Add attachment to testcase"),"Failed to map testcase to internal requirement");
		
		Assert.assertTrue(zeNavigator.clickonTestcaseCoverageLink("Add attachment to testcase"),"Not navigating to testcase details");
		
		
		isSuccess = true;
		logger.info("bvt295 executed successfully.");
		}
	@Test(enabled = testEnabled, priority = 194)
	public void bvt296_clickOnRequirementCoverageLink() {
		logger.info("Executing bvt296...");
		altID = 296;
		
		String releaseName = "Release 1.0";
		String appName = "Test Repository";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		zeNavigator.launchReleaseApp(appName);
		String phaseName = Config.getTCRPropValue("PHASE_5");
		String phaseDescription = phaseName + " description";
		Assert.assertTrue(zeNavigator.createPhase(releaseName, phaseName, phaseDescription),
				"Phase not created successfully.");
		
		List<String> phases = new ArrayList<String>();
		phases.add(Config.getTCRPropValue("PHASE_5"));
		Assert.assertTrue(zeNavigator.navigateToNodes(phases), "Not navigated to nodes.");
		String nodeName = Config.getTCRPropValue("PHASE_5");
		String testcaseId = zeNavigator.addDefaultTestcase(nodeName);
		Assert.assertNotNull(testcaseId, "Not added default testcase successfully.");
		List<String> reqPhases = new ArrayList<String>();
		reqPhases.add(Config.getReqPropValue("RELEASE_NAME"));
		reqPhases.add(Config.getReqPropValue("PHASE_1"));
		String reqName = "Untitled requirement";
		zeNavigator.mapRequirementToTestcase("Untitled", reqPhases, reqName);
		
		Assert.assertTrue(zeNavigator.clickonReqCoverageLink("Untitled requirement"),"Not navigating to requirement details");
		
		isSuccess = true;
		logger.info("bvt296 is executed successfully.");
		}
	
	@Test(enabled=testEnabled,priority=195)
	public void bvt_cloneRequirementwithMapping() {
		logger.info("Executing bvt280...");
		altID = 280;
		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		//Assert.assertTrue(zeNavigator.launchReleaseApp(appName), "Not navigated to : " + appName);
		zeNavigator.launchReleaseApp(appName);
		
		List<String> phases = new ArrayList<String>();
		phases.add("Release 1.0");
		phases.add(Config.getReqPropValue("PHASE_1"));
		Assert.assertTrue(zeNavigator.navigateToNodesInRequirements(phases), "Not navigated to nodes.");
		zeNavigator.cloneRequirement("Req 1");
		isSuccess = true;
		logger.info("bvt is executed successfully.");

	}
	
	@Test(enabled=testEnabled,priority=196)
	public void cretaeDuplicatePhase()
	{
		String releaseName = "Release 1.0";
		String appName = "Requirements";
		zeNavigator.selectProject("Sample Project");
		Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
		//Assert.assertTrue(zeNavigator.launchReleaseApp(appName), "Not navigated to : " + appName);
		zeNavigator.launchReleaseApp(appName);

		String phaseName = Config.getReqPropValue("PHASE_5");
		String phaseDescription = phaseName + " description";
		Assert.assertTrue(zeNavigator.dupicateRequiremnetNode(releaseName, phaseName, phaseDescription),
				"Phase created successfully.");
		isSuccess = true;
		logger.info("bvt is executed successfully.");
		
	}

	@BeforeMethod
	public void beforeMethod() {
		isSuccess = false;
	}

	@AfterMethod
	public void afterMethod() {
		baseAfterMethod();
		if(!isSuccess){
			zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
			String releaseName = "Release 1.0";
			String appName = "Requirements";
			zeNavigator.selectProject("Sample Project");
			Assert.assertTrue(zeNavigator.selectReleaseDropDown(releaseName), "Not selected release.");
			zeNavigator.launchReleaseApp(appName);
		}
	}

	@BeforeClass
	public void beforeClass() {
		zeNavigator.doLogin(Config.getValue("ZE_MANAGER_USERNAME"), Config.getValue("ZE_MANAGER_PASSWORD"));
	}

	@AfterClass
	public void afterClass() {
		zeNavigator.logout();
	}
}
